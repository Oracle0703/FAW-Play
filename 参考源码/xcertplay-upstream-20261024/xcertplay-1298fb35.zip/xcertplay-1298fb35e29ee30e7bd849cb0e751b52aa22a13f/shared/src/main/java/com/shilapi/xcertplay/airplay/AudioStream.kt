package com.shilapi.xcertplay.airplay

import java.io.Closeable
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

enum class AudioCodecKind { AAC_LC, AAC_ELD, OPUS, LPCM }

data class AudioFormat(
    val codec: AudioCodecKind,
    val sampleRate: Int,
    val channels: Int,
    val payloadType: Int,
    val audioType: String = "media",
    val framesPerPacket: Int? = null,
)

/**
 * Binds the RTP data and RTCP control UDP ports for one CarPlay audio stream.
 *
 * Wire layout follows LIVI `livi_audio_stream`: one RTP packet per datagram, a 12-byte header,
 * ciphertext, a 16-byte tag, then an 8-byte little-endian nonce. The header's last eight bytes
 * (timestamp + SSRC) are the AEAD associated data.
 */
class AudioStream(
    private val key: ByteArray,
    private val streamType: Int = -1,
) : Closeable {
    interface Listener {
        fun onStarted(firstSample: Int) {}
        fun onRtp(rtp: ByteArray, sample: Int) {}
        fun onPacket(
            wire: ByteArray,
            rtp: ByteArray?,
            sample: Int?,
            error: Throwable?,
        ) {}
    }

    private val closed = AtomicBoolean(false)
    private val receivedPackets = AtomicInteger()
    private val decryptedPackets = AtomicInteger()
    private val authenticationFailures = AtomicInteger()
    private var dataSocket: DatagramSocket? = null
    private var controlSocket: DatagramSocket? = null
    private var dataThread: Thread? = null
    private var controlThread: Thread? = null
    private var started = false

    fun listen(listener: Listener): Pair<Int, Int> {
        val data = bindAnyPort()
        val control = bindAnyPort()
        dataSocket = data
        controlSocket = control
        dataThread = Thread({ runData(data, listener) }, "airplay-audio-rx").apply {
            isDaemon = true
            start()
        }
        controlThread = Thread({ runControl(control) }, "airplay-rtcp-rx").apply {
            isDaemon = true
            start()
        }
        return data.localPort to control.localPort
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        dataSocket?.close()
        controlSocket?.close()
        dataThread?.interrupt()
        controlThread?.interrupt()
    }

    private fun runData(socket: DatagramSocket, listener: Listener) {
        val buffer = ByteArray(DATAGRAM_BYTES)
        while (!closed.get()) {
            val packet = DatagramPacket(buffer, buffer.size)
            try {
                socket.receive(packet)
            } catch (_: Exception) {
                if (closed.get()) return else continue
            }
            val wire = packet.data.copyOf(packet.length)
            val packetNumber = receivedPackets.incrementAndGet()
            if (wire.size < RTP_HEADER_LEN + TAIL_LEN) {
                if (packetNumber == 1) {
                    android.util.Log.w(
                        TAG,
                        "audio stream type=$streamType short packet bytes=${wire.size}",
                    )
                }
                listener.onPacket(
                    wire,
                    null,
                    null,
                    IOException("audio packet shorter than RTP header plus tail"),
                )
                continue
            }

            val aad = wire.copyOfRange(4, RTP_HEADER_LEN)
            val sealedEnd = wire.size - NONCE_LEN
            val sealed = wire.copyOfRange(RTP_HEADER_LEN, sealedEnd)
            val shortNonce = wire.copyOfRange(sealedEnd, wire.size)
            val nonce = ByteArray(12).also { shortNonce.copyInto(it, 4) }
            val sample = readU32Be(wire, 4)

            val payload = try {
                AirPlayCrypto.chachaOpen(key, nonce, sealed, aad)
            } catch (error: Exception) {
                val failureNumber = authenticationFailures.incrementAndGet()
                if (failureNumber == 1) {
                    android.util.Log.w(
                        TAG,
                        "audio stream type=$streamType first decrypt failure " +
                            "wire=${wire.toHexString()}",
                        error,
                    )
                }
                listener.onPacket(wire, null, sample, error)
                continue
            }
            val rtp = wire.copyOf(RTP_HEADER_LEN) + payload
            val decryptedNumber = decryptedPackets.incrementAndGet()
            if (decryptedNumber <= FIRST_PACKET_LOG_COUNT) {
                android.util.Log.i(
                    TAG,
                    "audio stream type=$streamType packet=$decryptedNumber sample=$sample " +
                        "wireBytes=${wire.size} payloadBytes=${payload.size} " +
                        "payloadHead=${payload.copyOf(minOf(payload.size, 16)).toHexString()}",
                )
            } else if (decryptedNumber % PACKET_LOG_INTERVAL == 0) {
                android.util.Log.i(
                    TAG,
                    "audio stream type=$streamType decrypted=$decryptedNumber " +
                        "authFailures=${authenticationFailures.get()}",
                )
            }
            listener.onPacket(wire, rtp, sample, null)
            if (!started) {
                started = true
                listener.onStarted(sample)
            }
            listener.onRtp(rtp, sample)
        }
    }

    private fun runControl(socket: DatagramSocket) {
        val buffer = ByteArray(DATAGRAM_BYTES)
        while (!closed.get()) {
            try {
                socket.receive(DatagramPacket(buffer, buffer.size))
            } catch (_: Exception) {
                if (closed.get()) return
            }
        }
    }

    private fun bindAnyPort(): DatagramSocket {
        val socket = DatagramSocket(null)
        socket.reuseAddress = true
        socket.bind(InetSocketAddress(InetAddress.getByName("::"), 0))
        return socket
    }

    private fun readU32Be(source: ByteArray, offset: Int): Int =
        ((source[offset].toInt() and 0xff) shl 24) or
            ((source[offset + 1].toInt() and 0xff) shl 16) or
            ((source[offset + 2].toInt() and 0xff) shl 8) or
            (source[offset + 3].toInt() and 0xff)

    private companion object {
        const val TAG = "xcertplay-usb"
        const val DATAGRAM_BYTES = 4_096
        const val RTP_HEADER_LEN = 12
        const val TAG_LEN = 16
        const val NONCE_LEN = 8
        const val TAIL_LEN = TAG_LEN + NONCE_LEN
        const val FIRST_PACKET_LOG_COUNT = 3
        const val PACKET_LOG_INTERVAL = 100
    }
}

/** Maps the phone's negotiated audioFormat bits to a decode/render format. */
object AudioStreamCodec {
    /** Opus input uses the selected rate, and its RTP timestamp clock follows the same rate. */
    fun opusCaptureRate(bits: Long): Int = when {
        bits and 0x40000000L != 0L -> 48_000
        bits and 0x20000000L != 0L -> 24_000
        bits and 0x10000000L != 0L -> 16_000
        else -> 48_000
    }

    fun fromFormatBits(bits: Long, payloadType: Int, audioType: String = "media"): AudioFormat {
        val isAacLc = bits == AAC_LC_44K_STEREO || bits == AAC_LC_48K_STEREO
        val isOpus = bits == 0x10000000L || bits == 0x20000000L || bits == 0x40000000L
        val pcm = PCM_FORMAT[bits]
        val eld = ELD_FORMAT[bits]
        return when {
            eld != null -> AudioFormat(AudioCodecKind.AAC_ELD, eld.first, eld.second, payloadType, audioType)
            isOpus -> AudioFormat(AudioCodecKind.OPUS, 48_000, 1, payloadType, audioType)
            isAacLc -> AudioFormat(
                AudioCodecKind.AAC_LC,
                if ((bits and AAC_LC_48K_STEREO) != 0L) 48_000 else 44_100,
                2,
                payloadType,
                audioType,
            )
            pcm != null -> AudioFormat(AudioCodecKind.LPCM, pcm.first, pcm.second, payloadType, audioType)
            else -> AudioFormat(AudioCodecKind.LPCM, 44_100, 2, payloadType, audioType)
        }
    }

    private const val AAC_LC_44K_STEREO = 0x400000L
    private const val AAC_LC_48K_STEREO = 0x800000L
    private val ELD_FORMAT = mapOf(
        (1L shl 24) to (44_100 to 2),
        (1L shl 25) to (48_000 to 2),
        (1L shl 26) to (16_000 to 1),
        (1L shl 27) to (24_000 to 1),
        (1L shl 31) to (44_100 to 1),
        (1L shl 32) to (48_000 to 1),
        (1L shl 43) to (32_000 to 1),
    )

    private val PCM_FORMAT = mapOf(
        0x4L to (8_000 to 1),
        0x8L to (8_000 to 2),
        0x10L to (16_000 to 1),
        0x20L to (16_000 to 2),
        0x40L to (24_000 to 1),
        0x80L to (24_000 to 2),
        0x100L to (32_000 to 1),
        0x200L to (32_000 to 2),
        0x400L to (44_100 to 1),
        0x800L to (44_100 to 2),
        0x4000L to (48_000 to 1),
        0x8000L to (48_000 to 2),
    )
}
