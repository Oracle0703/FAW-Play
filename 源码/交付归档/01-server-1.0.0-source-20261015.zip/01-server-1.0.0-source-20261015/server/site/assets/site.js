"use strict";
(() => {
  const downloadsApi = FawApi.downloads;
  const appId = downloadsApi.appId;
  const packages = { app: null, firmware: null };
  const byId = id => document.getElementById(id);
  let requestGeneration = 0;
  let toastTimer;
  const sizeLabel = bytes => bytes >= 1e9 ? `${(bytes / 1e9).toFixed(2)} GB` : `${(bytes / 1e6).toFixed(2)} MB`;
  const validText = (text, maximum) => typeof text === "string" && text.length > 0 && text.length <= maximum;

  function validatePackage(value, kind, live = false) {
    if (!value || !validText(value.versionName, 100) || !Number.isSafeInteger(value.sizeBytes) || value.sizeBytes <= 0
      || !/^[a-f0-9]{64}$/.test(value.sha256) || typeof value.releaseNotes !== "string" || value.releaseNotes.length > 20000) {
      throw new Error("Invalid package metadata");
    }
    if (kind === "app" && (value.packageName !== appId || !Number.isSafeInteger(value.versionCode) || value.versionCode <= 0
      || !Number.isSafeInteger(value.minSdk) || value.minSdk < 28 || value.minSdk > 100 || value.sizeBytes > 536870912)) {
      throw new Error("Invalid app metadata");
    }
    if (kind === "firmware" && !validText(value.model, 100)) throw new Error("Invalid firmware model");
    const file = { ...value, downloadUrl: null };
    if (live) {
      const expected = downloadsApi.artifact(value.sha256);
      if (value.schema !== 1 || value.downloadPath !== expected || !/^[a-f0-9]{64}$/.test(value.signingCertSha256)) throw new Error("Invalid update path");
      file.downloadUrl = expected;
      file.fileName = `FAW-Play-${value.versionCode}.apk`;
    } else if (value.downloadUrl != null) {
      // Only explicitly staged, same-origin files can become clickable downloads.
      if (!validText(value.downloadUrl, 512)) throw new Error("Invalid download URL");
      const url = new URL(value.downloadUrl, document.baseURI);
      const folder = new URL("./downloads/", document.baseURI).pathname;
      const name = url.pathname.slice(folder.length);
      const extension = kind === "app" ? ".apk" : ".zip";
      if (url.origin !== location.origin || !url.pathname.startsWith(folder) || !/^[A-Za-z0-9_.-]+$/.test(name)
        || !name.endsWith(extension) || url.search || url.hash || url.username || url.password) throw new Error("Invalid download URL");
      file.downloadUrl = url.href;
    }
    return file;
  }

  function parseUpdate(envelope) {
    if (!envelope || !validText(envelope.manifest, 100000) || !/^[A-Za-z0-9_-]+$/.test(envelope.manifest)
      || !validText(envelope.signature, 256) || !/^[A-Za-z0-9_-]+$/.test(envelope.signature)) throw new Error("Invalid update envelope");
    const base64 = envelope.manifest.replace(/-/g, "+").replace(/_/g, "/");
    const bytes = Uint8Array.from(atob(base64 + "=".repeat((4 - base64.length % 4) % 4)), ch => ch.charCodeAt(0));
    return validatePackage(JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes)), "app", true);
  }

  function setDownload(link, file) {
    const enabled = Boolean(file && file.downloadUrl);
    link.setAttribute("aria-disabled", String(!enabled));
    if (enabled) {
      link.href = file.downloadUrl;
      link.setAttribute("download", file.fileName || "");
      link.removeAttribute("tabindex");
    } else { link.removeAttribute("href"); link.removeAttribute("download"); link.setAttribute("tabindex", "-1"); }
  }

  function render(kind) {
    const file = packages[kind];
    byId(`${kind}-version`).textContent = file ? file.versionName : "暂无已发布版本";
    byId(`${kind}-size`).textContent = file ? sizeLabel(file.sizeBytes) : "—";
    setDownload(byId(`${kind}-download`), file);
    byId(`${kind}-download`).querySelector("span").textContent = file && file.downloadUrl
      ? (kind === "app" ? "下载 App 安装包" : "下载完整升级包") : "下载暂未开放";
    if (kind === "app") {
      byId("app-tag").textContent = file ? (file.live ? "当前发布版本" : "本地交付版本") : "车机 App";
      const android = { 28: "9.0", 29: "10", 30: "11", 31: "12", 32: "12L", 33: "13", 34: "14", 35: "15", 36: "16" };
      byId("app-system").textContent = file ? (android[file.minSdk] ? `Android ${android[file.minSdk]}+` : `Android API ${file.minSdk}+`) : "Android 9.0+";
    } else { byId("firmware-model").textContent = file ? file.model : "—"; }
    document.querySelector(`[data-copy-hash="${kind}"]`).disabled = !file;
  }

  async function loadDownloads() {
    const generation = ++requestGeneration;
    const refresh = byId("refresh-downloads");
    refresh.disabled = true;
    byId("download-status").textContent = "正在获取下载信息…";
    const [catalogResult, updateResult] = await Promise.allSettled([downloadsApi.catalog(), downloadsApi.update()]);
    if (generation !== requestGeneration) return;
    packages.app = null;
    packages.firmware = null;
    let metadataError = false;
    if (catalogResult.status === "fulfilled" && catalogResult.value) {
      const catalog = catalogResult.value;
      if (catalog.schema === 1) {
        for (const kind of ["app", "firmware"]) {
          if (catalog[kind]) {
            try { packages[kind] = validatePackage(catalog[kind], kind); } catch (_) { metadataError = true; }
          }
        }
      } else { metadataError = true; }
    } else if (catalogResult.status === "rejected") { metadataError = true; }
    if (updateResult.status === "fulfilled" && updateResult.value) {
      try { packages.app = { ...parseUpdate(updateResult.value), live: true }; } catch (_) { metadataError = true; }
    } else if (updateResult.status === "rejected" && !packages.app) { metadataError = true; }
    render("app"); render("firmware");
    const available = ["app", "firmware"].filter(kind => packages[kind]?.downloadUrl);
    byId("download-status").textContent = available.length === 2 ? "App 安装包与完整固件已准备就绪。"
      : available.length === 1 ? `${available[0] === "app" ? "App 安装包" : "车机固件"}可下载，其他文件暂未开放。`
      : metadataError ? "暂时无法获取完整下载信息，请稍后刷新。" : "暂无开放下载的文件，发布后将在这里显示。";
    refresh.disabled = false;
  }

  function filter(kind) {
    document.querySelectorAll("[data-filter]").forEach(button => button.setAttribute("aria-pressed", String(button.dataset.filter === kind)));
    document.querySelectorAll("[data-download-kind]").forEach(card => { card.hidden = kind !== "all" && card.dataset.downloadKind !== kind; });
  }
  function openDetails(kind) {
    const file = packages[kind];
    byId("dialog-kind").textContent = kind === "app" ? "APP / RELEASE NOTES" : "FIRMWARE / PACKAGE INFO";
    byId("dialog-title").textContent = kind === "app" ? "FAW Play 更新说明" : "HS5 升级包说明";
    byId("dialog-meta").textContent = file ? `${file.versionName} · ${sizeLabel(file.sizeBytes)}` : "暂无已发布版本";
    byId("dialog-notes").textContent = file?.releaseNotes || "下载信息暂未开放，请稍后刷新。";
    byId("dialog-hash").textContent = file?.sha256 || "—";
    setDownload(byId("dialog-download"), file);
    byId("dialog-download").textContent = file?.downloadUrl ? "下载文件 ↓" : "下载暂未开放";
    byId("package-dialog").showModal();
  }
  function toast(message) {
    byId("toast").textContent = message;
    byId("toast").hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { byId("toast").hidden = true; }, 3500);
  }
  document.querySelectorAll("[data-filter]").forEach(button => button.addEventListener("click", () => filter(button.dataset.filter)));
  document.querySelectorAll("[data-filter-link]").forEach(link => link.addEventListener("click", () => filter(link.dataset.filterLink)));
  document.querySelectorAll("[data-open-details]").forEach(button => button.addEventListener("click", () => openDetails(button.dataset.openDetails)));
  document.querySelectorAll("[data-copy-hash]").forEach(button => button.addEventListener("click", async () => {
    const kind = button.dataset.copyHash;
    if (!packages[kind]) return;
    try { await navigator.clipboard.writeText(packages[kind].sha256); toast("SHA-256 已复制"); }
    catch (_) { openDetails(kind); toast("请在说明中选择校验值，手动复制"); }
  }));
  byId("refresh-downloads").addEventListener("click", loadDownloads);
  byId("dialog-close").addEventListener("click", () => byId("package-dialog").close());
  byId("package-dialog").addEventListener("click", event => {
    if (event.target === byId("package-dialog")) {
      const bounds = event.target.getBoundingClientRect();
      if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) event.target.close();
    }
  });
  loadDownloads();
})();
