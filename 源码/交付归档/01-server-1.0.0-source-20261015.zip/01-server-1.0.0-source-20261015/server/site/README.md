# FAW Play 官网源码

原生 HTML、CSS、JavaScript，支持与 App 一致的浅色、深色及跟随系统主题。

App 优先使用同源发布更新接口；`downloads.json` 只在实际文件准备好后开放本地下载。二进制文件保存在 Git 仓库外，不写入这里。

构建、预览、JAR 集成与静态文件托管说明见 [官网说明](../docs/WEBSITE.md)。
