rootProject.name = "faw-play-authorization"
