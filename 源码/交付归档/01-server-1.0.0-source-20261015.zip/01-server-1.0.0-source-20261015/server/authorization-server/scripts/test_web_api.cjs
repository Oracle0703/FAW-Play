'use strict';
const assert = require('node:assert/strict');
const {test} = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const apiSource = fs.readFileSync(path.join(__dirname, '../../site/assets/api.js'), 'utf8');
const activationSource = fs.readFileSync(path.join(__dirname, '../src/main/resources/static/activate/activate.js'), 'utf8');

function fixture(respond, additions = {}) {
  const requests = [], timers = new Map(), cleared = [];
  let timerId = 0;
  const context = vm.createContext({AbortController, Error, TypeError, SyntaxError, URLSearchParams,
    setTimeout(callback, delay) { const id = ++timerId; timers.set(id, {callback, delay}); return id; },
    clearTimeout(id) { cleared.push(id); timers.delete(id); },
    fetch: async (url, options) => { requests.push({url, options}); return respond(url, options); }, ...additions});
  vm.runInContext(apiSource, context);
  return {api: context.FawApi, context, requests, timers, cleared};
}
const reply = (body, status = 200) => new Response(JSON.stringify(body), {status});

test('admin and activation credentials stay in headers or JSON bodies with redirects disabled', async () => {
  const page = fixture(() => reply({}));
  await page.api.admin.searchCode('access-secret', 'FAW-private-code');
  await page.api.activation.approve('browser-secret', 'FAW-private-code');
  await page.api.login.refresh('refresh-secret');
  for (const {url, options} of page.requests) {
    assert.ok(!/secret|private/.test(url));
    assert.equal(options.method, 'POST');
    assert.equal(options.credentials, 'omit');
    assert.equal(options.redirect, 'error');
    assert.equal(options.cache, 'no-store');
    assert.equal(options.headers['Content-Type'], 'application/json');
  }
  assert.equal(page.requests[0].options.headers.Authorization, 'Bearer access-secret');
  assert.equal(page.requests[1].options.headers.Authorization, undefined);
  assert.equal(JSON.parse(page.requests[1].options.body).browserToken, 'browser-secret');
  assert.equal(JSON.parse(page.requests[2].options.body).refreshToken, 'refresh-secret');
  assert.equal(page.timers.size, 0);
});

test('encoded identifiers cannot change admin path segments and update operations retain their verbs', async () => {
  const page = fixture(() => reply({}));
  await page.api.admin.updateLicense('token', 'license/one', {deviceLimit: 2});
  await page.api.admin.device('token', 'license/one', 'device/two', 'note', {note: '备注'});
  await page.api.admin.deleteLicense('token', 'license/one');
  assert.equal(page.requests[0].url, '/v1/admin/licenses/license%2Fone');
  assert.equal(page.requests[1].url, '/v1/admin/licenses/license%2Fone/devices/device%2Ftwo/note');
  assert.deepEqual(page.requests.map(r => r.options.method), ['PUT', 'PUT', 'DELETE']);
  assert.equal(page.requests[2].options.body, undefined);
});

test('missing public downloads stay optional while activation retains terminal HTTP status', async () => {
  const page = fixture(url => url.startsWith('/v1/activation/') ? reply({error: 'ACTIVATION_EXPIRED'}, 410) : reply({}, 404));
  assert.equal(await page.api.downloads.update(), null);
  await assert.rejects(page.api.activation.details('browser-secret'), error => error.code === 'ACTIVATION_EXPIRED' && error.status === 410);
  assert.equal(page.requests[0].options.credentials, 'same-origin');
  assert.equal(page.timers.size, 0);
});

test('download metadata limits reject oversized and malformed responses and release timers', async () => {
  const page = fixture(url => new Response(url === './downloads.json' ? 'x'.repeat(131073) : 'not-json'));
  await assert.rejects(page.api.downloads.catalog(), error => error.code === 'RESPONSE_TOO_LARGE');
  await assert.rejects(page.api.downloads.update(), {name: 'SyntaxError'});
  assert.equal(page.timers.size, 0);
});

test('activation timeout aborts the underlying request and is cleared after failure', async () => {
  const page = fixture((url, {signal}) => new Promise((resolve, reject) => {
    signal.addEventListener('abort', () => reject(Object.assign(new Error('aborted'), {name: 'AbortError'})));
  }));
  const pending = page.api.activation.details('browser-secret');
  const timer = [...page.timers.values()][0];
  assert.equal(timer.delay, 15000);
  timer.callback();
  await assert.rejects(pending, {name: 'AbortError'});
  assert.equal(page.requests[0].options.signal.aborted, true);
  assert.equal(page.timers.size, 0);
});

test('APK upload preserves multipart data and progress, and its handle cancels the request', async () => {
  let xhr;
  class Upload {
    constructor() { xhr = this; this.headers = {}; this.upload = {}; }
    open(method, url) { this.method = method; this.url = url; }
    setRequestHeader(name, value) { this.headers[name] = value; }
    send(body) { this.body = body; }
    abort() { this.onabort(); }
  }
  const page = fixture(() => { throw new Error('Unexpected fetch'); }, {XMLHttpRequest: Upload});
  const progress = [], body = new FormData();
  body.append('releaseNotes', '发布说明');
  const upload = page.api.admin.publishUpdate('private-token', 'package/id', body, event => progress.push(event.loaded));
  assert.equal(xhr.method, 'POST');
  assert.equal(xhr.url, '/v1/admin/updates/package%2Fid/stable');
  assert.equal(xhr.headers.Authorization, 'Bearer private-token');
  assert.equal(xhr.headers['Content-Type'], undefined);
  assert.equal(xhr.timeout, 900000);
  assert.equal(xhr.body, body);
  xhr.upload.onprogress({loaded: 10, total: 20, lengthComputable: true});
  assert.deepEqual(progress, [10]);
  upload.abort();
  await assert.rejects(upload.done, error => error.code === 'UPLOAD_ABORTED');
});

function activationFixture(approveReply) {
  const elements = new Map(), token = 'a'.repeat(43), historyPaths = [];
  const getElementById = id => {
    if (!elements.has(id)) elements.set(id, {value: '', disabled: true, checked: false, textContent: '', events: {},
      addEventListener(name, action) { this.events[name] = action; }});
    return elements.get(id);
  };
  const page = fixture(url => url.endsWith('/details')
    ? reply({deviceName: 'HS5', deviceFingerprint: 'AABB', status: 'pending', expiresAt: Math.floor(Date.now() / 1000) + 300})
    : approveReply(), {document: {getElementById}, location: {hash: '#token=' + token, pathname: '/activate/'},
    history: {replaceState(state, title, pathname) { historyPaths.push(pathname); }}});
  vm.runInContext(activationSource, page.context);
  return {...page, element: getElementById, historyPaths,
    settle: async () => { for (let i = 0; i < 30; i++) await Promise.resolve(); },
    submit: () => getElementById('activation-form').events.submit({preventDefault() {}})};
}

test('activation strips the URL token, clears successful codes, and prevents repeat submissions', async () => {
  const page = activationFixture(() => reply({status: 'activated'}));
  await page.settle();
  assert.deepEqual(page.historyPaths, ['/activate/']);
  page.element('code').value = ' FAW-private-code ';
  page.element('confirmed').checked = true;
  await page.submit();
  assert.equal(page.element('code').value, '');
  assert.equal(page.element('submit').disabled, true);
  await page.submit();
  assert.equal(page.requests.length, 2);
  assert.equal(JSON.parse(page.requests[1].options.body).activationCode, 'FAW-private-code');
});

test('expired activation permanently locks controls, while an invalid code permits retry', async () => {
  for (const [code, status, terminal] of [['ACTIVATION_EXPIRED', 410, true], ['INVALID_ACTIVATION_CODE', 400, false], ['ACTIVATION_ATTEMPTS', 400, true]]) {
    const page = activationFixture(() => reply({error: code}, status));
    await page.settle();
    page.element('code').value = 'FAW-code';
    page.element('confirmed').checked = true;
    await page.submit();
    assert.equal(page.element('submit').disabled, terminal);
    await page.submit();
    assert.equal(page.requests.length, terminal ? 2 : 3);
  }
});
