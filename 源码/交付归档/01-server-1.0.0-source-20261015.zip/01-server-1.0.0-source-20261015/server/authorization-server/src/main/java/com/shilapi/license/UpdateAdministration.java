package com.shilapi.license;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
class UpdateAdministration {
    private final UpdatePublisher publisher;
    private final LicenseService licenses;
    UpdateAdministration(UpdatePublisher publisher, LicenseService licenses) { this.publisher = publisher; this.licenses = licenses; }
    @GetMapping("/v1/admin/updates") List<UpdatePublisher.App> list() { return publisher.applications(); }
    @PostMapping(value="/v1/admin/updates/{appId}/stable", consumes=MediaType.MULTIPART_FORM_DATA_VALUE)
    JsonNode publish(@AuthenticationPrincipal Jwt jwt, @PathVariable String appId, @RequestPart("apk") MultipartFile apk,
                     @RequestParam(defaultValue="") String releaseNotes) {
        JsonNode result = publisher.publish(appId, apk, releaseNotes);
        licenses.audit(jwt.getSubject(), "PUBLISH_UPDATE", appId + ":" + result.path("versionCode").asInt() + ":" + result.path("sha256").asText());
        return result;
    }
}
