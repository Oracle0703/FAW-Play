package com.shilapi.license;

import java.io.*;
import java.nio.channels.Channels;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

@RestController
class UpdateController {
    private final UpdateService service;
    UpdateController(UpdateService service) { this.service = service; }
    @GetMapping("/v1/updates/{appId}/stable")
    ResponseEntity<UpdateService.SignedManifest> manifest(@PathVariable String appId) {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(service.manifest(appId));
    }
    @GetMapping("/v1/updates/{appId}/stable/artifacts/{sha256}.apk")
    ResponseEntity<StreamingResponseBody> artifact(@PathVariable String appId, @PathVariable String sha256) {
        UpdateService.Artifact artifact = service.artifact(appId, sha256);
        StreamingResponseBody body = output -> {
            try (artifact; InputStream input = Channels.newInputStream(artifact.channel())) {
                byte[] buffer = new byte[64 * 1024];
                long remaining = artifact.size();
                while (remaining > 0) {
                    int count = input.read(buffer, 0, (int) Math.min(buffer.length, remaining));
                    if (count == -1) throw new EOFException("Update artifact changed during transfer");
                    output.write(buffer, 0, count); remaining -= count;
                }
            }
        };
        return ResponseEntity.ok().contentType(MediaType.parseMediaType("application/vnd.android.package-archive"))
            .contentLength(artifact.size()).header(HttpHeaders.CACHE_CONTROL, "public, max-age=31536000, immutable").body(body);
    }
}
