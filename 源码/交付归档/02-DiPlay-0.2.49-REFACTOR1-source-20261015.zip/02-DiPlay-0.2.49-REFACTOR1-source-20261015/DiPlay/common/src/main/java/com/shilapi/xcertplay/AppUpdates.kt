package com.shilapi.xcertplay

import android.Manifest
import android.app.PendingIntent
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.AtomicFile
import android.widget.Toast
import com.shilapi.xcertplay.licensing.LicensePackageSignature
import com.shilapi.xcertplay.licensing.LicenseVerifier
import com.shilapi.xcertplay.licensing.ProductLicense
import com.shilapi.xcertplay.shared.BuildConfig
import com.shilapi.xcertplay.updates.*
import java.io.File
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

data class UpdateInstallCapability(val silent: Boolean, val message: String, val vendor: Boolean = false)

internal object AppUpdates {
    const val INSTALL_ACTION = "com.shilapi.xcertplay.UPDATE_INSTALL_RESULT"
    private val executor = Executors.newSingleThreadExecutor { task -> Thread(task, "app-updates").apply { isDaemon = true } }
    private val checking = AtomicBoolean(false)
    private val installing = AtomicBoolean(false)
    @Volatile var confirmationIntent: Intent? = null
        private set

    fun configurationProblem() = ProductLicense.configurationProblem()
    fun directory(context: Context) = File(context.cacheDir, "app-updates")
    private fun prefs(context: Context) = context.getSharedPreferences("faw_app_updates", Context.MODE_PRIVATE)
    private fun envelopeFile(context: Context) = AtomicFile(File(directory(context), "manifest-envelope.json"))
    fun currentVersion(context: Context): Long = context.packageManager.getPackageInfo(context.packageName, 0).longVersionCode

    fun capability(context: Context): UpdateInstallCapability {
        val permission = context.checkSelfPermission(Manifest.permission.INSTALL_PACKAGES) == PackageManager.PERMISSION_GRANTED
        val owner = runCatching { context.getSystemService(DevicePolicyManager::class.java)?.isDeviceOwnerApp(context.packageName) == true }.getOrDefault(false)
        return when {
            permission -> UpdateInstallCapability(true, "已检测到系统安装权限，可请求静默更新。")
            owner -> UpdateInstallCapability(true, "已检测到设备所有者权限，可请求静默更新。")
            else -> {
                val detection = FawVendorInstaller.inspect(context)
                when {
                    detection.available -> UpdateInstallCapability(true, detection.message, true)
                    Build.DEVICE == "t1c_acrn" || Build.MODEL == "HONG QI" ->
                        UpdateInstallCapability(false, "暂不能静默更新：${detection.message}")
                    else -> UpdateInstallCapability(false, "当前未检测到静默安装权限；可通过系统确认安装。")
                }
            }
        }
    }

    fun check(context: Context): UpdateManifest? {
        configurationProblem()?.let { throw UpdateException(it) }
        LicensePackageSignature.verify(context)
        return UpdateTransport.fetch(context.packageName, BuildConfig.FAW_LICENSE_PUBLIC_KEY_SPKI,
            BuildConfig.FAW_LICENSE_SIGNING_CERT_SHA256)?.takeIf { it.versionCode > currentVersion(context) }
    }

    fun checkOnOpen(context: Context) {
        if (configurationProblem() != null || !checking.compareAndSet(false, true)) return
        val app = context.applicationContext
        val last = prefs(app).getLong("last_check", 0)
        val now = System.currentTimeMillis()
        if (now >= last && now - last < 6 * 60 * 60 * 1000L) { checking.set(false); return }
        executor.execute {
            try {
                val update = check(app)
                prefs(app).edit().putLong("last_check", now).apply()
                if (update != null && prefs(app).getLong("notified_version", 0) != update.versionCode) {
                    Handler(Looper.getMainLooper()).post {
                        if (!CarPlayBackgroundSession.hasSession()) {
                            Toast.makeText(app, "发现新版本 ${update.versionName}，可在关于 → 检查更新中安装。", Toast.LENGTH_LONG).show()
                            prefs(app).edit().putLong("notified_version", update.versionCode).apply()
                        }
                    }
                }
            } catch (_: Exception) { /* Optional update checks never block connection or navigation. */ }
            finally { checking.set(false) }
        }
    }

    fun download(context: Context, manifest: UpdateManifest, cancelled: AtomicBoolean, progress: (Long, Long) -> Unit): File {
        LicensePackageSignature.verify(context)
        if (manifest.minSdk > Build.VERSION.SDK_INT) throw UpdateException("新版本需要更高的 Android 系统，当前车机暂不支持。")
        val file = UpdateTransport.download(manifest, directory(context), cancelled, progress)
        validateArchive(context, manifest, file)
        val atomic = envelopeFile(context)
        val out = atomic.startWrite()
        try { out.write(manifest.envelope.toByteArray(Charsets.UTF_8)); atomic.finishWrite(out) }
        catch (e: Exception) { atomic.failWrite(out); throw e }
        return file
    }

    fun ready(context: Context): Pair<UpdateManifest, File>? = runCatching {
        val text = envelopeFile(context).openRead().use { input ->
            val output = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(4096)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                require(output.size() + count <= UpdateManifestVerifier.MAX_ENVELOPE_BYTES)
                output.write(buffer, 0, count)
            }
            output.toString("UTF-8")
        }
        val manifest = UpdateManifestVerifier.verify(text, BuildConfig.FAW_LICENSE_PUBLIC_KEY_SPKI,
            context.packageName, BuildConfig.FAW_LICENSE_SIGNING_CERT_SHA256)
        if (manifest.versionCode <= currentVersion(context)) return@runCatching null
        val file = File(directory(context), manifest.sha256 + ".apk")
        if (!file.isFile) return@runCatching null
        manifest to file
    }.getOrNull()

    fun validateArchive(context: Context, manifest: UpdateManifest, file: File) {
        LicensePackageSignature.verify(context)
        if (manifest.versionCode <= currentVersion(context)) throw UpdateException("此更新包版本不高于当前版本。")
        if (manifest.minSdk > Build.VERSION.SDK_INT) throw UpdateException("当前车机系统不支持此版本。")
        if (!UpdateTransport.matchesFile(file, manifest)) throw UpdateException("本地更新包完整性校验失败，请重新下载。")
        // Some Android 9 vendor parsers collect archive certificates only with the legacy flag too.
        @Suppress("DEPRECATION")
        val archiveFlags = PackageManager.GET_SIGNING_CERTIFICATES or PackageManager.GET_SIGNATURES
        val info = context.packageManager.getPackageArchiveInfo(file.absolutePath, archiveFlags)
            ?: throw UpdateException("无法读取更新包，请重新下载。")
        val app = info.applicationInfo ?: throw UpdateException("更新包缺少应用信息。")
        val signers = info.signingInfo?.apkContentsSigners
        val cert = signers?.singleOrNull()?.let { LicenseVerifier.sha256Hex(it.toByteArray()) }
        if (info.packageName != context.packageName || info.longVersionCode != manifest.versionCode || info.versionName != manifest.versionName ||
            app.minSdkVersion != manifest.minSdk || cert != manifest.signingCertSha256 ||
            cert != BuildConfig.FAW_LICENSE_SIGNING_CERT_SHA256 || !info.splitNames.isNullOrEmpty()) {
            throw UpdateException("更新包的应用、版本或发布签名不匹配。")
        }
    }

    fun installationBlocked(hasSession: Boolean) = hasSession

    fun install(context: Context, manifest: UpdateManifest, file: File, silent: Boolean) {
        if (!installing.compareAndSet(false, true)) throw UpdateException("安装正在准备中，请稍候。")
        val pm = context.packageManager
        var id: Int? = null
        var vendorFolder: File? = null
        try {
            if (installationBlocked(CarPlayBackgroundSession.hasSession())) throw UpdateException("CarPlay 正在连接或运行，请断开连接后再安装更新。")
            if (silent && !capability(context).silent) throw UpdateException("当前车机未授予静默安装权限。")
            if (!silent && !capability(context).silent && !pm.canRequestPackageInstalls()) throw UpdateException("请先允许此应用安装更新包。")
            validateArchive(context, manifest, file)
            val old = prefs(context).getInt("session_id", -1)
            if (old >= 0) runCatching { pm.packageInstaller.abandonSession(old) }
            if (capability(context).vendor) {
                installStatus(context)
                if (prefs(context).contains("vendor_started")) throw UpdateException("车机正在安装更新，请等待安装结果。")
                val folder = FawVendorInstaller.stage(context, manifest, file)
                vendorFolder = folder
                if (CarPlayBackgroundSession.hasSession()) throw UpdateException("CarPlay 已开始连接，请稍后再安装。")
                if (!prefs(context).edit().remove("session_id").remove("request_nonce")
                    .putLong("target_version", manifest.versionCode).putLong("vendor_started", SystemClock.elapsedRealtime())
                    .putString("vendor_folder", folder.name).putString("install_status", "车机正在安装更新…").commit()) {
                    throw UpdateException("无法保存安装状态。")
                }
                confirmationIntent = null
                FawVendorInstaller.request(context, folder)
                return
            }
            val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL).apply {
                setAppPackageName(context.packageName); setSize(manifest.sizeBytes)
                if (Build.VERSION.SDK_INT >= 31) setRequireUserAction(if (silent) PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED else PackageInstaller.SessionParams.USER_ACTION_REQUIRED)
            }
            val sessionId = pm.packageInstaller.createSession(params)
            id = sessionId
            val nonce = UUID.randomUUID().toString()
            val intent = Intent(context, UpdateInstallResultReceiver::class.java).setAction(INSTALL_ACTION).putExtra("request_nonce", nonce)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val pending = PendingIntent.getBroadcast(context, sessionId, intent, flags)
            pm.packageInstaller.openSession(sessionId).use { session ->
                session.openWrite("base.apk", 0, manifest.sizeBytes).use { output -> file.inputStream().use { it.copyTo(output) }; session.fsync(output) }
                if (CarPlayBackgroundSession.hasSession()) throw UpdateException("CarPlay 已开始连接，请稍后再安装。")
                if (!prefs(context).edit().putInt("session_id", sessionId).putString("request_nonce", nonce)
                    .putLong("target_version", manifest.versionCode).putString("install_status", "正在请求系统安装…").commit()) throw UpdateException("无法保存安装状态。")
                confirmationIntent = null
                session.commit(pending.intentSender)
            }
        } catch (e: Exception) {
            id?.let { runCatching { pm.packageInstaller.abandonSession(it) } }
            vendorFolder?.let { FawVendorInstaller.cleanup(context, it.name) }
            confirmationIntent = null
            // A duplicate request must not erase the first vendor install's pending state.
            if (vendorFolder == null && prefs(context).contains("vendor_started")) throw e
            prefs(context).edit().remove("session_id").remove("request_nonce").remove("target_version")
                .remove("vendor_started").remove("vendor_folder")
                .putString("install_status", "安装未完成，请重试。").apply()
            throw e
        } finally { installing.set(false) }
    }

    fun installStatus(context: Context): String {
        val p = prefs(context)
        val target = p.getLong("target_version", 0)
        if (target > 0 && currentVersion(context) >= target) {
            FawVendorInstaller.cleanup(context, p.getString("vendor_folder", null))
            p.edit().remove("session_id").remove("request_nonce").remove("target_version")
                .remove("vendor_started").remove("vendor_folder").putString("install_status", "更新已安装成功。").apply()
            confirmationIntent = null
        } else if (p.contains("vendor_started")) {
            val started = p.getLong("vendor_started", 0)
            val now = SystemClock.elapsedRealtime()
            if (now < started || now - started >= 120_000) {
                FawVendorInstaller.cleanup(context, p.getString("vendor_folder", null))
                p.edit().remove("vendor_started").remove("vendor_folder").remove("target_version")
                    .putString("install_status", "车机未完成更新安装，请重试。").apply()
            }
        }
        return p.getString("install_status", "") ?: ""
    }

    fun completeVendorSelfUpdate(context: Context): Boolean {
        val p = prefs(context)
        val target = p.getLong("target_version", 0)
        if (!p.contains("vendor_started") || target <= 0 || currentVersion(context) < target) return false
        LicensePackageSignature.verify(context)
        installStatus(context)
        return true
    }

    fun acceptInstallResult(context: Context, intent: Intent) {
        val p = prefs(context)
        val nonce = p.getString("request_nonce", null) ?: return
        if (intent.action != INSTALL_ACTION || intent.getStringExtra("request_nonce") != nonce ||
            intent.getIntExtra(PackageInstaller.EXTRA_SESSION_ID, -1) != p.getInt("session_id", -2)) return
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        val message = when (status) {
            PackageInstaller.STATUS_SUCCESS -> "更新已安装成功。"
            PackageInstaller.STATUS_PENDING_USER_ACTION -> "系统要求确认安装，请点击“继续系统确认”。"
            else -> "系统安装未完成（状态 $status），请重试。"
        }
        @Suppress("DEPRECATION")
        confirmationIntent = if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) intent.getParcelableExtra(Intent.EXTRA_INTENT) else null
        val edit = p.edit().putString("install_status", message)
        if (status != PackageInstaller.STATUS_PENDING_USER_ACTION) edit.remove("session_id").remove("request_nonce").remove("target_version")
        edit.apply()
    }
}
