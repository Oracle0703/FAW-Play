package com.shilapi.xcertplay

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.graphics.drawable.ColorDrawable
import java.util.UUID
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import com.shilapi.xcertplay.host.R
import java.lang.ref.WeakReference

/** A separate task for stream 111. Routing is control traffic; video stays in the app process. */
class AdbClusterActivity : Activity() {
    private var waiting: TextView? = null
    private var surface: Surface? = null
    private var videoSurface: VideoSurfaceView? = null
    private var turnCard: ClusterTurnCardView? = null
    private var safeAreaPreview: SafeAreaEditorView? = null
    internal var routeStatus = ""
        private set

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!AdbClusterRouter.enabled(this)) { finish(); return }
        val token = intent.getStringExtra("cluster_launch_token")
        if (!ClusterActivityOutput.acceptsToken(token)) { finish(); return }
        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window.addFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        val root = FrameLayout(this).apply { setBackgroundColor(Color.TRANSPARENT) }
        val video = VideoSurfaceView(this, onSurface = { next ->
            surface?.let { ClusterActivityOutput.detach(this, it) }
            surface = next
            if (next != null && ClusterActivityOutput.activity.get() === this)
                ClusterActivityOutput.attach(this, next)
        }).also { videoSurface = it }
        root.addView(video, FrameLayout.LayoutParams(-1, -1))
        waiting = TextView(this).apply {
            setBackgroundColor(Color.BLACK)
            setTextColor(Color.WHITE)
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
        }
        root.addView(waiting, FrameLayout.LayoutParams(-1, -1))
        turnCard = ClusterTurnCardView(this).apply { visibility = View.GONE }
        root.addView(turnCard, FrameLayout.LayoutParams(-1, -1))
        safeAreaPreview = SafeAreaEditorView(this).apply {
            visibility = View.GONE
            interactive = false
            dimOutside = false
        }
        root.addView(safeAreaPreview, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        root.post {
            val attached = root.display?.displayId ?: -1
            if (attached > 0) confirmDisplay(token, attached)
            else Thread({
                val verified = AdbClusterRouter.verify(applicationContext, taskId)
                runOnUiThread { confirmDisplay(token, verified ?: -1) }
            }, "cluster-display-check").start()
        }
        updateStream()
    }

    internal fun updateStream() {
        waiting?.visibility = if (ClusterActivityOutput.streamActive) View.GONE else View.VISIBLE
        waiting?.text = ""
        updateTurnCard()
    }

    internal fun updateTurnCard() {
        turnCard?.setLayout(ClusterActivityOutput.cardX, ClusterActivityOutput.cardY, ClusterActivityOutput.cardSize)
        turnCard?.setOpacity(ClusterActivityOutput.cardOpacity)
        turnCard?.setNightMode(ClusterActivityOutput.cardNight)
        turnCard?.setGuidance(if (ClusterActivityOutput.streamActive) ClusterActivityOutput.guidance else null)
        updateSafeAreaPreview()
    }

    internal fun updateSafeAreaPreview() {
        val rect = ClusterActivityOutput.previewRect
        safeAreaPreview?.apply {
            visibility = if (rect == null) View.GONE else View.VISIBLE
            if (rect != null) { setRect(rect, 1920, 720); bringToFront() }
        }
    }

    private fun confirmDisplay(token: String?, display: Int) {
        if (isFinishing || isDestroyed || !ClusterActivityOutput.confirm(this, token, display)) {
            if (token != null && !ClusterActivityOutput.hasConfirmedRoute())
                com.shilapi.xcertplay.hud.FawOemClusterNavi.release(this, token)
            finish(); return
        }
        routeStatus = getString(R.string.adb_cluster_routed)
        surface?.let { ClusterActivityOutput.attach(this, it) }
        updateStream()
    }

    internal fun route() { ClusterActivityOutput.retry() }

    // Losing focus must not detach stream 111. Surface callbacks own the rendering lifetime.
    override fun onDestroy() {
        videoSurface?.close()
        videoSurface = null
        if (ClusterActivityOutput.activity.get() === this) {
            intent.getStringExtra("cluster_launch_token")?.let {
                com.shilapi.xcertplay.hud.FawOemClusterNavi.release(this, it)
            }
            ClusterActivityOutput.activity.clear()
            ClusterActivityOutput.launchPending = false
            ClusterActivityOutput.retry()
        }
        super.onDestroy()
    }
}

/** Main-thread handoff, with identity checks so a stale activity cannot clear a newer surface. */
internal object ClusterActivityOutput {
    var activity = WeakReference<AdbClusterActivity>(null)
    var launchPending = false
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var generation = 0
    @Volatile private var launchToken: String? = null
    @Volatile private var expectedDisplay = -1
    private var launchHost = WeakReference<Activity>(null)
    private val retryTick = Runnable { launchHost.get()?.let(::ensure) }

    fun acceptsToken(token: String?): Boolean = token != null && token == launchToken && hostOwner != null
    fun hasConfirmedRoute(): Boolean = activity.get()?.let { !it.isFinishing && !it.isDestroyed } == true &&
        expectedDisplay > 0
    fun confirm(window: AdbClusterActivity, token: String?, display: Int): Boolean {
        if (!acceptsToken(token) || display <= 0 || display != expectedDisplay ||
            !AdbClusterRouter.enabled(window)) return false
        activity.get()?.takeIf { it !== window }?.finish()
        activity = WeakReference(window)
        launchPending = false
        main.removeCallbacks(retryTick)
        return true
    }
    fun retry() {
        main.removeCallbacks(retryTick)
        if (hostOwner != null && launchHost.get() != null) main.postDelayed(retryTick, 5_000L)
    }
    var mainTaskId = -1
        private set
    var surface: Surface? = null
        private set
    private var surfaceOwner: Any? = null
    private var hostOwner: Any? = null
    private var onSurface: ((Surface?) -> Unit)? = null
    var streamActive = false
        private set

    var guidance: com.shilapi.xcertplay.hud.ClusterTurnGuidance? = null
        private set
    var cardX = com.shilapi.xcertplay.airplay.ClusterTurnCardOverlay.DEFAULT_X_PERCENT
        private set
    var cardY = com.shilapi.xcertplay.airplay.ClusterTurnCardOverlay.DEFAULT_Y_PERCENT
        private set
    var cardSize = com.shilapi.xcertplay.airplay.ClusterTurnCardOverlay.DEFAULT_SIZE_PERCENT
        private set
    var cardOpacity = com.shilapi.xcertplay.airplay.ClusterTurnCardOverlay.DEFAULT_OPACITY_PERCENT
        private set
    var cardNight = false
        private set

    fun setTurnCard(next: com.shilapi.xcertplay.hud.ClusterTurnGuidance?, x: Int, y: Int,
        size: Int, opacity: Int, night: Boolean) {
        guidance = next
        cardX = x
        cardY = y
        cardSize = size
        cardOpacity = opacity
        cardNight = night
        activity.get()?.updateTurnCard()
    }

    private var previewOwner: Any? = null
    var previewRect: com.shilapi.xcertplay.airplay.SafeAreaRect? = null
        private set

    fun beginSafeAreaPreview(owner: Any, rect: com.shilapi.xcertplay.airplay.SafeAreaRect) {
        previewOwner = owner
        updateSafeAreaPreview(owner, rect)
    }

    fun updateSafeAreaPreview(owner: Any, rect: com.shilapi.xcertplay.airplay.SafeAreaRect) {
        if (previewOwner !== owner) return
        previewRect = rect.clampTo(1920, 720)
        activity.get()?.updateSafeAreaPreview()
    }

    fun endSafeAreaPreview(owner: Any) {
        if (previewOwner !== owner) return
        previewOwner = null
        previewRect = null
        activity.get()?.updateSafeAreaPreview()
    }

    fun bind(owner: Any, taskId: Int, callback: (Surface?) -> Unit) {
        if (hostOwner !== owner && !hasConfirmedRoute()) {
            ++generation
            launchToken = null
            expectedDisplay = -1
            launchPending = false
        }
        hostOwner = owner
        mainTaskId = taskId
        onSurface = callback
        callback(surface)
    }

    fun ensure(host: Activity) {
        launchHost = WeakReference(host)
        if (!AdbClusterRouter.enabled(host) || hostOwner !== host) return
        if (activity.get()?.let { !it.isFinishing && !it.isDestroyed } == true || launchPending) return
        launchPending = true
        val epoch = ++generation
        val token = UUID.randomUUID().toString()
        launchToken = token
        expectedDisplay = -1
        val app = host.applicationContext
        Thread({
            val result = AdbClusterRouter.launch(app, token) { display ->
                if (generation != epoch || launchToken != token) false
                else { expectedDisplay = display; true }
            }
            main.post {
                completeLaunch(token, generation == epoch, result.success) {
                    com.shilapi.xcertplay.hud.FawOemClusterNavi.release(app, token)
                }
            }
        }, "adb-cluster-launch").start()
    }

    /** Actual display confirmation overrides an inconclusive shell reply. Main thread only. */
    internal fun completeLaunch(token: String, current: Boolean, accepted: Boolean, release: () -> Unit) {
        if (!current) { release(); return }
        launchPending = false
        if (!hasConfirmedRoute()) {
            if (!accepted) {
                // Invalidate admission before releasing OEM state: a delayed Activity cannot attach.
                if (launchToken == token) { launchToken = null; expectedDisplay = -1 }
                release()
            }
            retry()
        }
    }

    fun attach(owner: Any, next: Surface) {
        surfaceOwner = owner
        surface = next
        onSurface?.invoke(next)
    }

    fun detach(owner: Any, old: Surface) {
        if (surfaceOwner !== owner || surface !== old) return
        surfaceOwner = null
        surface = null
        onSurface?.invoke(null)
    }

    fun setStreamActive(active: Boolean) {
        streamActive = active
        activity.get()?.updateStream()
    }

    /** Settings may change while the projection host is paused. Stop its old lease immediately. */
    fun stopForSettings() { hostOwner?.let(::stop) }

    fun stop(owner: Any) {
        if (hostOwner !== owner) return
        val releaseContext = launchHost.get()?.applicationContext
        val releaseLease = launchToken
        ++generation
        launchToken = null
        expectedDisplay = -1
        launchHost.clear()
        if (releaseContext != null)
            com.shilapi.xcertplay.hud.FawOemClusterNavi.release(releaseContext, releaseLease)
        main.removeCallbacks(retryTick)
        onSurface?.invoke(null)
        onSurface = null
        hostOwner = null
        mainTaskId = -1
        surface = null
        surfaceOwner = null
        launchPending = false
        guidance = null
        previewOwner = null
        previewRect = null
        setStreamActive(false)
        activity.get()?.finish()
    }
}
