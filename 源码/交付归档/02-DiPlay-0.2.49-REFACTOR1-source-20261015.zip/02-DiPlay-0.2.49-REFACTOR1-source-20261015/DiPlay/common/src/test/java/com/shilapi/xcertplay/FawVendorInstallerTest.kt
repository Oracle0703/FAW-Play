package com.shilapi.xcertplay

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.pm.*
import android.os.Build
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito.*
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.util.ReflectionHelpers

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE, sdk = [28])
class FawVendorInstallerTest {
    private val context = mock(Context::class.java)
    private val pm = mock(PackageManager::class.java)
    private val signing = mock(SigningInfo::class.java)
    private lateinit var info: PackageInfo

    @Before fun setup() {
        ReflectionHelpers.setStaticField(Build::class.java, "DEVICE", "t1c_acrn")
        val certificate = javaClass.getResourceAsStream("/hs5-sota-support-certificate.der")!!.use { it.readBytes() }
        `when`(signing.apkContentsSigners).thenReturn(arrayOf(Signature(certificate)))
        info = PackageInfo().apply {
            packageName = FawVendorInstaller.PACKAGE; versionCode = 2731; versionName = "20240905-114725"
            signingInfo = signing
            applicationInfo = ApplicationInfo().apply { flags = ApplicationInfo.FLAG_SYSTEM; enabled = true }
            receivers = arrayOf(ActivityInfo().apply {
                name = FawVendorInstaller.RECEIVER; enabled = true; exported = true
            })
            services = arrayOf(ServiceInfo().apply {
                name = "${FawVendorInstaller.PACKAGE}.SotaSupportService"; enabled = true; exported = true
            })
        }
        `when`(context.packageManager).thenReturn(pm)
        `when`(pm.getPackageInfo(eq(FawVendorInstaller.PACKAGE), anyInt())).thenReturn(info)
        `when`(pm.checkPermission(Manifest.permission.INSTALL_PACKAGES, FawVendorInstaller.PACKAGE))
            .thenReturn(PackageManager.PERMISSION_GRANTED)
    }

    @Test fun requiresTheVerifiedOemSignerVersionAndInstallationGrant() {
        assertTrue(FawVendorInstaller.available(context))
        info.versionCode++
        assertFalse(FawVendorInstaller.available(context))
        info.versionCode--
        `when`(signing.apkContentsSigners).thenReturn(arrayOf(Signature(byteArrayOf(1, 2))))
        assertFalse(FawVendorInstaller.available(context))
        setup()
        `when`(pm.checkPermission(Manifest.permission.INSTALL_PACKAGES, FawVendorInstaller.PACKAGE))
            .thenReturn(PackageManager.PERMISSION_DENIED)
        assertFalse(FawVendorInstaller.available(context))
    }

    @Test fun acceptsThe3337ContractWhoseOemBytecodeMatchesTheVehicleBaseline() {
        info.versionCode = 3337
        info.versionName = "20250210-144658"
        assertTrue(FawVendorInstaller.available(context))
    }

    @Test fun readsTheLegacyCertificateWhenAndroid9OmitsSigningInfo() {
        val certificate = javaClass.getResourceAsStream("/hs5-sota-support-certificate.der")!!.use { it.readBytes() }
        info.signingInfo = null
        @Suppress("DEPRECATION")
        info.signatures = arrayOf(Signature(certificate))
        assertTrue(FawVendorInstaller.available(context))
        assertEquals("legacy", FawVendorInstaller.inspect(context).certificateSource)
    }

    @Test fun modernSignerMismatchCannotBeRescuedByATrustedLegacyCertificate() {
        @Suppress("DEPRECATION")
        info.signatures = signing.apkContentsSigners
        `when`(signing.apkContentsSigners).thenReturn(arrayOf(Signature(byteArrayOf(1, 2))))
        val result = FawVendorInstaller.inspect(context)
        assertFalse(result.available)
        assertEquals("CERTIFICATE_MISMATCH", result.code)
        assertEquals("SigningInfo", result.certificateSource)
    }

    @Test fun legacyCompatibilityStillRequiresExactlyOneTrustedCurrentCertificate() {
        val trusted = signing.apkContentsSigners[0]
        info.signingInfo = null
        @Suppress("DEPRECATION")
        info.signatures = null
        assertEquals("CERTIFICATE_UNAVAILABLE", FawVendorInstaller.inspect(context).code)
        @Suppress("DEPRECATION")
        info.signatures = arrayOf(Signature(byteArrayOf(1, 2)))
        assertEquals("CERTIFICATE_MISMATCH", FawVendorInstaller.inspect(context).code)
        @Suppress("DEPRECATION")
        info.signatures = arrayOf(trusted, trusted)
        assertEquals("CERTIFICATE_MISMATCH", FawVendorInstaller.inspect(context).code)
    }

    @Test fun bothVersionCodeAndVersionNameMustMatchAnAuditedPair() {
        info.versionName = "20250210-144658"
        assertEquals("VERSION_UNVERIFIED", FawVendorInstaller.inspect(context).code)
        info.versionCode = 3337
        assertTrue(FawVendorInstaller.available(context))
        info.versionCode = 3338
        assertEquals("VERSION_UNVERIFIED", FawVendorInstaller.inspect(context).code)
    }

    @Test fun honoursRuntimeDisableOverridesForTheAppAndBothComponents() {
        `when`(pm.getApplicationEnabledSetting(FawVendorInstaller.PACKAGE))
            .thenReturn(PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER)
        assertEquals("APP_DISABLED", FawVendorInstaller.inspect(context).code)
        `when`(pm.getApplicationEnabledSetting(FawVendorInstaller.PACKAGE))
            .thenReturn(PackageManager.COMPONENT_ENABLED_STATE_DEFAULT)
        val receiver = ComponentName(FawVendorInstaller.PACKAGE, FawVendorInstaller.RECEIVER)
        val service = ComponentName(FawVendorInstaller.PACKAGE, info.services!![0].name)
        `when`(pm.getComponentEnabledSetting(receiver)).thenReturn(PackageManager.COMPONENT_ENABLED_STATE_DISABLED)
        assertEquals("RECEIVER_DISABLED", FawVendorInstaller.inspect(context).code)
        `when`(pm.getComponentEnabledSetting(receiver)).thenReturn(PackageManager.COMPONENT_ENABLED_STATE_DEFAULT)
        `when`(pm.getComponentEnabledSetting(service)).thenReturn(PackageManager.COMPONENT_ENABLED_STATE_DISABLED)
        assertEquals("SERVICE_DISABLED", FawVendorInstaller.inspect(context).code)
    }

    @Test fun usesManifestEnabledValuesUnlessExplicitlyEnabledByPackageManager() {
        info.applicationInfo!!.enabled = false
        assertEquals("APP_DISABLED", FawVendorInstaller.inspect(context).code)
        `when`(pm.getApplicationEnabledSetting(FawVendorInstaller.PACKAGE))
            .thenReturn(PackageManager.COMPONENT_ENABLED_STATE_ENABLED)
        info.receivers!![0].enabled = false
        assertEquals("RECEIVER_DISABLED", FawVendorInstaller.inspect(context).code)
        `when`(pm.getComponentEnabledSetting(ComponentName(FawVendorInstaller.PACKAGE, FawVendorInstaller.RECEIVER)))
            .thenReturn(PackageManager.COMPONENT_ENABLED_STATE_ENABLED)
        info.services!![0].enabled = false
        assertEquals("SERVICE_DISABLED", FawVendorInstaller.inspect(context).code)
        `when`(pm.getComponentEnabledSetting(ComponentName(FawVendorInstaller.PACKAGE, info.services!![0].name)))
            .thenReturn(PackageManager.COMPONENT_ENABLED_STATE_ENABLED)
        assertTrue(FawVendorInstaller.available(context))
    }

    @Test fun distinguishesAbsentPackagesFromQueryFailuresWithoutExposingExceptionContents() {
        `when`(pm.getPackageInfo(eq(FawVendorInstaller.PACKAGE), anyInt()))
            .thenThrow(PackageManager.NameNotFoundException("private exception contents"))
        assertEquals("PACKAGE_NOT_FOUND", FawVendorInstaller.inspect(context).code)
        `when`(pm.getPackageInfo(eq(FawVendorInstaller.PACKAGE), anyInt()))
            .thenThrow(SecurityException("private exception contents"))
        val report = FawVendorInstaller.diagnosticReport(context)
        assertTrue(report.contains("reason=QUERY_FAILED"))
        assertTrue(report.contains("SecurityException"))
        assertFalse(report.contains("private exception contents"))
    }

    @Test fun exposesTheDetectedVersionAndSpecificFailureOnTheUpdatePageAndInDiagnostics() {
        `when`(context.checkSelfPermission(Manifest.permission.INSTALL_PACKAGES))
            .thenReturn(PackageManager.PERMISSION_DENIED)
        info.versionCode = 3337
        info.versionName = "20250210-144658"
        val capability = AppUpdates.capability(context)
        assertTrue(capability.silent)
        assertTrue(capability.vendor)
        info.versionCode = 9999
        val rejected = AppUpdates.capability(context)
        assertFalse(rejected.silent)
        assertTrue(rejected.message.contains("9999/20250210-144658"))
        val report = FawVendorInstaller.diagnosticReport(context)
        assertTrue(report.contains("reason=VERSION_UNVERIFIED"))
        assertTrue(report.contains("certificateSource=SigningInfo"))
    }

    @Test fun rejectsReplacedDisabledOrPermissionProtectedComponentsAndOtherDevices() {
        assertTrue(FawVendorInstaller.available(context))
        info.applicationInfo!!.flags = 0
        assertFalse(FawVendorInstaller.available(context))
        info.applicationInfo!!.flags = ApplicationInfo.FLAG_SYSTEM
        info.receivers!![0].permission = "vendor.signature.permission"
        assertFalse(FawVendorInstaller.available(context))
        info.receivers!![0].permission = null
        info.services!![0].exported = false
        assertFalse(FawVendorInstaller.available(context))
        info.services!![0].exported = true
        ReflectionHelpers.setStaticField(Build::class.java, "DEVICE", "phone")
        assertFalse(FawVendorInstaller.available(context))
    }

    @Test @Config(sdk = [33]) fun doesNotAssumeTheAndroid9ContractOnNewerFirmware() {
        assertFalse(FawVendorInstaller.available(context))
    }
}
