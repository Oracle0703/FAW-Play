package com.shilapi.xcertplay

import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28, 33])
class LicenseActivityTest {
    @Test fun carDisplaysQrActivationAndDoesNotCollectCustomerCodesOrAccounts() {
        val controller = Robolectric.buildActivity(LicenseActivity::class.java).setup()
        try {
            val views = descendants(controller.get().window.decorView)
            assertTrue(views.none { it is EditText })
            assertTrue(views.any { it.tag == "faw_purchase_qr" && it.visibility == View.VISIBLE })
            val purchase = views.filterIsInstance<Button>().single { it.text == "打开购买页面" }
            purchase.performClick()
            val opened = org.robolectric.Shadows.shadowOf(controller.get()).nextStartedActivity
            assertEquals(android.content.Intent.ACTION_VIEW, opened.action)
            assertEquals("https://wzyp.cn/item/lwbqa1", opened.data.toString())
            assertTrue(views.filterIsInstance<Button>().any { it.text == "生成设备激活二维码" })
            val text = views.filterIsInstance<TextView>().joinToString("\n") { it.text.toString() }
            assertTrue(text.contains("用手机扫码，核对设备识别码并输入兑换码"))
            assertFalse(text.contains("邮箱账号"))
            assertFalse(text.contains("扫码登录"))
        } finally { controller.pause().stop().destroy() }
    }

    private fun descendants(view: View): List<View> = listOf(view) +
        if (view is ViewGroup) (0 until view.childCount).flatMap { descendants(view.getChildAt(it)) } else emptyList()
}
