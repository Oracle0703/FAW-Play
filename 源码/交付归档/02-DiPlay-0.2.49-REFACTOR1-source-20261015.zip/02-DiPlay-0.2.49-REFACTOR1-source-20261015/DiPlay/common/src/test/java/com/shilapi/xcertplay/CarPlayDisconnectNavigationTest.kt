package com.shilapi.xcertplay

import android.os.Handler
import android.os.Looper
import com.shilapi.xcertplay.airplay.*
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import org.robolectric.util.ReflectionHelpers
import org.robolectric.util.ReflectionHelpers.ClassParameter.from

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28, 29], qualifiers = "en", manifest = Config.NONE)
@LooperMode(LooperMode.Mode.PAUSED)
class CarPlayDisconnectNavigationTest {
    private lateinit var activity: CarPlayHostActivity
    private lateinit var listener: AirPlaySessionListener
    private val sessions = mutableListOf<AirPlaySession>()

    @Before fun setup() {
        CarPlayBackgroundSession.clear()
        activity = Robolectric.buildActivity(CarPlayHostActivity::class.java).get()
        activity.setTheme(android.R.style.Theme_Material_NoActionBar)
        ReflectionHelpers.setField(CarPlayBackgroundSession, "owner", activity)
        listener = listener(0)
    }

    @After fun cleanup() {
        ReflectionHelpers.getField<Handler>(activity, "mainHandler").removeCallbacksAndMessages(null)
        sessions.forEach { it.close() }
        CarPlayBackgroundSession.clear()
    }

    @Test fun foregroundReturnsToConnectionPageBeforeEndAndOnlyOnce() {
        val session = active(true)
        listener.onSessionDisconnected(session)
        assertEquals("connection", shadowOf(activity).nextStartedActivity.getStringExtra("page"))
        assertNull(ReflectionHelpers.getField(activity, "activeAirPlaySession"))
        assertFalse(CarPlayBackgroundSession.active)
        assertFalse(ReflectionHelpers.getField(activity, "reconnectScheduled"))
        listener.onSessionDisconnected(session)
        listener.onSessionEnded(session)
        listener.onSessionEnded(session)
        assertNull(shadowOf(activity).nextStartedActivity)
        assertTrue(ReflectionHelpers.getField(activity, "reconnectScheduled"))
        assertEquals(1, ReflectionHelpers.getField<Int>(activity, "reconnectAttempts"))
    }

    @Test fun backgroundDisconnectDoesNotStealForeground() {
        val session = active(false)
        listener.onSessionDisconnected(session)
        listener.onSessionEnded(session)
        assertNull(shadowOf(activity).nextStartedActivity)
        assertTrue(ReflectionHelpers.getField(activity, "reconnectScheduled"))
    }

    @Test fun probeDoesNotClearCurrentProjectionOrScheduleRecovery() {
        val main = active(true)
        val probe = session()
        listener.onSessionDisconnected(probe)
        listener.onSessionEnded(probe)
        assertSame(main, ReflectionHelpers.getField(activity, "activeAirPlaySession"))
        assertTrue(CarPlayBackgroundSession.active)
        assertNull(shadowOf(activity).nextStartedActivity)
        assertFalse(ReflectionHelpers.getField(activity, "reconnectScheduled"))
    }

    @Test fun noActiveProjectionDoesNotNavigateOrReconnectForProbe() {
        val probe = session()
        ReflectionHelpers.setField(activity, "isActivityResumed", true)
        listener.onSessionDisconnected(probe)
        listener.onSessionEnded(probe)
        assertNull(shadowOf(activity).nextStartedActivity)
        assertFalse(ReflectionHelpers.getField(activity, "reconnectScheduled"))
    }

    @Test fun adoptedActiveControllerCanReturnWithoutHostSessionField() {
        val main = session()
        CarPlayBackgroundSession.active = true
        ReflectionHelpers.setField(activity, "isActivityResumed", true)
        listener.onSessionDisconnected(main)
        assertEquals("connection", shadowOf(activity).nextStartedActivity.getStringExtra("page"))
    }

    @Test fun staleShutdownAndResetCallbacksCannotNavigate() {
        val main = active(true)
        listener(1).onSessionDisconnected(main)
        ReflectionHelpers.getField<AtomicBoolean>(activity, "shuttingDown").set(true)
        listener.onSessionDisconnected(main)
        ReflectionHelpers.getField<AtomicBoolean>(activity, "shuttingDown").set(false)
        ReflectionHelpers.setField(activity, "handshakeResetInProgress", true)
        listener.onSessionDisconnected(main)
        ReflectionHelpers.setField(activity, "handshakeResetInProgress", false)
        ReflectionHelpers.setField(CarPlayBackgroundSession, "owner", Any())
        listener.onSessionDisconnected(main)
        assertNull(shadowOf(activity).nextStartedActivity)
        assertSame(main, ReflectionHelpers.getField(activity, "activeAirPlaySession"))
    }

    @Test fun lateEndCannotClearReplacementSession() {
        val first = active(false)
        listener.onSessionDisconnected(first)
        val replacement = active(false)
        listener.onSessionEnded(first)
        assertSame(replacement, ReflectionHelpers.getField(activity, "activeAirPlaySession"))
        assertTrue(CarPlayBackgroundSession.active)
        assertFalse(ReflectionHelpers.getField(activity, "reconnectScheduled"))
    }

    @Test fun transportErrorReturnsOnceAndDuplicateErrorSchedulesOnlyOneRetry() {
        active(true)
        listener.onTransportError("network gone")
        assertEquals("connection", shadowOf(activity).nextStartedActivity.getStringExtra("page"))
        listener.onTransportError("cleanup error")
        assertNull(shadowOf(activity).nextStartedActivity)
        assertEquals(1, ReflectionHelpers.getField<Int>(activity, "reconnectAttempts"))
    }

    @Test fun replacementActivationCancelsQueuedRetryAndOldEnd() {
        val first = active(false)
        listener.onSessionDisconnected(first)
        listener.onSessionEnded(first)
        assertTrue(ReflectionHelpers.getField(activity, "reconnectScheduled"))
        val replacement = session()
        listener.onSessionActive(replacement)
        assertFalse(ReflectionHelpers.getField(activity, "reconnectScheduled"))
        listener.onSessionEnded(first)
        assertSame(replacement, ReflectionHelpers.getField(activity, "activeAirPlaySession"))
        assertEquals(0, ReflectionHelpers.getField<Int>(activity, "reconnectAttempts"))
    }

    @Test fun alreadyClosedSessionCannotBecomeActiveAgain() {
        val closed = session()
        closed.close()
        listener.onSessionActive(closed)
        assertNull(ReflectionHelpers.getField(activity, "activeAirPlaySession"))
        assertFalse(CarPlayBackgroundSession.active)
    }

    private fun listener(generation: Int) = ReflectionHelpers.callInstanceMethod<AirPlaySessionListener>(
        activity, "createSessionListener", from(Int::class.javaPrimitiveType, generation))

    private fun active(foreground: Boolean): AirPlaySession = session().also {
        ReflectionHelpers.setField(activity, "activeAirPlaySession", it)
        ReflectionHelpers.setField(activity, "isActivityResumed", foreground)
        CarPlayBackgroundSession.active = true
    }

    private fun session() = AirPlaySession(Socket(),
        AirPlayConfig("test", "test", "", "1", AirPlayDisplayConfig(800, 480)),
        AirPlayIdentity.generate(), PairingStore(), null,
        object : AirPlaySessionListener {}, object : AirPlayMediaHandler {}).also(sessions::add)
}
