package com.shilapi.xcertplay.api

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

internal class ResponseLimitException(limit: Int) : IOException("Response exceeds $limit bytes")

internal fun InputStream.readBytesLimited(limit: Int): ByteArray {
    require(limit > 0)
    val output = ByteArrayOutputStream()
    val buffer = ByteArray(8192)
    while (true) {
        val count = read(buffer)
        if (count < 0) break
        if (count > limit - output.size()) throw ResponseLimitException(limit)
        output.write(buffer, 0, count)
    }
    return output.toByteArray()
}

/** Shared blocking transport; callers own endpoint validation and business response checks. */
internal object HttpTransport {
    data class Response(val status: Int, val body: String)

    fun <T> withConnection(
        url: String,
        connectTimeoutMillis: Int = 10_000,
        readTimeoutMillis: Int = 10_000,
        block: (HttpURLConnection) -> T
    ): T {
        require(connectTimeoutMillis > 0 && readTimeoutMillis > 0)
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.instanceFollowRedirects = false
            connection.useCaches = false
            connection.connectTimeout = connectTimeoutMillis
            connection.readTimeout = readTimeoutMillis
            return block(connection)
        } finally {
            connection.disconnect()
        }
    }

    fun request(
        method: String,
        url: String,
        body: String? = null,
        contentType: String = "application/json; charset=UTF-8",
        bearer: String? = null,
        connectTimeoutMillis: Int = 10_000,
        readTimeoutMillis: Int = 10_000,
        responseLimit: Int = 64 * 1024
    ): Response {
        require(responseLimit > 0)
        require(bearer == null || (!bearer.contains('\r') && !bearer.contains('\n')))
        return withConnection(url, connectTimeoutMillis, readTimeoutMillis) { connection ->
            connection.requestMethod = method
            connection.setRequestProperty("Accept", "application/json")
            bearer?.let { connection.setRequestProperty("Authorization", "Bearer $it") }
            if (body != null) {
                val bytes = body.toByteArray(Charsets.UTF_8)
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", contentType)
                connection.setFixedLengthStreamingMode(bytes.size)
                connection.outputStream.use { it.write(bytes) }
            }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.use { String(it.readBytesLimited(responseLimit), Charsets.UTF_8) }.orEmpty()
            Response(status, text)
        }
    }
}
