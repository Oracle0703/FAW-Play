package com.shilapi.xcertplay.media

import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat as AndroidAudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.VolumeShaper
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Surface
import com.shilapi.xcertplay.airplay.AudioCodecKind
import com.shilapi.xcertplay.airplay.AudioFormat
import com.shilapi.xcertplay.airplay.AudioStreamId
import com.shilapi.xcertplay.airplay.MediaSink
import com.shilapi.xcertplay.airplay.MicrophoneConfig
import com.shilapi.xcertplay.airplay.VideoCodec
import com.shilapi.xcertplay.airplay.toHexString
import java.io.Closeable
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.TimeUnit

/** AudioTrack's attributes getter is only available from Android 10. */
internal fun audioTrackAttributesForFocus(track: AudioTrack, configured: AudioAttributes): AudioAttributes =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) track.audioAttributes else configured

/** Owns one focus request for all eligible tracks in a CarPlay sink. */
internal class AudioFocusCoordinator(
    context: Context?,
    private val enabled: Boolean,
    private val report: (String) -> Unit = {},
) {
    private data class Entry(
        val channel: AudioChannel,
        val attributes: AudioAttributes,
        var navigationGain: Float = FULL_VOLUME,
        var navigationFade: VolumeShaper? = null,
    )

    private val manager = context?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val automotive = context?.packageManager
        ?.hasSystemFeature(PackageManager.FEATURE_AUTOMOTIVE) == true
    private val active = LinkedHashMap<AudioTrack, Entry>()
    private class FocusState {
        var request: AudioFocusRequest? = null
        var channel: AudioChannel? = null
        var attributes: AudioAttributes? = null
        var result = AudioManager.AUDIOFOCUS_REQUEST_FAILED
        var failures = 0
        var retryAt = 0L
        var generation = 0L
    }
    private val transientFocus = FocusState()
    private val mediaFocus = FocusState()
    private val handler by lazy { Handler(Looper.getMainLooper()) }
    private var closed = false
    private val retry = Runnable {
        synchronized(this) {
            if (!closed) refreshRequest()
        }
    }

    @Synchronized
    fun acquire(track: AudioTrack, channel: AudioChannel, attributes: AudioAttributes) {
        if (closed || !enabled || manager == null || (!automotive && channel == AudioChannel.NAVIGATION)) return
        active.putIfAbsent(track, Entry(channel, attributes))
        refreshNavigationVolume()
        refreshRequest()
    }

    @Synchronized
    fun release(track: AudioTrack) {
        active.remove(track)?.let { entry ->
            runCatching { entry.navigationFade?.close() }
            refreshNavigationVolume()
            refreshRequest()
        }
    }

    @Synchronized
    fun close() {
        closed = true
        if (enabled && manager != null) handler.removeCallbacks(retry)
        active.values.forEach { runCatching { it.navigationFade?.close() } }
        active.clear()
        abandon(transientFocus)
        abandon(mediaFocus)
    }

    private fun abandon(state: FocusState) {
        state.generation++
        state.request?.let { runCatching { manager?.abandonAudioFocusRequest(it) } }
        state.request = null
        state.channel = null
        state.attributes = null
        state.failures = 0
        state.retryAt = 0
    }

    private fun refreshRequest() {
        // Keep the vehicle's music source underneath temporary navigation/call focus.
        if (automotive) refresh(mediaFocus, active.values.firstOrNull { it.channel == AudioChannel.MEDIA }, true)
        val primary = active.values.filter { !automotive || it.channel != AudioChannel.MEDIA }
            .maxByOrNull { it.channel.focusPriority() }
        refresh(transientFocus, primary, false)
        handler.removeCallbacks(retry)
        if (closed) return
        listOf(mediaFocus, transientFocus).filter {
            it.request != null && it.result == AudioManager.AUDIOFOCUS_REQUEST_FAILED
        }.minOfOrNull { it.retryAt }?.let {
            handler.postDelayed(retry, (it - android.os.SystemClock.uptimeMillis()).coerceAtLeast(1))
        }
    }

    private fun refresh(state: FocusState, entry: Entry?, media: Boolean) {
        if (entry == null || closed) { abandon(state); return }
        val same = state.request != null && state.channel == entry.channel && state.attributes == entry.attributes
        val now = android.os.SystemClock.uptimeMillis()
        if (same && (state.result != AudioManager.AUDIOFOCUS_REQUEST_FAILED || now < state.retryAt)) return
        if (!same) abandon(state)
        val gain = when (entry.channel) {
            AudioChannel.MEDIA -> AudioManager.AUDIOFOCUS_GAIN
            AudioChannel.PHONE -> AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
            AudioChannel.ASSISTANT, AudioChannel.NAVIGATION -> AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
        }
        val generation = state.generation
        val next = state.request ?: AudioFocusRequest.Builder(gain)
            .setAudioAttributes(entry.attributes)
            .setOnAudioFocusChangeListener({ change ->
                synchronized(this) {
                    if (closed || generation != state.generation) return@synchronized
                    runCatching { report("Audio: focus change=$change channel=${entry.channel} activeTracks=${active.size}") }
                    // A granted request losing focus must not start a failed-request retry loop.
                    if (change == AudioManager.AUDIOFOCUS_GAIN) state.result = AudioManager.AUDIOFOCUS_REQUEST_GRANTED
                    if (!media && !automotive) when (change) {
                        AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> setMediaVolume(DUCKED_VOLUME)
                        AudioManager.AUDIOFOCUS_GAIN -> setMediaVolume(FULL_VOLUME)
                    }
                }
            }, handler).build()
        state.request = next
        state.channel = entry.channel
        state.attributes = entry.attributes
        state.result = runCatching { manager?.requestAudioFocus(next) }.getOrNull()
            ?: AudioManager.AUDIOFOCUS_REQUEST_FAILED
        if (state.result == AudioManager.AUDIOFOCUS_REQUEST_FAILED) {
            val delay = RETRY_DELAYS[state.failures.coerceAtMost(RETRY_DELAYS.lastIndex)]
            state.failures++
            state.retryAt = android.os.SystemClock.uptimeMillis() + delay
        } else {
            state.failures = 0
            state.retryAt = 0
        }
        val line = "Audio: focus requested channel=${entry.channel} gain=$gain granted=${state.result} activeTracks=${active.size}"
        Log.i(TAG, line)
        runCatching { report(line) }
    }

    private fun refreshNavigationVolume() {
        if (!automotive) return
        val gain = if (active.values.any { it.channel == AudioChannel.NAVIGATION }) NAVIGATION_MUSIC_GAIN else FULL_VOLUME
        active.forEach { (track, entry) ->
            if (entry.channel != AudioChannel.MEDIA || entry.navigationGain == gain) return@forEach
            val duration = if (gain < entry.navigationGain) NAVIGATION_FADE_DOWN_MILLIS else NAVIGATION_FADE_UP_MILLIS
            runCatching {
                val previous = entry.navigationFade
                val current = previous?.volume ?: FULL_VOLUME
                val curve = VolumeShaper.Configuration.Builder(VolumeShaper.Configuration.SCURVE_RAMP)
                    .scaleToStartVolume(current)
                    .scaleToEndVolume(gain)
                    .setDuration(duration)
                    .build()
                if (previous == null) {
                    entry.navigationFade = track.createVolumeShaper(curve).also { it.apply(VolumeShaper.Operation.PLAY) }
                } else {
                    // Join from the current gain when prompts arrive during a recovery fade.
                    previous.replace(curve, VolumeShaper.Operation.PLAY, true)
                }
                entry.navigationGain = gain
                val line = "Audio: navigation music transition target=$gain durationMs=$duration"
                Log.i(TAG, line)
                runCatching { report(line) }
            }.onFailure { error ->
                runCatching { report("Audio: navigation music transition unavailable ${error.javaClass.simpleName}") }
            }
        }
    }

    private fun setMediaVolume(volume: Float) {
        active.filterValues { it.channel == AudioChannel.MEDIA }.keys.forEach { track ->
            runCatching { track.setStereoVolume(volume, volume) }
        }
    }

    private fun AudioChannel.focusPriority(): Int = when (this) {
        AudioChannel.PHONE -> 4
        AudioChannel.ASSISTANT -> 3
        AudioChannel.NAVIGATION -> 2
        AudioChannel.MEDIA -> 1
    }

    private companion object {
        val RETRY_DELAYS = longArrayOf(1_000, 2_000, 5_000, 15_000, 30_000)
        const val TAG = "DiPlay-AudioFocus"
        const val FULL_VOLUME = 1f
        const val DUCKED_VOLUME = 0.2f
        const val NAVIGATION_MUSIC_GAIN = 0.75f
        const val NAVIGATION_FADE_DOWN_MILLIS = 400L
        const val NAVIGATION_FADE_UP_MILLIS = 800L
    }
}

/**
 * Android rendering backend for the CarPlay media engine. Video frames are
 * decoded with MediaCodec onto a Surface; audio streams are decoded to PCM and
 * played through AudioTrack. Each audio stream keeps its own track and usage so
 * media and navigation guidance stay independently routable. Call [close]
 * when the session tears down.
 */
class AndroidMediaSink(
    surface: Surface? = null,
    private val videoWidth: Int = 1280,
    private val videoHeight: Int = 720,
    private val preferSoftwareHevcDecoder: Boolean = false,
    private val advancedAudioChannelMapping: Boolean = false,
    private val audioFocusEnabled: Boolean = false,
    private val mediaChannel: Int = 0,
    private val navigationChannel: Int = 0,
    context: Context? = null,
    private val navigationStreamType: Int = AudioChannelMapper.DEFAULT_NAVIGATION_STREAM_TYPE,
    onScreenStreamActiveChanged: ((Int, Boolean) -> Unit)? = null,
    private val mediaBufferMillis: Int = MediaAudioBuffer.DEFAULT_MILLIS,
    onAudioDiagnostic: (String) -> Unit = {},
    /** True while any music ("media") audio stream is running; called from media threads. */
    private val onMediaAudioChanged: (Boolean) -> Unit = {},
    private val videoSizes: Map<Int, Pair<Int, Int>> = emptyMap(),
) : MediaSink {
    private val appContext = context?.applicationContext
    private val audioManager = appContext?.getSystemService(AudioManager::class.java)
    @Volatile private var diagnosticListener = onAudioDiagnostic
    private val reportAudio: (String) -> Unit = { diagnosticListener(it) }
    @Volatile private var sinkClosed = false
    fun setAudioDiagnosticListener(listener: (String) -> Unit) { diagnosticListener = listener }
    private val audioFocusCoordinator = AudioFocusCoordinator(
        appContext,
        audioFocusEnabled,
        reportAudio,
    )
    private val mixingOwners = mutableSetOf<Any>()
    private val speechAudioRouting = SpeechAudioRoutingState()
    private var audioContextSession: Any? = null
    init {
        if (audioFocusEnabled && appContext != null && appContext.packageManager.hasSystemFeature(PackageManager.FEATURE_AUTOMOTIVE))
            HongqiNavigationMixing.recover(appContext, reportAudio)
    }
    @Synchronized
    override fun onCarPlaySessionActive(session: Any) {
        if (audioContextSession !== session) {
            speechAudioRouting.reset()
            audioContextSession = session
        }
        if (sinkClosed || !audioFocusEnabled || appContext == null || !appContext.packageManager.hasSystemFeature(PackageManager.FEATURE_AUTOMOTIVE)) return
        synchronized(mixingOwners) {
            mixingOwners.add(session)
            HongqiNavigationMixing.acquire(appContext, session, reportAudio)
        }
    }
    @Synchronized
    override fun onCarPlaySessionEnded(session: Any) {
        if (audioContextSession === session) {
            audioContextSession = null
            speechAudioRouting.reset()
        }
        synchronized(mixingOwners) { mixingOwners.remove(session); HongqiNavigationMixing.release(session) }
    }
    @Synchronized
    override fun onPlaybackContext(session: Any, playback: CarPlayNowPlaying, phone: Boolean?, speech: Boolean?) {
        if (audioContextSession === session && speechAudioRouting.update(playback, phone, speech))
            reportAudio("Audio: speech context playing=${playback.playing} sourceKnown=${playback.sourceApp != null} " +
                "phone=$phone speech=$speech")
    }
    @Synchronized
    override fun onSiriRequested(session: Any) {
        if (audioContextSession === session) {
            speechAudioRouting.siriRequested()
            reportAudio("Audio: speech context siriRequested=true")
        }
    }
    private val screenStateLock = Any()
    private val activeScreenTypes = mutableSetOf<Int>()
    private var defaultSurface = surface
    private val videoOwnershipLock = Any()
    @Volatile private var screenStreamActiveChanged = onScreenStreamActiveChanged
    private val surfaces = ConcurrentHashMap<Int, Surface>()
    private val videoDecoders = ConcurrentHashMap<Int, VideoDecoder>()
    private val mediaAudioTypes = mutableSetOf<AudioStreamId>()
    private val audioRenderers = ConcurrentHashMap<AudioStreamId, AudioRenderer>()
    private val microphoneUplinks = ConcurrentHashMap<AudioStreamId, MicrophoneUplink>()
    private val audioModeLock = Any()
    private var communicationModeStream: AudioStreamId? = null
    private var savedAudioMode = AudioManager.MODE_NORMAL
    private val pendingVideoCodec = ConcurrentHashMap<Int, VideoCodec>()
    private val videoRecoveryHandlers = ConcurrentHashMap<Int, () -> Boolean>()
    private val videoDiagnosticHandlers = ConcurrentHashMap<Int, (String) -> Unit>()
    private val recoveryPending = ConcurrentHashMap.newKeySet<Int>()
    // Extra decoders draw the same stream on other surfaces, such as the centre card.
    private val mirrorLock = videoOwnershipLock
    private val mirrorSurfaces = HashMap<Pair<Int, String>, Surface>()
    private val mirrorDecoders = HashMap<Pair<Int, String>, VideoDecoder>()
    private val lastVideoConfig = ConcurrentHashMap<Int, Pair<VideoCodec, ByteArray>>()
    private val recoveryExecutor = Executors.newSingleThreadExecutor { task ->
        Thread(task, "carplay-video-recovery").apply { isDaemon = true }
    }

    override fun setVideoRecoveryHandler(type: Int, handler: () -> Boolean) {
        synchronized(videoOwnershipLock) { if (!sinkClosed) videoRecoveryHandlers[type] = handler }
    }

    override fun setVideoDiagnosticHandler(type: Int, handler: (String) -> Unit) {
        synchronized(videoOwnershipLock) { if (!sinkClosed) videoDiagnosticHandlers[type] = handler }
    }

    private fun requestVideoRecovery(type: Int, completed: (Boolean) -> Unit): Boolean {
        val handler = videoRecoveryHandlers[type] ?: return false
        if (sinkClosed || !recoveryPending.add(type)) return false
        try {
            recoveryExecutor.execute {
                val sent = try { !sinkClosed && handler() }
                catch (error: Exception) { Log.w("xcertplay-usb", "Video keyframe request failed", error); false }
                finally { recoveryPending.remove(type) }
                completed(sent)
            }
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            recoveryPending.remove(type)
            return false
        }
        return true
    }

    @Volatile private var radioDiagnosticSource: () -> String = { "wireless=unavailable" }
    override fun setWirelessDiagnosticSource(source: () -> String) { radioDiagnosticSource = source }
    private val resourceSampler = appContext?.let { PlaybackResourceSampler(it,
        decoders = { videoDecoders.size + synchronized(mirrorLock) { mirrorDecoders.size } },
        active = { videoDecoders.isNotEmpty() || audioRenderers.isNotEmpty() },
        report = { line -> reportAudio(line); runCatching { reportAudio("Playback radio ${radioDiagnosticSource()}") } }) }

    fun setSurface(type: Int, surface: Surface) {
        synchronized(videoOwnershipLock) {
            if (sinkClosed) return
            surfaces[type] = surface
            videoDecoders[type]?.takeIf { it.isRunning }?.setSurface(surface)
                ?: videoDecoder(type)
        }
    }

    fun clearSurface(type: Int, surface: Surface) {
        synchronized(videoOwnershipLock) {
            if (surfaces.remove(type, surface)) videoDecoders.remove(type)?.close()
            if (defaultSurface === surface) {
                defaultSurface = null
                videoDecoders.entries.filter { surfaces[it.key] == null }.forEach { (id, decoder) ->
                    videoDecoders.remove(id, decoder)
                    decoder.close()
                }
            }
        }
    }

    /** Each visible mirror owns a decoder; absent surfaces never block other consumers. */
    fun setMirrorSurface(type: Int, key: String, surface: Surface?) {
        val id = type to key
        synchronized(videoOwnershipLock) {
            if (sinkClosed) return
            if (mirrorSurfaces[id] === surface && mirrorDecoders[id]?.isRunning == true) return
            mirrorDecoders.remove(id)?.close()
            if (surface == null) mirrorSurfaces.remove(id) else mirrorSurfaces[id] = surface
            if (surface != null) mirrorDecoders(type)
        }
    }

    private fun mirrorDecoders(type: Int): List<VideoDecoder> {
        if (sinkClosed) return emptyList()
        return mirrorSurfaces.filterKeys { it.first == type }.map { (id, surface) ->
            mirrorDecoders[id]?.takeIf { it.isRunning } ?: newVideoDecoder(type, surface,
                " stream=$type mirror=${id.second}").also { decoder ->
                mirrorDecoders[id] = decoder
                lastVideoConfig[type]?.let { (codec, data) -> decoder.configure(codec, data) }
            }
        }
    }

    fun setScreenStreamActiveChangedListener(listener: ((Int, Boolean) -> Unit)?) {
        synchronized(screenStateLock) {
            if (sinkClosed) return
            screenStreamActiveChanged = listener
            activeScreenTypes.forEach { listener?.invoke(it, true) }
        }
    }

    override fun onVideoCodec(type: Int, codec: VideoCodec) {
        synchronized(videoOwnershipLock) { if (!sinkClosed) pendingVideoCodec[type] = codec }
    }

    override fun onVideoConfig(type: Int, codecData: ByteArray) {
        synchronized(videoOwnershipLock) {
            if (sinkClosed) return
            val codec = pendingVideoCodec[type] ?: VideoCodec.H264
            val data = codecData.copyOf()
            lastVideoConfig[type] = codec to data
            // Configure existing consumers; newly created ones pick up the retained configuration.
            videoDecoders[type]?.takeIf { it.isRunning }?.configure(codec, data) ?: videoDecoder(type)
            mirrorDecoders.filterKeys { it.first == type }.values.forEach { it.configure(codec, data) }
            mirrorDecoders(type)
        }
    }

    override fun onVideoFrame(type: Int, naluBytes: ByteArray) {
        prepareVideoFrame(type)(naluBytes)
    }

    override fun prepareVideoFrame(type: Int): (ByteArray) -> Unit =
        prepareVideoFrame(type, System.nanoTime(), 0L)

    override fun prepareVideoFrame(type: Int, arrivalNanos: Long, senderNanos: Long): (ByteArray) -> Unit {
        val targets = synchronized(videoOwnershipLock) {
            if (sinkClosed) emptyList() else listOfNotNull(videoDecoder(type)) + mirrorDecoders(type)
        }
        // Backpressure belongs outside lifecycle locks. Captured consumers cannot switch generations.
        return { bytes -> targets.forEach { it.submit(bytes, arrivalNanos, senderNanos) } }
    }

    override fun onScreenStreamActive(type: Int, active: Boolean) {
        synchronized(videoOwnershipLock) {
            if (sinkClosed) return
            if (!active) {
                videoRecoveryHandlers.remove(type)
                videoDiagnosticHandlers.remove(type)
                videoDecoders.remove(type)?.close()
                mirrorDecoders.keys.filter { it.first == type }.forEach { mirrorDecoders.remove(it)?.close() }
                lastVideoConfig.remove(type)
                pendingVideoCodec.remove(type)
            }
        }
        synchronized(screenStateLock) {
            if (sinkClosed) return
            if (active) activeScreenTypes.add(type) else activeScreenTypes.remove(type)
            screenStreamActiveChanged?.invoke(type, active)
        }
    }

    override fun onAudioStarted(id: AudioStreamId, format: AudioFormat, firstSample: Int) {
        audioRenderer(id, format).start()
        if (format.audioType == "media") updateMediaAudio(id, true)
    }

    override fun onAudioRtp(id: AudioStreamId, format: AudioFormat, rtp: ByteArray, sample: Int) {
        audioRenderer(id, format).submit(rtp, sample)
    }

    override fun onAudioStopped(id: AudioStreamId) {
        audioRenderers.remove(id)?.close()
        updateMediaAudio(id, false)
    }

    private fun updateMediaAudio(id: AudioStreamId, active: Boolean) {
        val (before, after) = synchronized(mediaAudioTypes) {
            val before = mediaAudioTypes.isNotEmpty()
            if (active) mediaAudioTypes.add(id) else mediaAudioTypes.remove(id)
            before to mediaAudioTypes.isNotEmpty()
        }
        if (before != after) onMediaAudioChanged(after)
    }

    override fun onMicrophoneStarted(id: AudioStreamId, config: MicrophoneConfig) {
        val startedAt = System.nanoTime()
        // This callback runs on the downlink thread; microphone failures must not stop playback.
        try {
            if (config.audioType == "telephony") enterCommunicationMode(id)
            val uplink = microphoneUplinks.computeIfAbsent(id) { MicrophoneUplink(config, reportAudio) }
            if (!uplink.start()) {
                microphoneUplinks.remove(id, uplink)
                restoreAudioMode(id)
            }
        } catch (error: Exception) {
            Log.e("xcertplay-usb", "microphone start failed stream=$id", error)
            MicrophoneCaptureStats.reportStartFailure(config, error, reportAudio)
            onMicrophoneStopped(id)
        } finally {
            runCatching { reportAudio("Microphone: lifecycle start elapsedMs=${(System.nanoTime() - startedAt) / 1_000_000}") }
        }
    }

    override fun onMicrophoneStopped(id: AudioStreamId) {
        val startedAt = System.nanoTime()
        try {
            microphoneUplinks.remove(id)?.close()
        } finally {
            restoreAudioMode(id)
            runCatching { reportAudio("Microphone: lifecycle stop elapsedMs=${(System.nanoTime() - startedAt) / 1_000_000}") }
        }
    }

    private fun enterCommunicationMode(id: AudioStreamId) {
        val manager = audioManager ?: return
        synchronized(audioModeLock) {
            if (communicationModeStream != null) return
            // Select the HAL communication path before AudioRecord is created.
            savedAudioMode = manager.mode
            manager.mode = AudioManager.MODE_IN_COMMUNICATION
            communicationModeStream = id
            Log.i("xcertplay-usb", "audio mode $savedAudioMode -> ${manager.mode} for telephony stream=$id")
        }
    }

    private fun restoreAudioMode(id: AudioStreamId?) {
        val manager = audioManager ?: return
        synchronized(audioModeLock) {
            val active = communicationModeStream ?: return
            if (id != null && id != active) return
            try {
                // setMode is owned per caller. Replaying the previous global mode
                // can adopt the OEM Bluetooth call's mode after that call has ended.
                // MODE_NORMAL releases our request and lets Android select any
                // remaining owner's mode.
                manager.mode = AudioManager.MODE_NORMAL
                communicationModeStream = null
                Log.i("xcertplay-usb", "audio communication mode released; current=${manager.mode}")
            } catch (error: RuntimeException) {
                Log.w("xcertplay-usb", "could not release audio communication mode", error)
            }
        }
    }

    fun close() {
        synchronized(videoOwnershipLock) {
            if (sinkClosed) return
            sinkClosed = true
            videoDecoders.values.forEach(VideoDecoder::close)
            videoDecoders.clear()
            mirrorDecoders.values.forEach(VideoDecoder::close)
            mirrorDecoders.clear()
            mirrorSurfaces.clear()
            surfaces.clear()
            defaultSurface = null
            lastVideoConfig.clear()
            pendingVideoCodec.clear()
            videoRecoveryHandlers.clear()
            videoDiagnosticHandlers.clear()
        }
        radioDiagnosticSource = { "wireless=closed" }
        resourceSampler?.close()
        audioFocusCoordinator.close()
        synchronized(mixingOwners) { mixingOwners.forEach(HongqiNavigationMixing::release); mixingOwners.clear() }
        synchronized(screenStateLock) {
            activeScreenTypes.forEach { screenStreamActiveChanged?.invoke(it, false) }
            activeScreenTypes.clear()
            screenStreamActiveChanged = null
        }
        recoveryExecutor.shutdownNow()
        audioRenderers.values.forEach(AudioRenderer::close)
        audioRenderers.clear()
        val hadMedia = synchronized(mediaAudioTypes) { mediaAudioTypes.isNotEmpty().also { mediaAudioTypes.clear() } }
        if (hadMedia) onMediaAudioChanged(false)
        try {
            microphoneUplinks.values.forEach(MicrophoneUplink::close)
        } finally {
            microphoneUplinks.clear()
            restoreAudioMode(null)
        }
    }

    /** Caller holds videoOwnershipLock. Only the main screen may wait for its startup Surface. */
    private fun videoDecoder(type: Int): VideoDecoder? {
        if (sinkClosed) return null
        val surface = surfaces[type] ?: defaultSurface
        if (type != 110 && surface == null) return null
        return videoDecoders[type]?.takeIf { it.isRunning } ?: newVideoDecoder(type, surface).also { decoder ->
            videoDecoders[type] = decoder
            lastVideoConfig[type]?.let { (codec, data) -> decoder.configure(codec, data) }
        }
    }

    private fun newVideoDecoder(type: Int, surface: Surface?, statsLabel: String? = null) = VideoDecoder(
        type,
        surface,
        videoSizes[type]?.first ?: videoWidth,
        videoSizes[type]?.second ?: videoHeight,
        preferSoftwareHevcDecoder,
        requestKeyFrame = { completed -> requestVideoRecovery(type, completed) },
        report = { videoDiagnosticHandlers[type]?.invoke(it) },
        statsLabel = statsLabel,
        context = appContext,
    )

    @Synchronized
    private fun audioRenderer(id: AudioStreamId, format: AudioFormat): AudioRenderer {
        val existing = audioRenderers[id]
        if (existing?.format == format && existing.isRunning) return existing
        existing?.close()
        lateinit var renderer: AudioRenderer
        renderer = AudioRenderer(
            format,
            advancedAudioChannelMapping,
            audioFocusEnabled,
            mediaChannel,
            navigationChannel,
            audioFocusCoordinator,
            navigationStreamType,
            mediaBufferMillis,
            reportAudio,
            speechAudioRouting,
            onChannelChanged = { channel ->
                if (audioRenderers[id] === renderer) updateMediaAudio(id, channel == AudioChannel.MEDIA)
            },
        )
        return renderer.also { audioRenderers[id] = it }
    }
}

private sealed interface VideoJob {
    data class Config(val codec: VideoCodec, val codecData: ByteArray) : VideoJob
    data class Frame(val nalus: ByteArray, val receivedNs: Long, val senderNs: Long) : VideoJob
}

/** Serial MediaCodec video decoder: one worker owns configure and frame feeding. */
private class VideoDecoder(
    streamType: Int,
    surface: Surface?,
    private val width: Int,
    private val height: Int,
    private val preferSoftwareHevcDecoder: Boolean,
    private val requestKeyFrame: ((Boolean) -> Unit) -> Boolean,
    private val report: (String) -> Unit,
    statsLabel: String? = null,
    context: Context? = null,
) : Closeable, VideoSurfaceHandoff.Owner {
    private val queue = VideoWorkQueue<VideoJob>(8)
    @Volatile private var running = true
    @Volatile private var decoder: MediaCodec? = null
    @Volatile private var requestedSurface: Surface? = surface
    @Volatile private var outputSurface: Surface? = surface
    private var heldFrame: VideoJob.Frame? = null
    private var pump: VideoDecodePump? = null
    private var syncGate: VideoSyncGate? = null
    private var needsKeyFrame = true
    private var pendingSinceNs = 0L
    private var lastPtsUs = 0L
    private var lastConfig: VideoJob.Config? = null
    private var renderedFrameLogged = false
    private var submittedFrameLogged = false
    private var duplicateConfigLogged = false
    private var awaitingConfig = false
    private var failureReports = 0
    private var lastKeyFrameRequestNs = 0L
    @Volatile private var keyFrameWriteFailed = false
    private var keyFrameWaitStartedNs = System.nanoTime()
    private val outputProgress = VideoOutputProgress()
    private val isMainScreen = streamType == 110 && statsLabel == null
    private var observedTouchNs = TouchLatencyProbe.latestTouchSentNs
    private var captureTouchNs = 0L
    private val traceSessionId = System.nanoTime()
    private val frameTrace = VideoFrameTrace(if (isMainScreen) context else null)
    private val exited = java.util.concurrent.CountDownLatch(1)
    val isRunning: Boolean get() = running
    // The main screen keeps the historical log format; other screens are labelled.
    private val stats = VideoStats(statsLabel ?: if (streamType == 110) "" else " stream=$streamType")
    private val thread = Thread(::run, "carplay-video").apply { isDaemon = true }
    init { VideoSurfaceHandoff.register(this); thread.start() }

    fun configure(codec: VideoCodec, codecData: ByteArray) {
        queue.control(VideoJob.Config(codec, codecData.copyOf()))
    }

    fun submit(nalus: ByteArray, arrivalNs: Long, senderNs: Long) {
        if (!running) return
        stats.onReceived(nalus.size, arrivalNs, senderNs)
        queue.frame(VideoJob.Frame(nalus, arrivalNs, senderNs))
    }

    override fun beginRelease(surface: Surface): Boolean {
        if (requestedSurface !== surface && outputSurface !== surface) return false
        close()
        return true
    }

    override fun awaitRelease(deadlineNs: Long): Boolean {
        if (Thread.currentThread() === thread) return false
        return exited.await((deadlineNs - System.nanoTime()).coerceAtLeast(0), java.util.concurrent.TimeUnit.NANOSECONDS)
    }

    fun setSurface(surface: Surface?) {
        requestedSurface = surface
    }

    override fun close() {
        running = false
        queue.close()
        thread.interrupt()
    }

    private fun run() {
        PlaybackResourceSampler.liveDecoderThreads.incrementAndGet()
        try {
            while (running) {
                try {
                    if (keyFrameWriteFailed) {
                        keyFrameWriteFailed = false
                        outputProgress.probeFailed()
                    }
                    if (outputSurface !== requestedSurface) changeSurface(requestedSurface)
                    if (isMainScreen) {
                        val touchNs = TouchLatencyProbe.latestTouchSentNs
                        if (touchNs != observedTouchNs) {
                            observedTouchNs = touchNs
                            outputProgress.beginEpisode(System.nanoTime())
                            // DOWN/UP and closely spaced move reports belong to the same capture.
                            if (touchNs - captureTouchNs > 300_000_000L &&
                                frameTrace.startCapture(traceSessionId, touchNs)) captureTouchNs = touchNs
                        }
                    }
                    if (needsKeyFrame && (lastConfig != null || awaitingConfig) && outputSurface != null) {
                        requestKeyFrameIfDue()
                    }
                    // Keep taking output even when the sender is idle or input buffers are busy.
                    pump?.tick()
                    if (!needsKeyFrame && outputSurface != null && outputProgress.shouldProbe(System.nanoTime()) &&
                        requestKeyFrameIfDue()) {
                        outputProgress.probeScheduled()
                        report("output pending without progress; keyframe probe queued ageMs=${outputProgress.ageNanos(System.nanoTime()) / 1_000_000}")
                    }
                    stats.logIfDue()?.let(report)
                    if (pump?.hasPending == true) {
                        check(System.nanoTime() - pendingSinceNs < INPUT_STALL_NS) {
                            "Video decoder input stalled"
                        }
                        Thread.sleep(2)
                        continue
                    }
                    if (heldFrame != null && outputSurface == null) {
                        Thread.sleep(5)
                        continue
                    }
                    when (val job = heldFrame ?: queue.poll(5)) {
                        is VideoJob.Config -> configureDecoder(job)
                        is VideoJob.Frame -> {
                            stats.onQueueAge(System.nanoTime() - job.receivedNs)
                            if (lastConfig == null) {
                                observeMissingConfig()
                            } else {
                                // Preserve the initial random access picture until a Surface exists.
                                heldFrame = if (outputSurface == null) job else null
                                if (outputSurface != null) feed(job)
                            }
                        }
                        null -> Unit
                    }
                } catch (error: InterruptedException) {
                    throw error
                } catch (error: Exception) {
                    if (running) {
                        Log.e(TAG, "video decoder failed; restarting at random access", error)
                        reportFailure("stage=decode", error)
                        recover("video decoder failed: ${error.javaClass.simpleName}")
                    }
                } catch (error: LinkageError) {
                    if (running) reportFailure("stage=decode", error)
                    throw error
                }
            }
        } catch (_: InterruptedException) {
            // Worker shut down.
        } finally {
            heldFrame = null
            queue.close()
            frameTrace.close()
            try { releaseDecoder() } finally {
                running = false
                PlaybackResourceSampler.liveDecoderThreads.decrementAndGet()
                VideoSurfaceHandoff.unregister(this)
                exited.countDown()
            }
        }
    }

    private fun configureDecoder(config: VideoJob.Config) {
        val previous = lastConfig
        if (
            decoder != null &&
            previous?.codec == config.codec &&
            previous.codecData.contentEquals(config.codecData)
        ) {
            if (!duplicateConfigLogged) {
                duplicateConfigLogged = true
                Log.i(TAG, "video decoder config unchanged; keeping existing decoder")
            }
            return
        }
        val rebuildStarted = System.nanoTime()
        lastConfig = config
        awaitingConfig = false
        duplicateConfigLogged = false
        releaseDecoder()
        needsKeyFrame = true
        keyFrameWaitStartedNs = System.nanoTime()
        val surface = outputSurface ?: return
        val codec = config.codec
        val codecData = config.codecData
        val mime = if (codec == VideoCodec.H265) MediaFormat.MIMETYPE_VIDEO_HEVC
        else MediaFormat.MIMETYPE_VIDEO_AVC
        val csd = if (codec == VideoCodec.H265) {
            MediaCodecSupport.hevcCodecSpecificData(codecData).takeIf { it.isNotEmpty() }
                ?.let { listOf(it) } ?: emptyList()
        } else {
            val (sps, pps) = MediaCodecSupport.avcParameterSets(codecData)
            listOfNotNull(
                sps.takeIf { it.isNotEmpty() }?.let { START_CODE + it },
                pps.takeIf { it.isNotEmpty() }?.let { START_CODE + it },
            )
        }
        require(csd.isNotEmpty() && (codec != VideoCodec.H264 || csd.size == 2)) {
            "Missing or invalid video parameter sets"
        }
        frameTrace.onConfig(codec, csd)
        val parameters = VideoParameters.parse(codec, csd.first())
        // Some vendor decoders (e.g. MediaTek c2.mtk.avc.decoder) reject the tuned
        // parameters with BAD_VALUE. Fall back to a minimal format, then to software.
        val lowLatencyName = if (codec == VideoCodec.H265 && preferSoftwareHevcDecoder) null
            else lowLatencyDecoderName(mime, parameters)
        val attempts = listOfNotNull(lowLatencyName?.let { DecoderAttempt(it, tuned = true) }) + listOf(
            DecoderAttempt(codecName = null, tuned = true),
            DecoderAttempt(codecName = null, tuned = false),
        ) + softwareDecoderName(mime)?.let { listOf(DecoderAttempt(it, tuned = false)) }.orEmpty()
        var next: MediaCodec? = null
        for (attempt in attempts) {
            next = tryConfigure(mime, csd, parameters, surface, attempt)
            if (next != null) break
        }
        if (next == null) {
            report("decoder configuration failed mime=$mime size=${width}x$height")
        }
        decoder = next
        if (next != null) {
            val active = next
            syncGate = VideoSyncGate(codec)
            pump = VideoDecodePump(object : VideoDecodePump.Port {
                override fun drain() = drainOutput(active)
                override fun queue(bytes: ByteArray, presentationTimeUs: Long): Boolean {
                    val index = active.dequeueInputBuffer(0)
                    if (index < 0) return false
                    val input = checkNotNull(active.getInputBuffer(index)) { "Decoder input buffer unavailable" }
                    input.clear()
                    check(bytes.size <= input.remaining()) { "Video access unit exceeds decoder input capacity" }
                    input.put(bytes)
                    active.queueInputBuffer(index, 0, bytes.size, presentationTimeUs, 0)
                    val now = System.nanoTime()
                    outputProgress.onInput(presentationTimeUs, now)
                    stats.onCodecInput(presentationTimeUs, now)
                    frameTrace.onInput(presentationTimeUs, now)
                    stats.onInputWait(now - pendingSinceNs)
                    return true
                }
            })
        }
        stats.onRebuild(System.nanoTime() - rebuildStarted)
        if (next != null) runCatching {
            next.setOnFrameRenderedListener({ codec, ptsUs, nanoTime ->
                if (running && decoder === codec) {
                    stats.onPresented(nanoTime, ptsUs)
                    frameTrace.onPresent(ptsUs, nanoTime)
                }
            }, PlaybackResourceSampler.handler)
        }.onFailure { report("frame rendered callback unavailable ${it.javaClass.simpleName}") }
        outputProgress.reset()
        renderedFrameLogged = false
        submittedFrameLogged = false
        if (next != null) {
            report("decoder=${next.name} mime=$mime coded=${parameters.width}x${parameters.height} negotiated=${width}x$height")
            Log.i(
                TAG,
                "video decoder configured name=${next.name} mime=$mime size=${width}x$height",
            )
        }
    }

    private data class DecoderAttempt(val codecName: String?, val tuned: Boolean)

    private fun buildFormat(mime: String, csd: List<ByteArray>, parameters: VideoParameters, tuned: Boolean): MediaFormat =
        MediaFormat.createVideoFormat(mime, parameters.width, parameters.height).apply {
            if (tuned) {
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, MAX_INPUT_SIZE)
                setInteger(MediaFormat.KEY_PRIORITY, 0)
            }
            csd.forEachIndexed { index, bytes -> setByteBuffer("csd-$index", ByteBuffer.wrap(bytes)) }
            if (parameters.colorStandard != -1) setInteger(MediaFormat.KEY_COLOR_STANDARD, parameters.colorStandard)
            if (parameters.colorRange != -1) setInteger(MediaFormat.KEY_COLOR_RANGE, parameters.colorRange)
            if (parameters.colorTransfer != -1) setInteger(MediaFormat.KEY_COLOR_TRANSFER, parameters.colorTransfer)
        }

    private fun tryConfigure(
        mime: String,
        csd: List<ByteArray>,
        parameters: VideoParameters,
        surface: Surface,
        attempt: DecoderAttempt,
    ): MediaCodec? {
        var candidate: MediaCodec? = null
        return try {
            val format = buildFormat(mime, csd, parameters, attempt.tuned)
            val codec = attempt.codecName?.let { MediaCodec.createByCodecName(it) } ?: createDecoder(mime)
            candidate = codec
            val lowLatency = attempt.tuned && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
                codec.codecInfo.getCapabilitiesForType(mime).isFeatureSupported("low-latency")
            if (lowLatency) {
                format.setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
            }
            codec.configure(format, surface, null, 0)
            codec.start()
            report("decoder started name=${codec.name} lowLatency=$lowLatency tuned=${attempt.tuned}")
            codec
        } catch (error: Exception) {
            runCatching { candidate?.release() }
            reportFailure("stage=configure tuned=${attempt.tuned} mime=$mime", error)
            Log.w(
                TAG,
                "video decoder configure failed name=${attempt.codecName ?: "default"} " +
                    "tuned=${attempt.tuned} mime=$mime size=${width}x$height",
                error,
            )
            null
        }
    }

    private fun lowLatencyDecoderName(mime: String, parameters: VideoParameters): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        return runCatching {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.firstOrNull { info ->
                !info.isEncoder && info.isHardwareAccelerated && !info.isAlias && mime in info.supportedTypes && runCatching {
                    info.getCapabilitiesForType(mime).let { capabilities ->
                        capabilities.isFeatureSupported("low-latency") &&
                            capabilities.videoCapabilities?.isSizeSupported(parameters.width, parameters.height) == true
                    }
                }.getOrDefault(false)
            }?.name
        }.getOrNull()
    }

    private fun softwareDecoderName(mime: String): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.firstOrNull {
            !it.isEncoder && it.isSoftwareOnly && mime in it.supportedTypes
        }?.name
    }

    private fun createDecoder(mime: String): MediaCodec {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
            mime == MediaFormat.MIMETYPE_VIDEO_HEVC &&
            preferSoftwareHevcDecoder
        ) {
            val software = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.firstOrNull {
                !it.isEncoder && it.isSoftwareOnly && mime in it.supportedTypes
            }
            if (software != null) {
                try {
                    return MediaCodec.createByCodecName(software.name)
                } catch (error: Exception) {
                    Log.w(TAG, "software HEVC decoder unavailable name=${software.name}", error)
                }
            }
        }
        return MediaCodec.createDecoderByType(mime)
    }

    private fun changeSurface(surface: Surface?) {
        if (outputSurface === surface) return
        if (surface == null) {
            releaseDecoder()
            outputSurface = null
            Log.i(TAG, "video decoder detached from surface")
            return
        }
        val codec = decoder
        if (codec != null) {
            try {
                codec.setOutputSurface(surface)
                outputSurface = surface
                Log.i(TAG, "video decoder output surface updated")
                return
            } catch (error: Exception) {
                Log.w(TAG, "video decoder output surface update failed; reconfiguring", error)
            }
        }
        releaseDecoder()
        outputSurface = surface
        lastConfig?.let(::configureDecoder)
    }

    private fun observeMissingConfig() {
        if (!awaitingConfig) {
            awaitingConfig = true
            Log.i(TAG, "video frames without codec config; requesting keyframe")
            report("frames without codec config; requesting keyframe")
        }
        needsKeyFrame = true
    }

    private fun feed(frame: VideoJob.Frame) {
        val config = lastConfig ?: return
        if (outputSurface == null) return
        if (decoder == null) configureDecoder(config)
        val activePump = pump ?: return
        val annexB = MediaCodecSupport.toAnnexB(frame.nalus)
        require(annexB.isNotEmpty()) { "Invalid video access unit" }
        if (syncGate?.accept(annexB) != true) {
            // Skipping RASL after CRA preserves sync; it does not need another keyframe.
            if (syncGate?.waitingForRandomAccess == true) needsKeyFrame = true
            return
        }
        if (needsKeyFrame) stats.onKeyFrameWait(System.nanoTime() - keyFrameWaitStartedNs)
        needsKeyFrame = false
        if (!submittedFrameLogged) {
            submittedFrameLogged = true
            Log.i(
                TAG,
                "video decoder first random access input bytes=${annexB.size}",
            )
        }
        lastPtsUs = maxOf(lastPtsUs + 1, frame.receivedNs / 1_000)
        frameTrace.onFrame(annexB, frame.receivedNs, frame.senderNs, lastPtsUs)
        activePump.submit(annexB, lastPtsUs)
        pendingSinceNs = System.nanoTime()
        activePump.tick()
    }

    private fun recover(reason: String) {
        Log.w(TAG, "Video recovery: $reason; waiting for keyframe")
        stats.onRecovery()
        report("recovery: $reason; waiting for keyframe")
        // Recreate with codec-specific data: flush can discard CSD before the first output.
        releaseDecoder()
        needsKeyFrame = true
        keyFrameWaitStartedNs = System.nanoTime()
        requestKeyFrameIfDue()
    }

    private fun requestKeyFrameIfDue(): Boolean {
        val now = System.nanoTime()
        if (lastKeyFrameRequestNs != 0L && now - lastKeyFrameRequestNs < 1_000_000_000L) return false
        if (!requestKeyFrame { sent -> if (!sent) keyFrameWriteFailed = true }) return false
        lastKeyFrameRequestNs = now
        return true
    }

    private fun drainOutput(codec: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        while (running) {
            val index = codec.dequeueOutputBuffer(info, 0)
            when {
                index == MediaCodec.INFO_TRY_AGAIN_LATER -> return
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> logOutputFormat(codec.outputFormat)
                index >= 0 -> {
                    val render = outputSurface != null && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0
                    codec.releaseOutputBuffer(index, render)
                    if (render) {
                        outputProgress.onOutput(info.presentationTimeUs, System.nanoTime())
                        stats.onCodecOutput(info.presentationTimeUs)
                        frameTrace.onOutput(info.presentationTimeUs, System.nanoTime())
                        stats.onRendered()
                    }
                    if (render && !renderedFrameLogged) {
                        renderedFrameLogged = true
                        report("first frame rendered")
                        Log.i(TAG, "video decoder rendered first frame bytes=${info.size}")
                    }
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
                else -> return
            }
        }
    }

    private fun logOutputFormat(format: MediaFormat) {
        report("output format requested=${width}x${height} " +
            "coded=${format.intOrNull(MediaFormat.KEY_WIDTH)}x${format.intOrNull(MediaFormat.KEY_HEIGHT)} " +
            "crop=${format.intOrNull("crop-left")},${format.intOrNull("crop-top")}," +
            "${format.intOrNull("crop-right")},${format.intOrNull("crop-bottom")} " +
            "stride=${format.intOrNull(MediaFormat.KEY_STRIDE)} slice=${format.intOrNull(MediaFormat.KEY_SLICE_HEIGHT)} " +
            "color=${format.intOrNull(MediaFormat.KEY_COLOR_STANDARD)}/${format.intOrNull(MediaFormat.KEY_COLOR_RANGE)}/${format.intOrNull(MediaFormat.KEY_COLOR_TRANSFER)}")
        Log.i(
            TAG,
            "video decoder output format " +
                "size=${format.intOrNull(MediaFormat.KEY_WIDTH)}x" +
                "${format.intOrNull(MediaFormat.KEY_HEIGHT)} " +
                "stride=${format.intOrNull(MediaFormat.KEY_STRIDE)} " +
                "slice=${format.intOrNull(MediaFormat.KEY_SLICE_HEIGHT)} " +
                "standard=${format.intOrNull(MediaFormat.KEY_COLOR_STANDARD)} " +
                "range=${format.intOrNull(MediaFormat.KEY_COLOR_RANGE)} " +
                "transfer=${format.intOrNull(MediaFormat.KEY_COLOR_TRANSFER)}",
        )
    }

    private fun reportFailure(context: String, error: Throwable) {
        // A bad decoder can fail again on every frame; exported detail stays bounded per worker.
        if (failureReports >= 8) return
        failureReports++
        runCatching { report("decoder failed api=${Build.VERSION.SDK_INT} $context " +
            MediaFailureSummary.describe(error)) }
    }

    @Synchronized
    private fun releaseDecoder() {
        val codec = decoder
        decoder = null
        pump = null
        syncGate = null
        stats.onDecoderReset()
        outputProgress.reset()
        if (codec != null) {
            try {
                codec.stop()
            } catch (_: Exception) {
                // Best effort.
            }
            try {
                codec.release()
            } catch (_: Exception) {
                // Best effort.
            }
        }
    }

    private companion object {
        const val TAG = "xcertplay-usb"
        const val MAX_INPUT_SIZE = 8 * 1024 * 1024
        const val INPUT_STALL_NS = 2_000_000_000L
        val START_CODE = byteArrayOf(0x00, 0x00, 0x00, 0x01)
    }
}

private fun MediaFormat.intOrNull(key: String): Int? =
    if (!containsKey(key)) {
        null
    } else {
        try {
            getInteger(key)
        } catch (_: Exception) {
            null
        }
    }

/** Decodes AAC-LC/Opus to PCM and plays it, or plays wired LPCM directly. */
private class AudioRenderer(
    val format: AudioFormat,
    private val advancedAudioChannelMapping: Boolean,
    private val audioFocusEnabled: Boolean,
    private val mediaChannel: Int,
    private val navigationChannel: Int,
    private val audioFocusCoordinator: AudioFocusCoordinator,
    private val navigationStreamType: Int,
    private val mediaBufferMillis: Int,
    private val report: (String) -> Unit,
    private val speechAudioRouting: SpeechAudioRoutingState,
    private val onChannelChanged: (AudioChannel) -> Unit,
) : Closeable {
    private data class AudioPacket(val rtp: ByteArray, val sample: Int)

    private var trackAttributes: AudioAttributes? = null
    private var mappedChannel: AudioChannel? = null
    private val queue = LinkedBlockingQueue<AudioPacket>(MAX_QUEUED_PACKETS)
    @Volatile private var running = true
    @Volatile private var started = false
    private var codec: MediaCodec? = null
    private var track: AudioTrack? = null
    private var pcm = ByteArray(64 * 1024)
    private var playbackStarted = false
    private var prebufferBytes = 0
    private var startThresholdBytes = 0
    private var fadeApplied = false
    private var droppedPacketsLogged = false
    private var firstAacPayloadLogged = false
    private var firstOpusShortPacketLogged = false
    private var firstInputQueuedLogged = false
    private var inputQueued = 0
    private var inputDropped = 0
    private var inputRetries = 0
    private var shortOpusPackets = 0
    private var decoderUnavailablePackets = 0
    private var outputBuffers = 0
    private var firstPcmLogged = false
    private val packetsReceived = AtomicInteger()
    private val packetsDropped = AtomicInteger()
    private val lastArrivalNs = AtomicLong()
    private val maxArrivalGapMs = AtomicLong()
    private val frameBytes = if (format.channels >= 2) 4 else 2
    private var totalWrittenFrames = 0L
    private var writtenFramesThisWindow = 0L
    private var writeErrorsThisWindow = 0
    private var lastWriteErrorCode: Int? = null
    private var zeroWritesThisWindow = 0
    private var partialWritesThisWindow = 0
    private var lastPlaybackHeadFrames: Long? = null
    private var maxWriteMs = 0L
    private var statsWindowStartNs = 0L
    private var statsLastUnderruns = 0
    private var bytesPerSecond = 0
    private var bufferProgress = AudioBufferProgress(if (format.channels >= 2) 4 else 2)
    private var underrunsAtPlaybackStart = 0
    private var lastPcmWriteNs = 0L
    private var rebufferCount = 0
    private var diagnosticStage = "starting"
    private var lastDecoderOutputMetadata: String? = null
    private var decoderOutputReports = 0
    private val thread = Thread(::run, "carplay-audio").apply { isDaemon = true }
    private val streamStartedAt = android.os.SystemClock.uptimeMillis()
    val isRunning: Boolean get() = running

    fun start() {
        if (started) return
        started = true
        thread.start()
    }

    fun submit(rtp: ByteArray, sample: Int) {
        if (started) {
            packetsReceived.incrementAndGet()
            val now = System.nanoTime()
            val previous = lastArrivalNs.getAndSet(now)
            if (previous != 0L) maxArrivalGapMs.accumulateAndGet((now - previous) / 1_000_000L, ::maxOf)
        }
        if (!started || !queue.offer(AudioPacket(rtp, sample))) {
            if (started) packetsDropped.incrementAndGet()
            if (started && !droppedPacketsLogged) {
                droppedPacketsLogged = true
                Log.w(TAG, "audio queue full; dropping newest packets to bound latency")
                report("Audio: queue full audioType=${format.audioType}")
            }
        }
    }

    override fun close() {
        running = false
        thread.interrupt()
    }

    private fun run() {
        try {
            try {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO)
            } catch (error: SecurityException) {
                Log.w(TAG, "audio thread priority unavailable", error)
            }
            runCatching { report("Audio: starting api=${Build.VERSION.SDK_INT} " +
                "audioType=${format.audioType} codec=${format.codec} rate=${format.sampleRate} channels=${format.channels} " +
                "mapping=${if (advancedAudioChannelMapping) "automotive" else "mobile"} " +
                "mediaChannel=$mediaChannel navigationChannel=$navigationChannel focus=$audioFocusEnabled") }
            when (format.codec) {
                AudioCodecKind.AAC_LC -> configureCodec(MediaFormat.MIMETYPE_AUDIO_AAC)
                AudioCodecKind.OPUS -> configureCodec(MediaFormat.MIMETYPE_AUDIO_OPUS)
                AudioCodecKind.LPCM -> Unit
            }
            if (format.codec != AudioCodecKind.LPCM && codec == null) {
                // Leave the renderer replaceable. A vendor codec can be temporarily
                // unavailable while the audio service is restarting; keeping this dead
                // instance in the sink would drop every later packet forever.
                running = false
                return
            }
            while (running && format.audioType == "speechrecognition" &&
                speechAudioRouting.route(streamStartedAt) == SpeechAudioRoute.WAIT) Thread.sleep(10)
            if (!running) return
            createTrack()
            if (track == null) {
                running = false
                return
            }
            diagnosticStage = "focus"
            requestAudioFocus()
            while (running) {
                refreshSpeechRoute()
                if (track == null) {
                    // A speech route switch can invalidate the native track. Let the
                    // next RTP packet replace this renderer instead of spinning silently.
                    running = false
                    break
                }
                diagnosticStage = "packet"
                queue.poll(AUDIO_POLL_MILLIS, TimeUnit.MILLISECONDS)?.let(::handle)
                // Output becomes ready asynchronously, including after the last packet of a burst.
                // Waiting for the next UDP packet can strand decoded sound for hundreds of ms.
                diagnosticStage = "decoder-output"
                codec?.let(::drainCodec)
                diagnosticStage = "buffer-maintenance"
                maintainPlaybackBuffer()
                diagnosticStage = "stats"
                logStatsIfDue()
            }
        } catch (_: InterruptedException) {
            // Worker shut down.
        } catch (error: Exception) {
            if (running) {
                running = false
                Log.e(TAG, "audio renderer worker failed", error)
                reportFailure(error)
            }
        } catch (error: LinkageError) {
            // Record an unsupported platform API without changing the existing crash semantics.
            if (running) {
                running = false
                reportFailure(error)
            }
            throw error
        } finally {
            runCatching { logStatsIfDue(force = true) }
            release()
        }
    }

    private fun configureCodec(mime: String) {
        diagnosticStage = "decoder-format"
        val mediaFormat = MediaFormat().apply {
            setString(MediaFormat.KEY_MIME, mime)
            setInteger(MediaFormat.KEY_SAMPLE_RATE, format.sampleRate)
            setInteger(MediaFormat.KEY_CHANNEL_COUNT, format.channels)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 64 * 1024)
            if (mime == MediaFormat.MIMETYPE_AUDIO_AAC) {
                setInteger(MediaFormat.KEY_IS_ADTS, 1)
                setByteBuffer("csd-0", ByteBuffer.wrap(aacAudioSpecificConfig()))
            } else {
                setByteBuffer("csd-0", ByteBuffer.wrap(opusHead()))
                setByteBuffer("csd-1", ByteBuffer.wrap(opusCodecDelay()))
                setByteBuffer("csd-2", ByteBuffer.wrap(opusSeekPreRoll()))
            }
        }
        if (mime == MediaFormat.MIMETYPE_AUDIO_AAC) {
            Log.i(
                TAG,
                "audio AAC config rate=${format.sampleRate} channels=${format.channels} " +
                    "csd0=${aacAudioSpecificConfig().toHexString()}",
            )
        }
        codec = try {
            MediaCodecStartup.create(
                create = { diagnosticStage = "decoder-create"; MediaCodec.createDecoderByType(mime) },
                configure = { diagnosticStage = "decoder-configure"; it.configure(mediaFormat, null, null, 0) },
                start = { diagnosticStage = "decoder-start"; it.start() },
                release = { it.release() },
            ).also {
                // A vendor name getter or diagnostic callback must not discard a started codec.
                runCatching {
                    val name = it.name
                    Log.i(TAG, "audio decoder configured mime=$mime name=$name")
                    report("Audio: decoder ready audioType=${format.audioType} codec=${format.codec} name=$name")
                }
            }
        } catch (error: Exception) {
            Log.e(TAG, "audio decoder configuration failed mime=$mime", error)
            reportFailure(error)
            null
        }
    }

    private fun createTrack() {
        diagnosticStage = "track-buffer-size"
        val encoding = AndroidAudioFormat.ENCODING_PCM_16BIT
        val channelMask = if (format.channels >= 2) AndroidAudioFormat.CHANNEL_OUT_STEREO
        else AndroidAudioFormat.CHANNEL_OUT_MONO
        val minBuffer = AudioTrack.getMinBufferSize(format.sampleRate, channelMask, encoding)
        if (minBuffer <= 0) {
            Log.e(TAG, "AudioTrack buffer size unavailable rate=${format.sampleRate} channels=${format.channels}")
            runCatching { report("Audio: track unavailable api=${Build.VERSION.SDK_INT} stage=$diagnosticStage " +
                "audioType=${format.audioType} codec=${format.codec} rate=${format.sampleRate} " +
                "channels=${format.channels} minBufferResult=$minBuffer") }
            return
        }
        val selection = mappedSelection()
        mappedChannel = selection.channel
        val streamOverride = channelOverride(selection.channel)
        var attributes = audioAttributesFor(selection, streamOverride)
        trackAttributes = attributes
        val plan = if (selection.channel == AudioChannel.NAVIGATION) {
            NavigationAudioBuffer.plan(format.sampleRate, format.channels, minBuffer)
        } else {
            MediaAudioBuffer.plan(selection.channel == AudioChannel.MEDIA,
                format.sampleRate, format.channels, minBuffer, mediaBufferMillis)
        }
        bytesPerSecond = format.sampleRate * frameBytes
        val built: AudioTrack
        var routeLabel: String
        diagnosticStage = "track-build"
        if (streamOverride == 0) {
            attributes = audioAttributesFor(selection)
            routeLabel = "usage"
            built = AudioTrack.Builder()
                .setAudioAttributes(attributes)
                .setAudioFormat(pcmFormat(encoding, channelMask))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(plan.trackBufferBytes)
                .build()
        } else {
            val streamType = streamOverride
            routeLabel = "streamType=$streamType"
            built = LegacyAudioFallback.build(
                createLegacy = {
                    AudioTrack(streamType, format.sampleRate, channelMask, encoding,
                        plan.trackBufferBytes, AudioTrack.MODE_STREAM)
                },
                isInitialized = { it.state == AudioTrack.STATE_INITIALIZED },
                release = { it.release() },
                createFallback = {
                    diagnosticStage = "track-fallback-build"
                    routeLabel = "streamType=$streamType(fallback=usage)"
                    Log.w(TAG, "streamType=$streamType rejected by this ROM; falling back to usage-based track")
                    attributes = audioAttributesFor(selection)
                    AudioTrack.Builder()
                        .setAudioAttributes(attributes)
                        .setAudioFormat(pcmFormat(encoding, channelMask))
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .setBufferSizeInBytes(plan.trackBufferBytes)
                        .build()
                },
            )
        }
        track = built
        diagnosticStage = "track-attributes"
        trackAttributes = audioTrackAttributesForFocus(built, attributes)
        diagnosticStage = "track-capacity"
        val capacityBytes = built.bufferSizeInFrames * frameBytes
        startThresholdBytes = MediaAudioBuffer.startBytesFor(plan.startBytes, capacityBytes, PREBUFFER_WRITE_CHUNK_BYTES)
        val trackMetadata = runCatching {
            "api=${Build.VERSION.SDK_INT} trackState=${built.state} trackRate=${built.sampleRate} " +
                "usage=${trackAttributes?.usage} contentType=${trackAttributes?.contentType} " +
                "attributesSource=${if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) "track" else "configured"}"
        }.getOrDefault("api=${Build.VERSION.SDK_INT} trackMetadata=unavailable")
        report("Audio: ready audioType=${format.audioType} codec=${format.codec} " +
            "rate=${format.sampleRate} channels=${format.channels} " +
            "route=$routeLabel " +
            "bufferMs=${capacityBytes * 1000L / bytesPerSecond} startMs=${startThresholdBytes * 1000L / bytesPerSecond} " +
            trackMetadata)
        Log.i(
            TAG,
            "audio track prepared type=${format.payloadType} audioType=${format.audioType} " +
                "codec=${format.codec} " +
                "rate=${format.sampleRate} channels=${format.channels} " +
                "route=$routeLabel " +
                "buffer=${capacityBytes * 1000L / bytesPerSecond}ms start=${startThresholdBytes * 1000L / bytesPerSecond}",
        )
        Log.i(
            TAG,
            "audio route type=${format.payloadType} audioType=${format.audioType} " +
                "mode=${if (advancedAudioChannelMapping) AudioChannelMappingMode.AUTOMOTIVE_BUS else AudioChannelMappingMode.MOBILE_COMPATIBLE} " +
                "channel=${selection.channel} usage=${usageFor(selection.channel)} " +
                "contentType=${contentTypeFor(selection.contentType)} " +
                "streamOverride=$streamOverride " +
                "focus=${if (audioFocusEnabled) "on" else "off"}",
        )
        if (format.audioType == "speechrecognition")
            report("Audio: speech output channel=${selection.channel} usage=${usageFor(selection.channel)} " +
                "reason=${if (selection.channel == AudioChannel.MEDIA) "ongoing-music" else "voice-or-unknown"}")
        onChannelChanged(selection.channel)
    }

    /** 0 uses usage-based routing; 1–20 attempt legacy stream types supported by the head unit. */
    private fun channelOverride(channel: AudioChannel): Int = when (channel) {
        AudioChannel.MEDIA -> mediaChannel
        AudioChannel.NAVIGATION -> navigationChannel
        else -> 0
    }

    private fun audioAttributesFor(
        selection: AudioChannelSelection,
        streamOverride: Int,
    ): AudioAttributes {
        if (streamOverride in AudioManager.STREAM_SYSTEM..AudioManager.STREAM_ACCESSIBILITY) {
            // Android accepts only its defined legacy stream IDs here. BYD audio policy can
            // map these standard streams to vehicle outputs; arbitrary channel numbers are
            // not valid AudioAttributes legacy stream types.
            try {
                return AudioAttributes.Builder().setLegacyStreamType(streamOverride).build()
            } catch (error: Exception) {
                Log.w(TAG, "legacy audio stream $streamOverride rejected; keeping usage routing", error)
            }
        }
        return AudioAttributes.Builder()
            .setUsage(usageFor(selection.channel))
            .setContentType(contentTypeFor(selection.contentType))
            .build()
    }

    private fun mappedSelection(): AudioChannelSelection {
        if (format.audioType == "speechrecognition") {
            val route = speechAudioRouting.route(streamStartedAt)
            if (route == SpeechAudioRoute.MEDIA || (route == SpeechAudioRoute.WAIT && mappedChannel == AudioChannel.MEDIA))
                return AudioChannelSelection(AudioChannel.MEDIA, AudioContentType.MUSIC)
        }
        val mode = if (advancedAudioChannelMapping) {
            AudioChannelMappingMode.AUTOMOTIVE_BUS
        } else {
            AudioChannelMappingMode.MOBILE_COMPATIBLE
        }
        return AudioChannelMapper.map(
            audioType = format.audioType,
            payloadType = format.payloadType,
            mode = mode,
        )
    }

    /** AudioAttributes are immutable: replace only the output track, retaining decoder and RTP. */
    private fun refreshSpeechRoute() {
        if (format.audioType != "speechrecognition" || track == null || mappedSelection().channel == mappedChannel) return
        val previous = mappedChannel
        logStatsIfDue(force = true)
        releaseTrack()
        playbackStarted = false
        prebufferBytes = 0
        bufferProgress = AudioBufferProgress(frameBytes)
        totalWrittenFrames = 0
        writtenFramesThisWindow = 0
        lastPlaybackHeadFrames = null
        statsLastUnderruns = 0
        statsWindowStartNs = 0
        lastPcmWriteNs = 0
        underrunsAtPlaybackStart = 0
        createTrack()
        requestAudioFocus()
        report("Audio: speech output changed previous=$previous channel=$mappedChannel")
    }

    private fun audioAttributesFor(selection: AudioChannelSelection): AudioAttributes =
        AudioAttributes.Builder()
            .setUsage(usageFor(selection.channel))
            .setContentType(contentTypeFor(selection.contentType))
            .build()

    /** The coordinator decides whether navigation needs a vehicle volume context. */
    private fun requestAudioFocus() {
        val channel = mappedChannel ?: return
        val attributes = trackAttributes ?: return
        track?.let { audioFocusCoordinator.acquire(it, channel, attributes) }
    }

    private fun abandonAudioFocus() {
        track?.let(audioFocusCoordinator::release)
    }

    private fun pcmFormat(encoding: Int, channelMask: Int) = AndroidAudioFormat.Builder()
        .setSampleRate(format.sampleRate)
        .setChannelMask(channelMask)
        .setEncoding(encoding)
        .build()

    private fun streamType(): Int {
        val mode = if (advancedAudioChannelMapping) {
            AudioChannelMappingMode.AUTOMOTIVE_BUS
        } else {
            AudioChannelMappingMode.MOBILE_COMPATIBLE
        }
        return AudioChannelMapper.map(
            audioType = format.audioType,
            payloadType = format.payloadType,
            mode = mode,
            navigationStreamType = navigationStreamType,
        ).streamType
    }

    private fun aacAudioSpecificConfig(): ByteArray {
        val frequencyIndex = MediaCodecSupport.aacFrequencyIndex(format.sampleRate)
        val value = (AAC_OBJECT_TYPE_LC shl 11) or
            (frequencyIndex shl 7) or
            (format.channels.coerceIn(1, 7) shl 3)
        return byteArrayOf((value ushr 8).toByte(), value.toByte())
    }

    private fun usageFor(channel: AudioChannel): Int = when (channel) {
        AudioChannel.MEDIA -> AudioAttributes.USAGE_MEDIA
        AudioChannel.PHONE -> AudioAttributes.USAGE_VOICE_COMMUNICATION
        AudioChannel.ASSISTANT -> AudioAttributes.USAGE_ASSISTANT
        AudioChannel.NAVIGATION -> AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE
    }

    private fun contentTypeFor(contentType: AudioContentType): Int = when (contentType) {
        AudioContentType.MUSIC -> AudioAttributes.CONTENT_TYPE_MUSIC
        AudioContentType.SPEECH -> AudioAttributes.CONTENT_TYPE_SPEECH
    }

    /** Minimal OpusHead CSD for the mono 48 kHz stream CarPlay negotiates. */
    private fun opusHead(): ByteArray {
        val head = ByteArray(19)
        "OpusHead".toByteArray(Charsets.US_ASCII).copyInto(head, 0)
        head[8] = 1
        head[9] = format.channels.toByte()
        head[10] = 0x38
        head[11] = 0x01
        head[12] = format.sampleRate.toByte()
        head[13] = (format.sampleRate ushr 8).toByte()
        head[14] = (format.sampleRate ushr 16).toByte()
        head[15] = (format.sampleRate ushr 24).toByte()
        return head
    }

    private fun opusCodecDelay(): ByteArray =
        java.nio.ByteBuffer.allocate(8)
            .order(java.nio.ByteOrder.LITTLE_ENDIAN)
            .putLong(OPUS_CODEC_DELAY_NANOS)
            .array()

    private fun opusSeekPreRoll(): ByteArray =
        java.nio.ByteBuffer.allocate(8)
            .order(java.nio.ByteOrder.LITTLE_ENDIAN)
            .putLong(OPUS_SEEK_PRE_ROLL_NANOS)
            .array()

    private fun handle(packet: AudioPacket) {
        val rtp = packet.rtp
        val timestampUs = sampleTimestampUs(packet.sample)
        when (format.codec) {
            AudioCodecKind.LPCM -> writePcm(byteSwapS16(rtp.copyOfRange(12, rtp.size)))
            AudioCodecKind.AAC_LC -> {
                val accessUnit = rtp.copyOfRange(12, rtp.size)
                if (accessUnit.isNotEmpty()) {
                    if (!firstAacPayloadLogged) {
                        firstAacPayloadLogged = true
                        Log.i(
                            TAG,
                            "audio AAC access unit bytes=${accessUnit.size}",
                        )
                    }
                    feedCodec(
                        MediaCodecSupport.adtsFrame(accessUnit, format.sampleRate, format.channels),
                        timestampUs,
                    )
                }
            }
            AudioCodecKind.OPUS -> {
                val accessUnit = rtp.copyOfRange(12, rtp.size)
                if (accessUnit.size < MIN_OPUS_PACKET_BYTES) {
                    shortOpusPackets++
                    if (!firstOpusShortPacketLogged) {
                        firstOpusShortPacketLogged = true
                        Log.i(
                            TAG,
                            "audio Opus skipping short packet bytes=${accessUnit.size}",
                        )
                    }
                    return
                }
                feedCodec(accessUnit, timestampUs)
            }
        }
    }

    private fun sampleTimestampUs(sample: Int): Long =
        (sample.toLong() and 0xffff_ffffL) * 1_000_000L / format.sampleRate

    private fun feedCodec(payload: ByteArray, presentationTimeUs: Long) {
        val codec = codec ?: run { decoderUnavailablePackets++; return }
        val index = AudioInputPump.acquire(
            running = { running },
            dequeue = {
                diagnosticStage = "decoder-input"
                codec.dequeueInputBuffer(INPUT_TIMEOUT_US)
            },
            drain = {
                inputRetries++
                drainCodec(codec)
                maintainPlaybackBuffer()
            },
        )
        if (index < 0 || !running) return
        val input = checkNotNull(codec.getInputBuffer(index)) { "Audio decoder input buffer unavailable" }
        input.clear()
        if (payload.size <= input.remaining()) {
            input.put(payload)
            codec.queueInputBuffer(index, 0, payload.size, presentationTimeUs, 0)
            inputQueued++
            if (!firstInputQueuedLogged) {
                firstInputQueuedLogged = true
                Log.i(
                    TAG,
                    "audio decoder first input codec=${format.codec} bytes=${payload.size}",
                )
            }
        } else {
            codec.queueInputBuffer(index, 0, 0, 0, 0)
            inputDropped++
        }
        drainCodec(codec)
    }

    private fun drainCodec(codec: MediaCodec) {
        diagnosticStage = "decoder-output"
        val info = MediaCodec.BufferInfo()
        while (running) {
            diagnosticStage = "decoder-output"
            val index = codec.dequeueOutputBuffer(info, 0)
            when {
                index == MediaCodec.INFO_TRY_AGAIN_LATER -> return
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    // Vendor metadata inspection must not interrupt otherwise working playback.
                    if (decoderOutputReports < 4) runCatching {
                        val outputFormat = codec.outputFormat
                        val metadata = "rate=${outputFormat.intOrNull(MediaFormat.KEY_SAMPLE_RATE)} " +
                            "channels=${outputFormat.intOrNull(MediaFormat.KEY_CHANNEL_COUNT)} " +
                            "pcmEncoding=${outputFormat.intOrNull(MediaFormat.KEY_PCM_ENCODING)}"
                        if (metadata != lastDecoderOutputMetadata) {
                            lastDecoderOutputMetadata = metadata
                            decoderOutputReports++
                            report("Audio: decoded format audioType=${format.audioType} codec=${format.codec} $metadata")
                        }
                    }
                }
                index >= 0 -> {
                    val size = info.size
                    if (size > 0) {
                        outputBuffers++
                        if (outputBuffers == 1 || outputBuffers % DECODED_BUFFER_LOG_INTERVAL == 0) {
                            Log.i(
                                TAG,
                                "audio decoder output codec=${format.codec} " +
                                    "buffers=$outputBuffers bytes=$size " +
                                    "queued=$inputQueued dropped=$inputDropped",
                            )
                        }
                    }
                    val copiedBytes = try {
                        val output = if (size > 0) codec.getOutputBuffer(index) else null
                        if (output == null) {
                            0
                        } else {
                            if (size > pcm.size) pcm = ByteArray(size)
                            output.position(info.offset)
                            output.limit(info.offset + size)
                            output.get(pcm, 0, size)
                            size
                        }
                    } finally {
                        // PCM is owned by this worker now. Do not hold a decoder buffer while
                        // AudioTrack blocks: the decoder needs it to keep accepting input.
                        codec.releaseOutputBuffer(index, false)
                    }
                    if (copiedBytes > 0) writePcm(pcm, 0, copiedBytes)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
                else -> return
            }
        }
    }

    private fun writePcm(data: ByteArray, offset: Int = 0, length: Int = data.size) {
        val track = track ?: return
        diagnosticStage = "track-write"
        if (!firstPcmLogged && length > 0) {
            firstPcmLogged = true
            Log.i(
                TAG,
                "audio first PCM type=${format.payloadType} bytes=$length",
            )
        }
        if (!fadeApplied) {
            applyFadeIn(data, offset, length)
            fadeApplied = true
        }
        var written = 0
        while (written < length && running) {
            val writeLength = if (playbackStarted) {
                length - written
            } else {
                minOf(length - written, PREBUFFER_WRITE_CHUNK_BYTES)
            }
            val writeStarted = System.nanoTime()
            diagnosticStage = "track-write"
            val count = track.write(data, offset + written, writeLength, AudioTrack.WRITE_BLOCKING)
            maxWriteMs = maxOf(maxWriteMs, (System.nanoTime() - writeStarted) / 1_000_000L)
            if (count < 0) {
                writeErrorsThisWindow++
                lastWriteErrorCode = count
                // These errors invalidate the native track. Stop this renderer so the
                // next packet can create a fresh track after a transient route/HAL reset.
                running = false
                break
            }
            if (count == 0) {
                zeroWritesThisWindow++
                break
            }
            if (count < writeLength) partialWritesThisWindow++
            written += count
            val framesWritten = count / frameBytes
            totalWrittenFrames += framesWritten
            writtenFramesThisWindow += framesWritten
            bufferProgress.written(count)
            lastPcmWriteNs = System.nanoTime()
            if (!playbackStarted) {
                prebufferBytes += count
                if (prebufferBytes >= startThresholdBytes) {
                    startPlayback(track)
                    Log.i(TAG, "audio playback started type=${format.payloadType}")
                }
            }
        }
    }

    private fun startPlayback(track: AudioTrack) {
        diagnosticStage = "track-play"
        underrunsAtPlaybackStart = track.underrunCount
        track.play()
        playbackStarted = true
    }

    private fun maintainPlaybackBuffer() {
        val track = track ?: return
        if (bufferProgress.shouldRebuffer(mappedChannel == AudioChannel.MEDIA, playbackStarted,
                track.underrunCount > underrunsAtPlaybackStart, queue.isEmpty(), track.playbackHeadPosition,
                startThresholdBytes / 2L)) {
            // The hardware buffer has starved below the recovery floor. Pause without flushing
            // or discarding PCM, then use the configured start threshold again when music resumes.
            track.pause()
            playbackStarted = false
            // Pausing retains queued PCM. Count it toward the restart threshold so a blocking
            // write cannot fill the paused track before play() is called.
            prebufferBytes = bufferProgress.queuedBytes(track.playbackHeadPosition)
                .coerceAtMost(startThresholdBytes.toLong()).toInt()
            lastPcmWriteNs = System.nanoTime()
            rebufferCount++
        }
        // A short final burst may never reach the start threshold. Play it after a bounded wait.
        if (!playbackStarted && prebufferBytes > 0 && queue.isEmpty() &&
            System.nanoTime() - lastPcmWriteNs >= BUFFER_TAIL_WAIT_NS) {
            startPlayback(track)
        }
    }

    // Persist counters even during packet starvation, and flush before disconnect releases the track.
    private fun logStatsIfDue(force: Boolean = false) {
        val now = System.nanoTime()
        if (statsWindowStartNs == 0L) statsWindowStartNs = now
        if (!force && now - statsWindowStartNs < STATS_WINDOW_NS) return
        val underruns = track?.underrunCount ?: 0
        val lastRx = lastArrivalNs.get()
        val currentTrack = track
        val playbackHeadFrames = currentTrack?.playbackHeadPosition
            ?.toLong()?.and(0xffff_ffffL)
        val playbackAdvanceFrames = playbackHeadFrames?.let { current ->
            val previous = lastPlaybackHeadFrames
            lastPlaybackHeadFrames = current
            previous?.let { (current - it) and 0xffff_ffffL }
        }
        val queuedFrames = playbackHeadFrames?.let { (totalWrittenFrames - it).coerceAtLeast(0L) }
        val line = "audio stats audioType=${format.audioType} channel=$mappedChannel " +
            "routeType=${currentTrack?.routedDevice?.type ?: -1} codec=${format.codec} " +
            "trackState=${currentTrack?.state ?: -1} playState=${currentTrack?.playState ?: -1} " +
            "sampleRate=${currentTrack?.sampleRate ?: format.sampleRate} " +
            "trackBufferFrames=${currentTrack?.bufferSizeInFrames ?: -1} " +
            "rx=${packetsReceived.getAndSet(0)} " +
            "dropped=${packetsDropped.getAndSet(0)} underruns=+${underruns - statsLastUnderruns} queue=${queue.size} " +
            "playing=$playbackStarted maxGapMs=${maxArrivalGapMs.getAndSet(0)} " +
            "sinceRxMs=${if (lastRx == 0L) -1 else (now - lastRx) / 1_000_000L} maxWriteMs=$maxWriteMs " +
            "writtenFrames=$writtenFramesThisWindow totalWrittenFrames=$totalWrittenFrames " +
            "playbackHeadFrames=${playbackHeadFrames ?: -1} playbackAdvanceFrames=${playbackAdvanceFrames ?: -1} " +
            "estimatedQueuedFrames=${queuedFrames ?: -1} writeErrors=$writeErrorsThisWindow " +
            "lastWriteError=${lastWriteErrorCode ?: "none"} zeroWrites=$zeroWritesThisWindow " +
            "partialWrites=$partialWritesThisWindow " +
            "decoderDroppedTotal=$inputDropped outputBuffersTotal=$outputBuffers rebuffers=$rebufferCount ended=$force"
        Log.i(STATS_TAG, line)
        report(line)
        if (format.codec != AudioCodecKind.LPCM) {
            // Keep this separate: the exported diagnostic recorder caps each line at 700 characters.
            val decoderLine = "Audio: decoder stats audioType=${format.audioType} codec=${format.codec} " +
                "inputQueuedTotal=$inputQueued inputDroppedTotal=$inputDropped " +
                "inputRetriesTotal=$inputRetries " +
                "shortOpusPacketsTotal=$shortOpusPackets decoderUnavailablePacketsTotal=$decoderUnavailablePackets " +
                "outputBuffersTotal=$outputBuffers ended=$force"
            Log.i(STATS_TAG, decoderLine)
            runCatching { report(decoderLine) }
        }
        statsLastUnderruns = underruns
        maxWriteMs = 0L
        writtenFramesThisWindow = 0L
        writeErrorsThisWindow = 0
        lastWriteErrorCode = null
        zeroWritesThisWindow = 0
        partialWritesThisWindow = 0
        statsWindowStartNs = now
    }

    private fun reportFailure(error: Throwable) {
        runCatching { report("Audio: renderer failed api=${Build.VERSION.SDK_INT} " +
            "audioType=${format.audioType} codec=${format.codec} stage=$diagnosticStage " +
            MediaFailureSummary.describe(error)) }
    }

    private fun applyFadeIn(data: ByteArray, offset: Int, length: Int) {
        val samples = (length - length % 2) / 2
        val fadeSamples = minOf(samples, maxOf(1, format.sampleRate / 100))
        for (index in 0 until fadeSamples) {
            val position = offset + index * 2
            val sample = (data[position].toInt() and 0xff) or (data[position + 1].toInt() shl 8)
            val scaled = (sample.toLong() * (index + 1) / fadeSamples).toInt()
            data[position] = scaled.toByte()
            data[position + 1] = (scaled shr 8).toByte()
        }
    }

    private fun byteSwapS16(source: ByteArray): ByteArray {
        for (index in 0 until source.size - 1 step 2) {
            val tmp = source[index]
            source[index] = source[index + 1]
            source[index + 1] = tmp
        }
        return source
    }

    @Synchronized
    private fun release() {
        releaseTrack()
        val codec = codec
        this.codec = null
        if (codec != null) {
            try {
                codec.stop()
            } catch (_: Exception) {
                // Best effort.
            }
            try {
                codec.release()
            } catch (_: Exception) {
                // Best effort.
            }
        }
    }

    private fun releaseTrack() {
        abandonAudioFocus()
        val previous = track
        track = null
        mappedChannel = null
        trackAttributes = null
        if (previous != null) {
            runCatching { previous.pause() }
            runCatching { previous.flush() }
            runCatching { previous.release() }
        }
    }

    private companion object {
        const val TAG = "xcertplay-usb"
        const val AAC_OBJECT_TYPE_LC = 2
        const val MIN_OPUS_PACKET_BYTES = 4
        const val OPUS_CODEC_DELAY_NANOS = 6_500_000L
        const val OPUS_SEEK_PRE_ROLL_NANOS = 80_000_000L
        const val INPUT_TIMEOUT_US = 10_000L
        const val AUDIO_POLL_MILLIS = 10L
        const val BUFFER_TAIL_WAIT_NS = 500_000_000L
        // Holds a burst after a Wi-Fi gap (~4 s of AAC) instead of dropping it.
        const val MAX_QUEUED_PACKETS = 192
        const val PREBUFFER_WRITE_CHUNK_BYTES = 2 * 1024
        const val STATS_TAG = "DiPlay-AudioStats"
        const val STATS_WINDOW_NS = 5_000_000_000L
        const val DECODED_BUFFER_LOG_INTERVAL = 50
    }
}
