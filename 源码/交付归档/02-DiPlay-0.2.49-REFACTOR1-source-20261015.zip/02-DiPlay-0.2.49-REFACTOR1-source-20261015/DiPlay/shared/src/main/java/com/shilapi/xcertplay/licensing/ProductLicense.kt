package com.shilapi.xcertplay.licensing

import com.shilapi.xcertplay.api.ApiUrls
import com.shilapi.xcertplay.api.readBytesLimited

import android.content.Context
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.AtomicFile
import com.shilapi.xcertplay.shared.BuildConfig
import org.json.JSONObject
import java.io.File
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

data class LicenseDecision(val allowed: Boolean, val message: String, val code: String = "", val expiresAtSeconds: Long? = null,
                           val features: Set<String> = emptySet(), val permanent: Boolean = false)
class ProductLicenseException(val decision: LicenseDecision) : IllegalStateException(decision.message)

object ProductLicense {
    private const val KEY_ALIAS = "faw_play_license_device_v1"
    private val stateLock = Any()
    private val operationLock = Any()
    private val executor = Executors.newSingleThreadExecutor { task -> Thread(task, "product-license").apply { isDaemon = true } }
    private val refreshing = AtomicBoolean(false)
    private data class CachedLicense(val token: String, val anchor: LicenseClockAnchor)
    private var featureDecision: LicenseDecision? = null
    private var featureCheckedAt = -1L
    private var featureRefreshAt = -60000L

    /** Bounded local cache for vehicle polling, with no synchronous HTTP on key/output threads. */
    @JvmStatic fun featureAllowed(context: Context, feature: String): Boolean {
        if (feature !in LicenseFeatures.ALL) return false
        if (!isRequired()) return true
        return synchronized(stateLock) {
            val elapsed = SystemClock.elapsedRealtime()
            if (elapsed - featureRefreshAt >= 60000) {
                featureRefreshAt = elapsed
                refreshAsync(context)
            }
            val decision = featureDecision?.takeIf { elapsed >= featureCheckedAt && elapsed - featureCheckedAt < 1000 }
                ?: check(context).also { featureDecision = it; featureCheckedAt = elapsed }
            decision.allowed && feature in decision.features
        }
    }

    private fun invalidateFeatures() { featureDecision = null; featureCheckedAt = -1 }

    @JvmStatic fun isRequired(): Boolean = BuildConfig.FAW_LICENSE_REQUIRED

    @JvmStatic fun configurationProblem(): String? {
        if (BuildConfig.FAW_LICENSE_SERVER_URL.isBlank() || BuildConfig.FAW_LICENSE_PUBLIC_KEY_SPKI.isBlank() ||
            BuildConfig.FAW_LICENSE_OIDC_ISSUER.isBlank() || BuildConfig.FAW_LICENSE_OIDC_CLIENT_ID.isBlank() ||
            !BuildConfig.FAW_LICENSE_SIGNING_CERT_SHA256.matches(Regex("[0-9a-f]{64}"))) {
            return "此安装包尚未配置授权服务器，请联系提供方获取已配置的正式版本。"
        }
        return try {
            ApiUrls.validateConfiguredUrl(BuildConfig.FAW_LICENSE_SERVER_URL)
            ApiUrls.validateConfiguredUrl(BuildConfig.FAW_LICENSE_OIDC_ISSUER)
            null
        } catch (_: Exception) { "授权服务器配置无效，请联系提供方。" }
    }

    /** Local check only. Never performs network IO or interrupts an existing CarPlay session. */
    @JvmStatic fun check(context: Context): LicenseDecision {
        if (!isRequired()) return LicenseDecision(true, "开发版本：授权检查未启用。", "DEVELOPMENT_BUILD")
        configurationProblem()?.let { return LicenseDecision(false, it, "NOT_CONFIGURED") }
        return synchronized(stateLock) {
            try {
                LicensePackageSignature.verify(context)
                val cached = read(context) ?: return@synchronized LicenseDecision(false, "请用手机扫码输入兑换码，激活这台车机。", "ACTIVATION_REQUIRED")
                val key = deviceKey()
                val claims = LicenseVerifier.verify(cached.token, BuildConfig.FAW_LICENSE_PUBLIC_KEY_SPKI, context.packageName,
                    LicenseVerifier.sha256Hex(key.public.encoded))
                val wall = System.currentTimeMillis()
                val elapsed = SystemClock.elapsedRealtime()
                val boot = bootCount(context)
                val nextAnchor = LicenseClock.advance(cached.anchor, wall, elapsed, boot)
                LicenseVerifier.validateTime(claims, nextAnchor.trustedSeconds)
                // Persist a wall-clock lower bound, including across process death and device reboot.
                write(context, CachedLicense(cached.token, nextAnchor))
                LicenseDecision(true, if (claims.permanent) "HUD、仪表地图和方向盘键控已永久授权；联网自动刷新验证票据。" else "HUD、仪表地图和方向盘键控已授权，联网后会自动续期。", "LICENSE_VALID", claims.expiresAt, claims.features, claims.permanent)
            } catch (e: LicenseValidationException) {
                LicenseDecision(false, e.message ?: "授权验证失败。", e.code)
            } catch (_: Exception) {
                LicenseDecision(false, "无法读取设备授权，请联网重新激活。", "LICENSE_UNAVAILABLE")
            }
        }
    }

    @JvmStatic fun requireStart(context: Context) {
        val decision = check(context)
        if (!decision.allowed) throw ProductLicenseException(decision)
    }

    @JvmStatic fun refreshAsync(context: Context) {
        if (configurationProblem() != null || !refreshing.compareAndSet(false, true)) return
        val app = context.applicationContext
        executor.execute { try { refresh(app) } finally { refreshing.set(false) } }
    }

    /** A failed connection keeps the existing offline ticket. Only an explicit denial clears it. */
    fun refresh(context: Context): LicenseDecision = synchronized(operationLock) {
        configurationProblem()?.let { return@synchronized LicenseDecision(false, it, "NOT_CONFIGURED") }
        val cached = try { synchronized(stateLock) { read(context) } } catch (_: Exception) {
            return@synchronized LicenseDecision(false, "无法读取设备授权，请重新扫码激活。", "LICENSE_UNAVAILABLE")
        }
            ?: return@synchronized LicenseDecision(false, "请先扫码输入兑换码，激活。", "ACTIVATION_REQUIRED")
        try {
            LicensePackageSignature.verify(context)
            val key = deviceKey()
            val token = LicenseApi.renew(context.packageName, key.public.encoded, cached.token) { proof -> sign(key, proof) }
            accept(context, token, key)
        } catch (e: LicenseApiException) {
            if (e.status == 403 && e.code in setOf("LICENSE_REVOKED", "DEVICE_REVOKED", "NO_LICENSE", "LICENSE_EXPIRED")) {
                synchronized(stateLock) {
                    if (read(context)?.token == cached.token) { file(context).delete(); invalidateFeatures() }
                }
                LicenseDecision(false, e.message ?: "此设备授权已被撤销。", e.code)
            } else {
                val local = check(context)
                local.copy(message = if (local.allowed) "联网验证暂未完成，现有离线授权仍可使用。" else e.message ?: local.message)
            }
        } catch (e: LicenseValidationException) {
            LicenseDecision(false, e.message ?: "服务器返回的授权无效。", e.code)
        } catch (_: Exception) {
            val local = check(context)
            local.copy(message = if (local.allowed) "无法连接服务器，现有离线授权仍可使用。" else "无法连接服务器，请检查网络后重试。")
        }
    }

    fun beginActivation(context: Context): DeviceActivation = synchronized(operationLock) {
        configurationProblem()?.let { throw LicenseApiException(0, "NOT_CONFIGURED", it) }
        LicensePackageSignature.verify(context)
        val key = deviceKey()
        LicenseApi.beginActivation(context.packageName, key.public.encoded, defaultDeviceName()) { sign(key, it) }
    }

    fun awaitActivation(context: Context, grant: DeviceActivation, cancelled: AtomicBoolean): LicenseDecision {
        val key = deviceKey()
        val token = LicenseApi.awaitActivation(grant, context.packageName, key.public.encoded, cancelled) { sign(key, it) }
        // Preserve a valid completed transaction even if the screen closes while collecting it.
        return synchronized(operationLock) { accept(context, token, key) }
    }

    fun cancelActivation(context: Context, grant: DeviceActivation) {
        val key = deviceKey()
        LicenseApi.cancelActivation(grant, context.packageName, key.public.encoded) { sign(key, it) }
    }

    /** Worker-thread only. Uses the same device key but never reads or changes the entitlement. */
    fun uploadDiagnostic(context: Context, metadata: DiagnosticMetadata, report: String): DiagnosticReceipt {
        configurationProblem()?.let { throw LicenseApiException(0, "NOT_CONFIGURED", it) }
        LicensePackageSignature.verify(context)
        val key = deviceKey()
        return LicenseApi.uploadDiagnostic(context.packageName, key.public.encoded, metadata, report) { sign(key, it) }
    }

    private fun accept(context: Context, issued: IssuedLicense, key: KeyPair): LicenseDecision = synchronized(stateLock) {
        val claims = LicenseVerifier.verify(issued.token, BuildConfig.FAW_LICENSE_PUBLIC_KEY_SPKI, context.packageName,
            LicenseVerifier.sha256Hex(key.public.encoded))
        // Only a newly verified server signature establishes a new clock anchor. The unsigned
        // serverTime response field can never rescue an expired or rolled-back cached ticket.
        val wall = System.currentTimeMillis()
        val elapsed = SystemClock.elapsedRealtime()
        val boot = bootCount(context)
        val trustedNow = LicenseFreshness.acceptTime(claims, issued.expectedChallengeId)
        write(context, CachedLicense(issued.token, LicenseClockAnchor(trustedNow, wall, elapsed, boot)))
        invalidateFeatures()
        LicenseDecision(true, if (claims.permanent) "永久授权成功，HUD、仪表地图和方向盘键控已启用。" else "授权成功，HUD、仪表地图和方向盘键控已启用。", "LICENSE_VALID", claims.expiresAt, claims.features, claims.permanent)
    }

    private fun sign(key: KeyPair, proof: ByteArray): String {
        val signature = Signature.getInstance("SHA256withECDSA")
        signature.initSign(key.private)
        signature.update(proof)
        return LicenseVerifier.encodeUrl(signature.sign())
    }

    private fun deviceKey(): KeyPair = synchronized(stateLock) {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (store.containsAlias(KEY_ALIAS)) {
            return@synchronized KeyPair(store.getCertificate(KEY_ALIAS).publicKey, store.getKey(KEY_ALIAS, null) as java.security.PrivateKey)
        }
        val generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
        // Android selects hardware protection where available. StrongBox and biometrics are not
        // required because car units frequently lack them and background renewal must work.
        generator.initialize(KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
            .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
            .setDigests(KeyProperties.DIGEST_SHA256)
            .setUserAuthenticationRequired(false)
            .build())
        generator.generateKeyPair()
    }

    private fun bootCount(context: Context): Int = try { Settings.Global.getInt(context.contentResolver, Settings.Global.BOOT_COUNT, -1) } catch (_: Exception) { -1 }
    private fun file(context: Context) = AtomicFile(File(context.noBackupFilesDir, "product-license-v1.json"))

    private fun read(context: Context): CachedLicense? {
        val atomic = file(context)
        if (!atomic.baseFile.exists()) return null
        atomic.openRead().use { stream ->
            val bytes = stream.readBytesLimited(32768)
            val json = JSONObject(String(bytes, Charsets.UTF_8))
            return CachedLicense(json.getString("license"), LicenseClockAnchor(json.getLong("trustedSeconds"), json.getLong("wallMillis"), json.getLong("elapsedMillis"), json.getInt("bootCount"), json.optInt("fractionalMillis", 0)))
        }
    }

    private fun write(context: Context, cached: CachedLicense) {
        val json = JSONObject().put("license", cached.token).put("trustedSeconds", cached.anchor.trustedSeconds)
            .put("wallMillis", cached.anchor.wallMillis).put("elapsedMillis", cached.anchor.elapsedMillis).put("bootCount", cached.anchor.bootCount)
            .put("fractionalMillis", cached.anchor.fractionalMillis)
        val atomic = file(context)
        val stream = atomic.startWrite()
        try {
            stream.write(json.toString().toByteArray(Charsets.UTF_8))
            atomic.finishWrite(stream)
        } catch (e: Exception) { atomic.failWrite(stream); throw e }
    }

    fun defaultDeviceName(): String = "${Build.MANUFACTURER} ${Build.MODEL}".take(80)
}
