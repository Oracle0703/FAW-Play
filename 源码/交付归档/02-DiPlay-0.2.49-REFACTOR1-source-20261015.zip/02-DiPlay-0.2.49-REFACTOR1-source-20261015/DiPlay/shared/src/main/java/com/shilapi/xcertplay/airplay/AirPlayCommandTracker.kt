package com.shilapi.xcertplay.airplay

/** Bounded CSeq correlation for display/recovery commands. A write is never reported as an ACK. */
internal class AirPlayCommandTracker(private val report: (String) -> Unit) {
    private data class Pending(val type: String, val screen: String, val startedNs: Long, var written: Boolean = false)
    private val pending = linkedMapOf<Int, Pending>()

    @Synchronized fun queued(cseq: Int, command: Map<String, Any?>, nowNs: Long = System.nanoTime()) {
        val type = command["type"] as? String ?: return
        if (type !in TRACKED) return
        expire(nowNs)
        if (pending.size >= 64) finish(pending.keys.first(), "evicted", nowNs)
        val uuid = (command["params"] as? Map<*, *>)?.get("uuid")
        val screen = when (uuid) {
            AirPlayInfoPlist.ALT_UUID -> "alternate"
            null, AirPlayInfoPlist.MAIN_UUID -> "main"
            else -> "unknown"
        }
        pending[cseq] = Pending(type, screen, nowNs)
    }

    @Synchronized fun written(cseq: Int) {
        val entry = pending[cseq] ?: return
        entry.written = true
        report("command cseq=$cseq type=${entry.type} screen=${entry.screen} written=true response=pending")
    }

    @Synchronized fun response(message: RtspMessage.Request, nowNs: Long = System.nanoTime()) {
        val cseq = message.headers["cseq"]?.toIntOrNull() ?: return
        val status = message.path.toIntOrNull() ?: return
        val result = if (message.body.isEmpty()) null else runCatching {
            (BplistCodec.decode(message.body) as? Map<*, *>)?.get("status") as? Number
        }.getOrNull()?.toLong()
        val outcome = if (status in 200..299 && (result == null || result == 0L)) "acknowledged" else "rejected"
        finish(cseq, "$outcome status=$status result=$result", nowNs)
        expire(nowNs)
    }

    @Synchronized fun failed(cseq: Int) { finish(cseq, "write-failed", System.nanoTime()) }
    @Synchronized fun close() { pending.keys.toList().forEach { finish(it, "session-closed", System.nanoTime()) } }

    private fun expire(nowNs: Long) {
        pending.filterValues { nowNs - it.startedNs >= 10_000_000_000L }.keys.toList()
            .forEach { finish(it, "response-timeout", nowNs) }
    }

    private fun finish(cseq: Int, outcome: String, nowNs: Long) {
        val entry = pending.remove(cseq) ?: return
        report("command cseq=$cseq type=${entry.type} screen=${entry.screen} written=${entry.written} " +
            "response=$outcome elapsedMs=${(nowNs - entry.startedNs).coerceAtLeast(0) / 1_000_000} effect=unmeasured")
    }

    private companion object {
        val TRACKED = setOf("forceKeyFrame", "showUI", "stopUI", "updateViewArea", "setVideoPlaybackAllowed")
    }
}
