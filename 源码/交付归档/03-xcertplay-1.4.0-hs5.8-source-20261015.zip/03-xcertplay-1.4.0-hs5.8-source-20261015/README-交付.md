# xcertplay HS5 最新源码交付

版本 **1.4.0-hs5.8 / versionCode 1408**，包名 `com.shilapi.xcertplay.hs5`。快照日期 **2026-10-15（北京时间）**，来源为 xcertplay-local-auth 当前工作树。Android Studio 打开 `xcertplay/`。mobile 与 automotive 是同包名的两种入口构建，不能在同一设备作为两个独立 App 并存。

保留 upstream 固定提交 `551895a121f5fb22312331f3cd0d7b2857bb478f` 上的 HS5 适配、新 UI、无线连接、音视频、HUD／仪表、方向盘和车辆状态边界。工程包含四模块、资源、JNI、测试、Gradle wrapper 及平台证据；`HS5_MIGRATION.json` 记录改动来源。基础提交号不代表未提交的适配文件已在上游。

- [构建与配置](docs/构建与配置.md)
- [架构与维护](docs/架构与维护.md)
- [当前功能及限制](xcertplay/START-HERE.zh-CN.md)
- [产品授权／更新接入](xcertplay/docs/HS5-PRODUCT-SERVICES.zh-CN.md)
- [车辆数据及控制边界](xcertplay/docs/HS5-VEHICLE-DATA-AND-CONTROLS.zh-CN.md)
- [CarPlay Ultra 接入状态](xcertplay/docs/APPLE-CARPLAY-ULTRA-INTEGRATION.zh-CN.md)
- [本次验证记录](verification.json)

正常构建要求持有人在 `.private/local-auth/` 提供配套认证文件；本源码交付不包含这些身份。为便于接收方在没有生产材料时验证，另附显式源码检查脚本，能使用 JDK 临时生成自签测试身份运行首装加载测试。这些测试数据无法替代 Apple 认证或独立车测包。

```sh
python3 verify_source.py
cd xcertplay
./gradlew --init-script ../tools/source-only.init.gradle -Phs5SyntheticTestIdentity=true \
  :shared:testDebugUnitTest :common:testDebugUnitTest \
  :shared:lintDebug :common:lintDebug :mobile:lintDebug :automotive:lintDebug \
  :mobile:assembleDebug :automotive:assembleDebug
```

JDK 25、Android SDK 37、NDK 28.2.13676358，最低 Android 9／API 28，原生架构 arm64-v8a、armeabi-v7a、x86_64。正式产品仍需原有正常构建流程、持有人认证输入、发布签名和服务信任配置。

软件授权和更新客户端已经实现，但新包名的服务端允许项、正式 APK 签名 pin、独立更新渠道和旧用户迁移尚待接入。默认源码缺少服务配置时显示未配置，不应把它解释为已授权或已是最新版。Apple CarPlay Ultra 尚未实现，相关开关禁用。既有 hs5.8 OPPO 连接记录随包提供；它不证明 Intel HS5 上的性能、车辆权限、HUD／仪表或音频已验收。

原有文档保留历史上下文，其中 hs5.1–hs5.7 结果不作为 hs5.8 当前证据。已将包内文件的本机绝对链接转换为相对路径；外部研究资料明确标注为未随包交付。项目许可证完整保留。
