# 无线连接修复与官方资料对照

本轮版本：`1.4.0-hs5.4`。目标是把无法连接定位到具体阶段，停止无界等待，并在适合的失败类型上重建无线网络。不能凭型号认定兼容或不兼容，也不能承诺所有手机秒连。

本轮系统包适配依据见 [HS5 系统接入说明](docs/HS5-SYSTEM-INTEGRATION.zh-CN.md)。首次打开不自动连接；点击连接后让蓝牙可被搜索，完成手机配对再建专用 P2P 组。匹配的 HS5 API 28 建组/组信息路径取消不必要的扫描定位授权。蓝牙总开关、Wi-Fi 总开关由现有系统保持。已有历史配对设备时，失败后刷新候选，新配对或已连接手机优先；同一地址在当前蓝牙阶段只尝试一次。

## 已确认的实现差异

| 原实现 | 官方资料 / 源码证据 | 本轮处理 |
| --- | --- | --- |
| 自动选择依赖手机名称、设备类别及缓存 UUID | Android `getUuids()` 只返回缓存；连接指定 UUID 的 RFCOMM socket 会自行查询 SDP | 已配对的手机、缺少类别信息的候选，以及无 UUID 缓存的 COMPUTER 候选可进行有界 iAP2 服务探测；明确 iAP2 服务及已连接手机优先。候选不代表已确认是 iPhone |
| RFCOMM 前没有停止系统扫描，首个候选能连蓝牙但不完成 iAP2 时不尝试后续手机 | Android 明确说明 discovery 会拖慢连接，连接前应取消，即使扫描由其他应用发起 | 有权限时停止扫描；全部候选总预算 20 秒，每个候选的 RFCOMM 与 iAP2 握手合计最多 8 秒，并为剩余候选预留时间 |
| 引导最多等 5 分钟，控制链路就绪后等待手机 Wi-Fi 无截止时间 | `Iap2WirelessControlClient` 的初始期限不覆盖长期收消息循环 | 无线独立阶段计时、90 秒总预算；旧代回调与重复报文不能刷新预算 |
| Bonjour 异步启动失败只写 Log | Android NSD 请求立即返回，真实结果通过 listener 回报 | 注册/发现失败进入 Controller 和中文 UI，停止当前连接并有限重试 |
| AirPlay 监听器绑定通配地址，可能接收错误网卡的连接 | 手机被告知的是当前热点地址；HS5 同时存在 P2P、STA、VPN 等接口 | 无线附件把 TCP listener 绑定到热点实际 `hostAddress`；旧调用仍回退到通配地址，避免跨网卡误接导致连接慢或失败 |
| 配对错误可能以 HTTP 200 + TLV8 错误字段返回 | 现有 pair-setup / pair-verify 源码 | 完整写入并 flush 错误响应后报告失败；不处理拒绝后同批的 RECORD；认证拒绝停止自动重试 |
| `/auth-setup` 的 HTTP 400 未立即报告 | MFi SAP 响应正文是独立二进制协议 | 按 HTTP 错误上报，不把 SAP 正文误当 TLV8，不改变签名或认证算法 |
| 失败后没有受控的信道恢复 | Android 公开频率请求及可用 GO 信道查询 | 仅无线网络建立/加入阶段失败增加选频次数；认证拒绝、普通会话断开不触发换信道 |
| 旧失败线程可能卸载新 Controller 的服务 attachment | 服务原 `detach()` 没有连接归属条件 | 无线 attachment 保存 owner，旧 Controller 清理只能卸载自己的服务 |
| 首页把具体错误压成“查看详情” | 原首页状态转换与单行显示 | 保留中文原因、重试次数和停止提示，最多三行；停止后保留手动重试按钮 |

## 超时与恢复策略

| 阶段 | 阶段预算 | 网络重选 |
| --- | --- | --- |
| 等待用户蓝牙配对 | 120 秒（独立准备预算） | 否 |
| 建立无线网络 | 20 秒 | 是 |
| 连接蓝牙 | 20 秒 | 否 |
| iAP2 识别 | 20 秒 | 否 |
| 附件身份验证 | 20 秒 | 否 |
| 等待 iPhone 加入 Wi-Fi | 25 秒 | 是 |
| 安全配对 | 30 秒 | 否 |
| 启动会话 | 20 秒 | 否 |

上述为本项目工程策略，不是 Apple 官方时间要求。用户蓝牙配对准备阶段最多 120 秒，未完成时只报告一次且停止自动重试；后续从建组开始，任一阶段到期或协议总计 90 秒到期均失败。底层无线 iAP2 初始引导另有 20 秒整体限制，并非识别、认证分别保证可等待满 20 秒。已活动的会话不受启动预算限制。

首次连接失败后，最多两次自动重试，间隔 2 秒、4 秒，共三次尝试。安全配对或附件认证明确拒绝时直接停止。失败不会自动删除 iPhone 信任记录或更改认证材料；手动点击“打开 CarPlay”开始新的尝试预算。

## 信道能力与限制

| 平台 | 处理 |
| --- | --- |
| Android 9 / API 28，HS5 当前平台 | 没有公开指定频段/频率的 P2P 配置接口；重新建组由系统选频，不声称实现指定信道 |
| API 29–33 | 首次系统选择 5 GHz；网络重试可请求 5180 或 5745 MHz，排除已失败频率，由系统决定是否允许 |
| API 34+ | 查询当前监管域与并发状态允许的 GO 信道，筛出非 DFS 5 GHz 候选，排除失败频率；无权限、无候选或不支持查询时回到系统选择 |

系统选择与固定频率请求交替进行，只重选 5 GHz，没有添加 2.4 GHz 回退。运行记录分别保存请求频率和组实际频率；请求被提交不能证明实际生效。等待入网超时后在后台用 250 毫秒查询实际 GO 关联状态；已有客户端或查询未知时不增加选频次数。不能把同组客户端直接当作已确认的当前 iPhone。会话或服务失败仍可能重建网络，系统自主选频可能变化；这与应用主动请求新的频率不同。活动会话不执行启动超时选频。HS5 的指定信道能力要依赖已验证的系统特权/OEM 接口，当前不猜测隐藏 API。

## 验证记录

本轮构建、单元测试、Lint、签名、ABI 和 APK 内身份材料排除检查以 [verification.json](artifacts/hs5.4/verification.json) 为准。本轮没有 HS5 实车运行证据。hs5.3 的 [历史手机记录](artifacts/hs5.3/phone-wireless-validation.json) 只记录设备离线未运行。正式运行记录应绑定已安装 APK 和源码清单哈希，仅保存白名单事件、时间和信道，不保存手机名称、地址或证书私钥。

hs5.2 的 Wi-Fi 断线与首页验证继续保留在原目录，不能当作 hs5.4 的运行验证。多个 iPhone 及 HS5 实车的完整连接、射频和音视频验收仍开放。

## 官方资料

- [BluetoothDevice.getUuids](https://developer.android.com/reference/android/bluetooth/BluetoothDevice#getUuids())：只读本地缓存。
- [BluetoothDevice.createRfcommSocketToServiceRecord](https://developer.android.com/reference/android/bluetooth/BluetoothDevice#createRfcommSocketToServiceRecord(java.util.UUID))：`connect()` 自动 SDP 查询。
- [BluetoothSocket](https://developer.android.com/reference/android/bluetooth/BluetoothSocket)：阻塞连接和关闭取消。
- [Android 蓝牙连接指南](https://developer.android.com/develop/connectivity/bluetooth/connect-bluetooth-devices)：连接前停止扫描。
- [P2P 频段请求](https://developer.android.com/reference/android/net/wifi/p2p/WifiP2pConfig.Builder#setGroupOperatingBand(int))、[P2P 频率请求](https://developer.android.com/reference/android/net/wifi/p2p/WifiP2pConfig.Builder#setGroupOperatingFrequency(int))：API 29+。
- [WifiManager.getUsableChannels](https://developer.android.com/reference/android/net/wifi/WifiManager#getUsableChannels(int,%20int))：API 34+；监管域、并发状态与 GO 模式过滤。
- [NsdManager](https://developer.android.com/reference/android/net/nsd/NsdManager)：异步注册和发现回调。
- [Apple CarPlay 设置](https://support.apple.com/en-us/108415)、[Apple CarPlay 开发入口](https://developer.apple.com/carplay/)、[MFi 计划](https://mfi.apple.com/)。

Apple 公开资料能确认蓝牙、Wi-Fi 及自动加入等基本连接条件。完整车机接收端认证、iAP2 无线规范和认证测试要求仍需 MFi 授权；本轮没有取得这些受限文档，不能把公开 Android 行为或开源实现称为完整 Apple 规范。
