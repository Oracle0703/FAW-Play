# HS5 软件授权与更新接入

本文描述客户端已经接入的行为，以及正式服务接入前需要准备的配置。本文中的服务端差异仅供审阅，没有应用到旧项目或线上服务，也没有发布 APK。

## 当前状态

新版包名为 `com.shilapi.xcertplay.hs5`。基础 CarPlay 免费；HUD、仪表地图和方向盘增强功能分别使用 `hud`、`instrument-map`、`steering-wheel` 授权范围。引导允许跳过绑定，继续使用基础功能。

当前本地已从旧项目的既有正式构建资料恢复 HTTPS 服务地址和验证公钥，并交叉核对公钥一致性；这些值保存在 Git 忽略的 `.private/product-services.properties`，文件权限为 `600`。文档及源代码不包含实际端点、公钥值、账户秘密或 APK 签名私钥。

**当前新 APK 的软件授权签名 pin 和更新签名 pin 均为空。默认构建因此真实返回 `NOT_CONFIGURED`，不会声称已绑定、检查到最新版本或可以安装更新。** 环境变量可以覆盖本地配置；如果构建环境提供正式配置，结果以该构建的配置和真实校验为准。缺配置不影响基础 CarPlay。

旧授权服务的源码默认允许名单没有 `com.shilapi.xcertplay.hs5`。尚未验证线上服务是否已经支持新包名，也未确认新包专用更新清单和旧用户迁移策略。客户端接入完成不等于这些服务步骤已经完成。

软件增强授权是你的产品购买及设备绑定，**不是 MFi 认证**。扫码绑定不会为 iPhone 提供 MFi 证书；MFi 的内置本地身份和预留 USB 认证走独立接口。这里的软件授权服务器也不是 xcertplay 的 REMOTE MFi 签名后端。

## 客户端行为与安全边界

入口为 `common/.../Hs5ProductServices.kt`：

| 操作 | 实现行为 |
| --- | --- |
| `licenseStatus` | 仅本地验证设备绑定的签名票据，不在界面线程请求网络 |
| `refreshLicense` | 在线续期；网络失败保留有效离线票据，明确撤销则清除授权 |
| `beginBinding` / `awaitBinding` / `cancelBinding` | 生成限时设备二维码，手机网页核对设备并输入兑换码，车机轮询后领取签名票据；取消停止等待并尽力取消服务器会话 |
| `featureAllowed` | 按增强功能范围验证；debug 构建也不会自动绕过授权 |
| `checkUpdate` | 不要求购买增强功能；区分可更新、最新、未配置、渠道未发布和失败 |
| `downloadUpdate` | 校验签名清单后下载，再核对大小、SHA-256 和 APK 包名、版本、SDK、发布签名 |
| `downloadedUpdate` / `installUpdate` | 从本地再次验证准备安装的更新，拒绝活跃 CarPlay 连接期间安装 |

新 App 使用独立 AndroidKeyStore 设备密钥和独立 `noBackupFilesDir` 票据文件。票据必须绑定新包名 `aud` 及当前设备公钥摘要；旧 App 的票据或私钥不能直接复制为新版授权。离线票据最长 90 天，永久购买也需要定期联网刷新验证票据；保留原有时间回滚、挑战匹配、签名验证和功能范围校验。

更新请求固定使用新包名的 stable 路由。只有签名有效的清单表明服务器版本不高于当前版本，才报告“当前已是最新版本”。HTTP 404 返回 `CHANNEL_NOT_PUBLISHED`；缺配置、请求失败或签名校验失败均不能报告最新。下载路径必须是签名清单中的固定同源路径，不接受重定向到任意地址或上游通用 APK。

## 本地正式构建配置

`shared/build.gradle` 从环境变量读取下列字段；没有对应环境变量时，读取被忽略的 `.private/product-services.properties`。字段只含服务信任配置，不能放入服务端私钥、登录令牌、APK keystore 或密码。

| 字段 | 意义 |
| --- | --- |
| `FAW_LICENSE_SERVER_URL` | 软件授权服务的 HTTPS 根地址 |
| `FAW_LICENSE_PUBLIC_KEY_SPKI` | 软件票据签名的 P-256 验证公钥，base64url SPKI |
| `FAW_LICENSE_SIGNING_CERT_SHA256` | 新 App 正式 APK 发布证书的 SHA-256，64 位小写十六进制 |
| `HS5_UPDATE_SERVER_URL` | HS5 定制 App 更新服务的 HTTPS 根地址 |
| `HS5_UPDATE_PUBLIC_KEY_SPKI` | 更新清单签名的 P-256 验证公钥，base64url SPKI |
| `HS5_UPDATE_SIGNING_CERT_SHA256` | 新 App 正式更新 APK 发布证书的 SHA-256 |

`FAW_LICENSE_ALLOW_HTTP` 固定为 `false`。软件授权与更新可使用同一现有后端及验证公钥，但客户端独立检查两套配置，更新不读取购买授权或设备票据。恢复旧服务地址、公钥不会证明服务器接受新包名，也不会确定新 App 的发布签名。

正式接入先确定稳定 release 签名，保留其 keystore 和密码在私有构建环境，再从实际签名的 release APK 或发布证书取得摘要。两个 APK 签名 pin 应与新版正式发布证书一致。**不能复制旧 App pin、用 debug pin 代替正式 pin，或关闭签名校验来使界面显示成功。** 本轮没有生成或填入替代正式签名的 debug 配置。

可离线导出所选正式证书，再计算摘要；以下变量均需由正式构建环境设置，证书口令由 `keytool` 交互读取：

```sh
keytool -exportcert -keystore "$HS5_RELEASE_STORE" -alias "$HS5_RELEASE_ALIAS" -file "$HS5_RELEASE_CERT"
shasum -a 256 "$HS5_RELEASE_CERT"
```

这些命令仅导出公开证书、核对正式签名，不生成新签名身份，也不发布服务。当前源码测试、debug APK 和未经配置的 release 构建不能被当作已接入的软件授权正式版本。

## 服务端可审阅差异与离线准备

需要在保留当前服务所有现有包名的前提下，向实际部署的 `LICENSE_ALLOWED_APP_IDS` 增加 `com.shilapi.xcertplay.hs5`。实际部署如果设置了环境变量，该变量优先于 Compose 的默认值；只改默认值不能改变已有的环境覆盖。

以下是对旧源码默认值的建议差异，**未应用**。它只涉及允许名单，不改签名密钥、不关闭设备额度校验：

```diff
--- authorization-server/compose.production.yml
+++ authorization-server/compose.production.yml
@@
-      LICENSE_ALLOWED_APP_IDS: ${LICENSE_ALLOWED_APP_IDS:-com.shihab.diplay,com.shilapi.xcertplay}
+      LICENSE_ALLOWED_APP_IDS: ${LICENSE_ALLOWED_APP_IDS:-com.shihab.diplay,com.shilapi.xcertplay,com.shilapi.xcertplay.hs5}
--- authorization-server/src/main/resources/application.yml
+++ authorization-server/src/main/resources/application.yml
@@
-  allowed-app-ids: ${LICENSE_ALLOWED_APP_IDS:com.shihab.diplay,com.shihab.diplay.hudtest,com.shilapi.xcertplay}
+  allowed-app-ids: ${LICENSE_ALLOWED_APP_IDS:com.shihab.diplay,com.shihab.diplay.hudtest,com.shilapi.xcertplay,com.shilapi.xcertplay.hs5}
```

正式更新还需要独立的 `com.shilapi.xcertplay.hs5/stable/manifest.json` 和该目录下的 APK artifacts。旧发布脚本 `authorization-server/scripts/publish-update.py` 已能从 APK 读取并验证实际包名、版本和发布证书，生成本地发布目录；服务端在返回清单时用现有服务签名密钥签名。脚本只准备本地文件，不会上传或部署。审阅新 release APK 后，可在私有暂存目录运行：

```sh
python3 ../FAW-Play/authorization-server/scripts/publish-update.py "$HS5_RELEASE_APK" \
  --directory "$HS5_UPDATE_STAGING" \
  --package-name com.shilapi.xcertplay.hs5 \
  --signing-cert-sha256 "$HS5_RELEASE_CERT_SHA256" \
  --notes-file "$HS5_RELEASE_NOTES"
```

以上命令以新工程目录为当前目录。生成目录是供审阅的离线材料，不等于服务器已经提供新频道，也不能把旧包更新清单改名后复用。实际部署、服务器新包接入和发布属于后续明确操作。

旧用户迁移必须先明确同一购买授权下如何从旧包的设备密钥迁移到新包的设备密钥，避免重复占用或超过兑换码设备额度。应保留旧购买记录与审计记录，由现有授权管理流程处理旧绑定，再为新版领取新的绑定票据；不能在 App 中重写票据 `aud`、拷贝旧票据、自动删除其他设备绑定或自动消耗另一个兑换码。当前客户端没有执行此类迁移。

## 安装更新的当前限制

当前客户端使用标准系统安装确认，文件通过不可导出的 FileProvider 共享；仅共享经过校验的更新目录。普通 APK 声明 `REQUEST_INSTALL_PACKAGES` 不等于已获得安装特殊权限，系统也可能没有可处理 APK 安装的组件。没有该权限时如实报告不可安装，不能用普通运行时权限弹窗冒充已获授权。

当前实现不默认调用旧原厂 SOTA 静默安装接口，也不承诺无需系统设置即可授予安装特殊权限。更新检查及已验证下载与安装授权分别处理；用户可继续基础 CarPlay，配置或权限失败不会伪装为安装成功。实车是否可以复用原厂安装器、以及安装结果回到 App 的完整体验，仍需独立验证。

正式接入的验收包括：新包真实扫码绑定及续期、旧用户迁移不多占额度、免费用户可以检查更新、真实签名清单和 APK 的一致性、失败/404 不报告最新、错误签名与旧包被拒绝、连接期间禁止安装、系统确认及实际版本升级。客户端编译、单元测试、离线目录准备和线上/实车验收应分别记录。
