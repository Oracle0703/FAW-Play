# Apple CarPlay Ultra 官方接入核查

核对日期：2026-10-15。目标为 Apple CarPlay Ultra 的真实通信、车辆状态、本地渲染、资源包和多屏协同。此前提出的“Ultra 风格 Kanzi 主题”路线已撤回。此文是来源及缺口核查，不是取得了 Apple 完整车端规范后的实现说明。

## 官方资料与访问边界

| Apple 原始来源 | 已确认的内容 | 不能据此推导的内容 |
| --- | --- | --- |
| [CarPlay 开发者入口](https://developer.apple.com/carplay/) | 将车机系统对 CarPlay、CarPlay Ultra 的支持引向 MFi Program；与 iPhone 第三方 App 开发分开说明 | 普通 CarPlay App entitlement 能让 Android 车机或仪表获得 Ultra 接收能力 |
| [WWDC24：Meet the next generation of CarPlay architecture](https://developer.apple.com/videos/play/wwdc2024/10111/) | Communication plug-in、四类 UI、本地 OpenGL 渲染、资源真实性验证、UI sync、车辆状态协议 | 完整报文/资源格式、参考渲染器的完整实现或当前版本的全部验收要求 |
| [WWDC24：Say hello to the next generation of CarPlay design system](https://developer.apple.com/videos/play/wwdc2024/10112/) | 车型定制的仪表设计系统、布局、车辆内容与动态内容 | Apple 为 HS5 提供了现成可安装的主题或已适配资源包 |
| [Apple 2025-05-15 Ultra 发布说明](https://www.apple.com/newsroom/2025/05/carplay-ultra-the-next-generation-of-carplay-begins-rolling-out-today/) | Ultra 产品形态、整车数据和多屏整合、Apple 与车厂共同设计主题 | 所有既有 CarPlay 车机都可以通过一个 APK 获得 Ultra |
| [MFi Program](https://mfi.apple.com/)及[FAQ](https://mfi.apple.com/en/faqs) | 提供车机相关技术规范与资源的正式入口；FAQ 明确区分技术授权和普通 App 开发 | 拥有附件认证证书等于持有完整规范、车型资源和集成验证结果 |

WWDC24 架构视频结尾明确将技术文档访问指向 MFi。当前会话没有取得登录后的完整 CarPlay Ultra 接收端文档及相关车端资源；不能将公开架构演讲写成完整协议规范，也不能凭空补全字段、资源签名规则或官方认证要求。

2026 开发者入口链接的 [Rev up your CarPlay app](https://developer.apple.com/videos/play/wwdc2026/212/)主要面向 iPhone App 能力，本次核对未从中取得 Ultra 接收端实现规范。

## 官方架构对实现的要求

以下为公开架构的功能分工，不是未经取得的私有规范字段定义。

| 部分 | 官方公开机制 | 当前验证需要回答的问题 |
| --- | --- | --- |
| Communication plug-in | 承接 iPhone 的通信、音视频、输入，并扩展车辆状态接入 | xcertplay 实际实现了哪些 Ultra 协议和能力协商，哪些只有触发/声明？ |
| Remote UI | iPhone 为相应屏幕提供视频画面 | 主屏及普通 type 111 导航流之外，Ultra 需要的屏幕、能力与生命周期是否一致？ |
| Local UI | 车端 OpenGL 渲染器处理车辆高频状态；可在手机未连接或无线中断时持续显示本地内容 | 是否具备能处理对应车型资源及行为脚本的兼容实现，并连接真实车辆信号？ |
| 车型资源 | 含图片及行为脚本，配对时由 iPhone 传输，使用前由车端验证真实性 | 资源身份、传输、完整性/真实性、格式与本地运行时是否完整对应？ |
| UI sync 与合成 | 低延迟同步通道与时间戳协调 Remote、Local、Punch-through；车辆系统另合成关键 Overlay | 是否真正处理同步消息、保留时间戳并驱动合成，而非只接受一个 SETUP 字段？ |
| Vehicle state protocol | 车辆能力配置、状态、交互与反馈，按显示/功能分工提供 | HS5 信号、单位、状态、可用性、刷新、控制反馈如何与协议的真实定义相接？ |
| Overlay / Punch-through | 原车关键指示及车厂特有 UI 由车辆系统渲染并参与组合 | HS5 的仪表宿主、显示合成与原厂状态是否具备可用接入边界？ |

官方资源包与 HS5 Kanzi `.kzb` 是两套已知不同的机制。目前没有证据表明官方资源可被原厂 Kanzi 直接加载。找到原厂换主题或共享导航画面的入口，不等于接通上述官方架构。

用户要求保留一个切换入口。这是接入完成后需要落实的产品行为；在真实能力未接通前，不保存虚假的启用状态。

## 本地基线与最新上游

本地固定基线为 `551895a121f5fb22312331f3cd0d7b2857bb478f`，保留 HS5 已有修改。本次只读核对最新上游，不将远端代码直接合并到用户工作树。

本地已确认：

- `Iap2CarPlayMessages.startSession` 有可选 `clusterAsset` 编码，不代表资源传输及本地运行时已接通。
- `HandshakeTimeline` 和 `handshake-wireless.txt` 出现 Ultra、CAF、UI sync 等日志/样本；日志解析和测试样本不是本地生产代码的端到端实现证据。
- 普通仪表导航的 `CarPlayClusterDisplay`、type 111 和 HS5 Presentation 不等同于官方 Ultra。

最新上游固定为 `2bb1adec3a49104760e751005e5db2c6ff82f6b4`（本次查询的 master，较本地固定基线新增 18 个提交）。作者在 [README](https://github.com/shilapi/xcertplay/blob/2bb1adec3a49104760e751005e5db2c6ff82f6b4/README.zh-CN.md#L13)明确说明能够触发 Ultra 提示，但协议栈未经测试且未完成。应分别记录作者声明与可读代码证据。

| 当前上游代码 | 核对结果 |
| --- | --- |
| [AirPlayInfoPlist.kt](https://github.com/shilapi/xcertplay/blob/2bb1adec3a49104760e751005e5db2c6ff82f6b4/shared/src/main/java/com/shilapi/xcertplay/airplay/AirPlayInfoPlist.kt#L299-L317) | 现有协商列表包含 viewAreas/hevc/iAPChannel/altScreen/uiContext；未从该实现确认官方 Ultra 的完整 UI sync、资源及车辆状态栈 |
| [无线 startSession 调用](https://github.com/shilapi/xcertplay/blob/2bb1adec3a49104760e751005e5db2c6ff82f6b4/shared/src/main/java/com/shilapi/xcertplay/transport/Iap2WirelessControlClient.kt#L319-L332)与[有线调用](https://github.com/shilapi/xcertplay/blob/2bb1adec3a49104760e751005e5db2c6ff82f6b4/shared/src/main/java/com/shilapi/xcertplay/transport/Iap2WiredControlClient.kt#L224-L231) | 这些实际调用没有传入 clusterAsset；可选编码槽不等于主题资源运行链路 |
| [Iap2Messages.kt](https://github.com/shilapi/xcertplay/blob/2bb1adec3a49104760e751005e5db2c6ff82f6b4/shared/src/main/java/com/shilapi/xcertplay/iap2/message/Iap2Messages.kt#L43-L95) | 保留 `Iap2ClusterAsset` 和 StartSession group 7 编码能力 |
| [Iap2VehicleStatus.kt](https://github.com/shilapi/xcertplay/blob/2bb1adec3a49104760e751005e5db2c6ff82f6b4/shared/src/main/java/com/shilapi/xcertplay/transport/Iap2VehicleStatus.kt#L30-L70)及新增 VehicleData/profile | 可复用的数据抽象、只读 AAOS 采集及普通 iAP2 状态上报；不能直接等同官方 Ultra vehicle state protocol |
| [Iap2FileTransferReceiver.kt](https://github.com/shilapi/xcertplay/blob/2bb1adec3a49104760e751005e5db2c6ff82f6b4/shared/src/main/java/com/shilapi/xcertplay/iap2/session/Iap2FileTransferReceiver.kt#L10-L58) | 已读实现面向 Now Playing 封面图，不能当作 Ultra 车型资源接收与验证 |

本次成功读取了完整 GitHub 目录树与关键生产文件，并扫描相关文本；未确认完整 CAF、UI sync、Apple 资源运行时/本地渲染模块。额外 codeload 内存复核请求因 TLS EOF 失败，未计为通过。这里不是“上游完全没有 Ultra”的结论，而是“公开触发声明及部分基础设施不足以提供完整接收栈”的当前证据。

不把远端整体合并当成已解决接入；任何可复用代码仍须按正式目标、HS5 数据/显示边界和端到端验证决定如何接入。

## HS5 系统包证据

本次复用了 3092 的 CarPlay 配置及 3222 的已提取系统组件和 IPC 调查。二者不是当前实车版本的共同运行证明。

| 已确认的证据 | 实际能够证明什么 |
| --- | --- |
| `airplay.conf` 的 Main Screen、1920×720、30 fps、传统音频/HID | 原厂传统 CarPlay 接收配置；配置身份字符串不是接收 SDK 的版本证明 |
| `AppleFunction.conf` 的 AIS R25 注释、VehicleStatus/GNSS/VehicleInfo | 既有 iAP2 配置和车辆接口线索；车辆信息字段本身不是 Ultra 能力 |
| `apple_service.rc` 的 AppleServiceNative、iAP2/NCM/UAC2 | 系统声明传统 Apple 服务集成；未证明当前设备上完整可运行 |
| 3222 `cluster-hmi` 的 `Kanzi version: 2021-12-01: 3.6.9` 及独立 KZB | 原厂仪表 HMI 的引擎和资源；不是 Apple Local UI 渲染器版本 |
| IPC 导航状态与共享表面消费链 | 原厂仪表能组合本地显示和外来导航画面；未证明兼容 Ultra 同步/资源/车辆状态协议 |

在已读目录、可打印字符串、既有反汇编范围内，未确认完整 Apple Ultra 接收端的阳性证据。未命中不能排除其他分区、压缩资源、无符号组件或其他版本固件；本次不作“HS5 硬件绝对无法支持”的结论。

本地证据见 `docs/evidence/hs5-3092/`、`../work/update-package-20261009/ipc-audit/IPC仪表导航消费核查.md` 及 [原厂主题历史调查](HS5-ULTRA-THEME-AUDIT.zh-CN.md)。

## 当前结论与验收边界

当前没有已完成、经官方规范对照验证的 HS5 CarPlay Ultra 实现。内置 DiPlay 身份不补齐正式车端文档、车型资源、本地渲染或系统显示接入。不能承诺“换个主题即可实现”，也没有依据承诺只更新 Android APK 就能完成。

后续实现依据必须逐项落到可取得的官方资料、实际代码和实机消息/显示证据。至少区分：Ultra 提示触发、各协议通道建立、真实资源传输与验证、本地渲染、车辆状态接入、多屏同步、完整仪表实机表现；任一单项通过都不自动视为全部完成。正式认证状态与兼容性研发结果也分别记录。

管理页改为真实目标“Apple CarPlay Ultra”，当前保持关闭且不可操作。日志中即使 UI sync 被接受也只报告该通道结果，不报告整个 Ultra 已就绪。本次未制作 Kanzi 主题、未写入固件、未部署官方车端组件，也未安装新的 APK。

## 本次修正验证

针对引导/管理提示与诊断就绪判断执行 34 项 common 回归检查，全部通过；common Lint 无错误。构建日志：`/tmp/hs5-ultra-scope-correction.log`。这些检查只验证本次源码修正，不是 Ultra 协议兼容或官方认证测试。原 hs5.6 APK 仍为此前构建，未重新打包或安装。

## hs5.7 后的实际接入可行性复核

用户进一步明确要在 Apple 官方 CarPlay Ultra 内操作空调和座椅，无需切换到 Android 管理页。2026-10-15 再次成功读取 Apple CarPlay 开发者入口、WWDC24 10111 和 GitHub master；上游仍为 `2bb1adec3a49104760e751005e5db2c6ff82f6b4`，没有新的完整 Ultra 实现。来源及响应摘要记录在 `docs/evidence/ultra-feasibility-20261015.json`。

hs5.7 新增的 `Hs5VehicleData.execute` 已提供车辆侧下发、校验和反馈基础设施，但当前 `CarPlayController` 的 AirPlay `/command` 回调只处理既有电话、语音、音频及蓝牙交接，没有 Ultra 空调/座椅命令解码。上游普通 iAP2 `VehicleStatus` 是部分状态上报，其座椅占用字段也不能当作加热/通风控制。

因此，当前材料不足以完成这次请求的官方 Ultra 原生控制。继续实现需要可取得且足以实现的车辆能力/命令/状态协议、订阅与确认/错误语义，以及兼容的车型资源、验证和 UI 运行/同步组件。DiPlay 附件身份证书不提供这些协议与组件；不能通过猜测 `/command` 字符串或仅声明 Ultra 能力完成接入。此结论不等于 HS5 硬件绝对不支持。

本次仅更新接入证据，没有修改生产代码或开启 Ultra，也没有生成新 APK。此前 hs5.7 的车辆层构建与模拟测试结果继续有效，车辆实测和 Ultra 验收仍未完成。
