> 路线更正（2026-10-15）：用户目标是 Apple 官方 CarPlay Ultra。本文的 Kanzi 换肤建议已撤回，仅保留原厂主题接口的只读证据；不作为 Ultra 实现或接入依据。当前工作以 [官方 Ultra 接入核查](APPLE-CARPLAY-ULTRA-INTEGRATION.zh-CN.md) 为准。

# HS5 原厂 Kanzi 主题接口调查（历史路线，已撤回）

日期：2026-10-15。范围：静态读取 3222 完整升级包及已恢复的对应方法体；未调用主题写入接口，未修改车机、固件或 App 源码。

## 结论

3222 包存在真实的仪表主题更新链路，IPC HMI 还实现了一个外部 Kanzi 主题槽位。因此不能说 HS5 完全没有全仪表换主题的入口。但目前没有一份能在该 HMI 上使用的 Ultra 风格主题包，也没有确认当前实车固件的槽位、普通 APK 的实际可达性和可验证的原厂恢复流程。此次 App 的开关不能据此标成可用。

`changeClusterTheme("ultra")` 不会安装或打开 Ultra：服务端把名称压缩成原厂 1/2/3 三个整数，未知名字直接走第 3 个原厂主题。`updateClusterTheme(...)` 是持久化主题包更新，涉及 IPC 文件系统；它不是导航副屏显示开关。

用户目标仍为完整仪表，包括车速、转速、地图、媒体和车辆信息布局；Android 1920×720 导航副屏不能代替完整仪表根层。原厂仪表 HMI 和警示模块必须继续正确工作。

## 版本与证据身份

- 此处 IPC 和主题更新结论来自 `neu_hs5y22_update_ivi_7901010DD52_250626-322200.zip`，下称 **3222**。
- 此前无线和权限审计另有 **3092** 基线。本报告没有确认 3092 IPC 的同一路径，也没有把 3222 等同于当前实车版本。
- 3222 的 `QisiAdapterService.apk` 为 versionCode 3820、versionName `20250210-144658`。
- 3222 `AlfusSystemServer.apk` 的 SHA256 为 `52eaf515195354389ba1aa0ba5745e5f0f0395466b63400fc178fff8611812b4`，与 2026-10-08 已恢复源码的原 APK 记录完全相同，因此可以复用其 SotaService/IvpModule 方法体。不是只按类名复用。

证据：本轮文件身份（外部历史资料：`work/ultra-theme-audit-20261015/file-identity.json`，未随包交付）、旧 APK 哈希记录（外部历史资料：`work/system-analysis-20261008/packages/records/priv-app__AlfusSystemServer__AlfusSystemServer.apk.json`，未随包交付）。

## 主题切换确实只有原厂三个档位

`ltd.qisi.adapterproxy.CarClusterUpdateManager` 构造时调用 `IVehicleRemoteClienter.queryBinder(53)`。3222 服务端对应 `j.a.b.f.t0`，继续委托 `CarClusterThemeUpdateManagerSDKImpl`。

| 调用名称 | SDK 实际行为 |
|---|---|
| `tech_dark` | `QISISettingsIF.setSystemTheme(1)` |
| `sport_dark` | `QISISettingsIF.setSystemTheme(2)` |
| 其余名称，包括 `ultra` | `QISISettingsIF.setSystemTheme(3)` |

`getSystemThemeToInt` 也是相同映射；未知名称返回 3。该映射只能确认可选原厂档位，不能确认任意自定义主题已注册。

证据：客户端 Binder 53（外部历史资料：`work/qisi-interface-audit-20261010/ltd_qisi_adapterproxy_CarClusterUpdateManager.dis.txt`，未随包交付）、主题切换实现（外部历史资料：`work/ultra-theme-audit-20261015/Qisi-CarClusterThemeUpdateManagerSDKImpl.dis.txt`，未随包交付）、服务端代理（外部历史资料：`work/ultra-theme-audit-20261015/Qisi-t0.dis.txt`，未随包交付）。

## 更新链路与参数

静态调用链：

`APK → Qisi Binder 53 → CarClusterThemeUpdateManagerSDKImpl → QISICarClusterManager → faw.sota.CarClusterUpdateManager → alfusos.sota.ISotaService → Alfus SotaService → IVP → IPC sota-server → /sota-data → cluster-hmi/Kanzi`

`updateClusterTheme` 的四个参数已由日志和参数注解交叉确认：`theme`、`md5`、`version`、`filepath`。Android 客户端检查非空字符串与监听器；SotaService 把输入文件复制到 `/mnt/update/<原文件名>`，检查调用者传入的 MD5，然后发出 `content://ihu/SotaUpdate`、`SotaTheme`。该方法接收 `version`，但其实现未用这个参数进行版本比较，而是调用 `copyFileToUpdate(theme, md5, filepath)`。

IPC `sota-server` 注册 IVP 回调 42/43，从 Android 镜像的共享更新分区取得对应 ZIP，解压进 `/sota-data`。这些是安装链路证据，尚未在实车执行。

证据：Qisi 更新参数及转发（外部历史资料：`work/ultra-theme-audit-20261015/Qisi-QISICarClusterManager.dis.txt`，未随包交付）、FAW 客户端（外部历史资料：`work/update-package-20261009/format-audit/faw-framework/bytecode.dis.txt`，未随包交付）、Android MD5 检查及 IPC 通知（外部历史资料：`work/system-analysis-20261008/oem-apps/AlfusSystemServer/smali/classes/com/alfus/server/sota/SotaService.smali`，未随包交付）、更新入口（外部历史资料：`work/system-analysis-20261008/oem-apps/AlfusSystemServer/smali/classes/com/alfus/server/sota/SotaService.smali`，未随包交付）、IVP 请求（外部历史资料：`work/system-analysis-20261008/oem-apps/AlfusSystemServer/smali/classes/com/alfus/server/sota/IvpModule.smali`，未随包交付）。

## HMI 不是任意主题目录扫描

3222 `KZBPlayerApplication::onProjectLoaded()` 先加入三个原厂资源包：

- `/usr/bin/cluster-hmi/Theme_packs/Classic.kzb`
- `/usr/bin/cluster-hmi/Theme_packs/Technology.kzb`
- `/usr/bin/cluster-hmi/Theme_packs/Light.kzb`

随后它构造 `/sota-data/sport_dark/cluster_version.xml`，调用 `IsVersionEnable()`。该函数打开文件、读到第 4 行并检查这一行是否含字符 `1`；条件成立后才调用 `ResourceManager.addKzbFile()` 加入 `/sota-data/sport_dark/cluster/Light.kzb`。已追到具体调用指令，因此这是实际 HMI 加载能力，超出“找到字符串”的证据。

目前确认的是 `sport_dark/Light.kzb` 固定槽位。未找到让普通 APK 新增第 4 个主题或直接接管整个仪表主工程的现成契约。导入扩展 KZB 不等于任意新文件都能替换原厂节点；新包仍须匹配原厂 Kanzi 资源名称、对象结构、数据源与运行版本。

加载证据来自 `onProjectLoaded()`；没有确认安装成功后无需 HMI 重启就能实时重新导入该 KZB。

证据：原厂加载及版本条件（外部历史资料：`work/ultra-theme-audit-20261015/HMI-onProjectLoaded-theme-slots.dis.txt`，未随包交付）、外部 KZB 导入（外部历史资料：`work/ultra-theme-audit-20261015/HMI-onProjectLoaded-override.dis.txt`，未随包交付）、启用文件解析（外部历史资料：`work/ultra-theme-audit-20261015/HMI-IsVersionEnable.dis.txt`，未随包交付）。

## 权限、验签及恢复边界

3222 `QISIAdapterService` 在 Manifest 中为 exported=true，service 节点未声明绑定权限；`onBind` 返回远程客户端 Stub。本轮已读 `queryBinder` 和 `t0` 的相关四个方法，未见调用者 UID、包名、签名或运行时权限校验。这只说明这些方法体没有显式检查，不能由此保证实车 SELinux、服务注册、上游初始化和文件可读性允许新 APK 调用。

Provider 的 `WRITE_SETTINGS` 是另一条受保护入口，其权限不应与 service 的 Binder 入口混为一谈。也不能把系统内置服务的特权转移给普通 APK。

本轮核对的 Android SotaService/IPC sota-server 安装路径仅见 MD5 和系统命令返回值检查，未见主题内容的数字签名验证、车型/资源兼容校验或事务式回滚。结论限于这条已读路径，不表示整车所有升级机制都没有验签。

**确认的恢复缺口**：IPC 先删除已有 `/sota-data`，再创建并解包新资源；不是先准备完成再原子替换。回调成功表示解压流程成功，不表示 KZB 能加载、仪表数据正确或警示仍可用。原厂三包保留在只读目录是潜在回退基础，但尚未确认坏包加载失败时自动恢复，以及用户开关关闭后能重新选择纯原厂资源。直接切换到另一个原厂档位也不等于卸载更新槽位。

证据：IPC 删除及解包（外部历史资料：`work/ultra-theme-audit-20261015/sota-server.dis.annotated.txt`，未随包交付）、解包后成功回调（外部历史资料：`work/ultra-theme-audit-20261015/sota-server.dis.annotated.txt`，未随包交付）、服务 Manifest（外部历史资料：`work/ultra-theme-audit-20261015/Qisi-service-manifest.txt`，未随包交付）、服务 onBind（外部历史资料：`work/update-package-20261009/format-audit/QisiAdapterService/bytecode.dis.txt`，未随包交付）、Binder 查询（外部历史资料：`work/ultra-theme-audit-20261015/Qisi-QISIAdapterService_b.dis.txt`，未随包交付）。

## 与官方 Ultra 目标的关系

原厂 Kanzi 主题切换和 SOTA 更新接口仅证明 HS5 原厂显示/主题能力，不证明 Apple 本地渲染器、官方资源包验证、UI sync 或车辆状态协议已接通。此前从这些接口推导“制作 Ultra 风格主题即可满足需求”的路线已撤回。

用户要求真正的 Apple CarPlay Ultra。官方架构、上游实现范围、缺失证据和接入限制统一记录到 [官方 Ultra 接入核查](APPLE-CARPLAY-ULTRA-INTEGRATION.zh-CN.md)。本文不再提出制作或安装 Kanzi 主题的执行步骤。

本次及此前只读调查均未写入主题或刷写车机。
