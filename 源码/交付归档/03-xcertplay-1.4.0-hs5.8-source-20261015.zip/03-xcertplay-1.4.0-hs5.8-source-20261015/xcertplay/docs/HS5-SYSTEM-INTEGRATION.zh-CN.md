# HS5 系统接入与安装权限边界

日期：2026-10-15。对象：xcertplay HS5 分支与用户提供的 `hs5y22_update` 3092 升级包。本轮为源码和固件静态核对，未在 HS5 实车验证首次安装、蓝牙配对或 P2P 建组，也未修改、重打包或刷入车机系统。

## 目标流程与当前接入方式

目标是“首次安装 → 打开首页 → 点击连接 → iPhone 搜索并配对车机蓝牙 → App 创建专用 Wi-Fi Direct 组主 → iPhone 加入 → CarPlay”。车机蓝牙和 Wi-Fi 总开关通常已打开，重点是蓝牙可发现、首次配对的衔接与 App 自己管理 P2P 组，不要求用户手工创建热点。

车机创建的 P2P 组主可接受普通 Wi-Fi 客户端加入。iPhone 通过无线 iAP2 控制链路获取该组的 SSID、密码和 AirPlay 端点，再加入网络；这不要求 iPhone 实现 Android 的 P2P 同伴发现 UI。无线会话使用直接本地网络，不需要 VPN/TUN。项目保留 P2P 接入，不恢复 LocalOnlyHotspot 或 Manual hotspot 作为回退。

Android 9 的 `createGroup(channel, listener)` 不接受应用指定的 SSID、密码、频段或频率；系统选择参数后，App 读取实际组信息并交给 iPhone。当前 `HongqiWifiP2pGroupManager` 使用此路径，关闭时移除自己持有的临时组，不能把“请求建组成功”当成“iPhone 已加入”或“CarPlay 已认证”。旧组回收仅针对 App 可以证明属于自己的组。

源码入口：[HongqiWifiP2pGroupManager.kt](../shared/src/main/java/com/shilapi/xcertplay/network/HongqiWifiP2pGroupManager.kt)、[CarPlayController.kt](../shared/src/main/java/com/shilapi/xcertplay/orchestration/CarPlayController.kt)、[IphoneBluetoothDevices.kt](../shared/src/main/java/com/shilapi/xcertplay/transport/IphoneBluetoothDevices.kt)。

## 普通 APK 与系统集成的区别

普通侧载 APK 可以自动请求 P2P 建组、启动本地 AirPlay 服务，并探测已配对 iPhone 的 iAP2 服务。首次安装无法仅凭 Manifest 静默授予所有权限，也不能假定有 OEM 平台身份。减少弹窗的依据应是“权限已被系统授予”或“该功能不需要此权限”，而非忽略检查。

| 项目 | HS5 Android 9 普通 APK | OEM 平台签名/预装集成需要核对的条件 |
| --- | --- | --- |
| Wi-Fi 状态、P2P 建组 | 3092 的组主创建与组/连接信息读取仅需 `ACCESS_WIFI_STATE`、`CHANGE_WIFI_STATE` 等安装时声明权限；HS5 API 28 的无线启动不请求扫描定位或开启定位总开关，P2P 返回真实结果后才继续 | 按实际系统框架核对；可选 GPS reporting 仍按需请求定位，不能仅以应用位于系统目录推断权限齐全 |
| 蓝牙已配对设备与 RFCOMM | Android 9 的 `BLUETOOTH`、`BLUETOOTH_ADMIN` 为安装时权限；配对由系统栈处理 | 可发现控制和首次配对策略需真实 OEM 接口或符合系统策略的调用；不能静默替用户接受 iPhone 首次配对 |
| 车机蓝牙可发现 | 3092 的 `setScanMode(II)` 是 public/light greylist，服务检查普通 `BLUETOOTH` 与当前用户；App 尝试 120 秒可发现并等待真实状态确认，失败才走 `ACTION_REQUEST_DISCOVERABLE` | 已有静态依据允许侧载 App 请求，但须核对实际固件运行结果，不能以系统 API 返回 accepted 等同于射频状态已更新 |
| 麦克风输入 | `RECORD_AUDIO` 运行时授权；首次点击连接时按需请求，拒绝后无法提供 Siri/通话麦克风输入 | `default-permissions` 可为合适的系统应用配置运行时默认授权；不能替代音频 HAL/路由适配 |
| 主屏 CarPlay | App 自己的 Activity/Surface 正常显示，不需要悬浮窗授权 | 同样使用主屏 Activity；不因追求免授权而改用全局悬浮窗 |
| 仪表地图悬浮窗口 | 当前 HS5 `Presentation` 设置 `TYPE_APPLICATION_OVERLAY`，需要 `Settings.canDrawOverlays()` 为真 | 单独配置/验证 `SYSTEM_ALERT_WINDOW` 权限与 AppOps；它不是普通运行时权限弹窗 |
| HUD 与车辆 Binder | 已知 Qisi 接口不等于任意服务、任意功能均对侧载包开放；接口调用仍需服务端允许 | 核对服务端权限检查、调用身份和 Binder SELinux，不能用权限 XML替代协议实现 |
| 板载 I2C 认证 | `/dev/i2c-0` 路径不是授权；设备文件权限与 SELinux 都必须允许 | 可由专用 native 服务代理，或 OEM 已存在且可验证的 Binder 服务提供能力；平台签名/预装本身不自动赋予任意 I2C 读写权限 |
| 无线 VPN 授权 | 无线不走 VPN，因此没有此授权步骤 | 无线保持本地网络；USB NCM 有线路径的 VPN consent 是另一条链路 |

当前 Manifest 与权限判断：[shared/AndroidManifest.xml](../shared/src/main/AndroidManifest.xml)、[common/AndroidManifest.xml](../common/src/main/AndroidManifest.xml)、[CarPlayHostActivity.kt](../common/src/main/java/com/shilapi/xcertplay/CarPlayHostActivity.kt)。

Android 12 以上的测试手机另有 `BLUETOOTH_CONNECT`/`BLUETOOTH_SCAN`/`BLUETOOTH_ADVERTISE`，其中可发现请求使用 `BLUETOOTH_ADVERTISE`；Android 13 以上另有 `NEARBY_WIFI_DEVICES`。这些已在当前 Manifest 与无线权限判断中声明，不能套用成 HS5 API 28 的运行时蓝牙权限。项目没有将降低 `targetSdk` 至旧权限模型作为免授权方案。

## 系统包能确认什么

3092 原始载荷路径：`external-firmware/neu_hs5y22_update_ivi_7901010DD42_240927-309200.zip`。该载荷实际为 SquashFS，内部包含分区镜像。本轮直接从该载荷解出的 system/vendor ext4 镜像读取下述白名单配置，保存到 `docs/evidence/hs5-3092/`；每个文件的路径、大小和 SHA-256 记录在 [manifest.json](evidence/hs5-3092/manifest.json)。此前核查还确认三份 CarPlay 文件与 3222 同名文件 SHA-256 一致，但本文件的系统权限结论使用本轮 3092 原件。

3092 属性证据确认 Android 9/API 28、`HONG QI`、`t1c_acrn`、Intel `broxton`、x86/x86_64。它们也是当前 HS5 适配器的设备匹配边界，不是认证芯片型号证据。

证据：[system build.prop](evidence/hs5-3092/system/system/build.prop)、[vendor build.prop](evidence/hs5-3092/vendor/build.prop)。

### 专用 P2P 与普通 Wi-Fi 是两个接口

3092 `init.t1c_acrn.rc` 设置 `wifi.direct.interface=p2p0`、`wifi.interface=wlan0`，并分别为两个接口加载配置：

```text
-ip2p0 -Dnl80211 -c/vendor/etc/wifi/p2p_supplicant.conf
-I/vendor/etc/wifi/p2p_supplicant_overlay.conf -N
-iwlan0 -Dnl80211 -c/vendor/etc/wifi/wpa_supplicant.conf
-I/vendor/etc/wifi/wpa_supplicant_overlay.conf
```

`p2p_supplicant_overlay.conf` 只有 `disable_scan_offload=1` 与 `p2p_no_group_iface=1`。`p2p_disabled=1` 出现在普通 `wlan0` 的 `wpa_supplicant_overlay.conf`，不能用这一行认定专用 `p2p0` 也被禁用。`p2p_no_group_iface=1` 意味着不为组再创建额外接口；App 应从系统返回的实际组接口读取地址，不能强行假定接口叫 `p2p-wlan0-0`。

VINTF 保留 Bluetooth HCI 1.0、Wi-Fi IWifi 1.2 及 hostapd/supplicant HAL；Wi-Fi HAL 进程以 `wifi` 身份运行并声明网络能力。这些说明系统具备专用无线服务路径，不能据此绕过 App 权限检查，也不能证明当前实车固件和运行参数完全一致。

证据：[supplicant 双接口启动](evidence/hs5-3092/vendor/etc/init/hw/init.t1c_acrn.rc)、[P2P overlay](evidence/hs5-3092/vendor/etc/wifi/p2p_supplicant_overlay.conf)、[普通 Wi-Fi overlay](evidence/hs5-3092/vendor/etc/wifi/wpa_supplicant_overlay.conf)、[Wi-Fi HAL 权限](evidence/hs5-3092/vendor/etc/init/android.hardware.wifi@1.0-service.rc)、[VINTF manifest](evidence/hs5-3092/vendor/etc/vintf/manifest.xml)。

### 3092 的组主创建不经过扫描定位检查

本轮核对了当前固件的 framework 与 Wi-Fi 服务两层。`WifiP2pManager.createGroup()`、`requestGroupInfo()`、`requestConnectionInfo()` 只校验 channel 并发送对应消息；`WifiP2pServiceImpl.getMessenger()` 强制 `ACCESS_WIFI_STATE` 和 `CHANGE_WIFI_STATE`，`ClientHandler` 将允许的消息转发给状态机。`CREATE_GROUP` 分支直接进入 `WifiP2pNative.p2pGroupAdd()`；组信息、连接信息分支复制当前状态并回复。上述路径没有定位权限、定位开关或扫描 AppOps 检查。

为区分相邻分支，已从 compact dex 的 sparse-switch 表核实 `CREATE_GROUP=0x2200d → PC 0x310`、`REQUEST_GROUP_INFO=0x22017 → PC 0x187`、`REQUEST_CONNECTION_INFO=0x22015 → PC 0x1a5`。`REQUEST_PEERS=0x22013` 是另一个分支，它调用 `getPeers()`，进而调用 `enforceCanAccessScanResults()` 检查定位开关与定位/AppOps。当前 App 自主创建 GO 并读取自己组信息，不调用扫描/同伴列表接口，因此 HS5 API 28 无线连接不再先请求定位权限，也不要求用户打开定位总开关。可选车机 GPS reporting 的定位授权保持独立；其他 Android 版本或其他固件仍遵循各自权限判断。

证据：[framework 三个 GO API](evidence/hs5-3092/wireless-framework/wifi-p2p-manager-go.txt)、[服务入口与声明权限](evidence/hs5-3092/wireless-framework/wifi-p2p-service-access.txt)、[GO 状态机分支](evidence/hs5-3092/wireless-framework/wifi-p2p-service-go.txt)、[switch 原始表与解码](evidence/hs5-3092/wireless-framework/wifi-p2p-switch-map.json)、[扫描定位门槛](evidence/hs5-3092/wireless-framework/wifi-p2p-peer-scan-gate.txt)。这些是静态框架依据，不等于已验证实车射频、HAL 并发能力或 iPhone 入网成功。

### 3092 的蓝牙可发现请求与实际状态确认

3092 `boot-framework.vdex` 中 `BluetoothAdapter.setScanMode(I)` 与 `setScanMode(II)` 的原始 dex access flags 均为 `0x0006`。Android 9 的 boot dex 把第一隐藏标志编码为 public/private/protected 位的反转；此值解码为 Java `PUBLIC=0x0001`，hidden 第一位为 1、第二位为 0，对应 `kLightGreylist=1`。它不是 Java private/protected，也不是 blacklist。Android 9 ART 默认策略允许 light greylist 访问并记录警告；此判断不使用 hidden API 豁免或绕过方案。

当前 Bluetooth APK 的 Binder `setScanMode(II)` 先检查当前用户，再调用服务；服务 `setScanMode(II)` 与 `setDiscoverableTimeout(I)` 仅强制普通 `android.permission.BLUETOOTH`，未在这两条方法中要求 `BLUETOOTH_PRIVILEGED`。因此这版固件有依据支持普通侧载 App 请求可发现，无需为此假定 OEM 平台签名。Qisi Adapter 的 `IBluetoothExtraManager` 只有配对设备排序和 listener 注册/注销方法，没有可发现控制方法，本轮不新增猜测的 OEM Binder transaction。

请求返回 `true` 只表示 native 层受理。`AdapterProperties.setScanMode()` 调用 `setAdapterPropertyNative()`，实际 `mScanMode` 到属性回调才更新，再发 `ACTION_SCAN_MODE_CHANGED`。当前 [CarPlayBluetoothDiscoverability.kt](../common/src/main/java/com/shilapi/xcertplay/CarPlayBluetoothDiscoverability.kt) 对已受理请求监听广播并在注册后再次读实际状态，最长等待 2 秒；确认真实模式为 `SCAN_MODE_CONNECTABLE_DISCOVERABLE` 才继续，否则调用系统可发现确认页。取消时注销 listener 并移除超时回调。该操作仅打开 120 秒可发现窗口，不修改 Wi-Fi/蓝牙总开关或车机蓝牙名称。

证据：[framework 原始 access flags 与服务调用](evidence/hs5-3092/wireless-framework/bluetooth-adapter-set-scan-mode.txt)、[服务权限与异步属性广播](evidence/hs5-3092/wireless-framework/bluetooth-service-set-scan-mode.txt)、[Qisi Bluetooth Extra 接口](evidence/hs5-3092/wireless-framework/qisi-bluetooth-extra-interface.txt)、[Android 9 ART 隐藏标志编码源码](evidence/hs5-3092/wireless-framework/aosp-p-hidden-api-access-flags.h)、[ART 默认策略判断](evidence/hs5-3092/wireless-framework/aosp-p-hidden-api.h)。

以上片段的原始 VDEX/APK 分区路径、大小、SHA-256、反汇编工具与原始行号，以及 AOSP 官方出处，保存于 [wireless-framework/manifest.json](evidence/hs5-3092/wireless-framework/manifest.json)。未将完整巨型反汇编或认证身份材料加入项目证据目录。运行时仍需核对实车实际固件、调用结果与广播；若车机原厂设置重新关闭可发现，App 必须报告状态而非声称请求永久生效。

### CarPlay 配置残留与服务

两版一致的 `AppleFunction.conf` 包含：

```ini
USBHostTransportCarPlayInterfaceNumber = 1
MFiAuthDevicePath = /dev/i2c-0
MFiAuthDeviceAddressA = 16
MFiAuthDeviceAddressB = 17
ACCESSORY_NAME = EXEED
ModelIdentifier = Neusoft Model
Manufacturer = Neusoft
SiriAudioStreamType = 11
AltAudioStreamType = 15
GNSSModeCarPlay = 127
CarPlay = 1
```

地址为 `0x10` 与 `0x11`，属于软件候选配置。`EXEED` 等跨车型名称说明配置可能沿用东软平台内容，不能证明本车主板装有 MFi 芯片或地址与布线一致。当前沿用用户已选择的本地认证后端，不自动改为板载 I2C。

`apple_service.rc` 声明以 `root` 启动 `/system/bin/AppleServiceNative`，并配置 USB iAP2、NCM、UAC2。两版已核对的 system 镜像目录均没有该程序。因此 `init` 声明、SELinux 类型或 Binder 服务名残留不能当作服务已运行。

证据：[3092 AppleFunction.conf](evidence/hs5-3092/system/system/etc/CarPlay/AppleFunction.conf)、[3092 apple_service.rc](evidence/hs5-3092/system/system/etc/init/apple_service.rc)、两版静态核查记录（外部历史资料：`outputs/reports/current/HS5-CarPlay残留与MFi硬件证据核查-20261014.md`，未随包交付）。

### I2C 和 apple-server 的权限证据

3092 `plat_file_contexts` 同时保留 `/dev/i2c-*` 的 `i2c_device` 和 `i2c-all_device` 匹配规则，实际节点最终 label 仍需实车读取确认；策略明确包含：

```text
(allow AppleServiceNative i2c-all_device (chr_file (ioctl read write open)))
(allow platform_app AppleServiceNative (binder (call transfer)))
(allow platform_app apple-server_service (service_manager (find)))
(allow system_app AppleServiceNative (binder (call transfer)))
(allow system_app apple-server_service (service_manager (find)))
```

`plat_service_contexts` 将 `apple-server` 映射到 `apple-server_service`。这些说明设计中存在“受系统身份约束的 App → AppleServiceNative → I2C”边界。当前未确认 Binder 实际注册、AIDL/transaction 协议、服务端权限检查或可供 xcertplay 使用的认证接口；不能直接猜 transaction 编号去调用。

普通 `untrusted_app`、`priv_app` 未发现上述 I2C 直接授权。历史实车检查中 I2C 节点为 root 所有且仅 root 可读写，shell 未获得有效芯片身份。这些与 Manifest 中的蓝牙/Wi-Fi 权限互相独立。

证据：[I2C 文件标签规则](evidence/hs5-3092/system/system/etc/selinux/plat_file_contexts)、[apple-server 标签](evidence/hs5-3092/system/system/etc/selinux/plat_service_contexts)、[I2C 域授权](evidence/hs5-3092/system/system/etc/selinux/plat_sepolicy.cil)、[平台 Binder 授权](evidence/hs5-3092/system/system/etc/selinux/plat_sepolicy.cil)、[系统 Binder 授权](evidence/hs5-3092/system/system/etc/selinux/plat_sepolicy.cil)。

### 默认权限文件

3092 vendor `default-permissions.xml` 为 `com.neusoft.audio`、`com.baidu.che.codriver`、`com.baidu.naviauto` 等既有包配置录音或定位默认授权；它没有为当前 xcertplay 包提供已确认的授权配置。文件中注释掉的旧包示例不属于生效规则。

`default-permissions` 用于系统默认授予危险/运行时权限。把 `SYSTEM_ALERT_WINDOW` 等名称写进此类 XML，不构成对应特殊 AppOps 已授权的证明；该文件中部分旧示例甚至处于注释内。`privapp-permissions` 用于 `signature|privileged` 权限白名单，同样不授予 Unix 设备文件权限、SELinux 域权限或任意 Binder 接口访问能力。

因此完整 OEM 安装即用需要逐项确认：实际应用签名与身份、系统认可的预装/默认授权策略、所需 privileged 权限白名单、悬浮窗口 AppOps，以及任何原生设备或 OEM Binder 的访问策略。平台签名和放入 `/system/priv-app` 是不同条件，不能互相替代；这里仅记录集成边界，不生成或部署刷机包。

证据：[vendor 默认权限](evidence/hs5-3092/vendor/etc/default-permissions/default-permissions.xml)、[系统默认权限](evidence/hs5-3092/system/system/etc/default-permissions/default-car-permissions.xml)、[privileged 权限白名单](evidence/hs5-3092/system/system/etc/permissions/privapp-permissions-platform.xml)。

## 验证与仍开放的验收

本文件核对的是静态文件和当前源码，不把历史 ADB、OPPO 测试或其他版本的构建结果记作本次 HS5 运行验证。需要绑定本次 APK 的实车验收仍包括：清空首次安装状态后点击连接、iPhone 能搜索到车机、系统配对完成后流程自动继续、组主和实际频率读取成功、iPhone 入网、CarPlay 主屏及麦克风上下行正常、断开后临时组正确释放。

免手工进入设置与完全没有系统确认框是不同验收项。HS5 API 28 的 GO 连接本身不再请求扫描定位；普通 APK 将其他必要请求集中在点击连接后，并让授权完成后自动继续。完全消除录音与仪表悬浮窗确认需已经生效的系统授权依据；可选 GPS reporting 另按需授权。首次蓝牙信任仍遵循车机与 iPhone 的系统配对过程。

Android 公开参考：[Wi-Fi Direct 接入](https://developer.android.com/develop/connectivity/wifi/wifip2p)、[WifiP2pManager.createGroup](https://developer.android.com/reference/android/net/wifi/p2p/WifiP2pManager#createGroup(android.net.wifi.p2p.WifiP2pManager.Channel,%20android.net.wifi.p2p.WifiP2pManager.ActionListener))、[蓝牙设置与可发现](https://developer.android.com/develop/connectivity/bluetooth/setup)、[默认权限源码](https://android.googlesource.com/platform/frameworks/base/+/android-9.0.0_r1/services/core/java/com/android/server/pm/DefaultPermissionGrantPolicy.java)、[privileged 权限白名单](https://source.android.com/docs/core/permissions/perms-allowlist)。这些资料解释 Android 能力，不替代受 MFi 授权限制的完整无线 CarPlay 接收端规范。
