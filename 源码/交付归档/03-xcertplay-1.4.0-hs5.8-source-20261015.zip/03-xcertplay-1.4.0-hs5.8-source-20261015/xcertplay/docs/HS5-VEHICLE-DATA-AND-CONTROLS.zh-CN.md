# HS5 车辆信息、空调与座椅接口核查

核查与接入日期：2026-10-15。先分析系统包和原厂应用，随后按用户要求在新项目接入原厂车辆接口。本轮没有改变实车状态或安装 APK；系统包可提供接口、信号及业务处理逻辑，不能提供车辆此刻的实时状态。

## 版本及证据

以下主要结论来自现有 **3222** 解包。另有 3092 对照材料，不能将两个版本的接口支持拼接成当前实车已通过。

- 原厂车辆服务：`work/update-package-20261009/format-audit/QisiAdapterService/bytecode.dis.txt`。
- 本轮恢复原厂 `vendor/app/QisiHVAC/oat/x86_64/QisiHVAC.vdex`，提取器退出码 0，恢复 3 个 CompactDex；反汇编在 `work/vehicle-controls-audit-20261015/QisiHVAC-3222/bytecode.dis.txt`。
- 按类提取的证据及原文 LF 行号：`work/vehicle-controls-audit-20261015/selected-index.json`。以上 `work` 路径均相对工作区根目录。

## 空调

原厂实际调用链为：`HvacRepository → CarACManager → ICarATCManager → 原厂服务实现 → QISICarATCManager → CAN 信号适配层`。客户端初始化读取状态，并通过 `registerCarACStateListener(ICarACStateListener)` 订阅变化。

| 功能 | 读取入口 | 控制入口 | 静态实现证据 |
| --- | --- | --- | --- |
| 空调开关 | `getACFrontState()` | `setACFrontState()` | 读取 `Rule_WorkingSt_AC`，写入进入 CAN 适配层 |
| 左右设定温度 | `getACFrontTemperature(index)` | `setACTemperature(index, temperature)` | 左右分别使用 `Rule_ExpectTemp_Left/Right`；原厂包含数值转换与范围校验 |
| 风量 | `getACFrontVolume()` | `setACFrontVolume()` | 读取 `Rule_BlowLevel`，写入进入 CAN 适配层 |
| 出风模式 | `getACBlowMode(index)` | `setACBlowMode(index, mode)` | `Rule_BlowMode`，原厂另作枚举转换 |
| AUTO | `getACAutoMode(index)` | `setACAutoMode()` | `Rule_AutoMode` |
| A/C 压缩机 | `getACCompressorState(index)` | `setACCompressorState()` | `Rule_CompressorSt` |
| 内外循环 | `getACCirculationState()` | `setACCirculationState()` | `Rule_FRSRECMode` |
| 前除霜 | `getACFrontDefFunctionState()` | `setACFrontDefFunctionState()` | `Rule_DEFMode` |
| 分区同步 | `getACZoneAutoSyncState(index)` | `setACZoneAutoSyncState()` | 找到原厂调用及实现，仍需核对车型能力 |
| 环境温度 | `getAmbientTemp()` | 无 | `Rule_AmbientTemp`，原厂有单位转换 |

这不是对 SDK 方法名称的简单罗列：原厂应用使用与服务端实际信号处理均已核对。但单个功能的有效枚举、当前可用性、权限、刷新时效和下发后的真实反馈仍未在本轮实车验证。后排空调、后除霜、空气净化等不按同名 API 自动判为支持；部分方法会返回 `-2`，须逐项核实。

## 前排座椅加热与通风

原厂 HVAC 实际使用 **CarSCCUManager**。同样名称也出现在 CarACManager/ATC 接口中，但不能据此选择调用路径。

| 项目 | 原厂实现情况 |
| --- | --- |
| 加热档位读取 | `getFrontSeatHeatLevel(index)`；3222 的 `QISICarSCCUManager` 在 `carType()==1` 分支读取 `Rule_SeatheatInd_FL/FR` |
| 通风档位读取 | `getFrontSeatVentLevel(index)`；相同车型分支读取 `Rule_SeatVentInd_FL/FR` |
| 加热/通风档位设置 | `setFrontSeatHeatLevel(index, level)` / `setFrontSeatVentLevel(index, level)`；对应车型分支有实际 CAN 发送路径 |
| 档位变化订阅 | `carType()==1` 时，底层注册上述四个 CAN 信号；信号变化经 `QISICarSCCUManager$2 → SDK Binder 回调 → HVAC listener` 更新 LiveData。加热/通风档位的静态反馈链已确认；尚无本轮实车事件与数值验证 |
| 座位索引 | 原厂应用区分主驾 0、副驾 1 |
| 单独开关状态接口 | 此处底层 `get/setFrontSeatHeatState`、`get/setFrontSeatVentState` 返回 `-2`；不能报告为已实现的独立开关通道 |
| 支持配置 | 原厂检查 `FRONT_SHS`、`FRONT_SVS` 等 EOL 配置；尚未读取本车配置，因此不能承诺所有座位、所有固件均可用 |

3222 原厂服务关键原文位置：加热档位读取 2158012；通风档位读取 2158089；加热档位设置 2158258；通风档位设置 2158344；信号注册 2158210；变化回调 2218600。这里的 CAN 适配层内部命令编号不等于总线 CAN 帧 ID。

车型分支也有代码依据：`QISICarEOLManager.carType()`（原文 2151496）读取 PDSN；前十位为 `7901010DD4` 或 `7901010DD5` 时返回 1（原厂日志 C255），`7901010DD2` 返回 0（C235），未知返回 -1。用户提供的零件号 `7901010-DD52-B` 去掉横杠后的前缀与 DD5 匹配，但尚未确认本车服务实际返回的 PDSN。

座椅档位设置参数在该实现中校验为 1～4，不能直接解释成四档或以 0 关闭。后续原厂 UI 静态核查确认命令关/低/中/高为 1/2/3/4，而回读为 0/1/2/3；本车实际反馈仍待验证，补充证据见下文。

## 其他车辆信息

| 信息 | 原厂入口/证据 | 当前结论 |
| --- | --- | --- |
| 车速、挡位 | `getCarSpeed()` / `getSensorTypeGear()`；`Rule_VehicleSpeed` / `Rule_LeverInfo` | 有原厂读取实现；旧 App 另有 AAOS/Qisi 读取代码 |
| 剩余燃油、低油量提醒 | `getRemainFuel()` / `getFuelLevelWarning()` | 有原厂读取实现 |
| 续航、总里程、平均油耗 | `getRemainMileage()` / `getTotalMileage()` / `getAverageFuelConsumptionFloat()` | 有原厂读取及缩放实现 |
| 四门、尾门 | `getCarDoorState(index)` / `getTrunkLidStatus()` | 有原厂读取实现 |
| 四轮胎压 | `getTirePressureStatus(index)` | 有原厂读取及换算实现；单位仍需结合原厂 UI/实车确认 |
| 位置灯 | `getPositionLightStatus()` / `onPositionLight` | 原厂实现；旧 App 的历史实车日夜切换有验证记录 |
| 车窗位置、运动状态 | `QISICarWindowsManager.getWindowPosition()` / `getWindowMoving()` | 有原厂实现；位置为分段值，不能当作精确百分比 |
| 发动机转速 | `Rule_EngineSpeed` 及原厂仪表消费符号 | 找到信号规则，但第三方 App 稳定读取出口及单位缩放尚未闭合 |
| 安全带、点火、制动、AEB/FCW 等 | 原厂相关方法、信号及回调 | 已找到线索，尚未逐项完成实现与实车确认 |

## 调用权限及接入边界

原厂 QisiHVAC Manifest 声明 `android.car.permission.CONTROL_CAR_CLIMATE`。现有 CarService 对该权限定义为 `signature|privileged`；它不能作为普通运行时权限弹窗授予。原厂 Qisi Binder 的访问条件须独立核查，不能因 SDK 可复制就宣称第三方 App 能直接调用，也不能因 AAOS 权限受限就断言所有 OEM 路径均不可用。

实际读取须处理未更新、服务失联和原厂无效值。例如该包对速度 32766/32767、油量 254/255、胎压 255 等有异常处理；不能将其显示为真实读数。控制请求返回成功也须结合真实状态回报验收。

这些证据属于 HS5 车辆数据/控制侧，为 CarPlay Ultra 车辆状态接入提供依据；尚未完成与 Apple 官方 Ultra 协议、资源及 UI 的映射。本轮没有车端实时读取、控制回报或完整 Ultra 验收结果。

## 已落地的应用接入

新代码位于 `shared/src/main/java/com/shilapi/xcertplay/vehicle/`，管理页状态卡位于 `common/src/main/java/com/shilapi/xcertplay/Hs5VehicleDataView.kt`。旧 FAW-Play 项目未改。

- 客户端显式连接 `ltd.qisi.adapterservice.QISIAdapterService`，`Hs5VehicleBinderRpc` 核验根服务和各模块 Binder descriptor，使用已恢复的实际 transaction 编号与基本类型 Parcel。不会通过任意 Parcelable 加载原厂代码，也不记录 PDSN。
- `Hs5ComfortProtocol` 接 ATC 33、SCCU 49、EOL 31；`Hs5DrivingProtocol` 接车辆状态 15。getter、setter、回调签名及原文行号分别记录在 `docs/evidence/hs5-comfort-3222.json` 和 `docs/evidence/hs5-driving-3222.json`。
- `Hs5VehicleClient` 在工作线程执行原厂调用，订阅三类回调并每秒读取；每 10 秒重新检查车型和座椅能力。`Hs5VehicleData` 由 Activity 和保留的 CarPlay 控制器共享，最后一个使用者释放后注销回调、解绑服务并清空状态。只读观察者不维持连接。
- 共 32 个字段进入快照。失联、异常返回或未获取不转换成 0；超过 5 秒或时间戳异常的值不可作为当前状态使用。服务断开后清空旧状态，重连按连接代次隔离旧回调。
- 管理页增加“车辆状态（只读）”，展示空调、温度、风量、座椅、车速原始值、挡位、续航、总里程和环境温度。手机端明确显示平台不支持；未获取和原厂编码不伪装成有效物理读数。
- 应用内部 `execute` 接口已实现空调开关、左右温度、风量、模式、AUTO、A/C、循环、前除霜、同步和前排座椅档位下发。没有导出的广播、网络控制入口或新增控制按钮；启动、读取和订阅均不写车辆。下发校验连接、DD4/DD5 车型、对应座椅 EOL、参数及目标字段时效。原厂应答和实车反馈分开处理，不做乐观状态更新。

ATC 开关参数采用原厂接受的 1/2 编码，内外循环为 0～2，出风模式为 1/3/5/6/7，左右温度为 15～35 °C、0.5 °C 步进。当前接口层保留原厂指令和反馈编码，未加入面向用户的控制映射。

后续补充的 `docs/evidence/hs5-comfort-ui-semantics-3222.json` 核对了原厂 ViewModel、Repository、绘制和座椅资源：开关命令关=1/开=2，与回读编码不同；循环外=1/内=2，0 含义未闭合；座椅命令关/低/中/高=1/2/3/4，回读=0/1/2/3；送风 1=脸、3=脸脚、5=脚、6=脚窗、7=窗。A/C 还存在原厂把回读 1/2 都显示开启的逻辑，不将状态 2 自行解释成物理压缩机子状态。这些是原厂 UI 静态证据，不能替代当前 HS5 实测，也不证明 Apple Ultra 已接入。

用户明确要求控制出现在 Apple 官方 CarPlay Ultra 内，保持 CarPlay 使用不中断。Android 管理页控制卡的未交付草稿已撤回；当前 APK 保留只读诊断卡和内部控制接口，没有将管理页开关或悬浮层当作 Ultra 原生控制。

Qisi 速度读数先以 `SPEED_RAW` 保存，不能视为 km/h；既有独立 AAOS 车速路径不受此接入影响。油量、油耗和胎压的物理单位未核实；续航和总里程沿用服务输出，绝不重复施加 CAN 缩放。发动机转速、车窗、安全带、制动及其他仅有线索的信号未纳入本次 32 字段。

尚待实车验收：当前固件和模块 descriptor、第三方 APK 访问条件、PDSN/EOL、本车原厂编码与物理单位、回调/读取一致性、断线重绑，以及每类控制的真实状态回报。`CONTROL_CAR_CLIMATE` 的 Manifest 声明不代表获得特权，访问被拒绝时如实报告。本层也没有向 iPhone 宣告完整 Ultra 能力，管理页 Ultra 开关仍禁用。

## 本次验证

`1.4.0-hs5.7`（1407）完整 Gradle 检查通过：shared 494 项、common 110 项测试，无失败、错误或跳过；shared/common/mobile/automotive 的 Lint 无 Error/Fatal，但仍有警告。两个 APK 已构建并完成签名、包名/版本、Intel x86_64 库、桌面入口元数据及身份资源边界检查。记录在 `artifacts/hs5.7/verification.json`。

其中车辆接入新增 48 项测试，使用 Robolectric 与模拟的原厂 Binder/Parcel：覆盖真实交易类型、畸形回调拒绝、负值/无效值、不自动写车、能力/范围校验、服务应答不冒充物理反馈、共享连接释放、拒绝权限、断线重连、旧代读取/死亡通知隔离、阻塞后的数据过期，以及只读卡片。测试替身不能证明当前车机开放接口或实车已执行指令。

OPPO PJZ110 已成功覆盖安装本版；ADB 核对 versionCode=1407、versionName=1.4.0-hs5.7，并观察到连接后的 CarPlay 主画面。没有在该手机验证车辆服务、空调或座椅控制，也未把管理页只读卡的设备分支单元测试当作手机实测。当前没有 HS5 车机连接。
