# 20261011 无线与 Surface 源码包对照

检查对象：用户提供的 `xcertplay-无线Surface显示链路源码-20261011.zip`。只读取和解包对照，没有把其中的业务代码覆盖到当前项目。排除 macOS 附带的 `__MACOSX/._*` 后，共 27 个 Kotlin 文件；其中 9 个文件与当前固定上游基线一致，14 个同名文件有差异，另有 4 个文件在当前项目没有同名对应文件。逐文件哈希和对应路径见工作目录 `surface-archive-inspection/comparison.json`。

这个包是带有 HS5 改写的部分源码导出，包含主屏、仪表、无线、AirPlay 与媒体代码。它没有 Gradle 构建配置、AndroidManifest、资源、原生库、测试或身份文件，且引用未附带的 `SoftApBootstrap`、`ScreenCodec` 等实现，因此不能作为完整工程独立编译，也不能仅凭文件日期认定它比当前固定基线更新。

| 边界 | 源码包中的实现 | 当前项目及结论 |
|---|---|---|
| 主屏显示 | `CarPlayHostActivity` 直接创建 SurfaceView，SurfaceHolder 回调绑定主屏 | HS5 使用 VideoSurfaceView；普通手机仍保留上游 TextureView 路径 |
| 仪表显示 | `CarPlayHostActivityClusterHud` 在原厂 Display 的 Presentation 中创建另一个 SurfaceView | 当前通过 HongqiHostIntegration 接入；主屏 type 110、仪表 type 111 有各自的 Surface 与解码状态 |
| Surface 所有权 | 框架持有 Surface，回调只引用，不主动 release | 当前同样保留这一约束，并通过 VideoSurfaceHandoff 撤销生产者、等待原生解码器释放，包括已退役的解码器 |
| Surface 更换 | 解码线程执行 setOutputSurface；无有效 Surface 时释放解码器，保留配置并请求关键帧 | 当前保留原解码链和关键帧恢复，并增加销毁交接检查；此次仅检查，没有调整解码策略 |
| 解码器选择 | 默认 MediaCodec.createDecoderByType；仅在 Android 10+ 且明确选择 HEVC 软件解码时尝试软件 codec | 当前默认选择逻辑相同。SurfaceView 本身不能证明 Intel 核显解码，仍需实车 codec.name 与实际出帧日志 |
| 编码选择 | 宿主固定 hevcEnabled=false、hevcSoftwareDecoderEnabled=false；注释记录 Intel H.265 双屏卡死的历史判断 | 这是固定 H.264 的策略，不是代码强制选择某个 Intel codec；注释不能代替本轮实车验证 |
| 已有网络 | 增加 EXISTING 模式，SoftApBootstrap 尝试启动系统 AP，再按 wlan1/wlan0/ap0/swlan0 查找 IPv4 | 当前已有上游 MANUAL 模式。源码包的接口列表和人工声明信道需要具体车机证据，不能直接用于 OPPO |
| 热点失败回退 | MANUAL 任意失败后尝试 ExistingNetworkManager | 回退条件过宽，且找到 Wi-Fi IPv4 不等于确认这是目标 AP；目前不并入这一策略 |
| Android 9 P2P | 源码包对 API 29 以下的 WIFI_P2P 有额外回退 | 当前 HS5 只使用专用 API 28 Wi-Fi Direct 后端，不并入 LocalOnlyHotspot 回退 |
| 仪表镜像 | 可不声明 altScreen，而将主屏压缩帧送入第二个解码器 | 减少第二路网络传输，但仍增加一次解码；不等于独立仪表地图，也不能解决高速路口内容协商 |
| 身份加载 | 控制器改为读取 assets/offline-mfi，放宽原 LOCAL_FILES 文档地址校验 | ZIP 本身未提供这些资产。当前按用户选择保留设备私有文件，不将身份打进 APK，不采用这一改写 |
| Android 17 权限 | 宿主的无线权限列表仍只有 Bluetooth / Nearby Wi-Fi 等既有权限 | 同样缺少 ACCESS_LOCAL_NETWORK。当前已依据 SDK 37 声明并在启动前请求，手机 Bonjour 发布已通过 |

视频接收路径仍是 ScreenStream 解密并处理视频帧，经过 CarPlayMediaEngine / AndroidMediaSink，送入按屏幕分配的 MediaCodec，再输出到各自的 Surface。这里没有把主屏和仪表共用为一个全局 Surface；单个 Activity 留存 Surface 引用与跨 Activity 共享一个 Surface 是两回事。

源码包的串行解码、有限队列、输入暂忙时重试、等待随机访问帧和关键帧恢复可用于交叉核对。当前项目已有这些机制及回归检查，后续应按具体缺口逐项比较；现有证据不支持整体替换当前媒体与无线链路。

本次结论来自源码和逐文件对照，未编译此不完整源码包，也没有对它进行 HS5 实车验收。当前工程的编译、测试、签名和手机运行证据仍单独记录在 `artifacts/hs5.2/`。
