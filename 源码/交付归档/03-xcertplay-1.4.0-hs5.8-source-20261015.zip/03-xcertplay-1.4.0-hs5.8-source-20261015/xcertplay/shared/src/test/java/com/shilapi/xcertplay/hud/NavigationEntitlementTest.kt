package com.shilapi.xcertplay.hud

import android.os.Build
import android.os.SystemClock
import com.shilapi.xcertplay.iap2.wire.Iap2CsmFramer
import com.shilapi.xcertplay.iap2.wire.Iap2Frame
import com.shilapi.xcertplay.licensing.LicenseDecision
import com.shilapi.xcertplay.licensing.LicenseFeatures
import com.shilapi.xcertplay.licensing.ProductLicense
import org.junit.After
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.util.ReflectionHelpers

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class NavigationEntitlementTest {
    private val context = RuntimeEnvironment.getApplication()
    private val owner = Any()
    private val originalModel = Build.MODEL
    private val originalDevice = Build.DEVICE
    private var turnListener: ((ClusterTurnGuidance?) -> Unit)? = null

    @After fun cleanUp() {
        FawNavigationOutputs.endNow(owner)
        turnListener?.let(FawNavigationOutputs::clearTurnOverlayListener)
        ReflectionHelpers.setStaticField(ProductLicense::class.java, "featureDecision", null)
        ReflectionHelpers.setStaticField(ProductLicense::class.java, "featureCheckedAt", -1L)
        ReflectionHelpers.setStaticField(ProductLicense::class.java, "featureRefreshAt", -60_000L)
        ReflectionHelpers.setStaticField(Build::class.java, "MODEL", originalModel)
        ReflectionHelpers.setStaticField(Build::class.java, "DEVICE", originalDevice)
    }

    @Test fun savedMapPreferenceCannotBypassMissingOrHudOnlyEntitlement() {
        ReflectionHelpers.setStaticField(Build::class.java, "MODEL", "HONG QI")
        ReflectionHelpers.setStaticField(Build::class.java, "DEVICE", "t1c_acrn")
        context.getSharedPreferences("xcertplay_hs5", 0).edit()
            .putBoolean("instrument_map_enabled", true).putBoolean("hongqi_cluster_visible", true).commit()
        cacheDecision(false, emptySet())
        assertFalse(HongqiNavigation.mapShown(context))
        cacheDecision(true, setOf(LicenseFeatures.HUD))
        assertFalse(HongqiNavigation.mapShown(context))
        cacheDecision(true, setOf(LicenseFeatures.INSTRUMENT_MAP))
        assertTrue(HongqiNavigation.mapShown(context))
        cacheDecision(false, emptySet())
        assertFalse(HongqiNavigation.mapShown(context))
    }

    @Test fun licenseLossClearsPublishedTurnWhileRoutePacketsContinueAndBindingRestoresIt() {
        cacheDecision(true, setOf(LicenseFeatures.INSTRUMENT_MAP))
        FawNavigationOutputs.start(context, owner)
        val delivered = mutableListOf<ClusterTurnGuidance?>()
        val listener: (ClusterTurnGuidance?) -> Unit = { delivered += it }
        turnListener = listener
        FawNavigationOutputs.setTurnOverlayListener(listener)
        FawNavigationOutputs.onFrame(Iap2Frame(0x5202, tlvs(u16(1, 7), u8(3, 1), u8(8, 0))))
        FawNavigationOutputs.onFrame(Iap2Frame(0x5201, tlvs(u8(1, 1), group(10, byteArrayOf(0, 0, 0, 100)), u16(13, 7))))
        assertNotNull(delivered.last())
        cacheDecision(false, emptySet())
        FawNavigationOutputs.refreshTurnOverlay()
        assertNull(delivered.last())
        FawNavigationOutputs.onFrame(Iap2Frame(0x5201, tlvs(u8(1, 1), group(10, byteArrayOf(0, 0, 0, 80)), u16(13, 7))))
        assertNull(delivered.last())
        cacheDecision(true, setOf(LicenseFeatures.INSTRUMENT_MAP))
        FawNavigationOutputs.refreshTurnOverlay()
        assertNotNull(delivered.last())
    }

    private fun cacheDecision(allowed: Boolean, features: Set<String>) {
        // Represents the already verified local decision; crypto verification has independent tests.
        ReflectionHelpers.setStaticField(ProductLicense::class.java, "featureDecision", LicenseDecision(allowed, "fixture", features = features))
        ReflectionHelpers.setStaticField(ProductLicense::class.java, "featureCheckedAt", SystemClock.elapsedRealtime())
        ReflectionHelpers.setStaticField(ProductLicense::class.java, "featureRefreshAt", SystemClock.elapsedRealtime())
    }

    private fun group(id: Int, value: ByteArray) = Iap2CsmFramer.encodeParam(id, value)
    private fun u8(id: Int, value: Int) = group(id, byteArrayOf(value.toByte()))
    private fun u16(id: Int, value: Int) = group(id, byteArrayOf((value shr 8).toByte(), value.toByte()))
    private fun tlvs(vararg values: ByteArray) = values.fold(byteArrayOf()) { bytes, next -> bytes + next }
}
