package com.shilapi.xcertplay.transport

import com.shilapi.xcertplay.iap2.wire.Iap2ParameterList
import org.junit.Assert.*
import org.junit.Test

class Hs5IdentificationTest {
    private fun identity() = Iap2IdentificationConfig("test", "test", "test", "test", "1", "1", 3)
    private fun fields(config: Iap2IdentificationConfig) =
        Iap2ParameterList.parse(Iap2IdentificationClient.identificationInformation(config).payload)
    private fun numbers(bytes: ByteArray) = bytes.toList().chunked(2).map { ((it[0].toInt() and 255) shl 8) or (it[1].toInt() and 255) }

    @Test fun routeLaneAndSpeedDeclarationsHaveIndependentGates() {
        val base = fields(identity())
        assertNull(base.first(30)); assertNull(base.first(22)); assertFalse(0x5204 in numbers(base.first(7)!!.payload))
        val route = fields(identity().copy(routeGuidanceEnabled = true))
        val component = Iap2ParameterList.parse(route.first(30)!!.payload)
        assertEquals(listOf(0, 1, 2, 4, 6), component.asList().map { it.id })
        assertEquals(listOf(42), numbers(component.first(0)!!.payload))
        assertEquals(listOf(64), numbers(component.first(2)!!.payload))
        assertEquals(listOf(8), numbers(component.first(6)!!.payload))
        val runtime = identity().copy(routeGuidanceEnabled = true, laneGuidanceEnabled = true,
            locationInformationEnabled = true, vehicleSpeedEnabled = true)
        val enabled = fields(runtime)
        assertEquals(listOf(8), numbers(Iap2ParameterList.parse(enabled.first(30)!!.payload).first(8)!!.payload))
        assertTrue(0x5204 in numbers(enabled.first(7)!!.payload))
        assertNotNull(Iap2ParameterList.parse(enabled.first(22)!!.payload).first(20))
        val bootstrap = fields(runtime.copy(routeGuidanceEnabled = false, laneGuidanceEnabled = false,
            locationInformationEnabled = false, vehicleSpeedEnabled = false))
        assertNull(bootstrap.first(30)); assertNull(bootstrap.first(22))
        assertFalse(0x5204 in numbers(bootstrap.first(7)!!.payload))
    }

    @Test fun unsupportedCapabilityCombinationsAreRejected() {
        assertTrue(runCatching { identity().copy(laneGuidanceEnabled = true) }.isFailure)
        assertTrue(runCatching { identity().copy(vehicleSpeedEnabled = true) }.isFailure)
    }
}
