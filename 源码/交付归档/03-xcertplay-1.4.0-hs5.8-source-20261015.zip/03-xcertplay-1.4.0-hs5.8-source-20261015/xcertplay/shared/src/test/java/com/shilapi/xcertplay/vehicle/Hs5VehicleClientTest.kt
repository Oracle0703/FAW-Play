package com.shilapi.xcertplay.vehicle

import android.content.ComponentName
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.ServiceConnection
import android.os.Binder
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.Parcel
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import org.robolectric.shadows.ShadowBuild
import java.io.Closeable
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Exercises real Parcel transactions and connection ownership rather than mocking the client. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
@LooperMode(LooperMode.Mode.PAUSED)
class Hs5VehicleClientTest {
    private val fixtures = mutableListOf<Fixture>()
    private val leases = mutableListOf<Closeable>()

    @Before fun isolateTheProcessSingletonFromRobolectricsDiscardedMainQueue() {
        shadowOf(Looper.getMainLooper()).idle()
        synchronized(Hs5VehicleData) {
            // Other controller tests also use this process singleton. Robolectric discards queued
            // Android tasks between tests but may reuse the Kotlin object and its coalescer token.
            // Check ownership first: resetting the token must not hide a real retained connection.
            assertNull("A previous test retained its vehicle client", facadeClient())
            assertTrue("A previous test retained its vehicle owner", (facadeField("owners") as Set<*>).isEmpty())
            assertTrue("A previous test retained its vehicle observer", (facadeField("observers") as List<*>).isEmpty())
            assertEquals(Hs5VehicleConnectionStatus.STOPPED, Hs5VehicleData.snapshot().status)
            (facadeField("notificationPending") as AtomicBoolean).set(false)
        }
    }

    @After fun cleanup() {
        leases.asReversed().forEach(Closeable::close)
        fixtures.forEach { it.close() }
        shadowOf(Looper.getMainLooper()).idle()
    }

    @Test fun refusedBindingIsUnavailableAndClosingCancelsItsRetry() {
        val fixture = fixture(FakeContext().apply { acceptsBinding = false })
        fixture.start()
        assertEquals(Hs5VehicleConnectionStatus.UNAVAILABLE, fixture.latest().status)
        assertEquals("bind-refused", fixture.latest().failure)
        assertTrue(fixture.latest().values.isEmpty())
        fixture.close()
        shadowOf(Looper.getMainLooper()).idleFor(30, TimeUnit.SECONDS)
        assertEquals(1, fixture.context.bindCount)
        assertEquals(0, fixture.context.unbindCount)
    }

    @Test fun deniedBindingReportsPermissionRatherThanPretendingConnected() {
        val fixture = fixture(FakeContext().apply { deniesBinding = true })
        fixture.start()
        assertEquals(Hs5VehicleConnectionStatus.PERMISSION_DENIED, fixture.latest().status)
        assertEquals("permission-denied", fixture.latest().failure)
        assertTrue(fixture.latest().values.isEmpty())
        assertTrue(fixture.root.writes.isEmpty())
    }

    @Test fun pollingAndCallbacksProvideReadingsWithoutSendingAnyControl() {
        val fixture = fixture()
        fixture.connect()
        assertEquals(Hs5VehicleConnectionStatus.CONNECTED, fixture.latest().status)
        assertEquals(22.0, fixture.latest().value(Hs5VehicleField.HVAC_LEFT_TEMPERATURE)!!, 0.0)
        assertTrue(fixture.latest().capabilities.frontSeatHeat)
        assertTrue(fixture.root.writes.isEmpty())

        fixture.root.climateTemperature(0, 26f)
        fixture.drain()
        assertEquals(26.0, fixture.latest().value(Hs5VehicleField.HVAC_LEFT_TEMPERATURE)!!, 0.0)
        assertTrue(fixture.root.writes.isEmpty())

        shadowOf(fixture.worker.looper).idleFor(1, TimeUnit.SECONDS)
        fixture.drain()
        assertEquals(22.0, fixture.latest().value(Hs5VehicleField.HVAC_LEFT_TEMPERATURE)!!, 0.0)
        assertTrue(fixture.root.writes.isEmpty())
    }

    @Test fun disconnectionClearsValuesAndRejectsAnOldListener() {
        val fixture = fixture()
        fixture.connect()
        val oldListener = fixture.root.listeners.getValue(33)
        fixture.client.onServiceDisconnected(COMPONENT)
        fixture.drain()
        assertEquals(Hs5VehicleConnectionStatus.UNAVAILABLE, fixture.latest().status)
        assertTrue(fixture.latest().values.isEmpty())
        assertEquals(1, fixture.context.unbindCount)
        assertEquals(setOf(15, 33, 49), fixture.root.unregistered.toSet())
        val count = fixture.snapshots.size

        climateTemperature(oldListener, 0, 30f)
        fixture.drain()
        assertEquals(count, fixture.snapshots.size)
        assertTrue(fixture.latest().values.isEmpty())
        assertTrue(fixture.root.writes.isEmpty())
    }

    @Test fun closingUnregistersSubscriptionsAndCannotReconnectOrWrite() {
        val fixture = fixture()
        fixture.connect()
        fixture.close()
        fixture.client.close()
        assertEquals(setOf(15, 33, 49), fixture.root.unregistered.toSet())
        assertEquals(3, fixture.root.unregistered.size)
        assertEquals(1, fixture.context.unbindCount)
        val count = fixture.snapshots.size
        shadowOf(Looper.getMainLooper()).idleFor(30, TimeUnit.SECONDS)
        assertEquals(1, fixture.context.bindCount)
        assertEquals(count, fixture.snapshots.size)

        var result: Hs5VehicleCommandResult? = null
        fixture.client.execute(Hs5VehicleCommand.ClimateFan(3)) { result = it }
        shadowOf(Looper.getMainLooper()).idle()
        assertEquals(Hs5VehicleCommandResult.Rejected("vehicle-disconnected"), result)
        assertTrue(fixture.root.writes.isEmpty())
    }

    @Test fun anUnknownVehicleModelCannotReceiveEvenAValidCommand() {
        val fixture = fixture().apply { root.model = "UNKNOWN" }
        fixture.connect()
        assertFalse(fixture.latest().capabilities.hs5Model)
        var result: Hs5VehicleCommandResult? = null
        fixture.client.execute(Hs5VehicleCommand.ClimateTemperature(0, 24.5f)) { result = it }
        fixture.drain()
        assertEquals(Hs5VehicleCommandResult.Rejected("vehicle-model-unverified"), result)
        assertTrue(fixture.root.writes.isEmpty())
    }

    @Test fun anExplicitAcceptedCommandWaitsForPhysicalReadback() {
        val fixture = fixture()
        fixture.connect()
        val firstCommandSnapshot = fixture.snapshots.size
        var result: Hs5VehicleCommandResult? = null
        fixture.client.execute(Hs5VehicleCommand.ClimateTemperature(0, 24.5f)) { result = it }
        fixture.drain()
        assertEquals(Hs5VehicleCommandResult.SentToService(0), result)
        assertEquals(listOf("temperature:0:24.5"), fixture.root.writes.toList())
        // The fake vehicle still reports 22: service acknowledgement must never change it to 24.5.
        assertEquals(22.0, fixture.latest().value(Hs5VehicleField.HVAC_LEFT_TEMPERATURE)!!, 0.0)
        assertFalse(fixture.snapshots.drop(firstCommandSnapshot).any {
            it.values[Hs5VehicleField.HVAC_LEFT_TEMPERATURE]?.value == 24.5
        })
    }

    @Test fun oneRemainingOwnerRetainsTheConnectionButAnObserverDoesNot() {
        ShadowBuild.setModel("HONG QI")
        ShadowBuild.setDevice("t1c_acrn")
        val context = FakeContext()
        val host = Hs5VehicleData.acquire(context, Any()).also(leases::add)
        val controller = Hs5VehicleData.acquire(context, Any()).also(leases::add)
        shadowOf(Looper.getMainLooper()).idle()
        assertEquals(1, context.bindCount)
        val sharedClient = facadeClient()!!
        val root = FakeRoot()
        context.connection!!.onServiceConnected(COMPONENT, root)
        drain(sharedClient)
        val events = mutableListOf<Hs5VehicleSnapshot>()
        val observer = Hs5VehicleData.observe { events.add(it) }.also(leases::add)
        shadowOf(Looper.getMainLooper()).idle()
        assertEquals(Hs5VehicleConnectionStatus.CONNECTED, events.last().status)

        host.close()
        shadowOf(Looper.getMainLooper()).idle()
        assertEquals(0, context.unbindCount)
        assertSame(sharedClient, facadeClient())
        controller.close()
        finishClosing(sharedClient)
        assertNull(facadeClient())
        assertEquals(Hs5VehicleConnectionStatus.STOPPED, Hs5VehicleData.snapshot().status)
        assertTrue(Hs5VehicleData.snapshot().values.isEmpty())
        assertEquals(1, context.unbindCount)
        assertEquals(setOf(15, 33, 49), root.unregistered.toSet())
        assertEquals(Hs5VehicleConnectionStatus.STOPPED, events.last().status)
        observer.close()
        val size = events.size
        val another = Hs5VehicleData.acquire(context, Any()).also(leases::add)
        shadowOf(Looper.getMainLooper()).idle()
        assertEquals(size, events.size)
        val anotherClient = facadeClient()!!
        another.close()
        finishClosing(anotherClient)
    }

    @Test fun anUnexpectedModuleInterfaceCannotSupplyAReading() {
        val root = object : Binder() {
            private val wrong = Binder().apply { attachInterface(null, "unexpected.module") }
            init { attachInterface(null, Hs5VehicleBinderRpc.CLIENT) }
            override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
                data.enforceInterface(Hs5VehicleBinderRpc.CLIENT)
                reply!!.writeNoException()
                reply.writeStrongBinder(wrong)
                return true
            }
        }
        val rpc = Hs5VehicleBinderRpc(root)
        try {
            rpc.int(33, 1)
            fail("An unrelated module was accepted")
        } catch (_: SecurityException) {
            assertTrue(rpc.permissionDenied)
            assertNotNull(rpc.failure)
        }
    }

    private fun fixture(context: FakeContext = FakeContext()) = Fixture(context).also(fixtures::add)

    private class Fixture(val context: FakeContext) : Closeable {
        val snapshots = CopyOnWriteArrayList<Hs5VehicleSnapshot>()
        val root = FakeRoot()
        val client = Hs5VehicleClient(context) { _, snapshot -> snapshots.add(snapshot) }
        val worker: Handler get() = worker(client)
        private var closed = false
        fun start() { client.start(); drain() }
        fun connect() { start(); context.connection!!.onServiceConnected(COMPONENT, root); drain() }
        fun drain() = drain(client)
        fun latest() = snapshots.last()
        override fun close() {
            if (closed) return
            closed = true
            client.close()
            finishClosing(client)
        }
    }

    private class FakeContext : ContextWrapper(RuntimeEnvironment.getApplication()) {
        var acceptsBinding = true
        var deniesBinding = false
        var bindCount = 0
        var unbindCount = 0
        var connection: ServiceConnection? = null
        override fun getApplicationContext(): Context = this
        override fun bindService(service: Intent, conn: ServiceConnection, flags: Int): Boolean {
            bindCount++
            assertEquals(COMPONENT, service.component)
            if (deniesBinding) throw SecurityException("denied")
            connection = conn
            return acceptsBinding
        }
        override fun unbindService(conn: ServiceConnection) {
            assertSame(connection, conn)
            unbindCount++
            connection = null
        }
    }

    /** Only explicitly listed write transactions are accepted and recorded. */
    private class FakeRoot : Binder() {
        var model = "7901010DD52B"
        val writes = CopyOnWriteArrayList<String>()
        val unregistered = CopyOnWriteArrayList<Int>()
        val listeners = java.util.concurrent.ConcurrentHashMap<Int, IBinder>()
        private val modules = mapOf(
            15 to Module(15, "ltd.qisi.adapterproxy.ICarVehicleStateManager"),
            31 to Module(31, "ltd.qisi.adapterproxy.ICarEOLManager"),
            33 to Module(33, "ltd.qisi.adapterproxy.ICarATCManager"),
            49 to Module(49, "ltd.qisi.adapterproxy.ICarSCCUManager"),
        )
        init { attachInterface(null, Hs5VehicleBinderRpc.CLIENT) }
        override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
            if (code != 1) return false
            data.enforceInterface(Hs5VehicleBinderRpc.CLIENT)
            reply!!.writeNoException()
            reply.writeStrongBinder(modules[data.readInt()])
            return true
        }
        fun climateTemperature(side: Int, value: Float) =
            climateTemperature(listeners.getValue(33), side, value)

        private inner class Module(private val id: Int, private val descriptor: String) : Binder() {
            init { attachInterface(null, descriptor) }
            override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
                data.enforceInterface(descriptor)
                reply!!.writeNoException()
                val registration = when (id) { 15 -> 42; 33 -> 85; 49 -> 29; else -> -1 }
                if (code == registration) { listeners[id] = data.readStrongBinder()!!; return true }
                if (code == registration + 1 && registration > 0) {
                    assertSame(listeners.remove(id), data.readStrongBinder())
                    unregistered.add(id)
                    return true
                }
                when {
                    id == 31 && code == 4 -> reply.writeString(model)
                    id == 31 && (code == 49 || code == 50) -> reply.writeInt(1)
                    id == 33 && code == 12 -> {
                        writes.add("temperature:${data.readInt()}:${data.readFloat()}")
                        reply.writeInt(0)
                    }
                    id == 33 && code == 14 -> { writes.add("fan:${data.readInt()}"); reply.writeInt(0) }
                    id == 49 && (code == 4 || code == 8) -> {
                        writes.add("seat:$code:${data.readInt()}:${data.readInt()}")
                        reply.writeInt(0)
                    }
                    id == 33 && code == 11 -> { data.readInt(); reply.writeFloat(22f) }
                    id == 33 && code == 93 -> reply.writeFloat(20f)
                    id == 33 && code == 13 -> reply.writeInt(2)
                    id == 33 -> reply.writeInt(1)
                    id == 49 && (code == 3 || code == 7) -> { data.readInt(); reply.writeInt(2) }
                    id == 15 && code == 59 -> reply.writeFloat(-2f)
                    else -> reply.writeInt(-2)
                }
                return true
            }
        }
    }

    companion object {
        private val COMPONENT = ComponentName("ltd.qisi.adapterservice", "ltd.qisi.adapterservice.QISIAdapterService")
        private fun worker(client: Hs5VehicleClient): Handler =
            client.javaClass.getDeclaredField("worker").apply { isAccessible = true }.get(client) as Handler

        private fun facadeField(name: String): Any? = Hs5VehicleData.javaClass
            .getDeclaredField(name).apply { isAccessible = true }.get(Hs5VehicleData)

        private fun facadeClient(): Hs5VehicleClient? = facadeField("connection") as Hs5VehicleClient?

        private fun drain(client: Hs5VehicleClient) {
            repeat(2) {
                shadowOf(Looper.getMainLooper()).idle()
                shadowOf(worker(client).looper).idle()
            }
            shadowOf(Looper.getMainLooper()).idle()
        }

        private fun finishClosing(client: Hs5VehicleClient) {
            shadowOf(Looper.getMainLooper()).idle()
            val thread = client.javaClass.getDeclaredField("thread").apply { isAccessible = true }.get(client) as HandlerThread
            thread.join(3_000)
            assertFalse("Vehicle worker must stop after close", thread.isAlive)
            shadowOf(Looper.getMainLooper()).idle()
        }

        private fun climateTemperature(listener: IBinder, side: Int, value: Float) {
            val data = Parcel.obtain()
            try {
                data.writeInterfaceToken("ltd.qisi.adapterproxy.listener.ICarATCStateListener")
                data.writeInt(side)
                data.writeFloat(value)
                assertTrue(listener.transact(6, data, null, IBinder.FLAG_ONEWAY))
            } finally { data.recycle() }
        }
    }
}
