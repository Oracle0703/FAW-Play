package com.shilapi.xcertplay.media

import org.junit.Assert.*
import org.junit.Test

class AudioInputPumpTest {
    @Test fun busyDecoderDrainsOutputAndAcceptsTheSamePacket() {
        var outputDrained = false
        var attempts = 0
        val input = AudioInputPump.acquire({ true }, { attempts++; if (outputDrained) 7 else -1 }, { outputDrained = true })
        assertEquals(7, input); assertEquals(2, attempts)
    }
    @Test fun shutdownWhileDrainingDoesNotQueueMoreInput() {
        var running = true
        var attempts = 0
        assertEquals(-1, AudioInputPump.acquire({ running }, { attempts++; -1 }, { running = false }))
        assertEquals(1, attempts)
    }
    @Test fun stuckDecoderFailsWithinTheDeadline() {
        var time = 0L
        val result = runCatching { AudioInputPump.acquire({ true }, { -1 }, { time += 100 }, { time }, timeoutNs = 200) }
        assertTrue(result.exceptionOrNull() is IllegalStateException)
        assertEquals(200L, time)
    }
}
