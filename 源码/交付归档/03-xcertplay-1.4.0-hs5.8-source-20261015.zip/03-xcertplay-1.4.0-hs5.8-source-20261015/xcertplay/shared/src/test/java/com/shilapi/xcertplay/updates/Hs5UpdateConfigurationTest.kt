package com.shilapi.xcertplay.updates

import com.shilapi.xcertplay.licensing.LicenseVerifier
import org.junit.Assert.*
import org.junit.Test
import java.security.KeyPairGenerator
import java.security.spec.ECGenParameterSpec

class Hs5UpdateConfigurationTest {
    private val key = KeyPairGenerator.getInstance("EC").apply { initialize(ECGenParameterSpec("secp256r1")) }.generateKeyPair()
    private val publicKey = LicenseVerifier.encodeUrl(key.public.encoded)
    private val pin = "ab".repeat(32)

    @Test fun acceptsIndependentUpdateTrustWithoutLicenseOrOidcConfiguration() {
        assertNull(Hs5UpdateConfiguration.validate("https://updates.example.invalid", publicKey, pin))
    }

    @Test fun rejectsIncompleteOrUntrustedUpdateConfiguration() {
        assertNotNull(Hs5UpdateConfiguration.validate("", publicKey, pin))
        assertNotNull(Hs5UpdateConfiguration.validate("https://updates.example.invalid", "", pin))
        assertNotNull(Hs5UpdateConfiguration.validate("https://updates.example.invalid", publicKey, ""))
        assertNotNull(Hs5UpdateConfiguration.validate("http://updates.example.invalid", publicKey, pin))
        assertNotNull(Hs5UpdateConfiguration.validate("https://user:pass@updates.example.invalid", publicKey, pin))
        assertNotNull(Hs5UpdateConfiguration.validate("https://updates.example.invalid", "invalid", pin))
    }
}
