package com.shilapi.xcertplay.network

import android.system.OsConstants
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28, 29], manifest = Config.NONE)
class TcpLivenessTest {
    @Test
    fun unsupportedOptionDoesNotDisableTheRemainingPeerProbes() {
        val applied = mutableMapOf<Int, Int>()
        val diagnostics = mutableListOf<String>()
        TcpLiveness.configureOptions(
            set = { option, value ->
                if (option == 4) throw UnsupportedOperationException()
                applied[option] = value
            },
            diagnostic = diagnostics::add,
        )

        assertEquals(mapOf(5 to 1, 6 to 3, OsConstants.TCP_USER_TIMEOUT to 5_000), applied)
        assertEquals(2, diagnostics.size)
        assertTrue(diagnostics.first().contains("idleSeconds unavailable"))
        assertTrue(diagnostics.last().contains("appliedOptions=3/4"))
        assertTrue(diagnostics.last().contains("no readback"))
    }

    @Test
    fun rejectedUserTimeoutRetainsKeepaliveProbes() {
        val applied = mutableMapOf<Int, Int>()
        val diagnostics = mutableListOf<String>()
        TcpLiveness.configureOptions(
            set = { option, value ->
                if (option == OsConstants.TCP_USER_TIMEOUT) throw UnsupportedOperationException()
                applied[option] = value
            },
            diagnostic = diagnostics::add,
        )

        assertEquals(mapOf(4 to 2, 5 to 1, 6 to 3), applied)
        assertTrue(diagnostics.first().contains("userTimeoutMillis unavailable"))
        assertTrue(diagnostics.last().contains("appliedOptions=3/4"))
    }

    @Test
    fun tuningPreservesLiveSocketAndDoesNotAddAnIdleReadDeadline() {
        ServerSocket(0, 1, InetAddress.getLoopbackAddress()).use { server ->
            Socket(InetAddress.getLoopbackAddress(), server.localPort).use { client ->
                server.accept().use { receiver ->
                    assertEquals(0, receiver.soTimeout)
                    TcpLiveness.configure(receiver) {}

                    assertTrue(receiver.keepAlive)
                    assertFalse(receiver.isClosed)
                    assertEquals(0, receiver.soTimeout)
                    // Use a bounded test read only after checking that production tuning leaves
                    // idle reads unlimited. Traffic still works even if platform tuning degrades.
                    receiver.soTimeout = 1_000
                    client.getOutputStream().write(42)
                    assertEquals(42, receiver.getInputStream().read())
                }
            }
        }
    }
}
