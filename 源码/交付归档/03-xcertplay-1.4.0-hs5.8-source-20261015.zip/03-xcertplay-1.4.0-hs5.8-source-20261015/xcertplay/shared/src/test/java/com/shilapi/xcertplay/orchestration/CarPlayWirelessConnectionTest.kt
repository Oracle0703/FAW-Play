package com.shilapi.xcertplay.orchestration

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothProfile
import android.content.Intent
import android.os.Looper
import android.os.SystemClock
import com.shilapi.xcertplay.airplay.*
import com.shilapi.xcertplay.network.WirelessHotspotInfo
import com.shilapi.xcertplay.network.WirelessHotspotManager
import com.shilapi.xcertplay.transport.Iap2IdentificationConfig
import com.shilapi.xcertplay.transport.IphoneBluetoothDevices
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.Socket
import java.lang.reflect.InvocationTargetException
import java.util.UUID
import java.time.Duration
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito.*
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowSystemClock

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class CarPlayWirelessConnectionTest {
    @Test
    fun firstPairingBroadcastContinuesPendingConnection() {
        val fixture = Fixture()
        val adapter = mock(BluetoothAdapter::class.java)
        val bonded = AtomicReference<Set<BluetoothDevice>>(emptySet())
        val registeredRead = CountDownLatch(1)
        val reads = AtomicInteger()
        `when`(adapter.isEnabled).thenReturn(true)
        `when`(adapter.bondedDevices).thenAnswer {
            if (reads.incrementAndGet() >= 2) registeredRead.countDown()
            bonded.get()
        }
        val phone = phone("02:00:00:00:00:03", mock(BluetoothSocket::class.java))
        val worker = Executors.newSingleThreadExecutor()
        try {
            val pending = worker.submit<List<*>> {
                fixture.method("awaitWirelessBluetoothDevices", BluetoothAdapter::class.java, Int::class.javaPrimitiveType!!)
                    .invoke(fixture.controller, adapter, fixture.owner) as List<*>
            }
            assertTrue(registeredRead.await(2, TimeUnit.SECONDS))
            assertFalse(pending.isDone)
            bonded.set(setOf(phone))
            RuntimeEnvironment.getApplication().sendBroadcast(Intent(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
                .putExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.BOND_BONDED))
            fixture.deliverStatuses()
            assertEquals(listOf(phone), pending.get(2, TimeUnit.SECONDS))
            assertTrue(fixture.statuses.any { it == CarPlayStatus.WaitingForPairedIphone })
            assertTrue(fixture.statuses.none { it is CarPlayStatus.Failed })
        } finally { fixture.close(); worker.shutdownNow() }
    }

    @Test
    fun existingPairingDoesNotWaitForBroadcast() {
        val fixture = Fixture()
        val adapter = mock(BluetoothAdapter::class.java)
        val phone = phone("02:00:00:00:00:03", mock(BluetoothSocket::class.java))
        `when`(adapter.bondedDevices).thenReturn(setOf(phone))
        try {
            val result = fixture.method("awaitWirelessBluetoothDevices", BluetoothAdapter::class.java, Int::class.javaPrimitiveType!!)
                .invoke(fixture.controller, adapter, fixture.owner)
            assertEquals(listOf(phone), result)
            fixture.deliverStatuses()
            assertTrue(fixture.statuses.none { it == CarPlayStatus.WaitingForPairedIphone })
        } finally { fixture.close() }
    }

    @Test
    fun controllerCloseCancelsWaitingForFirstPairing() {
        val fixture = Fixture()
        val adapter = mock(BluetoothAdapter::class.java)
        val registeredRead = CountDownLatch(1)
        val reads = AtomicInteger()
        `when`(adapter.isEnabled).thenReturn(true)
        `when`(adapter.bondedDevices).thenAnswer {
            if (reads.incrementAndGet() >= 2) registeredRead.countDown()
            emptySet<BluetoothDevice>()
        }
        val worker = Executors.newSingleThreadExecutor()
        try {
            val pending = worker.submit<List<*>> {
                fixture.method("awaitWirelessBluetoothDevices", BluetoothAdapter::class.java, Int::class.javaPrimitiveType!!)
                    .invoke(fixture.controller, adapter, fixture.owner) as List<*>
            }
            assertTrue(registeredRead.await(2, TimeUnit.SECONDS))
            fixture.close()
            assertEquals(emptyList<BluetoothDevice>(), pending.get(1, TimeUnit.SECONDS))
            assertTrue(fixture.statuses.none { it is CarPlayStatus.Failed })
        } finally { fixture.close(); worker.shutdownNow() }
    }

    @Test
    fun expiredUserPairingHasOneChineseFailureWithoutAutomaticRetry() {
        val fixture = Fixture()
        val adapter = mock(BluetoothAdapter::class.java)
        `when`(adapter.isEnabled).thenReturn(true)
        `when`(adapter.bondedDevices).thenReturn(emptySet())
        fixture.startDeadline(SystemClock.elapsedRealtime() - 120_000)
        try {
            val result = fixture.method("awaitWirelessBluetoothDevices", BluetoothAdapter::class.java, Int::class.javaPrimitiveType!!)
                .invoke(fixture.controller, adapter, fixture.owner)
            assertEquals(emptyList<BluetoothDevice>(), result)
            assertTrue(fixture.hotspot.closed.await(2, TimeUnit.SECONDS))
            fixture.deliverStatuses()
            assertFalse(fixture.failure().retryable)
            assertFalse(fixture.failure().radioRecovery)
            assertTrue(fixture.failure().message.contains("配对超时"))
            assertEquals(WirelessConnectionStage.WAITING_FOR_PAIR, fixture.failure().wirelessStage)
        } finally { fixture.close() }
    }

    @Test
    fun rfcommAcceptanceFollowedByIap2EofClosesCandidateAndTriesNextPhone() {
        val fixture = Fixture()
        fixture.setBluetoothAdapter(null)
        val firstSocket = mock(BluetoothSocket::class.java)
        val secondSocket = mock(BluetoothSocket::class.java)
        val first = phone("02:00:00:00:00:01", firstSocket)
        val second = phone("02:00:00:00:00:02", secondSocket)
        val events = CopyOnWriteArrayList<String>()
        val secondFailure = IOException("second candidate was attempted")
        `when`(firstSocket.inputStream).thenReturn(ByteArrayInputStream(ByteArray(0)))
        `when`(firstSocket.outputStream).thenReturn(ByteArrayOutputStream())
        doAnswer { events += "first connect"; null }.`when`(firstSocket).connect()
        doAnswer { events += "first close"; null }.`when`(firstSocket).close()
        doAnswer { events += "second connect"; throw secondFailure }.`when`(secondSocket).connect()
        val caller = Executors.newSingleThreadExecutor()
        try {
            val attempt = caller.submit<Throwable?> {
                runCatching {
                    fixture.method("connectWirelessBluetoothDevices", List::class.java, Int::class.javaPrimitiveType!!)
                        .invoke(fixture.controller, listOf(first, second), fixture.owner)
                }.exceptionOrNull()
            }
            val failure = attempt.get(5, TimeUnit.SECONDS)

            assertTrue(failure is InvocationTargetException && failure.cause is IOException)
            assertSame(secondFailure, failure!!.cause!!.cause)
            verify(firstSocket).connect()
            verify(firstSocket, atLeastOnce()).close()
            verify(secondSocket).connect()
            assertTrue(events.indexOf("first close") >= 0)
            assertTrue(events.indexOf("first close") < events.indexOf("second connect"))
        } finally {
            fixture.close()
            caller.shutdownNow()
        }
    }

    @Test
    fun phoneBondedDuringFailedProbePrecedesRemainingHistoricalPhone() {
        val fixture = Fixture()
        val adapter = mock(BluetoothAdapter::class.java)
        val firstSocket = mock(BluetoothSocket::class.java)
        val oldSocket = mock(BluetoothSocket::class.java)
        val newSocket = mock(BluetoothSocket::class.java)
        val first = phone("02:00:00:00:00:01", firstSocket)
        val old = phone("02:00:00:00:00:02", oldSocket)
        val new = phone("02:00:00:00:00:03", newSocket)
        val bonded = AtomicReference(setOf(first, old))
        val newFailure = IOException("newly paired phone was attempted")
        fixture.setBluetoothAdapter(adapter)
        `when`(adapter.isEnabled).thenReturn(true)
        `when`(adapter.bondedDevices).thenAnswer { bonded.get() }
        doAnswer {
            bonded.set(setOf(first, old, new))
            throw IOException("historical phone unavailable")
        }.`when`(firstSocket).connect()
        doAnswer {
            ShadowSystemClock.advanceBy(Duration.ofSeconds(20))
            throw newFailure
        }.`when`(newSocket).connect()
        try {
            val failure = fixture.connectFailure(listOf(first, old))
            assertSame(newFailure, failure!!.cause!!.cause)
            verify(firstSocket).connect()
            verify(newSocket).connect()
            verify(oldSocket, never()).connect()
        } finally { fixture.close() }
    }

    @Test
    fun phoneBondedAfterHistoricalCandidatesAreExhaustedJoinsPendingAttempt() {
        val fixture = Fixture()
        val adapter = mock(BluetoothAdapter::class.java)
        val oldSocket = mock(BluetoothSocket::class.java)
        val newSocket = mock(BluetoothSocket::class.java)
        val old = phone("02:00:00:00:00:01", oldSocket)
        val new = phone("02:00:00:00:00:02", newSocket)
        val bonded = AtomicReference(setOf(old))
        val exhaustedRead = CountDownLatch(1)
        val newFailure = IOException("newly paired phone was attempted")
        fixture.setBluetoothAdapter(adapter)
        `when`(adapter.isEnabled).thenReturn(true)
        `when`(adapter.bondedDevices).thenAnswer { exhaustedRead.countDown(); bonded.get() }
        doThrow(IOException("historical phone unavailable")).`when`(oldSocket).connect()
        doAnswer {
            ShadowSystemClock.advanceBy(Duration.ofSeconds(20))
            throw newFailure
        }.`when`(newSocket).connect()
        val worker = Executors.newSingleThreadExecutor()
        try {
            val pending = worker.submit<Throwable?> { fixture.connectFailure(listOf(old)) }
            assertTrue(exhaustedRead.await(2, TimeUnit.SECONDS))
            assertFalse(pending.isDone)
            bonded.set(setOf(old, new))
            pairingBroadcast(fixture)
            val failure = pending.get(2, TimeUnit.SECONDS)
            assertSame(newFailure, failure!!.cause!!.cause)
            verify(oldSocket).connect()
            verify(newSocket).connect()
        } finally { fixture.close(); worker.shutdownNow() }
    }

    @Test
    fun repeatedBondEventsDoNotRepeatHistoricalProbeOrRenewBluetoothBudget() {
        val fixture = Fixture()
        val adapter = mock(BluetoothAdapter::class.java)
        val socket = mock(BluetoothSocket::class.java)
        val old = phone("02:00:00:00:00:01", socket)
        val firstRefresh = CountDownLatch(1)
        val secondRefresh = CountDownLatch(1)
        val reads = AtomicInteger()
        fixture.setBluetoothAdapter(adapter)
        `when`(adapter.isEnabled).thenReturn(true)
        `when`(adapter.bondedDevices).thenAnswer {
            if (reads.incrementAndGet() == 1) firstRefresh.countDown() else secondRefresh.countDown()
            setOf(old)
        }
        doThrow(IOException("historical phone unavailable")).`when`(socket).connect()
        val worker = Executors.newSingleThreadExecutor()
        try {
            val pending = worker.submit<Throwable?> { fixture.connectFailure(listOf(old)) }
            assertTrue(firstRefresh.await(2, TimeUnit.SECONDS))
            ShadowSystemClock.advanceBy(Duration.ofSeconds(19))
            pairingBroadcast(fixture)
            assertTrue(secondRefresh.await(2, TimeUnit.SECONDS))
            assertFalse(pending.isDone)
            ShadowSystemClock.advanceBy(Duration.ofSeconds(1))
            pairingBroadcast(fixture)
            assertTrue(pending.get(2, TimeUnit.SECONDS)!!.cause is IOException)
            verify(socket).connect()
        } finally { fixture.close(); worker.shutdownNow() }
    }

    @Test
    fun exhaustedCandidatesEndAfterShortEventWindowInsteadOfFullBluetoothBudget() {
        val fixture = Fixture()
        val adapter = mock(BluetoothAdapter::class.java)
        val socket = mock(BluetoothSocket::class.java)
        val old = phone("02:00:00:00:00:01", socket)
        fixture.setBluetoothAdapter(adapter)
        `when`(adapter.isEnabled).thenReturn(true)
        `when`(adapter.bondedDevices).thenReturn(setOf(old))
        doThrow(IOException("phone unavailable")).`when`(socket).connect()
        val worker = Executors.newSingleThreadExecutor()
        try {
            val pending = worker.submit<Throwable?> { fixture.connectFailure(listOf(old)) }
            assertTrue("Exhaustion must not consume the remaining 20-second budget",
                pending.get(3, TimeUnit.SECONDS)!!.cause is IOException)
            verify(socket).connect()
        } finally { fixture.close(); worker.shutdownNow() }
    }

    @Test
    fun newEventsForSamePhonePermitOneRetryWithoutRepeatingHistoricalProbesIndefinitely() {
        val fixture = Fixture()
        val adapter = mock(BluetoothAdapter::class.java)
        val firstSocket = mock(BluetoothSocket::class.java)
        val retrySocket = mock(BluetoothSocket::class.java)
        val phone = phone("02:00:00:00:00:01", firstSocket)
        `when`(phone.createRfcommSocketToServiceRecord(UUID.fromString(IphoneBluetoothDevices.IAP2_SERVICE_UUID)))
            .thenReturn(firstSocket, retrySocket)
        fixture.setBluetoothAdapter(adapter)
        `when`(adapter.isEnabled).thenReturn(true)
        `when`(adapter.bondedDevices).thenReturn(setOf(phone))
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        doAnswer {
            entered.countDown()
            check(release.await(5, TimeUnit.SECONDS))
            throw IOException("service was not ready on first attempt")
        }.`when`(firstSocket).connect()
        doThrow(IOException("retry finished")).`when`(retrySocket).connect()
        val worker = Executors.newSingleThreadExecutor()
        try {
            val pending = worker.submit<Throwable?> { fixture.connectFailure(listOf(phone)) }
            assertTrue(entered.await(2, TimeUnit.SECONDS))
            repeat(3) {
                RuntimeEnvironment.getApplication().sendBroadcast(Intent(BluetoothDevice.ACTION_UUID)
                    .putExtra(BluetoothDevice.EXTRA_DEVICE, phone))
            }
            fixture.deliverStatuses()
            release.countDown()
            assertTrue(pending.get(3, TimeUnit.SECONDS)!!.cause is IOException)
            verify(firstSocket).connect()
            verify(retrySocket).connect()
        } finally { release.countDown(); fixture.close(); worker.shutdownNow() }
    }

    @Test
    fun onlyActivatedProjectionRemembersPhoneAndNewOrConnectedPhonesKeepPriority() {
        val fixture = Fixture()
        val adapter = mock(BluetoothAdapter::class.java)
        val historical = phone("02:00:00:00:00:01", mock(BluetoothSocket::class.java))
        val successful = phone("02:00:00:00:00:02", mock(BluetoothSocket::class.java))
        val newlyPaired = phone("02:00:00:00:00:03", mock(BluetoothSocket::class.java))
        `when`(adapter.bondedDevices).thenReturn(setOf(historical, successful))
        val selected = fixture.select(adapter)
        assertEquals(listOf(historical, successful), selected)
        fixture.setConnectedIphone(successful)
        assertNull(fixture.savedPhone())
        val projected = fixture.session()
        try {
            fixture.sessionListener().onSessionActive(projected)
            assertEquals(successful.address, fixture.savedPhone())
            assertEquals(successful, fixture.select(adapter).first())

            val headset = mock(BluetoothHeadset::class.java)
            `when`(headset.connectedDevices).thenReturn(listOf(historical))
            `when`(adapter.getProfileConnectionState(BluetoothProfile.HEADSET)).thenReturn(BluetoothAdapter.STATE_CONNECTED)
            doAnswer { call ->
                call.getArgument<BluetoothProfile.ServiceListener>(1).onServiceConnected(BluetoothProfile.HEADSET, headset)
                true
            }.`when`(adapter).getProfileProxy(any(android.content.Context::class.java),
                any(BluetoothProfile.ServiceListener::class.java), eq(BluetoothProfile.HEADSET))
            assertEquals(historical, fixture.select(adapter).first())

            `when`(adapter.bondedDevices).thenReturn(setOf(historical, successful, newlyPaired))
            assertEquals(newlyPaired, fixture.select(adapter, setOf(historical.address, successful.address)).first())
        } finally { projected.close(); fixture.close() }
    }

    @Test
    fun enteringBluetoothAgainDoesNotRenewExpiredStageBudget() {
        val fixture = Fixture()
        val socket = mock(BluetoothSocket::class.java)
        val old = phone("02:00:00:00:00:01", socket)
        try {
            fixture.advanceDeadline(WirelessConnectionStage.BLUETOOTH, SystemClock.elapsedRealtime())
            ShadowSystemClock.advanceBy(Duration.ofSeconds(20))
            assertTrue(fixture.connectFailure(listOf(old))!!.cause is IOException)
            verify(socket, never()).connect()
        } finally { fixture.close() }
    }

    private fun pairingBroadcast(fixture: Fixture) {
        RuntimeEnvironment.getApplication().sendBroadcast(Intent(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
            .putExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.BOND_BONDED))
        fixture.deliverStatuses()
    }

    @Test
    fun wifiTimeoutWithAssociatedPhoneUsesServiceRecovery() {
        assertWifiClassification(true, false)
    }

    @Test
    fun wifiTimeoutWithConfirmedEmptyGroupAllowsRadioRecovery() {
        assertWifiClassification(false, true)
    }

    @Test
    fun wifiTimeoutWithUnknownAssociationDoesNotChangeFrequency() {
        assertWifiClassification(null, false)
    }

    @Test
    fun missingAssociationCallbackDoesNotBlockCallerAndLateReplyCannotChangeFailure() {
        val hotspot = AssociationHotspot(autoReply = false)
        val fixture = Fixture(hotspot)
        val caller = Executors.newSingleThreadExecutor()
        val callingThread = AtomicReference<Thread>()
        try {
            val call = caller.submit {
                callingThread.set(Thread.currentThread())
                fixture.fail(WirelessConnectionStage.PHONE_WIFI)
            }
            call.get(1, TimeUnit.SECONDS)
            assertTrue(hotspot.queried.await(3, TimeUnit.SECONDS))
            assertNotSame(callingThread.get(), hotspot.queryingThread.get())
            assertTrue(hotspot.closed.await(3, TimeUnit.SECONDS))
            fixture.deliverStatuses()
            val published = fixture.failure()
            assertFalse(published.radioRecovery)

            hotspot.callback.get()!!(false)
            fixture.deliverStatuses()
            assertSame(published, fixture.failure())
            assertEquals(1, fixture.statuses.filterIsInstance<CarPlayStatus.Failed>().size)
        } finally {
            fixture.close()
            caller.shutdownNow()
        }
    }

    @Test
    fun bluetoothFailureDoesNotQueryWifiAssociationOrRequestRadioRecovery() {
        val hotspot = AssociationHotspot(response = false)
        val fixture = Fixture(hotspot)
        try {
            fixture.fail(WirelessConnectionStage.BLUETOOTH)
            assertTrue(hotspot.closed.await(3, TimeUnit.SECONDS))
            fixture.deliverStatuses()

            assertEquals(0, hotspot.queries.get())
            assertEquals(WirelessConnectionStage.BLUETOOTH, fixture.failure().wirelessStage)
            assertFalse(fixture.failure().radioRecovery)
        } finally { fixture.close() }
    }

    private fun assertWifiClassification(associated: Boolean?, expectedRadioRecovery: Boolean) {
        val hotspot = AssociationHotspot(associated)
        val fixture = Fixture(hotspot)
        try {
            val callingThread = Thread.currentThread()
            fixture.fail(WirelessConnectionStage.PHONE_WIFI)
            assertTrue(hotspot.closed.await(3, TimeUnit.SECONDS))
            fixture.deliverStatuses()

            assertEquals(1, hotspot.queries.get())
            assertNotSame(callingThread, hotspot.queryingThread.get())
            val failure = fixture.failure()
            assertEquals(WirelessConnectionStage.PHONE_WIFI, failure.wirelessStage)
            assertEquals(expectedRadioRecovery, failure.radioRecovery)
            if (associated == true) assertTrue(failure.message.contains("服务响应超时"))
        } finally { fixture.close() }
    }

    private fun phone(address: String, socket: BluetoothSocket): BluetoothDevice =
        mock(BluetoothDevice::class.java).also { device ->
            `when`(device.address).thenReturn(address)
            `when`(device.name).thenReturn("renamed phone")
            `when`(device.createRfcommSocketToServiceRecord(UUID.fromString(IphoneBluetoothDevices.IAP2_SERVICE_UUID)))
                .thenReturn(socket)
            `when`(socket.remoteDevice).thenReturn(device)
        }

    private class AssociationHotspot(
        private val response: Boolean? = null,
        private val autoReply: Boolean = true,
    ) : WirelessHotspotManager {
        val queries = AtomicInteger(0)
        val queried = CountDownLatch(1)
        val closed = CountDownLatch(1)
        val queryingThread = AtomicReference<Thread>()
        val callback = AtomicReference<((Boolean?) -> Unit)?>()
        override fun queryHasAssociatedClients(callback: (Boolean?) -> Unit) {
            queries.incrementAndGet()
            queryingThread.set(Thread.currentThread())
            this.callback.set(callback)
            queried.countDown()
            if (autoReply) callback(response)
        }
        override fun start(timeoutMillis: Long): WirelessHotspotInfo = error("Radio start is forbidden in this fixture")
        override fun close() { closed.countDown() }
    }

    private class Fixture(val hotspot: AssociationHotspot = AssociationHotspot()) {
        val owner = 9
        val statuses = CopyOnWriteArrayList<CarPlayStatus>()
        val controller = CarPlayController(
            RuntimeEnvironment.getApplication(),
            CarPlayRuntimeConfig(mfiTarget = MfiTarget.REMOTE, remoteMfiServer = "https://mfi.example.test",
                transport = CarPlayTransport.WIRELESS,
                identification = Iap2IdentificationConfig("test", "test", "test", "test", "1", "1", 3)),
            AirPlayConfig("test", "test", "", "1", AirPlayDisplayConfig(800, 480)),
            AirPlayIdentity.generate(), PairingStore(), object : AirPlaySessionListener {},
            object : AirPlayMediaHandler {}, statuses::add,
        )
        init {
            RuntimeEnvironment.getApplication().getSharedPreferences("carplay_wireless", 0).edit().clear().commit()
            val phase = field("phase")
            phase.set(controller, phase.type.enumConstants.single { it.toString() == "WIRELESS" })
            (field("wirelessGeneration").get(controller) as AtomicInteger).set(owner)
            (field("wirelessDeadline").get(controller) as WirelessConnectionDeadline)
                .start(owner, SystemClock.elapsedRealtime())
            field("hotspot").set(controller, hotspot)
        }
        fun fail(stage: WirelessConnectionStage) {
            (field("wirelessDeadline").get(controller) as WirelessConnectionDeadline)
                .advance(owner, stage, SystemClock.elapsedRealtime())
            method("failWireless", Int::class.javaPrimitiveType!!, String::class.java,
                WirelessConnectionStage::class.java, Boolean::class.javaPrimitiveType!!,
                Boolean::class.javaPrimitiveType!!)
                .invoke(controller, owner, "test timeout", stage, true, stage.radioRecovery)
        }
        fun startDeadline(now: Long) {
            (field("wirelessDeadline").get(controller) as WirelessConnectionDeadline).start(owner, now)
        }
        fun setBluetoothAdapter(adapter: BluetoothAdapter?) { field("bluetoothAdapter").set(controller, adapter) }
        fun setConnectedIphone(device: BluetoothDevice) { field("connectedIphone").set(controller, device) }
        fun savedPhone(): String? = RuntimeEnvironment.getApplication().getSharedPreferences("carplay_wireless", 0)
            .getString("last_successful_bluetooth_address", null)
        @Suppress("UNCHECKED_CAST")
        fun select(adapter: BluetoothAdapter, initial: Set<String>? = null): List<BluetoothDevice> =
            method("selectWirelessBluetoothDevices", BluetoothAdapter::class.java, Set::class.java, java.lang.Long::class.java)
                .invoke(controller, adapter, initial, null) as List<BluetoothDevice>
        fun sessionListener() = field("sessionListener").get(controller) as AirPlaySessionListener
        fun session() = AirPlaySession(Socket(), AirPlayConfig("test", "test", "", "1", AirPlayDisplayConfig(800, 480)),
            AirPlayIdentity.generate(), PairingStore(), null, sessionListener(), object : AirPlayMediaHandler {})
        fun advanceDeadline(stage: WirelessConnectionStage, now: Long) {
            (field("wirelessDeadline").get(controller) as WirelessConnectionDeadline).advance(owner, stage, now)
        }
        fun connectFailure(devices: List<BluetoothDevice>): Throwable? = runCatching {
            method("connectWirelessBluetoothDevices", List::class.java, Int::class.javaPrimitiveType!!)
                .invoke(controller, devices, owner)
        }.exceptionOrNull()
        fun failure() = statuses.filterIsInstance<CarPlayStatus.Failed>().single()
        fun deliverStatuses() { shadowOf(Looper.getMainLooper()).idle() }
        fun close() {
            controller.close()
            assertTrue(controller.awaitClosed(3_000))
            deliverStatuses()
        }
        private fun field(name: String) = CarPlayController::class.java.getDeclaredField(name).apply { isAccessible = true }
        fun method(name: String, vararg types: Class<*>) = CarPlayController::class.java
            .getDeclaredMethod(name, *types).apply { isAccessible = true }
    }

}
