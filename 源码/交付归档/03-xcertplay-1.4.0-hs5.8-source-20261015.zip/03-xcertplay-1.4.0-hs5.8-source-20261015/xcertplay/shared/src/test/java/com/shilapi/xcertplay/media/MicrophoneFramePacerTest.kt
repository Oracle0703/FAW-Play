package com.shilapi.xcertplay.media

import com.shilapi.xcertplay.airplay.AudioCodecKind
import com.shilapi.xcertplay.airplay.MicrophoneConfig
import com.shilapi.xcertplay.airplay.MicrophoneCounters
import com.shilapi.xcertplay.airplay.MicrophonePacketizer
import java.net.InetAddress
import org.junit.Assert.*
import org.junit.Test

class MicrophoneFramePacerTest {
    @Test fun eightyMillisecondHalBurstsAreSentAsTwentyMillisecondFrames() {
        val pacer = MicrophoneFramePacer(1920, interval)
        val sent = mutableListOf<Pair<Long, Int>>()
        for (millis in 0L..140L) {
            if (millis % 80L == 0L) repeat(4) { pacer.offer(frame((millis / 20).toInt() + it)) }
            pacer.poll(millis * 1_000_000)?.let { sent.add(millis to it.pcm[0].toInt()) }
        }
        assertEquals((0..7).toList(), sent.map { it.second })
        assertEquals((0L..140L step 20).toList(), sent.map { it.first })
        assertEquals(0, pacer.underruns)
        assertEquals(0, pacer.droppedFrames)
    }

    @Test fun stalledSchedulerCannotSendACatchupBurst() {
        val pacer = MicrophoneFramePacer(1920, interval)
        repeat(6) { pacer.offer(frame(it)) }
        assertNotNull(pacer.poll(0))
        assertNotNull(pacer.poll(83_000_000))
        assertNull(pacer.poll(83_000_000))
        assertNull(pacer.poll(102_999_999))
        assertNotNull(pacer.poll(103_000_000))
    }

    @Test fun underrunWaitsForFourNewFramesBeforeRestarting() {
        val pacer = MicrophoneFramePacer(1920, interval)
        repeat(3) { pacer.offer(frame(it)) }
        assertNull(pacer.poll(0))
        pacer.offer(frame(3))
        repeat(4) { assertNotNull(pacer.poll(it * interval)) }
        assertNull(pacer.poll(4 * interval))
        assertEquals(1, pacer.underruns)
        repeat(3) { pacer.offer(frame(it + 4)) }
        assertNull(pacer.poll(5 * interval))
        pacer.offer(frame(7))
        assertEquals(4, pacer.poll(5 * interval)!!.pcm[0].toInt())
        assertNull(pacer.poll(5 * interval))
    }

    @Test fun overflowKeepsRecentPcmAndAdvancesTheSelectedRtpClockOnly() {
        for (clock in listOf(16_000, 24_000, 48_000)) {
            val config = MicrophoneCaptureProfile.select(MicrophoneConfig(
                "telephony", clock, 1, 100, 20, InetAddress.getLoopbackAddress(), 32001,
                ByteArray(32), AudioCodecKind.OPUS,
            ), true, 100).config
            val pacer = MicrophoneFramePacer(config.frameBytes, interval)
            repeat(8) { pacer.offer(frame(it)) }
            val ready = pacer.poll(0)!!
            assertEquals(2, ready.pcm[0].toInt())
            assertEquals(2, ready.skippedFrames)
            val counters = MicrophoneCounters()
            counters.timestamp += ready.skippedFrames * config.rtpSamplesPerPacket
            val packet = MicrophonePacketizer.sealPacket(config.key, 100, counters, byteArrayOf(1), config.rtpSamplesPerPacket)
            assertEquals(2 * clock / 50, timestamp(packet))
            assertEquals(3 * clock / 50, counters.timestamp)
            assertEquals(1, counters.sequence)
            assertEquals(1L, counters.nonce)
            assertEquals(0, pacer.poll(interval)!!.skippedFrames)
        }
    }

    @Test fun smallWakeupDelaysDoNotAccumulateIntoLostSpeech() {
        val pacer = MicrophoneFramePacer(1920, interval)
        var now = 0L
        var produced = 0
        var sent = 0
        while (now < 10_000_000_000L) {
            while (produced * interval <= now) pacer.offer(frame(produced++))
            if (pacer.poll(now) != null) sent++
            now += 4_100_000L
        }
        assertTrue("packet cadence drifted", sent >= 496)
        assertEquals(0, pacer.droppedFrames)
        assertEquals(0, pacer.underruns)
    }

    private val interval = 20_000_000L
    private fun frame(id: Int) = ByteArray(1920).also { it[0] = id.toByte() }
    private fun timestamp(packet: ByteArray): Int =
        (4..7).fold(0) { value, index -> (value shl 8) or (packet[index].toInt() and 255) }
}
