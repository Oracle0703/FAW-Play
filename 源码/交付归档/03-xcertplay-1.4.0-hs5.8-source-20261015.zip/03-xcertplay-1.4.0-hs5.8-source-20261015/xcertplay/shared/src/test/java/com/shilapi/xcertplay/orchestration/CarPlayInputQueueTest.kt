package com.shilapi.xcertplay.orchestration

import android.os.Looper
import com.shilapi.xcertplay.airplay.AirPlayConfig
import com.shilapi.xcertplay.airplay.AirPlayContact
import com.shilapi.xcertplay.airplay.AirPlayDisplayConfig
import com.shilapi.xcertplay.airplay.AirPlayIdentity
import com.shilapi.xcertplay.airplay.AirPlayMediaHandler
import com.shilapi.xcertplay.airplay.AirPlaySession
import com.shilapi.xcertplay.airplay.AirPlaySessionListener
import com.shilapi.xcertplay.airplay.CarPlayMediaButton
import com.shilapi.xcertplay.airplay.PairingStore
import com.shilapi.xcertplay.iap2.message.Iap2HidMessages
import com.shilapi.xcertplay.iap2.message.Iap2MediaRemoteCommand
import com.shilapi.xcertplay.iap2.session.Iap2Session
import com.shilapi.xcertplay.iap2.wire.Iap2Frame
import com.shilapi.xcertplay.transport.Iap2IdentificationConfig
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ExecutorService
import java.util.concurrent.TimeUnit
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Answers
import org.mockito.Mockito.mock
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class CarPlayInputQueueTest {
    @Test
    fun blockedMediaSendDoesNotBlockTouch() {
        val fixture = Fixture()
        val pressEntered = CountDownLatch(1)
        val releasePress = CountDownLatch(1)
        val touched = CountDownLatch(1)
        fixture.onMediaSend = {
            if (fixture.mediaFrames.size == 1) {
                pressEntered.countDown()
                check(releasePress.await(5, TimeUnit.SECONDS))
            }
        }
        fixture.onTouch = { touched.countDown() }
        try {
            assertTrue(fixture.controller.sendMediaButton(CarPlayMediaButton.NEXT))
            assertTrue("The media send should be blocked", pressEntered.await(3, TimeUnit.SECONDS))

            assertTrue(fixture.controller.sendTouch(CONTACTS))
            assertTrue("Touch must not wait for media transport", touched.await(3, TimeUnit.SECONDS))
            assertEquals(1L, releasePress.count)
            assertEquals(listOf(CONTACTS), fixture.touches.toList())

            releasePress.countDown()
            fixture.drainMedia()
            assertEquals(2, fixture.mediaFrames.size)
            assertFrame(Iap2HidMessages.mediaReport(Iap2MediaRemoteCommand.NEXT), fixture.mediaFrames[0])
            assertFrame(Iap2HidMessages.releaseMediaButtons(), fixture.mediaFrames[1])
        } finally {
            releasePress.countDown()
            fixture.close()
        }
    }

    @Test
    fun queuedTouchFromPreviousTokenIsDropped() {
        val fixture = Fixture()
        val blocker = QueueBlocker(fixture.touchExecutor)
        try {
            blocker.awaitStarted()
            assertTrue(fixture.controller.sendTouch(CONTACTS))
            fixture.rotateToken()
            blocker.release()
            fixture.drainTouches()

            assertTrue("An old touch must not reach a new session token", fixture.touches.isEmpty())
            assertTrue(fixture.controller.sendTouch(CONTACTS))
            fixture.drainTouches()
            assertEquals(listOf(CONTACTS), fixture.touches.toList())
        } finally {
            blocker.release()
            fixture.close()
        }
    }

    @Test
    fun sameSessionScreenReplacementDropsQueuedTouchWithoutRotatingTheSession() {
        val fixture = Fixture()
        val blocker = QueueBlocker(fixture.touchExecutor)
        try {
            blocker.awaitStarted()
            assertTrue(fixture.controller.sendTouch(CONTACTS))
            fixture.rotateMainScreen()
            blocker.release()
            fixture.drainTouches()
            assertTrue(fixture.touches.isEmpty())
            assertTrue(fixture.controller.sendTouch(CONTACTS))
            fixture.drainTouches()
            assertEquals(listOf(CONTACTS), fixture.touches.toList())
        } finally {
            blocker.release()
            fixture.close()
        }
    }

    @Test
    fun gestureOpensOneEpisodeAcrossMovesAndRelease() {
        val fixture = Fixture()
        try {
            assertTrue(fixture.controller.sendTouch(CONTACTS))
            assertTrue(fixture.controller.sendTouch(CONTACTS.map { it.copy(x = .5) }))
            assertTrue(fixture.controller.sendTouch(CONTACTS.map { it.copy(down = false) }))
            fixture.drainTouches()
            assertEquals(1, fixture.interactions.size)
            assertTrue(fixture.controller.sendTouch(CONTACTS))
            fixture.drainTouches()
            assertEquals(2, fixture.interactions.size)
        } finally { fixture.close() }
    }

    @Test
    fun queuedMediaFromPreviousTokenIsDropped() {
        val fixture = Fixture()
        val blocker = QueueBlocker(fixture.mediaExecutor)
        try {
            blocker.awaitStarted()
            assertTrue(fixture.controller.sendMediaButton(CarPlayMediaButton.NEXT))
            fixture.rotateToken()
            blocker.release()
            fixture.drainMedia()

            assertTrue("An old media press must not reach a new session token", fixture.mediaFrames.isEmpty())
            assertTrue(fixture.controller.sendMediaButton(CarPlayMediaButton.NEXT))
            fixture.drainMedia()
            assertEquals(2, fixture.mediaFrames.size)
            assertFrame(Iap2HidMessages.mediaReport(Iap2MediaRemoteCommand.NEXT), fixture.mediaFrames[0])
            assertFrame(Iap2HidMessages.releaseMediaButtons(), fixture.mediaFrames[1])
        } finally {
            blocker.release()
            fixture.close()
        }
    }

    @Test
    fun tokenChangeDuringPressPreventsRelease() {
        val fixture = Fixture()
        val pressEntered = CountDownLatch(1)
        val releasePress = CountDownLatch(1)
        fixture.onMediaSend = {
            if (fixture.mediaFrames.size == 1) {
                pressEntered.countDown()
                check(releasePress.await(5, TimeUnit.SECONDS))
            }
        }
        try {
            assertTrue(fixture.controller.sendMediaButton(CarPlayMediaButton.NEXT))
            assertTrue(pressEntered.await(3, TimeUnit.SECONDS))
            fixture.rotateToken()
            releasePress.countDown()
            fixture.drainMedia()

            assertEquals("No release from an old token may be sent", 1, fixture.mediaFrames.size)
            assertFrame(Iap2HidMessages.mediaReport(Iap2MediaRemoteCommand.NEXT), fixture.mediaFrames.single())
        } finally {
            releasePress.countDown()
            fixture.close()
        }
    }

    private class QueueBlocker(executor: ExecutorService) {
        private val started = CountDownLatch(1)
        private val released = CountDownLatch(1)

        init {
            executor.execute {
                started.countDown()
                check(released.await(5, TimeUnit.SECONDS))
            }
        }

        fun awaitStarted() { assertTrue(started.await(3, TimeUnit.SECONDS)) }
        fun release() { released.countDown() }
    }

    private class Fixture {
        val mediaFrames = CopyOnWriteArrayList<Iap2Frame>()
        val touches = CopyOnWriteArrayList<List<AirPlayContact>>()
        val interactions = CopyOnWriteArrayList<Any>()
        @Volatile private var mainScreenToken: Any = Any()
        @Volatile var onMediaSend: (Iap2Frame) -> Unit = {}
        @Volatile var onTouch: (List<AirPlayContact>) -> Unit = {}
        private val airPlaySession = mock(AirPlaySession::class.java) { invocation ->
            if (invocation.method.name.startsWith("mainScreenSessionToken")) {
                mainScreenToken
            } else if (invocation.method.name.startsWith("sendTouchForMainScreen")) {
                val contacts = invocation.getArgument<List<AirPlayContact>>(0).toList()
                touches += contacts
                onTouch(contacts)
                true
            } else Answers.RETURNS_DEFAULTS.answer(invocation)
        }
        private val mediaSession = mock(Iap2Session::class.java) { invocation ->
            if (invocation.method.name == "send" && invocation.arguments.firstOrNull() is Iap2Frame) {
                val frame = invocation.getArgument<Iap2Frame>(0)
                mediaFrames += frame
                onMediaSend(frame)
                null
            } else Answers.RETURNS_DEFAULTS.answer(invocation)
        }
        val controller = CarPlayController(
            context = RuntimeEnvironment.getApplication(),
            config = CarPlayRuntimeConfig(
                mfiTarget = MfiTarget.REMOTE,
                remoteMfiServer = "https://mfi.example.test",
                identification = Iap2IdentificationConfig("test", "test", "test", "test", "1", "1", 3),
            ),
            airPlayConfig = AirPlayConfig("test", "test", "", "1", AirPlayDisplayConfig(800, 480)),
            identity = AirPlayIdentity.generate(),
            pairings = PairingStore(),
            listener = object : AirPlaySessionListener {},
            media = object : AirPlayMediaHandler {
                override fun onVideoInteraction(session: AirPlaySession, token: Any) { interactions.add(token) }
            },
            reportStatus = {},
        )
        val touchExecutor = field("touchExecutor").get(controller) as ExecutorService
        val mediaExecutor = field("mediaButtonExecutor").get(controller) as ExecutorService

        init {
            field("activeSession").set(controller, airPlaySession)
            field("activeMediaRemoteSession").set(controller, mediaSession)
            rotateToken()
        }

        fun rotateToken() { field("activeAirPlayToken").set(controller, Any()); rotateMainScreen() }
        fun rotateMainScreen() { mainScreenToken = Any() }
        fun drainTouches() { touchExecutor.submit {}.get(3, TimeUnit.SECONDS) }
        fun drainMedia() { mediaExecutor.submit {}.get(3, TimeUnit.SECONDS) }
        fun close() {
            controller.close()
            assertTrue(controller.awaitClosed(3_000))
            assertTrue(touchExecutor.awaitTermination(3, TimeUnit.SECONDS))
            assertTrue(mediaExecutor.awaitTermination(3, TimeUnit.SECONDS))
            shadowOf(Looper.getMainLooper()).idle()
        }

        private fun field(name: String) = CarPlayController::class.java.getDeclaredField(name)
            .apply { isAccessible = true }
    }

    private fun assertFrame(expected: Iap2Frame, actual: Iap2Frame) {
        assertEquals(expected.messageId, actual.messageId)
        assertArrayEquals(expected.payload, actual.payload)
    }

    companion object {
        private val CONTACTS = listOf(AirPlayContact(1, 0.25, 0.75, true))
    }
}
