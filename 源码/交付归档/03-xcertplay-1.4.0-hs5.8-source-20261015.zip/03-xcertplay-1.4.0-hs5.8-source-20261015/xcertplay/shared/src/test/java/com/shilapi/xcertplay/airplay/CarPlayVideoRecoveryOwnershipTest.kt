package com.shilapi.xcertplay.airplay

import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE, sdk = [28])
class CarPlayVideoRecoveryOwnershipTest {
    @Test fun recoveryAndInteractionBelongToTheCurrentMainStream() {
        Fixture().use { fixture ->
            val session = fixture.session()
            assertNull(session.mainScreenSessionToken())
            fixture.engine.onScreen(session, 111, stream())!!
            assertNull("An alternate display cannot own main-screen input", session.mainScreenSessionToken())

            fixture.engine.onScreen(session, 110, stream())!!
            val oldToken = session.mainScreenSessionToken()!!
            val oldRecovery = fixture.recovery!!
            assertSame(oldToken, fixture.engine.mainScreenSessionToken(session))
            assertTrue(oldRecovery())
            fixture.engine.onVideoInteraction(session, oldToken)
            assertEquals(listOf(110), fixture.interactions)

            fixture.engine.onScreen(session, 110, stream())!!
            val currentToken = session.mainScreenSessionToken()!!
            val currentRecovery = fixture.recovery!!
            assertNotSame(oldToken, currentToken)
            assertFalse("A retained decoder callback cannot recover its replacement", oldRecovery())
            fixture.engine.onVideoInteraction(session, oldToken)
            assertEquals(listOf(110), fixture.interactions)
            assertTrue(currentRecovery())
            fixture.engine.onVideoInteraction(session, currentToken)
            assertEquals(listOf(110, 110), fixture.interactions)

            fixture.engine.onTeardown(session, 110)
            assertNull(session.mainScreenSessionToken())
            assertFalse(currentRecovery())
            fixture.engine.onVideoInteraction(session, currentToken)
            assertEquals(listOf(110, 110), fixture.interactions)
            assertEquals(listOf("forceKeyFrame", "forceKeyFrame"), fixture.commandTypes(session))
        }
    }

    @Test fun replacingTheOutputSessionRevokesOldRecoveryAndInteraction() {
        Fixture().use { fixture ->
            val oldSession = fixture.session()
            fixture.engine.onScreen(oldSession, 110, stream())!!
            val oldToken = oldSession.mainScreenSessionToken()!!
            val oldRecovery = fixture.recovery!!
            val currentSession = fixture.session()
            fixture.engine.onScreen(currentSession, 110, stream())!!
            val currentToken = currentSession.mainScreenSessionToken()!!
            val currentRecovery = fixture.recovery!!

            assertNull(oldSession.mainScreenSessionToken())
            assertFalse(oldRecovery())
            fixture.engine.onVideoInteraction(oldSession, oldToken)
            fixture.engine.onVideoInteraction(currentSession, oldToken)
            fixture.engine.onVideoInteraction(oldSession, currentToken)
            assertTrue(fixture.interactions.isEmpty())
            assertTrue("The new owner must retain working recovery", currentRecovery())
            fixture.engine.onVideoInteraction(currentSession, currentToken)
            assertEquals(listOf(110), fixture.interactions)
            assertTrue(fixture.commandTypes(oldSession).isEmpty())
            assertEquals(listOf("forceKeyFrame"), fixture.commandTypes(currentSession))

            oldSession.close()
            assertSame("Late old-session cleanup cannot revoke the new screen", currentToken,
                currentSession.mainScreenSessionToken())
            assertTrue(currentRecovery())
        }
    }

    @Test fun closingTheOwnerRevokesItsRetainedRecoveryAndInteraction() {
        Fixture().use { fixture ->
            val session = fixture.session()
            fixture.engine.onScreen(session, 110, stream())!!
            val token = session.mainScreenSessionToken()!!
            val recovery = fixture.recovery!!
            session.close()

            assertNull(session.mainScreenSessionToken())
            assertFalse(recovery())
            fixture.engine.onVideoInteraction(session, token)
            assertTrue(fixture.interactions.isEmpty())
            assertTrue(fixture.commandTypes(session).isEmpty())
        }
    }

    @Test fun recoveryWaitingForEventWriterCannotTargetAReplacementScreen() {
        for (switchSession in listOf(false, true)) {
            Fixture().use { fixture ->
                val oldSession = fixture.session()
                fixture.engine.onScreen(oldSession, 110, stream())!!
                val oldRecovery = fixture.recovery!!
                val currentSession = if (switchSession) fixture.session() else oldSession

                val result = replaceWhileEventRequestWaits(oldSession, oldRecovery) {
                    fixture.engine.onScreen(currentSession, 110, stream())!!
                }

                assertFalse("Queued recovery must recheck ownership after acquiring the writer", result)
                assertTrue(fixture.commandTypes(oldSession).isEmpty())
                assertTrue(fixture.commandTypes(currentSession).isEmpty())
                assertTrue(fixture.recovery!!())
                assertEquals(listOf("forceKeyFrame"), fixture.commandTypes(currentSession))
            }
        }
    }

    @Test fun touchWaitingForEventWriterCannotTargetAReplacementScreen() {
        val contacts = listOf(AirPlayContact(0, .5, .5, true))
        for (switchSession in listOf(false, true)) {
            Fixture().use { fixture ->
                val oldSession = fixture.session()
                fixture.engine.onScreen(oldSession, 110, stream())!!
                val oldToken = oldSession.mainScreenSessionToken()!!
                val currentSession = if (switchSession) fixture.session() else oldSession

                val result = replaceWhileEventRequestWaits(oldSession,
                    { oldSession.sendTouchForMainScreen(contacts, oldToken) }) {
                    fixture.engine.onScreen(currentSession, 110, stream())!!
                }

                assertFalse("Queued touch must not reach the replacement display", result)
                assertTrue(fixture.commandTypes(oldSession).isEmpty())
                assertTrue(fixture.commandTypes(currentSession).isEmpty())
                assertTrue(currentSession.sendTouchForMainScreen(contacts,
                    currentSession.mainScreenSessionToken()!!))
                assertEquals(listOf("hidSendReport"), fixture.commandTypes(currentSession))
            }
        }
    }

    /** Replacement runs separately so an accidental lock-order regression fails instead of hanging the test. */
    private fun replaceWhileEventRequestWaits(
        session: AirPlaySession,
        request: () -> Boolean,
        replace: () -> Unit,
    ): Boolean {
        val result = AtomicReference<Boolean?>()
        val failure = AtomicReference<Throwable?>()
        val replacementDone = CountDownLatch(1)
        val requester = Thread({
            try { result.set(request()) } catch (error: Throwable) { failure.set(error) }
        }, "test-old-main-screen-request").apply { isDaemon = true }
        val replacement = Thread({
            try { replace() } catch (error: Throwable) { failure.set(error) }
            finally { replacementDone.countDown() }
        }, "test-replace-main-screen").apply { isDaemon = true }
        try {
            synchronized(field(session, "eventWriteLock").get(session)) {
                requester.start()
                val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(3)
                while (requester.state != Thread.State.BLOCKED && requester.isAlive &&
                    System.nanoTime() < deadline) Thread.yield()
                assertEquals("The old request must be queued on the event writer",
                    Thread.State.BLOCKED, requester.state)
                replacement.start()
                assertTrue("Screen replacement must not wait for an event sender holding stale ownership",
                    replacementDone.await(3, TimeUnit.SECONDS))
            }
            requester.join(3_000)
            assertFalse("The queued request must finish after the writer is released", requester.isAlive)
            failure.get()?.let { throw AssertionError("Concurrent screen operation failed", it) }
            return requireNotNull(result.get())
        } finally {
            requester.join(3_000)
            if (replacement.state != Thread.State.NEW) replacement.join(3_000)
        }
    }

    private class Fixture : Closeable {
        var recovery: (() -> Boolean)? = null
        val interactions = mutableListOf<Int>()
        val engine = CarPlayMediaEngine(object : MediaSink {
            override fun onVideoRecoveryHandler(type: Int, requestKeyFrame: (() -> Boolean)?) {
                if (type == 110) recovery = requestKeyFrame
            }
            override fun onVideoInteraction(type: Int) { interactions.add(type) }
        })
        private val outputs = linkedMapOf<AirPlaySession, ByteArrayOutputStream>()

        fun session(): AirPlaySession {
            val peer = InetSocketAddress(InetAddress.getLoopbackAddress(), 32000)
            val session = AirPlaySession(
                socket = object : Socket() {
                    override fun getRemoteSocketAddress() = peer
                    override fun getInetAddress() = peer.address
                },
                config = AirPlayConfig("test", "02:00:00:00:00:02", "02:00:00:00:00:01", "1.0",
                    AirPlayDisplayConfig(800, 480)),
                identity = AirPlayIdentity.generate(), pairings = PairingStore(), mfi = null,
                listener = object : AirPlaySessionListener {}, media = engine,
            )
            val output = ByteArrayOutputStream()
            outputs[session] = output
            field(session.pairVerify, "sharedSecret").set(session.pairVerify, ByteArray(32) { it.toByte() })
            field(session, "eventSocket").set(session, object : Socket() {
                override fun getOutputStream() = output
            })
            field(session, "eventCipher").set(session, ControlCipher(ByteArray(32), ByteArray(32)))
            return session
        }

        fun commandTypes(session: AirPlaySession): List<String> {
            val plain = ControlCipher(ByteArray(32), ByteArray(32)).decrypt(outputs.getValue(session).toByteArray())
            assertEquals(0, plain.rest.size)
            val parsed = RtspMessage.parseMessages(plain.data)
            assertEquals(0, parsed.rest.size)
            return parsed.messages.map { (BplistCodec.decode(it.body) as Map<*, *>)["type"] as String }
        }

        override fun close() { outputs.keys.forEach { it.close() } }
    }

    private companion object {
        fun stream(): Map<String, Any?> = mapOf("streamConnectionID" to 1L)

        fun field(owner: Any, name: String) = owner.javaClass.getDeclaredField(name).apply { isAccessible = true }
    }
}
