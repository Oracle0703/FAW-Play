// SPDX-License-Identifier: AGPL-3.0-only
package com.shilapi.xcertplay.vehicle

import android.os.IBinder
import android.os.Parcel
import android.os.RemoteException
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class Hs5DrivingProtocolTest {
    @Test fun reads3222PrimitiveContractWithoutApplyingCanScalingAgain() {
        val rpc = FakeRpc().apply {
            ints[Key(7)] = 1234
            ints[Key(6)] = 2
            ints[Key(31)] = 37
            ints[Key(58)] = 0
            ints[Key(2)] = 423
            ints[Key(24)] = 12345
            floats[59] = 8.5f
            repeat(4) { index ->
                ints[Key(5, listOf(index))] = index % 2
                ints[Key(26, listOf(index))] = 247 + index
            }
            ints[Key(28)] = 1
            ints[Key(19)] = 0
        }
        val values = Hs5DrivingProtocol.read(rpc)
        assertEquals(17, values.size)
        assertEquals(1234.0, values[Hs5VehicleField.SPEED_RAW])
        assertEquals(12345.0, values[Hs5VehicleField.ODOMETER_KM])
        assertEquals(8.5, values[Hs5VehicleField.AVERAGE_FUEL_CONSUMPTION_RAW])
        assertEquals(247.0, values[Hs5VehicleField.TIRE_PRESSURE_RAW_FL])
        assertEquals(250.0, values[Hs5VehicleField.TIRE_PRESSURE_RAW_RR])
        assertEquals(1.0, values[Hs5VehicleField.DOOR_FR])
        assertEquals(1.0, values[Hs5VehicleField.TRUNK])
        assertEquals(listOf(59), rpc.floatCalls)
        assertEquals(setOf(7, 6, 31, 58, 2, 24, 5, 28, 19, 26), rpc.intCalls.map { it.method }.toSet())
        assertTrue(rpc.intCalls.filter { it.method == 5 || it.method == 26 }.all { it.args.single() in 0..3 })
        assertEquals(0, rpc.writes)
    }

    @Test fun unavailableAndReservedValuesRemainUnknownWhileOtherFieldsStillRead() {
        val rpc = FakeRpc().apply {
            ints[Key(7)] = 32767
            ints[Key(6)] = 9
            ints[Key(31)] = 255
            ints[Key(58)] = 3
            ints[Key(2)] = 65535
            ints[Key(24)] = -6553 // OEM may scale an underlying timeout before returning.
            floats[59] = -65533f
            ints[Key(5, listOf(0))] = -65534
            ints[Key(5, listOf(1))] = 1
            ints[Key(26, listOf(0))] = -180218
            ints[Key(26, listOf(1))] = 255 // Already-scaled 255 is not the raw CAN 255 sentinel.
            ints[Key(19)] = 1
        }
        val values = Hs5DrivingProtocol.read(rpc)
        for (field in listOf(Hs5VehicleField.SPEED_RAW, Hs5VehicleField.GEAR_RAW, Hs5VehicleField.FUEL_RAW,
            Hs5VehicleField.LOW_FUEL, Hs5VehicleField.RANGE_KM, Hs5VehicleField.ODOMETER_KM,
            Hs5VehicleField.AVERAGE_FUEL_CONSUMPTION_RAW, Hs5VehicleField.DOOR_FL,
            Hs5VehicleField.TIRE_PRESSURE_RAW_FL)) assertNull(field.name, values[field])
        assertEquals(1.0, values[Hs5VehicleField.DOOR_FR])
        assertEquals(255.0, values[Hs5VehicleField.TIRE_PRESSURE_RAW_FR])
        assertEquals(1.0, values[Hs5VehicleField.POSITION_LIGHT])
        assertEquals(17, values.size)
    }

    @Test fun nonfiniteAverageConsumptionIsUnknown() {
        val rpc = FakeRpc().apply { floats[59] = Float.NaN }
        assertNull(Hs5DrivingProtocol.read(rpc)[Hs5VehicleField.AVERAGE_FUEL_CONSUMPTION_RAW])
        rpc.floats[59] = Float.POSITIVE_INFINITY
        assertNull(Hs5DrivingProtocol.read(rpc)[Hs5VehicleField.AVERAGE_FUEL_CONSUMPTION_RAW])
    }

    @Test fun callbacksUseVerifiedOnewayWireAndSameSentinelRulesAsPolling() {
        val updates = mutableListOf<Pair<Hs5VehicleField, Double?>>()
        val subscription = Hs5DrivingProtocol.listeners { field, value -> updates += field to value }.single()
        assertEquals(15, subscription.module)
        assertEquals("ltd.qisi.adapterproxy.ICarVehicleStateManager", subscription.descriptor)
        assertEquals(42, subscription.registerMethod)
        assertEquals(43, subscription.unregisterMethod)
        assertTrue(send(subscription.listener, 8, 2, 1))
        assertTrue(send(subscription.listener, 10, 1234))
        assertTrue(send(subscription.listener, 11, 15))
        assertTrue(send(subscription.listener, 13, 1))
        assertTrue(send(subscription.listener, 29, 0))
        assertTrue(send(subscription.listener, 30, 254))
        assertTrue(send(subscription.listener, 31, 420))
        assertEquals(listOf(
            Hs5VehicleField.DOOR_RL to 1.0, Hs5VehicleField.SPEED_RAW to 1234.0,
            Hs5VehicleField.GEAR_RAW to null, Hs5VehicleField.POSITION_LIGHT to 1.0,
            Hs5VehicleField.LOW_FUEL to 0.0, Hs5VehicleField.FUEL_RAW to null,
            Hs5VehicleField.RANGE_KM to 420.0,
        ), updates)
        assertFalse(send(subscription.listener, 32, 10000)) // No confirmed 3222 odometer event chain.
        assertEquals(7, updates.size)
    }

    @Test fun malformedCallbackAndUnexpectedInterfaceNeverPublishVehicleValues() {
        val updates = mutableListOf<Pair<Hs5VehicleField, Double?>>()
        val listener = Hs5DrivingProtocol.listeners { field, value -> updates += field to value }.single().listener
        // Binder logs exceptions from one-way calls instead of returning them to the caller.
        // Use its synchronous path here to assert the actual receiver validation errors.
        assertRejected { send(listener, 8, 4, 1, oneWay = false) }
        assertRejected { send(listener, 10, 100, 200, oneWay = false) }
        assertRejected { send(listener, 10, oneWay = false) }
        assertRejected { send(listener, 10, 100, descriptor = "invalid.vehicle.interface", oneWay = false) }
        assertTrue(updates.isEmpty())
    }

    @Test fun synchronousCompatibilityCallPublishesAndWritesSuccessfulAcknowledgement() {
        val updates = mutableListOf<Pair<Hs5VehicleField, Double?>>()
        val listener = Hs5DrivingProtocol.listeners { field, value -> updates += field to value }.single().listener
        // OEM callbacks remain one-way. This exercises the supported synchronous reply path.
        assertTrue(send(listener, 10, 1234, oneWay = false))
        assertEquals(listOf(Hs5VehicleField.SPEED_RAW to 1234.0), updates)
    }

    private fun send(listener: IBinder, code: Int, vararg args: Int,
        descriptor: String = Hs5DrivingProtocol.LISTENER_DESCRIPTOR, oneWay: Boolean = true): Boolean {
        val data = Parcel.obtain()
        val reply = if (oneWay) null else Parcel.obtain()
        try {
            data.writeInterfaceToken(descriptor)
            args.forEach(data::writeInt)
            data.setDataPosition(0)
            val accepted = listener.transact(code, data, reply, if (oneWay) IBinder.FLAG_ONEWAY else 0)
            if (accepted && reply != null) {
                reply.setDataPosition(0)
                reply.readException()
            }
            return accepted
        } finally { data.recycle(); reply?.recycle() }
    }

    private fun assertRejected(action: () -> Unit) {
        try { action(); fail("Malformed vehicle callback accepted") }
        catch (_: IllegalArgumentException) { }
        catch (_: SecurityException) { }
        catch (_: RemoteException) { }
    }

    private data class Key(val method: Int, val args: List<Int> = emptyList())

    private class FakeRpc : Hs5VehicleRpc {
        val ints = mutableMapOf<Key, Int>()
        val floats = mutableMapOf<Int, Float>()
        val intCalls = mutableListOf<Key>()
        val floatCalls = mutableListOf<Int>()
        var writes = 0
        override fun int(module: Int, method: Int, vararg args: Int): Int {
            assertEquals(15, module)
            val key = Key(method, args.toList())
            intCalls += key
            return ints[key] ?: throw RemoteException("Property unavailable")
        }
        override fun float(module: Int, method: Int, vararg args: Int): Float {
            assertEquals(15, module)
            assertTrue(args.isEmpty())
            floatCalls += method
            return floats[method] ?: throw RemoteException("Property unavailable")
        }
        override fun string(module: Int, method: Int): String? = error("Unexpected string request")
        override fun callIntFloat(module: Int, method: Int, area: Int, value: Float): Int { writes++; error("Read-only protocol") }
        override fun register(module: Int, method: Int, listener: IBinder) { writes++; error("Registration is owned by client") }
        override fun unregister(module: Int, method: Int, listener: IBinder) { writes++; error("Registration is owned by client") }
    }
}
