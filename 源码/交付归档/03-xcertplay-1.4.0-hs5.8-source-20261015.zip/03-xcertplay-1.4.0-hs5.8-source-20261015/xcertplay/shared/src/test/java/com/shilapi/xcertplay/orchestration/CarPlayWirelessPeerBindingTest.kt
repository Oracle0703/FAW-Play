package com.shilapi.xcertplay.orchestration

import com.shilapi.xcertplay.airplay.*
import com.shilapi.xcertplay.network.WirelessHotspotInfo
import com.shilapi.xcertplay.network.WirelessHotspotManager
import com.shilapi.xcertplay.transport.Iap2IdentificationConfig
import java.net.Socket
import java.util.concurrent.atomic.AtomicInteger
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class CarPlayWirelessPeerBindingTest {
    @Test fun pendingAndRetiredSessionsCannotReplaceOrClearTheActiveWifiPeer() {
        val f = Fixture(); val old = f.session(); val current = f.session()
        try {
            f.listener.onDeviceInfo(old, info("02:00:00:00:00:01"))
            assertNull(f.hotspot.peer)
            f.listener.onSessionActive(old)
            assertEquals("02:00:00:00:00:01", f.hotspot.peer)
            f.listener.onDeviceInfo(current, info("02:00:00:00:00:02"))
            assertEquals("02:00:00:00:00:01", f.hotspot.peer)
            f.listener.onSessionActive(current)
            assertEquals("02:00:00:00:00:02", f.hotspot.peer)
            old.close()
            assertEquals("02:00:00:00:00:02", f.hotspot.peer)
            current.close()
            assertNull(f.hotspot.peer)
        } finally { old.close(); current.close(); f.close() }
    }

    @Test fun infoAfterRecordBindsPeerAndIncompleteInfoDoesNotEraseIt() {
        val f = Fixture(); val current = f.session()
        try {
            f.listener.onSessionActive(current)
            assertNull(f.hotspot.peer)
            f.listener.onDeviceInfo(current, info("02:00:00:00:00:03"))
            assertEquals("02:00:00:00:00:03", f.hotspot.peer)
            f.listener.onDeviceInfo(current, info(""))
            assertEquals("02:00:00:00:00:03", f.hotspot.peer)
        } finally { current.close(); f.close() }
    }

    @Test fun departureOfAnotherClientCannotInvalidateTheActiveWirelessSession() {
        val f = Fixture(); val current = f.session()
        try {
            val phase = f.field("phase")
            phase.set(f.controller, phase.type.enumConstants.single { it.toString() == "WIRELESS" })
            val generation = f.field("wirelessGeneration").get(f.controller) as AtomicInteger
            generation.set(9)
            f.listener.onDeviceInfo(current, info("02:00:00:00:00:03"))
            f.listener.onSessionActive(current)
            val handler = CarPlayController::class.java.getDeclaredMethod("onWirelessPeerDisconnected",
                Int::class.javaPrimitiveType, WirelessHotspotManager::class.java, String::class.java).apply { isAccessible = true }
            handler.invoke(f.controller, 9, f.hotspot, "02:00:00:00:00:04")
            assertEquals(9, generation.get())
            assertFalse(current.isClosed())
            handler.invoke(f.controller, 8, f.hotspot, "02:00:00:00:00:03")
            assertEquals(9, generation.get())
            handler.invoke(f.controller, 9, f.hotspot, "02:00:00:00:00:03")
            assertEquals(10, generation.get())
        } finally { current.close(); f.close() }
    }

    private fun info(mac: String) = AirPlayDeviceInfo("test", "", mac, "test")
    private class Hotspot : WirelessHotspotManager {
        var peer: String? = null
        override fun setActivePeer(wifiMac: String?) { peer = wifiMac }
        override fun start(timeoutMillis: Long): WirelessHotspotInfo = error("Must not start a radio in this test")
        override fun close() {}
    }
    private class Fixture {
        val hotspot = Hotspot()
        val config = AirPlayConfig("test", "test", "", "1", AirPlayDisplayConfig(800, 480))
        val identity = AirPlayIdentity.generate()
        val controller = CarPlayController(
            RuntimeEnvironment.getApplication(),
            CarPlayRuntimeConfig(mfiTarget = MfiTarget.REMOTE, remoteMfiServer = "https://mfi.example.test",
                transport = CarPlayTransport.WIRELESS,
                identification = Iap2IdentificationConfig("test", "test", "test", "test", "1", "1", 3)),
            config, identity, PairingStore(), object : AirPlaySessionListener {}, object : AirPlayMediaHandler {}, {})
        val listener = field("sessionListener").get(controller) as AirPlaySessionListener
        init { field("hotspot").set(controller, hotspot) }
        fun session() = AirPlaySession(Socket(), config, identity, PairingStore(), null, listener, object : AirPlayMediaHandler {})
        fun close() { controller.close(); assertTrue(controller.awaitClosed(3_000)) }
        fun field(name: String) = CarPlayController::class.java.getDeclaredField(name).apply { isAccessible = true }
    }
}
