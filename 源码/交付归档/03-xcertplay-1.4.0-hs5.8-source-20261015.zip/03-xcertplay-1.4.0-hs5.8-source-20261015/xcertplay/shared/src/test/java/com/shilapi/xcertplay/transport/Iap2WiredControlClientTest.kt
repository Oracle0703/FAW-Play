package com.shilapi.xcertplay.transport

import com.shilapi.xcertplay.iap2.body.Iap2BodyReader
import com.shilapi.xcertplay.iap2.session.Iap2Session
import com.shilapi.xcertplay.iap2.wire.Iap2Frame
import com.shilapi.xcertplay.iap2.wire.Iap2Parameter
import com.shilapi.xcertplay.iap2.wire.Iap2ParameterList
import com.shilapi.xcertplay.mfi.Iap2MfiAuthenticationClient
import com.shilapi.xcertplay.mfi.MfiAuthenticator
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import org.mockito.Mockito.mock
import org.mockito.Mockito.RETURNS_DEFAULTS
import java.io.IOException

class Iap2WiredControlClientTest {
    @Test
    fun incomingBurstsDoNotIncreaseLocationRateAndStopEndsUpdates() {
        val source = FakeLocationProvider()
        var nowMillis = 0L
        val acceptedAt = mutableListOf<Long>()
        val radio = ScriptedSession(
            *successfulBringUp(),
            frame(0xfffa),
            *Array(12) { frame(0x5101) },
            frame(0x5102),
            *Array(5) { frame(0x5101) },
            frame(0x5103),
            frame(0x5101),
            frame(0xfffc),
            frame(0x5104),
            *Array(5) { frame(0x5101) },
        )
        radio.onReceive = {
            when (it?.messageId) {
                0x5102 -> nowMillis = 400
                0x5103 -> nowMillis = 1_000
                0x5104 -> nowMillis = 2_000
            }
        }
        radio.onTrySendLocation = {
            acceptedAt += nowMillis
            true
        }

        val result = client(radio) { nowMillis * 1_000_000 }.run(
            identification(), endpoint(), availableCurrentMilliAmps = 500,
            locationProvider = source,
        )

        assertEquals(listOf(0L, 1_000L), acceptedAt)
        assertEquals(2, radio.sent.count { it.messageId == 0xfffb })
        assertFalse(source.started)
        assertTrue(radio.consumedWholeScript)
        assertEquals(Iap2WiredControlTerminal.CHANNEL_CLOSED, result.terminal)
    }

    @Test
    fun locationBackpressureSkipsOldSampleAndResumesWithLatestWithoutClosingControl() {
        val source = FakeLocationProvider()
        var nowMillis = 0L
        val attemptedAt = mutableListOf<Long>()
        val radio = ScriptedSession(
            *successfulBringUp(),
            frame(0xfffa),
            *Array(5) { frame(0x5101) },
            frame(0x5102),
            frame(0x5101),
            frame(0x5103),
            frame(0xfffc),
            frame(0x5104),
        )
        radio.onReceive = {
            when (it?.messageId) {
                0x5102 -> {
                    nowMillis = 400
                    source.nmea = "\$GPRMC,intermediate\r\n"
                }
                0x5103 -> {
                    nowMillis = 1_000
                    source.nmea = "\$GPRMC,latest\r\n"
                }
                0x5104 -> nowMillis = 2_000
            }
        }
        radio.onTrySendLocation = {
            attemptedAt += nowMillis
            attemptedAt.size > 1
        }

        val result = client(radio) { nowMillis * 1_000_000 }.run(
            identification(), endpoint(), availableCurrentMilliAmps = 500,
            locationProvider = source,
        )

        assertEquals(listOf(0L, 1_000L), attemptedAt)
        val accepted = radio.sent.single { it.messageId == 0xfffb }
        assertEquals(source.nmea, Iap2BodyReader.of(accepted).string(0))
        assertFalse(source.started)
        assertTrue(radio.consumedWholeScript)
        assertEquals(Iap2WiredControlTerminal.CHANNEL_CLOSED, result.terminal)
    }

    @Test
    fun locationTransportFailureStillPropagatesAndStopsProvider() {
        val source = FakeLocationProvider()
        val radio = ScriptedSession(*successfulBringUp(), frame(0xfffa))
        val expected = IOException("test wired link failure")
        radio.onTrySendLocation = { throw expected }

        val failure = runCatching {
            client(radio).run(
                identification(), endpoint(), availableCurrentMilliAmps = 500,
                locationProvider = source,
            )
        }.exceptionOrNull()

        assertSame(expected, failure)
        assertFalse(source.started)
    }

    @Test
    fun criticalControlSendFailuresAreNotTreatedAsOptionalLocationBackpressure() {
        val radio = ScriptedSession(*successfulBringUp(), frame(0x4300))
        val expected = IOException("test critical send failure")
        radio.onSend = { if (it.messageId == 0x4301) throw expected }

        val failure = runCatching {
            client(radio).run(identification(), endpoint(), availableCurrentMilliAmps = 500)
        }.exceptionOrNull()

        assertSame(expected, failure)
    }

    @Test
    fun carPlayStartSessionNestsAddressesInsideWiredAttributes() {
        val frame = Iap2WiredControlClient.carPlayStartSession(
            Iap2WiredCarPlayEndpoint(
                ipv6Addresses = listOf("fe80::2"),
                airPlayPort = 7000,
                deviceIdentifier = "02:00:00:00:00:02",
                publicKey = "abcd",
                sourceVersion = "1.0",
            ),
        )

        assertEquals(0x4301, frame.messageId)
        val outer = Iap2BodyReader.of(frame).list()
        val wired = outer.single { it.id == 0 }
        val addresses = Iap2ParameterList.parse(wired.payload).asList()
        assertEquals(1, addresses.size)
        assertEquals(0, addresses.single().id)
        assertArrayEquals("fe80::2\u0000".encodeToByteArray(), addresses.single().payload)
    }

    private fun identification() = Iap2IdentificationConfig(
        name = "test receiver",
        modelIdentifier = "test receiver",
        manufacturer = "test",
        serialNumber = "test-1",
        firmwareVersion = "1.0",
        hardwareVersion = "1.0",
        carPlayUsbInterfaceNumber = 4,
    )

    private fun endpoint() = Iap2WiredCarPlayEndpoint(
        ipv6Addresses = listOf("fe80::2"),
        airPlayPort = 7000,
        publicKey = "test-public-key",
        sourceVersion = "1.0",
    )

    private fun client(
        radio: ScriptedSession,
        locationNanoTime: () -> Long = System::nanoTime,
    ) = Iap2WiredControlClient(
        radio.session,
        Iap2MfiAuthenticationClient(object : MfiAuthenticator {
            override fun protocolMajor() = 3
            override fun readCertificate(maximumOutputLength: Int) = byteArrayOf(1, 2, 3)
            override fun signChallenge(challenge: ByteArray) = byteArrayOf(4, 5, 6)
        }),
        locationNanoTime,
    )

    private fun successfulBringUp(): Array<Iap2Frame?> = arrayOf(
        frame(0x1d00),
        frame(0x1d02),
        frame(0xaa00),
        Iap2Frame(0xaa02, Iap2ParameterList.of(Iap2Parameter(0, byteArrayOf(1))).encode()),
        frame(0xaa05),
    )

    private fun frame(messageId: Int) = Iap2Frame(messageId, ByteArray(0))

    /** Mock transport only so identification, authentication and the real control loop run. */
    private class ScriptedSession(vararg incoming: Iap2Frame?) {
        val sent = mutableListOf<Iap2Frame>()
        var onSend: (Iap2Frame) -> Unit = {}
        var onReceive: (Iap2Frame?) -> Unit = {}
        var onTrySendLocation: (Iap2Frame) -> Boolean = { true }
        private val script = incoming.toList()
        private var position = 0
        private var closed = false
        val consumedWholeScript get() = position == script.size
        val session = mock(Iap2Session::class.java) { call ->
            when (call.method.name) {
                "awaitReady" -> true
                "isClosed" -> closed
                "recv" -> {
                    val incomingFrame = if (position < script.size) script[position++] else {
                        closed = true
                        null
                    }
                    onReceive(incomingFrame)
                    incomingFrame
                }
                "send" -> {
                    val outgoing = call.getArgument<Iap2Frame>(0)
                    assertFalse("Optional location must use the nonblocking path", outgoing.messageId == 0xfffb)
                    onSend(outgoing)
                    sent += outgoing
                    null
                }
                "trySendLocation" -> {
                    val outgoing = call.getArgument<Iap2Frame>(0)
                    onTrySendLocation(outgoing).also { accepted -> if (accepted) sent += outgoing }
                }
                else -> RETURNS_DEFAULTS.answer(call)
            }
        }
    }

    private class FakeLocationProvider : Iap2LocationProvider {
        var started = false
        var nmea = "\$GPRMC,initial\r\n"
        override fun start(): Boolean { started = true; return true }
        override fun stop() { started = false }
        override fun latestNmea() = nmea
    }
}
