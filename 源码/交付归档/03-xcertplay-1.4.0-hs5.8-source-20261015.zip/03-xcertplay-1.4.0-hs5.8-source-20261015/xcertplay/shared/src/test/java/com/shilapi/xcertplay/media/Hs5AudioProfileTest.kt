package com.shilapi.xcertplay.media

import org.junit.Assert.*
import org.junit.Test

class Hs5AudioProfileTest {
    @Test fun hs5GuidanceDoesNotChangeGenericAutomotiveRouting() {
        assertEquals(AudioChannel.MEDIA, AudioChannelMapper.map("default", 100, AudioChannelMappingMode.AUTOMOTIVE_BUS).channel)
        assertEquals(AudioChannel.NAVIGATION, Hs5AudioProfile.selection("default", 100, AudioChannelMappingMode.AUTOMOTIVE_BUS).channel)
        for (mode in AudioChannelMappingMode.entries) for (type in listOf("media", "telephony", "speechrecognition", "compatibility", "alert"))
            assertEquals(AudioChannelMapper.map(type, 100, mode), Hs5AudioProfile.selection(type, 100, mode))
    }
    @Test fun rejectedAndUninitializedLegacyTracksFallBackAndRelease() {
        val released = mutableListOf<String>()
        assertEquals("usage", LegacyAudioFallback.build({ "bad" }, { false }, released::add, { "usage" }))
        assertEquals(listOf("bad"), released)
        assertEquals("usage", LegacyAudioFallback.build<String>({ throw IllegalArgumentException() }, { true }, released::add, { "usage" }))
        assertEquals("legacy", LegacyAudioFallback.build({ "legacy" }, { true }, released::add, { "usage" }))
        assertEquals(1, released.size)
    }
}
