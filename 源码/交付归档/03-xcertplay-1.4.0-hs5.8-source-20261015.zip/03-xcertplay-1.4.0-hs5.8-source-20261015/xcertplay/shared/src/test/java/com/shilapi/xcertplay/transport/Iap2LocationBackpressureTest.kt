package com.shilapi.xcertplay.transport

import com.shilapi.xcertplay.iap2.session.Iap2Session
import com.shilapi.xcertplay.iap2.wire.Iap2Frame
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.ArrayDeque
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock
import org.junit.Assert.*
import org.junit.Test
import org.mockito.Mockito.*

class Iap2LocationBackpressureTest {
    @Test
    fun aPendingCommandRejectsTheWholeLocationWithoutClosingOrAddingFragments() {
        val fixture = Fixture()
        try {
            assertTrue(fixture.link.sendControl(byteArrayOf(42)))
            assertFalse(fixture.session.trySendLocation(location("old")))
            assertFalse(fixture.session.isClosed)
            assertEquals(1, fixture.queued().size)
            assertArrayEquals(byteArrayOf(42), fixture.queued().single())
            verify(fixture.stream, never()).close()

            fixture.drainCommands()
            val latest = location("latest")
            assertTrue(fixture.session.trySendLocation(latest))
            assertTrue("The sample exercises a split CSM frame", fixture.queued().size > 1)
            assertArrayEquals(latest.encodedFrame(), fixture.queued().joinBytes())
            assertEquals(1, fixture.traces.count { it.startsWith("IAP2 TX") })
        } finally { fixture.session.close() }
    }

    @Test
    fun onePendingLocationCannotAccumulateMoreOldLocations() {
        val fixture = Fixture()
        try {
            val first = location("first")
            assertTrue(fixture.session.trySendLocation(first))
            repeat(100) { assertFalse(fixture.session.trySendLocation(location("later-$it"))) }
            assertArrayEquals(first.encodedFrame(), fixture.queued().joinBytes())
            assertFalse(fixture.session.isClosed)
        } finally { fixture.session.close() }
    }

    @Test
    fun aSampleThatCannotFitCompletelyLeavesNoFragmentsBehind() {
        val fixture = Fixture()
        try {
            assertFalse(fixture.session.trySendLocation(location("x".repeat(1_200))))
            assertTrue(fixture.queued().isEmpty())
            assertFalse(fixture.session.isClosed)
            assertTrue(fixture.session.trySendLocation(location("new-small-fix")))
        } finally { fixture.session.close() }
    }

    @Test
    fun criticalSendStillFailsClosedWhenTheCompleteFrameCannotBeQueued() {
        val fixture = Fixture()
        repeat(64) { assertTrue(fixture.link.sendControl(byteArrayOf(1))) }
        assertFalse(fixture.session.trySendLocation(location("replaceable")))
        assertFalse(fixture.session.isClosed)

        val failure = assertThrows(IOException::class.java) { fixture.session.send(Iap2Frame(0x6803, byteArrayOf(1)), 0) }
        assertTrue(failure.message.orEmpty().contains("complete CSM frame"))
        assertTrue(fixture.session.isClosed)
        verify(fixture.stream).close()
    }

    @Test
    fun aBusyCriticalSenderDoesNotMakeALocationWaitForTheSendLock() {
        val fixture = Fixture()
        val lock = Iap2CsmChannel::class.java.getDeclaredField("sendLock").apply { isAccessible = true }
            .get(fixture.channel) as ReentrantLock
        val worker = Executors.newSingleThreadExecutor()
        lock.lock()
        try {
            val result = worker.submit<Boolean> { fixture.session.trySendLocation(location("skip")) }
            assertFalse(result.get(500, TimeUnit.MILLISECONDS))
            assertTrue(fixture.queued().isEmpty())
        } finally { lock.unlock(); worker.shutdownNow(); fixture.session.close() }
    }

    @Test
    fun aRealLinkFailureStillPropagatesAndClosesTheLocationSender() {
        val fixture = Fixture()
        val failure = IOException("synthetic underlying write failure")
        Iap2LinkChannel::class.java.getDeclaredField("terminalFailure").apply { isAccessible = true }
            .set(fixture.link, failure)
        val observed = assertThrows(IOException::class.java) { fixture.session.trySendLocation(location("sample")) }
        assertSame(failure, observed)
        assertTrue(fixture.session.isClosed)
        verify(fixture.stream).close()
    }

    @Test
    fun criticalMessagesCannotUseTheDroppableLocationPath() {
        val fixture = Fixture()
        try {
            assertThrows(IllegalArgumentException::class.java) {
                fixture.session.trySendLocation(Iap2Frame(0x6803, byteArrayOf(1)))
            }
            assertTrue(fixture.queued().isEmpty())
            assertFalse(fixture.session.isClosed)
        } finally { fixture.session.close() }
    }

    private fun location(label: String) = Iap2LocationMessages.locationInformation("\$GPGGA,$label,synthetic-test-data\r\n")

    private fun List<ByteArray>.joinBytes() = ByteArrayOutputStream().also { out -> forEach(out::write) }.toByteArray()

    /** A negotiated, deliberately unpumped link makes every queue transition deterministic. */
    private class Fixture {
        val stream = mock(BlockingDuplexByteStream::class.java)
        val link = Iap2LinkChannel::class.java.getDeclaredConstructor(
            BlockingDuplexByteStream::class.java, Iap2LinkConfig::class.java, Boolean::class.javaPrimitiveType!!,
        ).apply { isAccessible = true }.newInstance(stream, Iap2LinkConfig(), false)
        val channel = Iap2CsmChannel::class.java.getDeclaredConstructor(Iap2LinkChannel::class.java)
            .apply { isAccessible = true }.newInstance(link)
        val traces = mutableListOf<String>()
        val session = Iap2Session.wrap(channel, onTrace = traces::add)

        init {
            field("ready").setBoolean(link, true)
            field("peerMaxControlPayloadBytes").set(link, 18)
        }

        fun queued(): List<ByteArray> = commands().map { command ->
            command.javaClass.getDeclaredField("bytes").apply { isAccessible = true }.get(command) as ByteArray
        }

        fun drainCommands() {
            commands().clear()
            field("commandBytes").setInt(link, 0)
        }

        @Suppress("UNCHECKED_CAST")
        private fun commands() = field("commands").get(link) as ArrayDeque<Any>
        private fun field(name: String) = Iap2LinkChannel::class.java.getDeclaredField(name).apply { isAccessible = true }
    }
}
