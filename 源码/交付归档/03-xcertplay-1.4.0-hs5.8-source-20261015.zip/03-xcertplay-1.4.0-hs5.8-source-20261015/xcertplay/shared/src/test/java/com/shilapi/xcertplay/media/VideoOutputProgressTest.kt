package com.shilapi.xcertplay.media

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VideoOutputProgressTest {
    @Test
    fun idleScreenWithNoUnreleasedInputDoesNotRequestRefresh() {
        val progress = VideoOutputProgress()
        assertFalse(progress.shouldProbe(10_000_000_000L))
        progress.onInput(1L, 1L)
        progress.onOutput(1L, 10L)
        assertFalse(progress.shouldProbe(10_000_000_000L))
        progress.onOutput(2L, 20L)
        assertFalse(progress.shouldProbe(10_000_000_000L))
    }

    @Test
    fun acceptedTailGetsOneProbeAndANewEpisodeCanProbeAgain() {
        val progress = VideoOutputProgress()
        progress.onInput(1L, 1L)
        progress.onInput(2L, 30_000_000L)
        progress.onOutput(1L, 40_000_000L)
        assertFalse(progress.shouldProbe(539_999_999L))
        assertTrue(progress.shouldProbe(540_000_000L))
        progress.probeScheduled()
        assertFalse(progress.shouldProbe(2_000_000_000L))
        progress.onInput(3L, 2_000_000_000L)
        progress.onOutput(2L, 2_010_000_000L)
        assertFalse(progress.shouldProbe(5_000_000_000L))
        progress.beginEpisode(5_000_000_000L)
        progress.onInput(4L, 5_000_000_000L)
        progress.onInput(5L, 5_033_000_000L)
        assertTrue(progress.shouldProbe(5_533_000_000L))
    }

    @Test
    fun eitherInputOrOutputRestartsTheStallDeadline() {
        val progress = VideoOutputProgress()
        progress.onInput(1L, 1L)
        progress.onInput(2L, 400_000_000L)
        assertFalse(progress.shouldProbe(899_999_999L))
        assertTrue(progress.shouldProbe(900_000_000L))
        progress.onOutput(1L, 950_000_000L)
        assertFalse(progress.shouldProbe(1_449_999_999L))
        assertTrue(progress.shouldProbe(1_450_000_000L))
    }

    @Test
    fun resetClearsThePendingTailProbeAndContinuousInputCandidate() {
        val progress = VideoOutputProgress()
        progress.onOutput(99L, 0L)
        progress.onInput(100L, 1L)
        progress.probeScheduled()
        repeat(5) { frame ->
            progress.onInput(101L + frame, 1_000_000_000L + frame * 100_000_000L)
        }
        progress.reset()
        assertFalse(progress.shouldProbe(10_000_000_000L))
        // A restarted stream may begin with lower presentation timestamps.
        progress.onInput(1L, 11_000_000_000L)
        assertTrue(progress.shouldProbe(11_500_000_000L))
        progress.onOutput(1L, 11_600_000_000L)
        assertFalse(progress.shouldProbe(12_100_000_000L))
    }

    @Test
    fun multiFrameRefreshRepliesCannotRearmTheirOwnProbe() {
        val progress = VideoOutputProgress()
        progress.onInput(1L, 1L)
        progress.onInput(2L, 30_000_000L)
        progress.onOutput(1L, 40_000_000L)
        assertTrue(progress.shouldProbe(540_000_000L))
        progress.probeScheduled()

        // A forceKeyFrame response can contain several pictures, leaving another tail.
        repeat(5) { burst ->
            repeat(3) { frame ->
                val now = (1L + burst) * 1_000_000_000L + frame * 33_000_000L
                val ptsUs = 3L + burst * 3 + frame
                progress.onInput(ptsUs, now)
                progress.onOutput(ptsUs - 1L, now + 1L)
            }
            assertFalse(progress.shouldProbe((2L + burst) * 1_000_000_000L - 1L))
        }
        assertFalse(progress.shouldProbe(10_000_000_000L))
    }

    @Test
    fun sustainedAnimationStartsANewEpisodeAndItsNextTailCanRecover() {
        val progress = VideoOutputProgress()
        progress.onInput(1L, 1L)
        progress.probeScheduled()

        // Resume real 30 fps animation after the refresh, without another touch.
        repeat(17) { frame ->
            val now = 1_000_000_000L + frame * 33_000_000L
            progress.onInput(2L + frame, now)
            progress.onOutput(1L + frame, now + 1L)
            assertFalse(progress.shouldProbe(now))
        }
        assertFalse(progress.shouldProbe(2_027_999_999L))
        assertTrue(progress.shouldProbe(2_028_000_001L))
        progress.probeScheduled()
        assertFalse(progress.shouldProbe(3_000_000_000L))
    }

    @Test
    fun denseInputMustContinueForHalfASecondToStartANewEpisode() {
        val progress = VideoOutputProgress()
        progress.onInput(1L, 1L)
        progress.probeScheduled()
        repeat(5) { frame ->
            progress.onInput(2L + frame, 1_000_000_000L + frame * 100_000_000L)
        }
        assertFalse(progress.shouldProbe(1_900_000_000L))
        progress.onInput(7L, 1_500_000_000L)
        assertTrue(progress.shouldProbe(2_000_000_000L))
    }

    @Test
    fun gapBetweenShortBurstsRestartsTheContinuousInputCandidate() {
        val progress = VideoOutputProgress()
        progress.onInput(1L, 1L)
        progress.probeScheduled()
        repeat(5) { frame ->
            progress.onInput(2L + frame, 1_000_000_000L + frame * 100_000_000L)
        }
        // One nanosecond beyond the allowed input gap must break the first candidate.
        repeat(5) { frame ->
            progress.onInput(7L + frame, 1_520_000_001L + frame * 100_000_000L)
        }
        assertFalse(progress.shouldProbe(2_420_000_001L))
        progress.onInput(12L, 2_020_000_001L)
        assertTrue(progress.shouldProbe(2_520_000_001L))
    }

    @Test
    fun maximumAllowedInputGapStillRearmsAfterHalfASecond() {
        val progress = VideoOutputProgress()
        progress.onInput(1L, 1L)
        progress.probeScheduled()
        repeat(6) { frame ->
            progress.onInput(2L + frame, 1_000_000_000L + frame * 120_000_000L)
        }
        assertTrue(progress.shouldProbe(2_100_000_000L))
    }

    @Test
    fun catchingUpWithinARefreshResponseDoesNotCreateANewEpisode() {
        val progress = VideoOutputProgress()
        progress.onInput(1L, 1L)
        assertTrue(progress.shouldProbe(500_000_001L))
        progress.probeScheduled()
        progress.onInput(2L, 1_000_000_000L)
        progress.onOutput(2L, 1_010_000_000L)
        progress.onInput(3L, 1_033_000_000L)
        assertFalse(progress.shouldProbe(2_000_000_000L))
    }

    @Test
    fun newInteractionWaitsBeforeProbingThePendingTail() {
        val progress = VideoOutputProgress()
        progress.onInput(1L, 1L)
        assertTrue(progress.shouldProbe(500_000_001L))
        progress.probeScheduled()
        progress.beginEpisode(2_000_000_000L)
        assertFalse(progress.shouldProbe(2_499_999_999L))
        assertTrue(progress.shouldProbe(2_500_000_000L))
        progress.probeScheduled()
        assertFalse(progress.shouldProbe(3_000_000_000L))
    }

    @Test
    fun newEpisodeWithoutAPendingPictureDoesNotProbe() {
        val progress = VideoOutputProgress()
        progress.beginEpisode(1_000_000_000L)
        assertFalse(progress.shouldProbe(2_000_000_000L))
        progress.onInput(1L, 2_000_000_000L)
        progress.onOutput(1L, 2_010_000_000L)
        progress.beginEpisode(3_000_000_000L)
        assertFalse(progress.shouldProbe(4_000_000_000L))
    }

    @Test
    fun onlyAScheduledRequestConsumesTheProbeAndItCannotRetryWithinTheEpisode() {
        val progress = VideoOutputProgress()
        progress.onInput(1L, 1L)
        assertTrue(progress.shouldProbe(500_000_001L))
        // A throttled or already pending request has not been scheduled.
        assertTrue(progress.shouldProbe(1_000_000_001L))
        progress.probeScheduled()
        // Scheduling consumes this probe even if sending the request later fails.
        assertFalse(progress.shouldProbe(2_000_000_001L))
        assertFalse(progress.shouldProbe(10_000_000_001L))
    }

    @Test
    fun ageDoesNotBecomeNegativeWhenQueriedBeforeLatestProgress() {
        val progress = VideoOutputProgress()
        progress.onInput(1L, 1_000_000_000L)
        assertEquals(0L, progress.ageNanos(999_999_999L))
        assertFalse(progress.shouldProbe(999_999_999L))
    }
}
