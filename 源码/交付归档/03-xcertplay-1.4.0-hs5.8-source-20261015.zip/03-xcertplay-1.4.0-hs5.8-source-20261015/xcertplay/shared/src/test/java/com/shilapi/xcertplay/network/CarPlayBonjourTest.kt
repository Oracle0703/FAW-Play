package com.shilapi.xcertplay.network

import com.shilapi.xcertplay.airplay.AirPlayConfig
import com.shilapi.xcertplay.airplay.AirPlayDisplayConfig
import com.shilapi.xcertplay.airplay.AirPlayIdentity
import org.junit.Assert.assertEquals
import org.junit.Test
import java.net.Inet6Address
import java.net.InetAddress

class CarPlayBonjourTest {
    @Test
    fun ipv4ListenerSkipsIpv6AndOtherInterfaceSubnet() {
        val local = InetAddress.getByName("192.0.2.1")
        val peer = InetAddress.getByName("192.0.2.2")
        assertEquals(listOf(peer), CarPlayBonjourProtocol.compatibleAddresses(listOf(
            InetAddress.getByName("fe80::2"), InetAddress.getByName("198.51.100.2"), peer,
        ), local, 24))
    }

    @Test
    fun linkLocalIpv6UsesOnlyCurrentP2pScope() {
        fun scoped(host: String, scope: Int) = Inet6Address.getByAddress(null, InetAddress.getByName(host).address, scope)
        val local = scoped("fe80::1", 7)
        val unscoped = scoped("fe80::2", 0)
        val addresses = CarPlayBonjourProtocol.compatibleAddresses(listOf(
            scoped("fe80::3", 9), InetAddress.getByName("2001:db8::2"), unscoped,
        ), local)
        assertEquals(1, addresses.size)
        assertEquals(7, (addresses.single() as Inet6Address).scopeId)
        assertEquals(unscoped, addresses.single())
    }

    @Test
    fun compatibleProbeCandidatesAreDistinctAndBounded() {
        val local = InetAddress.getByName("192.0.2.1")
        val peers = (2..7).map { InetAddress.getByName("192.0.2.$it") }
        assertEquals(peers.take(4), CarPlayBonjourProtocol.compatibleAddresses(
            listOf(peers.first(), peers.first(), InetAddress.getByName("127.0.0.1")) + peers, local))
    }

    private val config = AirPlayConfig(
        deviceName = "xcertplay",
        deviceId = "02:00:00:00:00:02",
        btMac = "02:00:00:00:00:02",
        sourceVersion = "366.0",
        main = AirPlayDisplayConfig(widthPixels = 1280, heightPixels = 720),
        model = "LIVI",
    )
    private val identity = AirPlayIdentity(
        privateKey = ByteArray(32),
        publicKey = byteArrayOf(0x01, 0x23, 0xab.toByte()),
        pairingId = "pairing-1",
    )

    @Test
    fun airPlayTxtRecordsMatchLivi() {
        assertEquals(
            linkedMapOf(
                "deviceid" to "02:00:00:00:00:02",
                "features" to "0x44540380,0x61",
                "flags" to "0x4",
                "model" to "LIVI",
                "srcvers" to "366.0",
                "protovers" to "1.1",
                "pi" to "pairing-1",
                "pk" to "0123ab",
            ),
            CarPlayBonjourProtocol.airPlayTxtRecords(config, identity),
        )
    }

    @Test
    fun connectProbeRequestMatchesExactRequestLineAndHeaders() {
        assertEquals(
            "GET /ctrl-int/1/connect HTTP/1.1\r\n" +
                "Host: [fe80::1]:7000\r\n" +
                "User-Agent: AirPlay/366.0\r\n" +
                "AirPlay-Receiver-Device-ID: 020000000002\r\n" +
                "Connection: close\r\n" +
                "\r\n",
            CarPlayBonjourProtocol.connectProbeRequest(
                host = "fe80::1%wlan0",
                port = 7000,
                sourceVersion = "366.0",
                deviceId = "02:00:00:00:00:02",
            ),
        )
    }
}
