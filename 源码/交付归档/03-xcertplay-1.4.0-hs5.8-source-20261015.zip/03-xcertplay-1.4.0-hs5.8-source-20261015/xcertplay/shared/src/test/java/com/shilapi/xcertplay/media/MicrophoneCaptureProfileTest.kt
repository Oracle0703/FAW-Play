package com.shilapi.xcertplay.media

import android.media.MediaRecorder
import com.shilapi.xcertplay.airplay.AudioCodecKind
import com.shilapi.xcertplay.airplay.AudioStreamCodec
import com.shilapi.xcertplay.airplay.MicrophoneConfig
import java.net.InetAddress
import org.concentus.OpusDecoder
import org.junit.Assert.*
import org.junit.Test

class MicrophoneCaptureProfileTest {
    @Test fun hs5KeepsFortyEightKilohertzCaptureAtEveryNegotiatedOpusClock() {
        for ((bits, clock) in clocks) {
            val negotiated = config(AudioStreamCodec.opusCaptureRate(bits))
            val profile = MicrophoneCaptureProfile.select(negotiated, hs5 = true, requestedGainPercent = 170)
            assertEquals(clock, negotiated.sampleRate)
            assertEquals(48_000, profile.captureRateHz)
            assertEquals(48_000, profile.config.sampleRate)
            assertEquals(1, profile.config.channels)
            assertEquals(20, profile.config.frameMillis)
            assertEquals(960, profile.config.samplesPerPacket)
            assertEquals(1920, profile.config.frameBytes)
            assertEquals(clock, profile.config.rtpClockRate)
            assertEquals(clock / 50, profile.config.rtpSamplesPerPacket)
            assertEquals(100, profile.gainPercent)
            assertTrue(profile.paced)
        }
    }

    @Test fun hs5UsesItsVerifiedSourcesForCallsAndSiriWithoutChangingNegotiatedDestination() {
        val call = config(16_000)
        val siri = call.copy(audioType = "speechRecognition")
        val callProfile = MicrophoneCaptureProfile.select(call, true, 100)
        val siriProfile = MicrophoneCaptureProfile.select(siri, true, 100)
        assertEquals(MediaRecorder.AudioSource.VOICE_COMMUNICATION, callProfile.audioSource)
        assertEquals(MediaRecorder.AudioSource.VOICE_RECOGNITION, siriProfile.audioSource)
        assertEquals(call.host, callProfile.config.host)
        assertEquals(call.port, callProfile.config.port)
        assertSame(call.key, callProfile.config.key)
        assertEquals(call.payloadType, callProfile.config.payloadType)
        assertEquals(call.audioType, callProfile.config.audioType)
    }

    @Test fun genericOpusAndHs5PcmKeepTheirOriginalCaptureAndTransport() {
        val opus = config(24_000)
        val generic = MicrophoneCaptureProfile.select(opus, false, 140)
        assertSame(opus, generic.config)
        assertEquals(16_000, generic.captureRateHz)
        assertEquals(48_000, generic.config.rtpClockRate)
        assertEquals(960, generic.config.rtpSamplesPerPacket)
        assertEquals(MediaRecorder.AudioSource.MIC, generic.audioSource)
        assertEquals(140, generic.gainPercent)
        assertFalse(generic.paced)

        val pcm = config(44_100).copy(codec = AudioCodecKind.LPCM, rtpClockRate = 44_100, channels = 2, frameMillis = 10)
        val hs5 = MicrophoneCaptureProfile.select(pcm, true, 160)
        assertSame(pcm, hs5.config)
        assertEquals(16_000, hs5.captureRateHz)
        assertEquals(441, hs5.config.rtpSamplesPerPacket)
        assertEquals(1764, hs5.config.frameBytes)
        assertEquals(MediaRecorder.AudioSource.MIC, hs5.audioSource)
        assertEquals(100, hs5.gainPercent)
        assertFalse(hs5.paced)
    }

    @Test fun fortyEightKilohertzEncodedFramesDecodeToTwentyMillisecondsAtSelectedClock() {
        for ((_, clock) in clocks) {
            val profile = MicrophoneCaptureProfile.select(config(clock), true, 100)
            val encoder = SoftwareOpusBackend(profile.config.sampleRate, profile.config.bitrate!!)
            try {
                val pcm = ByteArray(profile.config.frameBytes) { index -> (index % 13).toByte() }
                val packet = encoder.encode(pcm).single()
                val decoder = OpusDecoder(clock, 1)
                val output = ShortArray(clock / 50)
                val decoded = decoder.decode(packet, 0, packet.size, output, 0, output.size, false)
                assertEquals(clock / 50, decoded)
            } finally {
                encoder.close()
            }
        }
    }

    private fun config(rate: Int) = MicrophoneConfig(
        audioType = "telephony", sampleRate = rate, channels = 1, payloadType = 100,
        frameMillis = 20, host = InetAddress.getLoopbackAddress(), port = 32001,
        key = ByteArray(32), codec = AudioCodecKind.OPUS, bitrate = 48_000,
    )

    private val clocks = listOf(0x10000000L to 16_000, 0x20000000L to 24_000, 0x40000000L to 48_000)
}
