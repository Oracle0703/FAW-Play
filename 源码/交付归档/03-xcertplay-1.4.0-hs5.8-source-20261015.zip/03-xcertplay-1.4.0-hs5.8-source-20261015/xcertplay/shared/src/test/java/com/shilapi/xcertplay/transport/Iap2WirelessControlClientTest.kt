package com.shilapi.xcertplay.transport

import com.shilapi.xcertplay.iap2.body.Iap2BodyReader
import com.shilapi.xcertplay.iap2.message.Iap2WirelessMessages
import com.shilapi.xcertplay.iap2.session.Iap2Session
import com.shilapi.xcertplay.iap2.wire.Iap2Frame
import com.shilapi.xcertplay.iap2.wire.Iap2Parameter
import com.shilapi.xcertplay.iap2.wire.Iap2ParameterList
import com.shilapi.xcertplay.mfi.Iap2MfiAuthenticationClient
import com.shilapi.xcertplay.mfi.Iap2MfiAuthenticationException
import com.shilapi.xcertplay.mfi.MfiAuthenticator
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import org.mockito.Mockito.mock
import org.mockito.Mockito.RETURNS_DEFAULTS
import java.io.IOException

class Iap2WirelessControlClientTest {
    @Test
    fun bringUpStagesTrackProtocolWorkWithoutRepeatingOnWifiRetriesOrIdlePolls() {
        // Either a credentials request, availability or transport notification can initiate
        // the Wi-Fi handoff. Repeated messages must not restart the caller's handoff deadline.
        for (firstHandoffMessage in listOf(0x5702, 0x4300, 0x4e0e)) {
            val radio = ScriptedSession(
                *successfulBringUp(),
                null,
                frame(firstHandoffMessage),
                frame(firstHandoffMessage),
                frame(0x5702),
                frame(0x4300),
                frame(0x4e0e),
                null,
            )
            val stages = mutableListOf<Iap2WirelessBringUpStage>()
            var ready = 0
            var stopped = 0
            radio.onSend = { outgoing ->
                when (outgoing.messageId) {
                    0x1d01 -> assertEquals(Iap2WirelessBringUpStage.IDENTIFYING, stages.last())
                    0xaa01, 0xaa03 -> assertEquals(Iap2WirelessBringUpStage.AUTHENTICATING, stages.last())
                    0x6800 -> assertEquals(Iap2WirelessBringUpStage.SUBSCRIBING, stages.last())
                }
            }

            val result = client(radio).run(
                identification(),
                endpoint(),
                onReady = {
                    assertEquals(Iap2WirelessBringUpStage.CONTROL_READY, stages.last())
                    ready++
                },
                onStopped = { stopped++ },
                onStageChanged = stages::add,
            )

            assertEquals(Iap2WirelessBringUpStage.entries.toList(), stages)
            assertEquals(1, ready)
            assertEquals(1, stopped)
            assertEquals(Iap2WirelessControlTerminal.CHANNEL_CLOSED, result.terminal)
            assertEquals(Iap2WirelessControlStage.POST_TRANSPORT_WIFI_CONFIG_SENT, result.stage)
            assertTrue(result.wifiConfigurationsSent > 0)
            assertTrue(result.carPlayStartSessionsSent > 0)
            assertTrue(result.transportNotificationSeen)
            assertTrue(radio.consumedWholeScript)
        }
    }

    @Test
    fun identificationRejectionDoesNotStartAuthenticationOrReportReady() {
        val radio = ScriptedSession(frame(0x1d00), frame(0x1d03))
        val stages = mutableListOf<Iap2WirelessBringUpStage>()
        var ready = false

        val failure = runCatching {
            client(radio).run(
                identification(),
                endpoint(),
                onReady = { ready = true },
                onStageChanged = stages::add,
            )
        }.exceptionOrNull()

        assertTrue(failure is Iap2IdentificationException.Rejected)
        assertEquals(listOf(Iap2WirelessBringUpStage.IDLE, Iap2WirelessBringUpStage.IDENTIFYING), stages)
        assertFalse(ready)
        assertEquals(listOf(0x1d01), radio.sent.map { it.messageId })
    }

    @Test
    fun authenticationRejectionDoesNotStartSubscriptionsOrReportReady() {
        val radio = ScriptedSession(frame(0x1d00), frame(0x1d02), frame(0xaa04))
        val stages = mutableListOf<Iap2WirelessBringUpStage>()
        var ready = false

        val failure = runCatching {
            client(radio).run(
                identification(),
                endpoint(),
                onReady = { ready = true },
                onStageChanged = stages::add,
            )
        }.exceptionOrNull()

        assertTrue(failure is Iap2MfiAuthenticationException)
        assertEquals(
            listOf(
                Iap2WirelessBringUpStage.IDLE,
                Iap2WirelessBringUpStage.IDENTIFYING,
                Iap2WirelessBringUpStage.AUTHENTICATING,
            ),
            stages,
        )
        assertFalse(ready)
        assertEquals(listOf(0x1d01), radio.sent.map { it.messageId })
    }

    @Test
    fun startHidFailureDoesNotReportControlReady() {
        val radio = ScriptedSession(*successfulBringUp())
        radio.onSend = { if (it.messageId == 0x6800) throw IOException("test send failure") }
        val stages = mutableListOf<Iap2WirelessBringUpStage>()
        var ready = false
        var stopped = false

        val failure = runCatching {
            client(radio).run(
                identification(),
                endpoint(),
                onReady = { ready = true },
                onStopped = { stopped = true },
                onStageChanged = stages::add,
            )
        }.exceptionOrNull()

        assertTrue(failure is IOException)
        assertEquals(Iap2WirelessBringUpStage.SUBSCRIBING, stages.last())
        assertFalse(ready)
        assertTrue(stopped)
    }

    @Test
    fun failedWifiConfigurationSendDoesNotReportWaitingForWifi() {
        val radio = ScriptedSession(*successfulBringUp(), frame(0x5702))
        radio.onSend = { if (it.messageId == 0x5703) throw IOException("test send failure") }
        val stages = mutableListOf<Iap2WirelessBringUpStage>()

        val failure = runCatching {
            client(radio).run(identification(), endpoint(), onStageChanged = stages::add)
        }.exceptionOrNull()

        assertTrue(failure is IOException)
        assertEquals(Iap2WirelessBringUpStage.CONTROL_READY, stages.last())
        assertFalse(Iap2WirelessBringUpStage.WAITING_FOR_WIFI in stages)
    }

    @Test
    fun incomingBurstsDoNotIncreaseLocationRateAndStopEndsUpdates() {
        val source = FakeLocationProvider()
        var nowMillis = 0L
        val acceptedAt = mutableListOf<Long>()
        val radio = ScriptedSession(
            *successfulBringUp(),
            frame(0xfffa),
            *Array(12) { frame(0x5101) },
            frame(0x5102),
            *Array(5) { frame(0x5101) },
            frame(0x5103),
            frame(0x5101),
            frame(0xfffc),
            frame(0x5104),
            *Array(5) { frame(0x5101) },
        )
        radio.onReceive = {
            when (it?.messageId) {
                0x5102 -> nowMillis = 400
                0x5103 -> nowMillis = 1_000
                0x5104 -> nowMillis = 2_000
            }
        }
        radio.onTrySendLocation = {
            acceptedAt += nowMillis
            true
        }

        val result = client(radio) { nowMillis * 1_000_000 }.run(
            identification(), endpoint(), locationProvider = source,
        )

        assertEquals(listOf(0L, 1_000L), acceptedAt)
        assertEquals(2, radio.sent.count { it.messageId == 0xfffb })
        assertFalse(source.started)
        assertTrue(radio.consumedWholeScript)
        assertEquals(Iap2WirelessControlTerminal.CHANNEL_CLOSED, result.terminal)
    }

    @Test
    fun locationBackpressureSkipsOldSampleAndResumesWithLatestWithoutClosingControl() {
        val source = FakeLocationProvider()
        var nowMillis = 0L
        val attemptedAt = mutableListOf<Long>()
        val radio = ScriptedSession(
            *successfulBringUp(),
            frame(0xfffa),
            *Array(5) { frame(0x5101) },
            frame(0x5102),
            frame(0x5101),
            frame(0x5103),
            frame(0xfffc),
            frame(0x5104),
        )
        radio.onReceive = {
            when (it?.messageId) {
                0x5102 -> {
                    nowMillis = 400
                    source.nmea = "\$GPRMC,intermediate\r\n"
                }
                0x5103 -> {
                    nowMillis = 1_000
                    source.nmea = "\$GPRMC,latest\r\n"
                }
                0x5104 -> nowMillis = 2_000
            }
        }
        radio.onTrySendLocation = {
            attemptedAt += nowMillis
            attemptedAt.size > 1
        }

        val result = client(radio) { nowMillis * 1_000_000 }.run(
            identification(), endpoint(), locationProvider = source,
        )

        assertEquals(listOf(0L, 1_000L), attemptedAt)
        val accepted = radio.sent.single { it.messageId == 0xfffb }
        assertEquals(source.nmea, Iap2BodyReader.of(accepted).string(0))
        assertFalse(source.started)
        assertTrue(radio.consumedWholeScript)
        assertEquals(Iap2WirelessControlTerminal.CHANNEL_CLOSED, result.terminal)
    }

    @Test
    fun locationTransportFailureStillPropagatesAndStopsProvider() {
        val source = FakeLocationProvider()
        val radio = ScriptedSession(*successfulBringUp(), frame(0xfffa))
        val expected = IOException("test tunnel failure")
        radio.onTrySendLocation = { throw expected }

        val failure = runCatching {
            client(radio).run(identification(), endpoint(), locationProvider = source)
        }.exceptionOrNull()

        assertSame(expected, failure)
        assertFalse(source.started)
    }

    @Test
    fun bluetoothBootstrapFinishingCannotStopTheActiveTunnelLocationProvider() {
        val source = FakeLocationProvider()
        var nowMillis = 0L
        val bootstrap = ScriptedSession(*successfulBringUp(), frame(0xfffa))
        val tunnel = ScriptedSession(*successfulBringUp(), frame(0xfffa), frame(0x5101), frame(0x5102))
        var bootstrapCompleted = false
        tunnel.onReceive = { incoming ->
            if (incoming?.messageId == 0x5101) {
                assertTrue(source.started)
                assertEquals(1, source.starts)

                val result = client(bootstrap).run(
                    identification().copy(locationInformationEnabled = false, vehicleSpeedEnabled = false),
                    endpoint(),
                    // Match the Controller's RFCOMM bootstrap: only the type-130 session owns location.
                    locationProvider = null,
                )

                assertEquals(Iap2WirelessControlTerminal.CHANNEL_CLOSED, result.terminal)
                assertTrue("Bootstrap finally must preserve the tunnel's active source", source.started)
                assertEquals(0, source.stops)
                assertTrue(bootstrap.sent.none { it.messageId == 0xfffb })
                bootstrapCompleted = true
                nowMillis = 1_000
            }
        }

        val result = client(tunnel) { nowMillis * 1_000_000 }.run(
            identification(), endpoint(), locationProvider = source,
        )

        assertTrue(bootstrapCompleted)
        assertEquals(2, tunnel.sent.count { it.messageId == 0xfffb })
        assertEquals(Iap2WirelessControlTerminal.CHANNEL_CLOSED, result.terminal)
        assertFalse(source.started)
        assertEquals(1, source.starts)
        assertEquals(1, source.stops)
    }

    @Test
    fun accessoryWiFiConfigurationMatchesLiviVector() {
        val frame = Iap2WirelessControlClient.accessoryWiFiConfiguration(endpoint())

        assertEquals(
            "404000275703000900014c49564900000e00027365637265743132330000050003030005000424",
            frame.encodedFrame().hex(),
        )
    }

    @Test
    fun carPlayStartSessionMatchesLiviWirelessVector() {
        val frame = Iap2WirelessControlClient.carPlayStartSession(endpoint())

        assertEquals(
            "40400060430100350001000900004c49564900000e000173656372657431323300000500022400100003" +
                "3139322e3136382e322e31000005000403000800020000c000000a00036465762d3100000b000461" +
                "61626263630000080005312e3000",
            frame.encodedFrame().hex(),
        )
    }

    @Test
    fun wirelessIdentificationAdvertisesTransportComponentsWithoutUsbHost() {
        val config = Iap2IdentificationConfig(
            name = "LIVI",
            modelIdentifier = "LIVI",
            manufacturer = "LIVI",
            serialNumber = "0123456",
            firmwareVersion = "1.0.0",
            hardwareVersion = "1.0",
            wireless = Iap2WirelessIdentification(
                bluetoothMac = "AA:BB:CC:DD:EE:FF",
                ssid = "LIVI",
            ),
        )
        val parameters = parameters(
            Iap2IdentificationClient.identificationInformation(config).payload,
        )

        assertNull(parameters.firstOrNull { it.id == 16 })
        assertArrayEquals(byteArrayOf(0), parameters.single { it.id == 8 }.payload)

        val bluetooth = parameters(parameters.single { it.id == 17 }.payload)
        assertEquals("blue\u0000", bluetooth.single { it.id == 1 }.payload.decodeToString())
        assertArrayEquals(
            byteArrayOf(0xaa.toByte(), 0xbb.toByte(), 0xcc.toByte(), 0xdd.toByte(), 0xee.toByte(), 0xff.toByte()),
            bluetooth.single { it.id == 3 }.payload,
        )

        val wireless = parameters(parameters.single { it.id == 24 }.payload)
        assertEquals("LIVI\u0000", wireless.single { it.id == 1 }.payload.decodeToString())

        val sent = u16Values(parameters.single { it.id == 6 }.payload)
        val received = u16Values(parameters.single { it.id == 7 }.payload)
        assertTrue(0x5703 in sent)
        assertTrue(0x4301 in sent)
        assertFalse(0xae03 in sent)
        assertTrue(0x4300 in received)
        assertTrue(0x6801 in received)
        assertTrue(0x4e0d in received)
        assertTrue(0x4e0e in received)
        assertTrue(0x5702 in received)
    }

    @Test
    fun wirelessCarPlayUpdateReadsBooleanAvailability() {
        val frame = Iap2Frame(
            0x4e0d,
            Iap2ParameterList.of(Iap2Parameter(0, byteArrayOf(1))).encode(),
        )

        assertTrue(Iap2WirelessMessages.wirelessCarPlayAvailability(frame))
    }

    @Test
    fun wiredIdentificationKeepsCarPlayStartSessionDeclaration() {
        val config = Iap2IdentificationConfig(
            name = "wired",
            modelIdentifier = "wired",
            manufacturer = "test",
            serialNumber = "1",
            firmwareVersion = "1.0",
            hardwareVersion = "1.0",
            carPlayUsbInterfaceNumber = 4,
        )
        val parameters = parameters(
            Iap2IdentificationClient.identificationInformation(config).payload,
        )

        val sent = u16Values(parameters.single { it.id == 6 }.payload)
        assertTrue(0x4301 in sent)
        assertTrue(0x6800 in sent)
        assertTrue(0x6802 in sent)
        assertTrue(0x6803 in sent)
        assertTrue(0x4300 in u16Values(parameters.single { it.id == 7 }.payload))
        assertTrue(0x6801 in u16Values(parameters.single { it.id == 7 }.payload))
        val hid = parameters(parameters.single { it.id == 18 }.payload)
        assertArrayEquals(byteArrayOf(0, 0), hid.single { it.id == 0 }.payload)
        assertEquals("Media Playback Remote\u0000", hid.single { it.id == 1 }.payload.decodeToString())
        assertArrayEquals(byteArrayOf(1), hid.single { it.id == 2 }.payload)
    }

    @Test
    fun identificationInformationEmitsParametersInAscendingOrder() {
        val wirelessConfig = Iap2IdentificationConfig(
            name = "LIVI",
            modelIdentifier = "LIVI",
            manufacturer = "LIVI",
            serialNumber = "0123456",
            firmwareVersion = "1.0.0",
            hardwareVersion = "1.0",
            wireless = Iap2WirelessIdentification(
                bluetoothMac = "AA:BB:CC:DD:EE:FF",
                ssid = "LIVI",
            ),
        )
        val wiredConfig = Iap2IdentificationConfig(
            name = "wired",
            modelIdentifier = "wired",
            manufacturer = "test",
            serialNumber = "1",
            firmwareVersion = "1.0",
            hardwareVersion = "1.0",
            carPlayUsbInterfaceNumber = 4,
        )

        for (config in listOf(wirelessConfig, wiredConfig)) {
            val ids = parameters(
                Iap2IdentificationClient.identificationInformation(config).payload,
            ).map { it.id }
            assertEquals(ids.sorted(), ids)
        }
    }

    private fun endpoint(): Iap2WirelessCarPlayEndpoint = Iap2WirelessCarPlayEndpoint(
        ssid = "LIVI",
        passphrase = "secret123",
        channel = 36,
        security = Iap2WirelessSecurity.WPA3_TRANSITION,
        ipAddresses = listOf("192.168.2.1"),
        airPlayPort = 49152,
        deviceIdentifier = "dev-1",
        publicKey = "aabbcc",
        sourceVersion = "1.0",
    )

    private fun identification() = Iap2IdentificationConfig(
        name = "test receiver",
        modelIdentifier = "test receiver",
        manufacturer = "test",
        serialNumber = "test-1",
        firmwareVersion = "1.0",
        hardwareVersion = "1.0",
        wireless = Iap2WirelessIdentification("AA:BB:CC:DD:EE:FF", "LIVI"),
    )

    private fun client(
        radio: ScriptedSession,
        locationNanoTime: () -> Long = System::nanoTime,
    ) = Iap2WirelessControlClient(
        radio.session,
        Iap2MfiAuthenticationClient(object : MfiAuthenticator {
            override fun protocolMajor() = 3
            override fun readCertificate(maximumOutputLength: Int) = byteArrayOf(1, 2, 3)
            override fun signChallenge(challenge: ByteArray) = byteArrayOf(4, 5, 6)
        }),
        locationNanoTime,
    )

    private fun successfulBringUp(): Array<Iap2Frame?> = arrayOf(
        frame(0x1d00),
        frame(0x1d02),
        frame(0xaa00),
        Iap2Frame(0xaa02, Iap2ParameterList.of(Iap2Parameter(0, byteArrayOf(1))).encode()),
        frame(0xaa05),
    )

    private fun frame(messageId: Int) = Iap2Frame(messageId, ByteArray(0))

    /** Mock only transport I/O; identification, MFi and wireless protocol work run unchanged. */
    private class ScriptedSession(vararg incoming: Iap2Frame?) {
        val sent = mutableListOf<Iap2Frame>()
        var onSend: (Iap2Frame) -> Unit = {}
        var onReceive: (Iap2Frame?) -> Unit = {}
        var onTrySendLocation: (Iap2Frame) -> Boolean = { true }
        private val script = incoming.toList()
        private var position = 0
        private var closed = false
        val consumedWholeScript get() = position == script.size
        val session = mock(Iap2Session::class.java) { call ->
            when (call.method.name) {
                "awaitReady" -> true
                "isClosed" -> closed
                "recv" -> {
                    val incomingFrame = if (position < script.size) script[position++] else {
                        closed = true
                        null
                    }
                    onReceive(incomingFrame)
                    incomingFrame
                }
                "send" -> {
                    val outgoing = call.getArgument<Iap2Frame>(0)
                    assertFalse("Optional location must use the nonblocking path", outgoing.messageId == 0xfffb)
                    onSend(outgoing)
                    sent += outgoing
                    null
                }
                "trySendLocation" -> {
                    val outgoing = call.getArgument<Iap2Frame>(0)
                    onTrySendLocation(outgoing).also { accepted -> if (accepted) sent += outgoing }
                }
                else -> RETURNS_DEFAULTS.answer(call)
            }
        }
    }

    private class FakeLocationProvider : Iap2LocationProvider {
        var started = false
        var starts = 0
        var stops = 0
        var nmea = "\$GPRMC,initial\r\n"
        override fun start(): Boolean { starts++; started = true; return true }
        override fun stop() { stops++; started = false }
        override fun latestNmea() = nmea
    }

    private fun u16Values(bytes: ByteArray): List<Int> =
        List(bytes.size / 2) { index ->
            ((bytes[index * 2].toInt() and 0xff) shl 8) or (bytes[index * 2 + 1].toInt() and 0xff)
        }

    private fun parameters(bytes: ByteArray) = Iap2ParameterList.parse(bytes).asList()

    private fun ByteArray.hex(): String =
        joinToString(separator = "") { "%02x".format(it.toInt() and 0xff) }
}
