package com.shilapi.xcertplay.vehicle

import android.os.Binder
import android.os.IBinder
import android.os.Parcel
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class Hs5VehicleBinderRpcTest {
    private class Endpoint(val token: String, val handler: (Int, Parcel, Parcel) -> Boolean) : Binder() {
        init { attachInterface(null, token) }
        override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
            if (code == INTERFACE_TRANSACTION) { reply?.writeString(token); return true }
            data.enforceInterface(token)
            return handler(code, data, requireNotNull(reply))
        }
    }

    private fun client(target: IBinder, queried: MutableList<Int> = mutableListOf()) = Endpoint(Hs5VehicleBinderRpc.CLIENT) { code, data, reply ->
        assertEquals(1, code)
        queried.add(data.readInt())
        assertEquals(0, data.dataAvail())
        reply.writeNoException(); reply.writeStrongBinder(target); true
    }

    @Test fun usesTypedPrimitivesAndCachesOnlyVerifiedModules() {
        var calls = 0
        val queried = mutableListOf<Int>()
        val endpoint = Endpoint("ltd.qisi.adapterproxy.ICarATCManager") { code, data, reply ->
            calls++
            reply.writeNoException()
            when (code) {
                11 -> { assertEquals(1, data.readInt()); reply.writeFloat(23.5f) }
                12 -> { assertEquals(1, data.readInt()); assertEquals(22.5f, data.readFloat()); reply.writeInt(0) }
                13 -> reply.writeInt(6)
                85, 86 -> assertEquals("test.listener", data.readStrongBinder()?.interfaceDescriptor)
                else -> fail("Unexpected transaction $code")
            }
            assertEquals(0, data.dataAvail()); true
        }
        val rpc = Hs5VehicleBinderRpc(client(endpoint, queried))
        assertEquals(23.5f, rpc.float(33, 11, 1))
        assertEquals(0, rpc.callIntFloat(33, 12, 1, 22.5f))
        assertEquals(6, rpc.int(33, 13))
        val listener = Binder().apply { attachInterface(null, "test.listener") }
        rpc.register(33, 85, listener); rpc.unregister(33, 86, listener)
        assertEquals(listOf(33), queried)
        assertEquals(5, calls)
        assertNull(rpc.failure)
    }

    @Test fun refusesUnexpectedRootAndModuleDescriptors() {
        assertThrows(IllegalArgumentException::class.java) { Hs5VehicleBinderRpc(Binder()) }
        var accessed = false
        val endpoint = Endpoint("incorrect.interface") { _, _, _ -> accessed = true; true }
        val rpc = Hs5VehicleBinderRpc(client(endpoint))
        assertThrows(SecurityException::class.java) { rpc.int(33, 13) }
        assertFalse(accessed)
        assertTrue(rpc.permissionDenied)
        assertEquals("33:SecurityException", rpc.failure)
    }

    @Test fun permissionFailureAndTruncatedRepliesCannotProduceZeroData() {
        val endpoint = Endpoint("ltd.qisi.adapterproxy.ICarATCManager") { code, _, reply ->
            if (code == 1) reply.writeException(SecurityException("rejected")) else reply.writeNoException()
            true
        }
        val rpc = Hs5VehicleBinderRpc(client(endpoint))
        assertThrows(SecurityException::class.java) { rpc.int(33, 1) }
        assertTrue(rpc.permissionDenied)
        rpc.beginRead()
        assertFalse(rpc.permissionDenied)
        assertNull(rpc.failure)
        assertThrows(IllegalStateException::class.java) { rpc.float(33, 11, 0) }
    }

    @Test fun handlesUnsupportedTransactionsAndBoundsIdentifiersWithoutPrintingThem() {
        val endpoint = Endpoint("ltd.qisi.adapterproxy.ICarEOLManager") { code, _, reply ->
            if (code != 4) false else { reply.writeNoException(); reply.writeString("x".repeat(257)); true }
        }
        val rpc = Hs5VehicleBinderRpc(client(endpoint))
        assertThrows(IllegalStateException::class.java) { rpc.string(31, 4) }
        assertFalse(rpc.failure!!.contains("xxx"))
        assertThrows(android.os.RemoteException::class.java) { rpc.int(31, 49) }
    }
}
