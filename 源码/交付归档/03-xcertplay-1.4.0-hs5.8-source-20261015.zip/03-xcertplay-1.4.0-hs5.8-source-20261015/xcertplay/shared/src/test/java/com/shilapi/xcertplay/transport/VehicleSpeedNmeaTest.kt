package com.shilapi.xcertplay.transport

import com.shilapi.xcertplay.iap2.message.Iap2Messages
import com.shilapi.xcertplay.iap2.wire.Iap2ParameterList
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class VehicleSpeedNmeaTest {
    @Test
    fun encodesLikeARealHeadUnit() {
        // From a production head unit's iAP2 log: parked, two samples 0.16 s apart.
        val reading = VehicleSpeedReading(
            VehicleGear.PARK,
            listOf(VehicleSpeedSample(17_877_092, 0.0), VehicleSpeedSample(17_877_252, 0.0)),
        )

        assertEquals("\$PASCD,17877.092,C,P,0,2,0.00,0.000,0.16,0.000*54\r\n", PascdEncoder.encode(reading))
    }

    @Test
    fun encodesSpeedGearAndChecksum() {
        val reading = VehicleSpeedReading(
            VehicleGear.REVERSE,
            listOf(VehicleSpeedSample(1_000, 1.5), VehicleSpeedSample(1_250, 1.25)),
        )

        val sentence = PascdEncoder.encode(reading)!!.trimEnd()
        assertTrue(sentence.startsWith("\$PASCD,1.000,C,R,0,2,0.00,1.500,0.25,1.250*"))
        val star = sentence.lastIndexOf('*')
        assertEquals(checksum(sentence.substring(1, star)), sentence.substring(star + 1))
        assertNull(PascdEncoder.encode(VehicleSpeedReading(VehicleGear.DRIVE, emptyList())))
    }

    @Test
    fun addsSpeedOnlyWhenTheIphoneAsksForIt() {
        val speed = FakeSpeed()
        val position = FakePosition("\$GPGGA\r\n")
        val provider = VehicleSpeedLocationProvider(position, speed)

        provider.onRequested(setOf(1, 2))
        provider.start()
        assertEquals("\$GPGGA\r\n", provider.latestNmea())
        assertFalse(speed.started)

        provider.onRequested(setOf(1, 2, Iap2LocationMessages.VEHICLE_SPEED_DATA))
        assertTrue(speed.started)
        assertEquals(1, speed.startCount)
        assertEquals(1, position.startCount)
        assertTrue(provider.latestNmea()!!.startsWith("\$GPGGA\r\n\$PASCD,"))
        provider.stop()
        assertFalse(speed.started)
    }

    @Test
    fun activeSubscriptionCanDropAndRestoreSpeedWithoutRestartingPosition() {
        val speed = FakeSpeed()
        val position = FakePosition("\$GPGGA\r\n")
        val provider = VehicleSpeedLocationProvider(position, speed)
        val withSpeed = setOf(1, 2, Iap2LocationMessages.VEHICLE_SPEED_DATA)

        provider.onRequested(withSpeed)
        assertTrue(provider.start())
        provider.onRequested(withSpeed)
        assertEquals(1, speed.startCount)

        provider.onRequested(setOf(1, 2))
        assertFalse(speed.started)
        assertEquals(1, speed.stopCount)
        assertEquals("\$GPGGA\r\n", provider.latestNmea())
        provider.onRequested(setOf(1, 2))
        assertEquals(1, speed.stopCount)

        provider.onRequested(withSpeed)
        assertTrue(speed.started)
        assertEquals(2, speed.startCount)
        assertEquals(1, position.startCount)
        assertEquals(withSpeed, position.requested)
        assertTrue(provider.latestNmea()!!.contains("\$PASCD,"))
    }

    @Test
    fun inactiveSubscriptionsOnlyRecordSelectionUntilProviderStarts() {
        val speed = FakeSpeed()
        val position = FakePosition("\$GPGGA\r\n")
        val provider = VehicleSpeedLocationProvider(position, speed)
        val withSpeed = setOf(1, 2, Iap2LocationMessages.VEHICLE_SPEED_DATA)

        provider.onRequested(withSpeed)
        provider.onRequested(setOf(1, 2))
        provider.onRequested(withSpeed)
        assertEquals(0, speed.startCount)
        assertEquals(0, speed.stopCount)
        assertEquals(0, position.startCount)
        assertEquals(withSpeed, position.requested)

        assertTrue(provider.start())
        assertTrue(speed.started)
        assertEquals(1, speed.startCount)
    }

    @Test
    fun stoppedProviderDoesNotReactivateSpeedUntilStartedAgain() {
        val speed = FakeSpeed()
        val position = FakePosition("\$GPGGA\r\n")
        val provider = VehicleSpeedLocationProvider(position, speed)
        val withSpeed = setOf(Iap2LocationMessages.VEHICLE_SPEED_DATA)
        provider.onRequested(withSpeed)
        assertTrue(provider.start())
        provider.stop()

        provider.onRequested(emptySet())
        provider.onRequested(withSpeed)
        assertFalse(speed.started)
        assertEquals(1, speed.startCount)
        assertEquals(1, speed.stopCount)

        assertTrue(provider.start())
        assertTrue(speed.started)
        assertEquals(2, speed.startCount)
        assertEquals(2, position.startCount)
    }

    @Test
    fun keepsSendingSpeedWithoutAPositionFix() {
        val provider = VehicleSpeedLocationProvider(FakePosition(null), FakeSpeed())

        provider.onRequested(setOf(Iap2LocationMessages.VEHICLE_SPEED_DATA))
        assertTrue(provider.start())
        assertTrue(provider.latestNmea()!!.startsWith("\$PASCD,"))
    }

    @Test
    fun readsTheRequestedSentenceTypes() {
        val request = Iap2Messages.buildRaw(Iap2LocationMessages.START_LOCATION_INFORMATION) {
            void(1)
            void(2)
            void(4)
            u32(0x8004, 100)
        }

        assertEquals(setOf(1, 2, 4, 0x8004), Iap2LocationMessages.requestedComponents(request))
    }

    @Test
    fun identificationOffersSpeedOnlyWhenEnabled() {
        assertFalse(20 in locationComponentIds(vehicleSpeedEnabled = false))
        assertTrue(20 in locationComponentIds(vehicleSpeedEnabled = true))
    }

    private fun locationComponentIds(vehicleSpeedEnabled: Boolean): List<Int> {
        val config = Iap2IdentificationConfig(
            name = "xcertplay",
            modelIdentifier = "xcertplay",
            manufacturer = "xcertplay",
            serialNumber = "xcertplay",
            firmwareVersion = "1.0.0",
            hardwareVersion = "1.0",
            carPlayUsbInterfaceNumber = 3,
            locationInformationEnabled = true,
            vehicleSpeedEnabled = vehicleSpeedEnabled,
        )
        val parameters = Iap2ParameterList.parse(Iap2IdentificationClient.identificationInformation(config).payload)
        return Iap2ParameterList.parse(parameters.first(22)!!.payload).asList().map { it.id }
    }

    private fun checksum(body: String): String {
        var value = 0
        for (character in body) value = value xor character.code
        return "%02X".format(value)
    }

    private class FakePosition(private val nmea: String?) : Iap2LocationProvider {
        var startCount = 0
        var requested: Set<Int>? = null
        override fun onRequested(components: Set<Int>) { requested = components }
        override fun start(): Boolean { startCount++; return nmea != null }
        override fun stop() = Unit
        override fun latestNmea() = nmea
    }

    private class FakeSpeed : VehicleSpeedSource {
        var started = false
        var startCount = 0
        var stopCount = 0
        override fun start() { startCount++; started = true }
        override fun stop() { stopCount++; started = false }
        override fun drain() = VehicleSpeedReading(VehicleGear.DRIVE, listOf(VehicleSpeedSample(5_000, 13.9)))
    }
}
