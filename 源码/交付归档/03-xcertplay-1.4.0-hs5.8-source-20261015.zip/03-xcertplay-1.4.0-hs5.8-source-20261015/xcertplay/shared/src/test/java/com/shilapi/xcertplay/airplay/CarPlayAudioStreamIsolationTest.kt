package com.shilapi.xcertplay.airplay

import java.io.Closeable
import java.net.Socket
import java.security.SecureRandom
import com.shilapi.xcertplay.media.CarPlayNowPlaying
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [29], manifest = Config.NONE)
class CarPlayAudioStreamIsolationTest {
    @Test fun playbackContextAndSiriRequestsOnlyReachTheCurrentSession() {
        val contexts = mutableListOf<Any>()
        val requests = mutableListOf<Any>()
        val engine = CarPlayMediaEngine(object : MediaSink {
            override fun onPlaybackContext(session: Any, playback: CarPlayNowPlaying, phone: Boolean?, speech: Boolean?) {
                contexts.add(session)
                assertTrue(playback.playing)
                assertEquals(false, phone)
                assertEquals(true, speech)
            }
            override fun onSiriRequested(session: Any) { requests.add(session) }
        })
        val first = session()
        val second = session()
        val music = CarPlayNowPlaying(sourceApp = "music", playing = true)
        try {
            engine.onSessionActive(first)
            engine.onPlaybackContext(first, music, false, true)
            engine.onSessionActive(second)
            engine.onSessionClosed(first)
            engine.onPlaybackContext(first, music.copy(playing = false), true, false)
            engine.onSiriRequested(first)
            engine.onPlaybackContext(second, music, false, true)
            engine.onSiriRequested(second)
            engine.onSessionClosed(second)
            engine.onPlaybackContext(second, music, false, true)
            engine.onSiriRequested(second)
            assertEquals(listOf(first, second), contexts)
            assertEquals(listOf(second), requests)
        } finally {
            engine.onSessionClosed(first); engine.onSessionClosed(second)
            first.close(); second.close()
        }
    }

    @Test fun guidanceSetupAndMediaReplacementKeepTheOtherAudioStreamAlive() {
        val session = session()
        val engine = CarPlayMediaEngine(object : MediaSink {})
        try {
            assertNotNull(engine.onAudio(session, 100, setup("media")))
            val streams = streams(engine)
            val mediaKey = CarPlayMediaEngine.StreamKey(session, 100, "media")
            val firstMedia = streams[mediaKey]
            assertNotNull(engine.onAudio(session, 100, setup("default")))
            val guidanceKey = CarPlayMediaEngine.StreamKey(session, 100, "default")
            val guidance = streams[guidanceKey]
            assertSame(firstMedia, streams[mediaKey])
            assertEquals(2, streams.size)
            assertNotNull(engine.onAudio(session, 100, setup("MEDIA")))
            assertNotSame(firstMedia, streams[mediaKey])
            assertSame(guidance, streams[guidanceKey])
            assertEquals(2, streams.size)
        } finally {
            engine.onSessionClosed(session)
            session.close()
        }
    }

    @Test fun typeTeardownClosesEveryVariantButKeepsOtherTypes() {
        val stopped = mutableListOf<AudioStreamId>()
        val engine = CarPlayMediaEngine(object : MediaSink {
            override fun onAudioStopped(id: AudioStreamId) { stopped.add(id) }
        })
        val session = session()
        try {
            assertNotNull(engine.onAudio(session, 100, setup("media")))
            assertNotNull(engine.onAudio(session, 100, setup("default")))
            assertNotNull(engine.onAudio(session, 102, setup("media")))
            stopped.clear()
            engine.onTeardown(session, 100)
            assertEquals(setOf(AudioStreamId(100, "media"), AudioStreamId(100, "default")), stopped.toSet())
            assertEquals(setOf(CarPlayMediaEngine.StreamKey(session, 102, "media")), streams(engine).keys)
        } finally {
            engine.onSessionClosed(session)
            session.close()
        }
    }

    @Test fun replacementMicrophoneStartsAfterSetupAndSurvivesOldSessionClose() {
        val started = mutableListOf<AudioStreamId>()
        val stopped = mutableListOf<AudioStreamId>()
        val engine = CarPlayMediaEngine(object : MediaSink {
            override fun onMicrophoneStarted(id: AudioStreamId, config: MicrophoneConfig) { started.add(id) }
            override fun onMicrophoneStopped(id: AudioStreamId) { stopped.add(id) }
        }, microphoneEnabled = true)
        val first = session(); val second = session()
        val stream = mapOf("audioType" to "telephony", "audioFormat" to 0x10000000L,
            "streamConnectionID" to 42L, "dataPort" to 32001)
        try {
            engine.onSessionActive(first)
            engine.onAudio(first, 100, stream)
            assertTrue(started.isEmpty())
            engine.onSetupResponseSent(first)
            engine.onSetupResponseSent(first)
            assertEquals(1, started.size)
            engine.onAudio(second, 100, stream)
            engine.onSetupResponseSent(second)
            assertEquals(2, started.size)
            assertEquals(1, stopped.size)
            engine.onSessionActive(second)
            engine.onSessionClosed(first)
            assertEquals(1, stopped.size)
            engine.onSessionClosed(second)
            assertEquals(2, stopped.size)
        } finally { engine.onSessionClosed(first); engine.onSessionClosed(second); first.close(); second.close() }
    }

    @Test fun newSetupRevokesPreviousOutputsAndStaleSetupCannotTakeThemBack() {
        val ended = mutableListOf<Any>()
        val engine = CarPlayMediaEngine(object : MediaSink {
            override fun onCarPlaySessionEnded(session: Any) { ended.add(session) }
        })
        val first = session(); val second = session()
        try {
            engine.onAudio(first, 100, setup("media"))
            engine.onAudio(second, 100, setup("media"))
            assertEquals(listOf(first), ended)
            assertEquals(setOf(CarPlayMediaEngine.StreamKey(second, 100, "media")), streams(engine).keys)
            assertNull(engine.onAudio(first, 100, setup("telephony")))
            assertNull(engine.onScreen(first, 111, setup("media")))
            engine.onSessionClosed(first)
            assertEquals(setOf(CarPlayMediaEngine.StreamKey(second, 100, "media")), streams(engine).keys)
        } finally { engine.onSessionClosed(first); engine.onSessionClosed(second); first.close(); second.close() }
    }

    private fun setup(audioType: String): Map<String, Any?> = mapOf(
        "audioType" to audioType,
        "audioFormat" to 0x8000L,
        "streamConnectionID" to 42L,
    )

    @Suppress("UNCHECKED_CAST")
    private fun streams(engine: CarPlayMediaEngine): MutableMap<CarPlayMediaEngine.StreamKey, Closeable> =
        CarPlayMediaEngine::class.java.getDeclaredField("streams").apply { isAccessible = true }
            .get(engine) as MutableMap<CarPlayMediaEngine.StreamKey, Closeable>

    private fun session(): AirPlaySession {
        val session = AirPlaySession(
            socket = object : Socket() {
                private val peer = java.net.InetSocketAddress(java.net.InetAddress.getLoopbackAddress(), 32000)
                override fun getRemoteSocketAddress() = peer
                override fun getInetAddress() = peer.address
            },
            config = AirPlayConfig(
                deviceName = "test", deviceId = "02:00:00:00:00:02", btMac = "02:00:00:00:00:01",
                sourceVersion = "1.0", main = AirPlayDisplayConfig(widthPixels = 800, heightPixels = 480),
            ),
            identity = AirPlayIdentity.generate(), pairings = PairingStore(), mfi = null,
            listener = object : AirPlaySessionListener {}, media = object : AirPlayMediaHandler {},
        )
        val secret = ByteArray(32).also(SecureRandom()::nextBytes)
        session.pairVerify.javaClass.getDeclaredField("sharedSecret").apply { isAccessible = true }
            .set(session.pairVerify, secret)
        return session
    }
}
