package com.shilapi.xcertplay.network

import android.content.Context
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito.mock
import org.mockito.Mockito.verifyNoInteractions
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [29], manifest = Config.NONE)
class WirelessRadioSelectionPolicyTest {
    private class Platform {
        var permissionGranted = true
        var permissionChecks = 0
        var queries = 0
        var channels = listOf<WirelessRadioSelectionPolicy.GoChannel>()
        var failure: RuntimeException? = null
        val diagnostics = mutableListOf<String>()

        fun select(retry: Int = 1, failedFrequency: Int? = null, sdkInt: Int = 34): WirelessRadioSelection =
            WirelessRadioSelectionPolicy.selectForPlatform(
                sdkInt = sdkInt,
                networkRetry = retry,
                failedFrequencyMHz = failedFrequency,
                hasNearbyWifiPermission = { permissionChecks++; permissionGranted },
                queryGoChannels = {
                    queries++
                    failure?.let { throw it }
                    channels
                },
                diagnostic = { diagnostics.add(it) },
            )

        fun goChannels(vararg frequencies: Int) {
            channels = frequencies.map { WirelessRadioSelectionPolicy.GoChannel(it, GO_MODE) }
        }
    }

    @Test fun firstAttemptAndEvenRetriesUseSystemSelection() {
        assertSame(WirelessRadioSelection.System5Ghz, WirelessRadioSelectionPolicy.selectFromCandidates(0, candidates = listOf(5180)))
        assertSame(WirelessRadioSelection.System5Ghz, WirelessRadioSelectionPolicy.selectFromCandidates(2, candidates = listOf(5180)))
    }

    @Test fun retryUsesUsableNonDfsGoChannelAndAvoidsFailedFrequency() {
        assertEquals(WirelessRadioSelection.Frequency(5745, WirelessRadioSelection.Source.SYSTEM_USABLE_CHANNELS),
            WirelessRadioSelectionPolicy.selectFromCandidates(1, 5180, listOf(5500, 5180, 5745, 2412, 5745)))
    }

    @Test fun dfsAndOtherBandCandidatesAreRejected() {
        assertSame(WirelessRadioSelection.System5Ghz,
            WirelessRadioSelectionPolicy.selectFromCandidates(1, candidates = listOf(5260, 5500, 2412)))
    }

    @Test fun laterRetryRotatesCandidateWithoutUsingDfs() {
        assertEquals(WirelessRadioSelection.Frequency(5745, WirelessRadioSelection.Source.SYSTEM_USABLE_CHANNELS),
            WirelessRadioSelectionPolicy.selectFromCandidates(3, candidates = listOf(5220, 5745, 5180)))
    }

    @Test fun candidateOrderIsStableAndDuplicatesDoNotChangeRotation() {
        val candidates = listOf(5220, 5745, 5745, 5180, 5180)
        assertEquals(WirelessRadioSelection.Frequency(5180, WirelessRadioSelection.Source.SYSTEM_USABLE_CHANNELS),
            WirelessRadioSelectionPolicy.selectFromCandidates(1, candidates = candidates))
        assertEquals(WirelessRadioSelection.Frequency(5220, WirelessRadioSelection.Source.SYSTEM_USABLE_CHANNELS),
            WirelessRadioSelectionPolicy.selectFromCandidates(5, candidates = candidates))
    }

    @Test fun failedFrequencyIsExcludedAndEmptyCandidatesFallBack() {
        assertEquals(WirelessRadioSelection.Frequency(5745, WirelessRadioSelection.Source.SYSTEM_USABLE_CHANNELS),
            WirelessRadioSelectionPolicy.selectFromCandidates(1, 5180, listOf(5180, 5745)))
        assertSame(WirelessRadioSelection.System5Ghz,
            WirelessRadioSelectionPolicy.selectFromCandidates(1, candidates = emptyList()))
    }

    @Test fun invalidFrequencyIsRejected() {
        for (frequency in listOf(2412, 5500, 5181, 5975)) {
            assertTrue(runCatching { WirelessRadioSelection.Frequency(frequency) }.exceptionOrNull() is IllegalArgumentException)
        }
    }

    @Test fun publicEntryPointOnApi29UsesSharedSelectorAndLabelsUnverifiedRequest() {
        val context = mock(Context::class.java)
        assertEquals(WirelessRadioSelection.Frequency(5745, WirelessRadioSelection.Source.LEGACY_REQUEST),
            WirelessRadioSelectionPolicy.select(context, 1, failedFrequencyMHz = 5180))
        assertSame(WirelessRadioSelection.System5Ghz, WirelessRadioSelectionPolicy.select(context, 2))
        verifyNoInteractions(context)
    }

    @Test @Config(sdk = [28]) fun publicEntryPointOnApi28KeepsSystemSelectionAndReportsLimit() {
        val context = mock(Context::class.java)
        val diagnostics = mutableListOf<String>()
        assertSame(WirelessRadioSelection.System5Ghz,
            WirelessRadioSelectionPolicy.select(context, 1, diagnostic = { diagnostics.add(it) }))
        assertTrue(diagnostics.any { it.endsWith("no_public_frequency_control") })
        verifyNoInteractions(context)
    }

    @Test fun modernPlatformUsesSameFilteredSortedSelectorAsPureTests() {
        val platform = Platform()
        platform.goChannels(5500, 5220, 5745, 5180, 2412, 5745)
        val chosen = platform.select(failedFrequency = 5180)
        assertEquals(
            WirelessRadioSelectionPolicy.selectFromCandidates(1, 5180, platform.channels.map { it.frequencyMHz }),
            chosen,
        )
        assertEquals(WirelessRadioSelection.Frequency(5745, WirelessRadioSelection.Source.SYSTEM_USABLE_CHANNELS), chosen)
        assertEquals(1, platform.permissionChecks)
        assertEquals(1, platform.queries)
    }

    @Test fun firstAttemptAndSystemReselectionDoNotCheckPermissionOrQueryChannels() {
        val platform = Platform()
        platform.failure = SecurityException()
        assertSame(WirelessRadioSelection.System5Ghz, platform.select(retry = 0))
        assertSame(WirelessRadioSelection.System5Ghz, platform.select(retry = 2))
        assertEquals(0, platform.permissionChecks)
        assertEquals(0, platform.queries)
    }

    @Test fun permissionDeniedFallsBackWithoutAttemptingChannelQuery() {
        val platform = Platform()
        platform.permissionGranted = false
        platform.goChannels(5745)
        assertSame(WirelessRadioSelection.System5Ghz, platform.select())
        assertEquals(0, platform.queries)
        assertTrue(platform.diagnostics.any { it.endsWith("channel_query_permission_unavailable") })
    }

    @Test fun stationOnlyChannelIsRejectedButCombinedGoModeIsAllowed() {
        val platform = Platform()
        platform.channels = listOf(
            WirelessRadioSelectionPolicy.GoChannel(5180, 1),
            WirelessRadioSelectionPolicy.GoChannel(5745, GO_MODE or 1),
        )
        assertEquals(WirelessRadioSelection.Frequency(5745, WirelessRadioSelection.Source.SYSTEM_USABLE_CHANNELS),
            platform.select())
        platform.channels = listOf(WirelessRadioSelectionPolicy.GoChannel(5180, 1))
        assertSame(WirelessRadioSelection.System5Ghz, platform.select())
    }

    @Test fun modernEmptyDfsOrOtherBandChannelsNeverBroadenTo24Ghz() {
        val platform = Platform()
        for (frequencies in listOf(emptyList(), listOf(5260, 5500, 2412, 5975))) {
            platform.goChannels(*frequencies.toIntArray())
            assertSame(WirelessRadioSelection.System5Ghz, platform.select())
        }
        platform.goChannels(5180)
        assertSame(WirelessRadioSelection.System5Ghz, platform.select(failedFrequency = 5180))
    }

    @Test fun documentedChannelQueryFailuresUseSystemSelectionWithSpecificDiagnostic() {
        for ((failure, diagnostic) in listOf(
            SecurityException() to "channel_query_permission_rejected",
            UnsupportedOperationException() to "channel_query_unsupported",
            IllegalArgumentException() to "channel_query_rejected",
        )) {
            val platform = Platform()
            platform.failure = failure
            assertSame(WirelessRadioSelection.System5Ghz, platform.select())
            assertEquals(1, platform.queries)
            assertTrue(platform.diagnostics.any { it.endsWith(diagnostic) })
        }
    }

    @Test fun olderPlatformsNeverInvokeModernPermissionOrQueryCallbacks() {
        val platform = Platform()
        platform.failure = IllegalStateException("modern query must not be called")
        assertSame(WirelessRadioSelection.System5Ghz, platform.select(sdkInt = 28))
        assertEquals(WirelessRadioSelection.Frequency(5745, WirelessRadioSelection.Source.LEGACY_REQUEST),
            platform.select(sdkInt = 33, failedFrequency = 5180))
        assertEquals(0, platform.permissionChecks)
        assertEquals(0, platform.queries)
    }

    @Test fun negativeRetryIsRejectedBeforeAnyPlatformCall() {
        val platform = Platform()
        assertTrue(runCatching { platform.select(retry = -1) }.exceptionOrNull() is IllegalArgumentException)
        assertEquals(0, platform.permissionChecks)
        assertEquals(0, platform.queries)
    }

    private companion object {
        const val GO_MODE = 1 shl 3
    }
}
