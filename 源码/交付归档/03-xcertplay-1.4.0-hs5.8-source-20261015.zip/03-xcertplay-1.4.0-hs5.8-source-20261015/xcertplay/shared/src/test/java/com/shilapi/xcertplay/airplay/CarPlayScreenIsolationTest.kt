package com.shilapi.xcertplay.airplay

import java.io.Closeable
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Collections
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE, sdk = [28])
class CarPlayScreenIsolationTest {
    private val shared = ByteArray(32) { it.toByte() }

    @Test fun alternateEofPreservesMainMusicCallAndMicrophone() {
        val alternateStopped = CountDownLatch(1)
        val microphoneStarted = CountDownLatch(1)
        val callPackets = CountDownLatch(2)
        val stoppedAudio = Collections.synchronizedList(mutableListOf<AudioStreamId>())
        val stoppedMicrophones = Collections.synchronizedList(mutableListOf<AudioStreamId>())
        val engine = CarPlayMediaEngine(object : MediaSink {
            override fun onScreenStreamActive(type: Int, active: Boolean) {
                if (type == 111 && !active) alternateStopped.countDown()
            }
            override fun onAudioRtp(id: AudioStreamId, format: AudioFormat, rtp: ByteArray, sample: Int) {
                if (id.audioType == "telephony") callPackets.countDown()
            }
            override fun onMicrophoneStarted(id: AudioStreamId, config: MicrophoneConfig) { microphoneStarted.countDown() }
            override fun onMicrophoneStopped(id: AudioStreamId) { stoppedMicrophones.add(id) }
            override fun onAudioStopped(id: AudioStreamId) { stoppedAudio.add(id) }
        }, microphoneEnabled = true)
        val session = session(engine)
        try {
            engine.onAudio(session, 102, stream("media"))!!
            val call = engine.onAudio(session, 100, stream("telephony"))!!
            engine.onSetupResponseSent(session)
            stoppedAudio.clear() // SETUP releases an earlier stream with the same ID.
            stoppedMicrophones.clear()
            sendAudio(call, 0)
            assertTrue(microphoneStarted.await(3, TimeUnit.SECONDS))
            val mainPort = engine.onScreen(session, 110, stream())!!
            val alternatePort = engine.onScreen(session, 111, stream())!!
            Socket(InetAddress.getLoopbackAddress(), alternatePort).use { it.shutdownOutput() }
            assertTrue(alternateStopped.await(3, TimeUnit.SECONDS))
            assertFalse("An instrument EOF must not end CarPlay", session.isClosed())
            assertEquals(2, (engine.onFeedback(session)!!["streams"] as List<*>).size)
            sendAudio(call, 1)
            assertTrue("Call packets must still reach the audio sink", callPackets.await(3, TimeUnit.SECONDS))
            assertTrue(stoppedAudio.isEmpty())
            assertTrue(stoppedMicrophones.isEmpty())
            Socket(InetAddress.getLoopbackAddress(), mainPort).use {
                assertFalse("The main receiver must still accept connections", session.isClosed())
            }
        } finally { session.close() }
    }

    @Test fun alternateDecryptFailureCanBeReplacedWithoutEndingMainSession() {
        val stopped = CountDownLatch(1)
        val frame = CountDownLatch(1)
        val engine = CarPlayMediaEngine(object : MediaSink {
            override fun onScreenStreamActive(type: Int, active: Boolean) {
                if (type == 111 && !active) stopped.countDown()
            }
            override fun onVideoFrame(type: Int, naluBytes: ByteArray) {
                if (type == 111) frame.countDown()
            }
        })
        val session = session(engine)
        try {
            engine.onScreen(session, 110, stream())!!
            val badPort = engine.onScreen(session, 111, stream())!!
            Socket(InetAddress.getLoopbackAddress(), badPort).use {
                writeVideo(it, ByteArray(32)) // Invalid authentication tag, not a valid video frame.
                assertTrue(stopped.await(3, TimeUnit.SECONDS))
            }
            assertFalse(session.isClosed())
            val newPort = engine.onScreen(session, 111, stream())!!
            Socket(InetAddress.getLoopbackAddress(), newPort).use {
                writeVideo(it)
                assertTrue("A new instrument stream must deliver frames", frame.await(3, TimeUnit.SECONDS))
                assertFalse(session.isClosed())
            }
        } finally { session.close() }
    }

    @Test fun delayedEofFromAReplacedScreenCannotStopItsReplacement() {
        for (screenType in listOf(110, 111)) {
            val states = Collections.synchronizedList(mutableListOf<Boolean>())
            val frame = CountDownLatch(1)
            val engine = CarPlayMediaEngine(object : MediaSink {
                override fun onScreenStreamActive(type: Int, active: Boolean) {
                    if (type == screenType) states.add(active)
                }
                override fun onVideoFrame(type: Int, naluBytes: ByteArray) {
                    if (type == screenType) frame.countDown()
                }
            })
            val session = session(engine)
            try {
                engine.onScreen(session, screenType, stream())!!
                val old = screenListener(engine, session, screenType)
                val port = engine.onScreen(session, screenType, stream())!!
                // Model a callback already dispatched by the old receiver before replacement.
                old.onClosed(null)
                assertFalse(session.isClosed())
                assertEquals(listOf(true, true), states)
                Socket(InetAddress.getLoopbackAddress(), port).use {
                    writeVideo(it)
                    assertTrue(frame.await(3, TimeUnit.SECONDS))
                }
            } finally { session.close() }
        }
    }

    @Test fun mainEofClosesSessionWithBusyAlternateSubmission() {
        val frameEntered = CountDownLatch(1)
        val resumeFrame = CountDownLatch(1)
        val ended = CountDownLatch(1)
        val mainStopped = CountDownLatch(1)
        val engine = CarPlayMediaEngine(object : MediaSink {
            override fun prepareVideoFrame(type: Int): ((ByteArray) -> Unit) = {
                if (type == 111) {
                    frameEntered.countDown()
                    check(resumeFrame.await(5, TimeUnit.SECONDS))
                }
            }
            override fun onScreenStreamActive(type: Int, active: Boolean) {
                if (type == 110 && !active) mainStopped.countDown()
            }
        })
        val session = session(engine, object : AirPlaySessionListener {
            override fun onSessionEnded(session: AirPlaySession) { ended.countDown() }
        })
        val main = Socket(InetAddress.getLoopbackAddress(), engine.onScreen(session, 110, stream())!!)
        val alternate = Socket(InetAddress.getLoopbackAddress(), engine.onScreen(session, 111, stream())!!)
        try {
            writeVideo(alternate)
            assertTrue(frameEntered.await(3, TimeUnit.SECONDS))
            main.shutdownOutput()
            assertTrue("Main disconnect cannot wait for a busy media sink", ended.await(3, TimeUnit.SECONDS))
            assertTrue(session.isClosed())
            resumeFrame.countDown()
            assertTrue(ended.await(3, TimeUnit.SECONDS))
            assertTrue("Main decoder must still be cleaned up", mainStopped.await(3, TimeUnit.SECONDS))
        } finally {
            resumeFrame.countDown()
            main.close()
            alternate.close()
            session.close()
        }
    }

    private fun stream(audioType: String = "media"): Map<String, Any?> = mapOf(
        "audioType" to audioType, "audioFormat" to 0x10000000L,
        "streamConnectionID" to 1L, "dataPort" to 32001,
    )

    private fun writeVideo(socket: Socket, body: ByteArray = byteArrayOf(0, 0, 0, 2, 0x65, 1)) {
        val header = ByteArray(128).apply { this[0] = body.size.toByte() }
        socket.getOutputStream().write(header + body)
    }

    private fun sendAudio(result: Map<String, Any?>, counter: Long) {
        val key = AirPlayCrypto.hkdfSha512(shared, "DataStream-Salt1".toByteArray(),
            "DataStream-Output-Encryption-Key".toByteArray(), 32)
        val wire = MicrophonePacketizer.sealPacket(key, 100, MicrophoneCounters(nonce = counter), byteArrayOf(1, 2, 3), 320)
        DatagramSocket().use {
            it.send(DatagramPacket(wire, wire.size, InetAddress.getLoopbackAddress(), result["dataPort"] as Int))
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun screenListener(engine: CarPlayMediaEngine, session: AirPlaySession, type: Int): ScreenStream.Listener {
        val streams = CarPlayMediaEngine::class.java.getDeclaredField("streams").apply { isAccessible = true }
            .get(engine) as Map<CarPlayMediaEngine.StreamKey, Closeable>
        val screen = streams[CarPlayMediaEngine.StreamKey(session, type)] as ScreenStream
        return ScreenStream::class.java.getDeclaredField("listener").apply { isAccessible = true }
            .get(screen) as ScreenStream.Listener
    }

    private fun session(media: AirPlayMediaHandler, listener: AirPlaySessionListener = object : AirPlaySessionListener {}): AirPlaySession {
        val peer = InetSocketAddress(InetAddress.getLoopbackAddress(), 32000)
        return AirPlaySession(
            socket = object : Socket() {
                override fun getRemoteSocketAddress() = peer
                override fun getInetAddress() = peer.address
            },
            config = AirPlayConfig(deviceName = "test", deviceId = "02:00:00:00:00:02",
                btMac = "02:00:00:00:00:01", sourceVersion = "1.0",
                main = AirPlayDisplayConfig(widthPixels = 800, heightPixels = 480)),
            identity = AirPlayIdentity.generate(), pairings = PairingStore(), mfi = null,
            listener = listener, media = media,
        ).also {
            PairVerify::class.java.getDeclaredField("sharedSecret").apply { isAccessible = true }
                .set(it.pairVerify, shared.copyOf())
        }
    }
}
