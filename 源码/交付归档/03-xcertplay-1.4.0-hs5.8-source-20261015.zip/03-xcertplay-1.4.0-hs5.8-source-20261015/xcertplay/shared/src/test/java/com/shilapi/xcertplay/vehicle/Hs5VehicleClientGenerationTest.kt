package com.shilapi.xcertplay.vehicle

import android.content.ComponentName
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.ServiceConnection
import android.os.Binder
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.Parcel
import android.os.SystemClock
import org.junit.After
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import org.robolectric.shadows.ShadowSystemClock
import java.time.Duration
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit

/** Connection changes during an actual synchronous Parcel read must invalidate that read. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
@LooperMode(LooperMode.Mode.PAUSED)
class Hs5VehicleClientGenerationTest {
    private val fixtures = mutableListOf<Fixture>()

    @After fun cleanup() {
        fixtures.forEach { it.close() }
        shadowOf(Looper.getMainLooper()).idle()
    }

    @Test fun disconnectDuringPollingCannotPublishOldReadingsAsConnected() {
        val fixture = fixture()
        val root = Root(22f)
        fixture.connect(root)
        var interruptedAt = -1
        root.onTemperatureRead = {
            root.onTemperatureRead = null
            interruptedAt = fixture.snapshots.size
            fixture.client.onServiceDisconnected(COMPONENT)
        }

        shadowOf(fixture.worker.looper).idleFor(1, TimeUnit.SECONDS)
        fixture.drain()

        assertTrue(interruptedAt >= 0)
        val afterDisconnect = fixture.snapshots.drop(interruptedAt)
        assertTrue(afterDisconnect.isNotEmpty())
        assertFalse(afterDisconnect.any { it.status == Hs5VehicleConnectionStatus.CONNECTED })
        assertEquals(Hs5VehicleConnectionStatus.UNAVAILABLE, fixture.latest().status)
        assertTrue(fixture.latest().values.isEmpty())
    }

    @Test fun aPollQueuedBeforeCleanupCannotTreatAnInvalidatedBinderAsTheNewGeneration() {
        val fixture = fixture()
        val root = Root(22f)
        fixture.connect(root)
        val count = fixture.snapshots.size
        var readsAfterInvalidation = 0
        root.onTemperatureRead = { readsAfterInvalidation++ }
        // This poll reaches the worker ahead of cleanup, but generation is invalidated now.
        val poll = fixture.client.javaClass.getDeclaredField("poll").apply { isAccessible = true }
            .get(fixture.client) as Runnable
        fixture.worker.post(poll)
        fixture.client.onServiceDisconnected(COMPONENT)

        fixture.drain()

        assertEquals(0, readsAfterInvalidation)
        assertFalse(fixture.snapshots.drop(count).any { it.status == Hs5VehicleConnectionStatus.CONNECTED })
        assertEquals(Hs5VehicleConnectionStatus.UNAVAILABLE, fixture.latest().status)
        assertTrue(fixture.latest().values.isEmpty())
    }

    @Test fun reconnectDuringPollingCannotPublishSamplesFromThePreviousBinder() {
        val fixture = fixture()
        val old = Root(22f)
        val replacement = Root(27f)
        fixture.connect(old)
        var interruptedAt = -1
        old.onTemperatureRead = {
            old.onTemperatureRead = null
            interruptedAt = fixture.snapshots.size
            fixture.client.onServiceConnected(COMPONENT, replacement)
        }

        shadowOf(fixture.worker.looper).idleFor(1, TimeUnit.SECONDS)
        fixture.drain()

        assertTrue(interruptedAt >= 0)
        val afterReconnect = fixture.snapshots.drop(interruptedAt)
        assertTrue(afterReconnect.isNotEmpty())
        assertFalse(afterReconnect.any {
            it.values[Hs5VehicleField.HVAC_LEFT_TEMPERATURE]?.value == 22.0
        })
        assertEquals(Hs5VehicleConnectionStatus.CONNECTED, fixture.latest().status)
        assertEquals(27.0, fixture.latest().value(Hs5VehicleField.HVAC_LEFT_TEMPERATURE)!!, 0.0)
    }

    @Test fun lateDeathNotificationFromTheOldBinderCannotDisconnectTheReplacement() {
        val fixture = fixture()
        val old = Root(22f)
        fixture.connect(old)
        val oldRecipient = requireNotNull(old.recipient)
        val replacement = Root(27f)
        fixture.client.onServiceConnected(COMPONENT, replacement)
        fixture.drain()
        assertNull(old.recipient) // cleanup unlinked it, but dispatch may already have started.
        val count = fixture.snapshots.size

        oldRecipient.binderDied()
        fixture.drain()

        assertEquals(count, fixture.snapshots.size)
        assertEquals(0, fixture.context.unbindCount)
        assertEquals(Hs5VehicleConnectionStatus.CONNECTED, fixture.latest().status)
        assertEquals(27.0, fixture.latest().value(Hs5VehicleField.HVAC_LEFT_TEMPERATURE)!!, 0.0)
        assertNotNull(replacement.recipient)
    }

    @Test fun aSlowReadCannotMakeEarlierSamplesFreshAtCompletion() {
        val fixture = fixture()
        val root = Root(22f)
        root.onTemperatureRead = {
            root.onTemperatureRead = null
            ShadowSystemClock.advanceBy(Duration.ofSeconds(6))
        }
        val startedAt = SystemClock.elapsedRealtime()

        fixture.connect(root)

        val value = fixture.latest().values.getValue(Hs5VehicleField.HVAC_LEFT_TEMPERATURE)
        assertEquals(22.0, value.value!!, 0.0)
        assertEquals(startedAt, value.updatedAtMillis)
        assertNull(fixture.latest().value(Hs5VehicleField.HVAC_LEFT_TEMPERATURE))
    }

    @Test fun aCallbackQueuedWhileTheWorkerIsBusyKeepsItsArrivalTime() {
        val fixture = fixture()
        val root = Root(22f)
        fixture.connect(root)
        val poll = fixture.client.javaClass.getDeclaredField("poll").apply { isAccessible = true }
            .get(fixture.client) as Runnable
        fixture.worker.removeCallbacks(poll)
        val arrivedAt = SystemClock.elapsedRealtime()
        val request = Parcel.obtain()
        try {
            request.writeInterfaceToken(Hs5ComfortProtocol.ATC_LISTENER)
            request.writeInt(0)
            request.writeFloat(29f)
            request.setDataPosition(0)
            assertTrue(requireNotNull(root.climateListener).transact(6, request, null, IBinder.FLAG_ONEWAY))
        } finally { request.recycle() }
        ShadowSystemClock.advanceBy(Duration.ofSeconds(6))

        fixture.drain()

        val value = fixture.latest().values.getValue(Hs5VehicleField.HVAC_LEFT_TEMPERATURE)
        assertEquals(29.0, value.value!!, 0.0)
        assertEquals(arrivedAt, value.updatedAtMillis)
        assertNull(fixture.latest().value(Hs5VehicleField.HVAC_LEFT_TEMPERATURE))
    }

    private fun fixture() = Fixture().also(fixtures::add)

    private class Fixture {
        val context = FakeContext()
        val snapshots = CopyOnWriteArrayList<Hs5VehicleSnapshot>()
        val client = Hs5VehicleClient(context) { _, snapshot -> snapshots.add(snapshot) }
        val worker = client.javaClass.getDeclaredField("worker").apply { isAccessible = true }.get(client) as Handler
        private var closed = false
        fun connect(root: IBinder) {
            client.start()
            drain()
            requireNotNull(context.connection).onServiceConnected(COMPONENT, root)
            drain()
        }
        fun latest() = snapshots.last()
        fun drain() {
            repeat(2) {
                shadowOf(Looper.getMainLooper()).idle()
                shadowOf(worker.looper).idle()
            }
            shadowOf(Looper.getMainLooper()).idle()
        }
        fun close() {
            if (closed) return
            closed = true
            client.close()
            shadowOf(Looper.getMainLooper()).idle()
            val thread = client.javaClass.getDeclaredField("thread").apply { isAccessible = true }.get(client) as HandlerThread
            thread.join(3_000)
            assertFalse("Vehicle worker must close", thread.isAlive)
        }
    }

    private class FakeContext : ContextWrapper(RuntimeEnvironment.getApplication()) {
        var connection: ServiceConnection? = null
        var unbindCount = 0
        override fun bindService(service: Intent, conn: ServiceConnection, flags: Int): Boolean {
            connection = conn
            return true
        }
        override fun unbindService(conn: ServiceConnection) {
            unbindCount++
            connection = null
        }
    }

    private class Root(private val temperature: Float) : Binder() {
        var recipient: IBinder.DeathRecipient? = null
        var climateListener: IBinder? = null
        var onTemperatureRead: (() -> Unit)? = null
        private val modules = mapOf(
            15 to Module(15, "ltd.qisi.adapterproxy.ICarVehicleStateManager"),
            31 to Module(31, "ltd.qisi.adapterproxy.ICarEOLManager"),
            33 to Module(33, "ltd.qisi.adapterproxy.ICarATCManager"),
            49 to Module(49, "ltd.qisi.adapterproxy.ICarSCCUManager"),
        )
        init { attachInterface(null, Hs5VehicleBinderRpc.CLIENT) }
        override fun linkToDeath(recipient: IBinder.DeathRecipient, flags: Int) { this.recipient = recipient }
        override fun unlinkToDeath(recipient: IBinder.DeathRecipient, flags: Int): Boolean {
            if (this.recipient !== recipient) return false
            this.recipient = null
            return true
        }
        override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
            if (code != 1) return false
            data.enforceInterface(Hs5VehicleBinderRpc.CLIENT)
            reply!!.writeNoException()
            reply.writeStrongBinder(modules[data.readInt()])
            return true
        }

        private inner class Module(private val id: Int, private val descriptor: String) : Binder() {
            init { attachInterface(null, descriptor) }
            override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
                data.enforceInterface(descriptor)
                reply!!.writeNoException()
                val registration = when (id) { 15 -> 42; 33 -> 85; 49 -> 29; else -> -1 }
                if (code == registration || (registration > 0 && code == registration + 1)) {
                    val listener = data.readStrongBinder()
                    if (id == 33) climateListener = if (code == registration) listener else null
                    return true
                }
                when {
                    id == 31 && code == 4 -> reply.writeString("7901010DD52B")
                    id == 31 && (code == 49 || code == 50) -> reply.writeInt(1)
                    id == 33 && code == 11 -> {
                        data.readInt()
                        onTemperatureRead?.invoke()
                        reply.writeFloat(temperature)
                    }
                    id == 33 && code == 93 -> reply.writeFloat(20f)
                    id == 15 && code == 59 -> reply.writeFloat(-2f)
                    else -> reply.writeInt(-2)
                }
                return true
            }
        }
    }

    private companion object {
        val COMPONENT = ComponentName("ltd.qisi.adapterservice", "ltd.qisi.adapterservice.QISIAdapterService")
    }
}
