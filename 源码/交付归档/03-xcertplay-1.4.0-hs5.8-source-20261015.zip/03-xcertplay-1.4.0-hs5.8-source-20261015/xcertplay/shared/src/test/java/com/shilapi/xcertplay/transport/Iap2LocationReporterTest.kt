package com.shilapi.xcertplay.transport

import com.shilapi.xcertplay.iap2.body.Iap2BodyReader
import com.shilapi.xcertplay.iap2.message.Iap2Messages
import com.shilapi.xcertplay.iap2.wire.Iap2Frame
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException

class Iap2LocationReporterTest {
    private val provider = FakeProvider()
    private val sent = mutableListOf<Iap2Frame>()
    private val progress = mutableListOf<String>()
    private var nowMillis = 0L

    private val start = Iap2Messages.buildRaw(Iap2LocationMessages.START_LOCATION_INFORMATION) {
        u16(0, 0)
        void(1)
        void(2)
        void(4)
        u32(0x8001, 1000)
    }
    private val stop = Iap2Messages.buildRaw(Iap2LocationMessages.STOP_LOCATION_INFORMATION) {}

    private fun reporter(source: FakeProvider? = provider) =
        Iap2LocationReporter(source, { progress += it }, nanoTime = { nowMillis * 1_000_000 })

    private fun accept(frame: Iap2Frame): Boolean {
        sent += frame
        return true
    }

    @Test
    fun aLinkSendsOnlyBetweenItsOwnStartAndStop() {
        val reporter = reporter()

        assertTrue(reporter.handle(start, ::accept))
        assertEquals(setOf(0, 1, 2, 4, 0x8001), provider.requested)
        assertTrue(provider.started)
        nowMillis += 1_000
        reporter.tick(::accept)
        assertEquals(2, sent.size)
        assertTrue(sent.all { it.messageId == Iap2LocationMessages.LOCATION_INFORMATION })

        assertTrue(reporter.handle(stop, ::accept))
        assertFalse(provider.started)
        nowMillis += 1_000
        reporter.tick(::accept)
        assertEquals(2, sent.size)
        assertEquals(60_000L, reporter.pollTimeout(60_000L))
    }

    @Test
    fun aSeparateLinkDoesNotInheritAnotherLinksRequest() {
        val bluetoothProvider = FakeProvider()
        reporter(bluetoothProvider).handle(start) { true }
        bluetoothProvider.stop()

        val wifiProvider = FakeProvider()
        val wifi = reporter(wifiProvider)
        wifi.tick(::accept)
        nowMillis += 1_000
        wifi.tick(::accept)

        assertFalse(wifiProvider.started)
        assertTrue(sent.isEmpty())
        assertEquals(60_000L, wifi.pollTimeout(60_000L))
    }

    @Test
    fun anInactiveOrAbsentProviderSendsNothingAndDoesNotPoll() {
        val inactive = reporter()
        inactive.tick(::accept)
        val absent = reporter(null)
        absent.handle(start, ::accept)
        absent.tick(::accept)

        assertFalse(provider.started)
        assertTrue(sent.isEmpty())
        assertEquals(60_000L, inactive.pollTimeout(60_000L))
        assertEquals(60_000L, absent.pollTimeout(60_000L))
    }

    @Test
    fun aBurstOfIncomingMessagesStillSendsOneFixASecond() {
        val reporter = reporter()
        reporter.handle(start, ::accept)
        repeat(12) { reporter.tick(::accept) }
        assertEquals(1, sent.size)

        nowMillis += 400
        repeat(5) { reporter.tick(::accept) }
        assertEquals(1, sent.size)
        assertEquals(600L, reporter.pollTimeout(60_000L))

        nowMillis += 600
        reporter.tick(::accept)
        assertEquals(2, sent.size)
        assertEquals(1_000L, reporter.pollTimeout(60_000L))
    }

    @Test
    fun repeatedStartsRefreshComponentsWithoutResettingCadenceUntilStopped() {
        val reporter = reporter()
        val revisedStart = Iap2Messages.buildRaw(Iap2LocationMessages.START_LOCATION_INFORMATION) {
            void(2)
            u32(0x8001, 1000)
        }
        val dueStart = Iap2Messages.buildRaw(Iap2LocationMessages.START_LOCATION_INFORMATION) {
            void(1)
            void(4)
        }
        reporter.handle(start, ::accept)

        for (time in listOf(0L, 400L, 999L)) {
            nowMillis = time
            reporter.handle(revisedStart, ::accept)
            assertEquals(setOf(2, 0x8001), provider.requested)
            assertEquals(1, provider.startCount)
            assertEquals(1, sent.size)
        }

        nowMillis = 1_000
        provider.nmea = "\$GPRMC,latest\r\n"
        reporter.handle(dueStart, ::accept)
        assertEquals(setOf(1, 4), provider.requested)
        assertEquals(1, provider.startCount)
        assertEquals(2, sent.size)
        assertEquals(provider.nmea, Iap2BodyReader.of(sent.last()).string(0))
        assertEquals(1, progress.count { it == "iap2 tx=0xfffb location-information" })

        nowMillis = 1_001
        reporter.handle(stop, ::accept)
        provider.nmea = "\$GPRMC,restarted\r\n"
        reporter.handle(start, ::accept)
        assertEquals(2, provider.startCount)
        assertEquals(3, sent.size)
        assertEquals(provider.nmea, Iap2BodyReader.of(sent.last()).string(0))
        assertEquals(1_000L, reporter.pollTimeout(60_000L))
    }

    @Test
    fun noFixMeansNothingIsSentAndDoesNotCreateABusyPoll() {
        provider.nmea = null
        val reporter = reporter()
        reporter.handle(start, ::accept)
        repeat(12) { reporter.tick(::accept) }

        assertTrue(provider.started)
        assertTrue(sent.isEmpty())
        assertEquals(1_000L, reporter.pollTimeout(60_000L))
    }

    @Test
    fun backpressureDropsTheOldSampleAndTriesTheLatestAtTheNextInterval() {
        val reporter = reporter()
        var attempts = 0
        reporter.handle(start) {
            attempts++
            false
        }
        assertTrue(progress.none { it == "iap2 tx=0xfffb location-information" })

        nowMillis = 400
        provider.nmea = "\$GPRMC,intermediate\r\n"
        repeat(12) {
            reporter.tick {
                attempts++
                accept(it)
            }
        }
        assertEquals(1, attempts)

        nowMillis = 1_000
        provider.nmea = "\$GPRMC,latest\r\n"
        reporter.tick {
            attempts++
            accept(it)
        }

        assertEquals(2, attempts)
        assertEquals(provider.nmea, Iap2BodyReader.of(sent.single()).string(0))
        assertEquals(1, progress.count { it == "iap2 tx=0xfffb location-information" })
        assertEquals(1_000L, reporter.pollTimeout(60_000L))
    }

    @Test
    fun transportErrorsAreNotMistakenForBackpressure() {
        val expected = IOException("test link failure")
        val failure = runCatching {
            reporter().handle(start) { throw expected }
        }.exceptionOrNull()

        assertSame(expected, failure)
    }

    private class FakeProvider : Iap2LocationProvider {
        var started = false
        var startCount = 0
        var requested: Set<Int>? = null
        var nmea: String? = "\$GPRMC,initial\r\n"
        override fun onRequested(components: Set<Int>) { requested = components }
        override fun start(): Boolean { startCount++; started = true; return true }
        override fun stop() { started = false }
        override fun latestNmea() = nmea
    }
}
