package com.shilapi.xcertplay.orchestration

import com.shilapi.xcertplay.airplay.*
import com.shilapi.xcertplay.network.CarPlayVpnService
import com.shilapi.xcertplay.network.WirelessHotspotInfo
import com.shilapi.xcertplay.network.WirelessHotspotManager
import com.shilapi.xcertplay.transport.Iap2IdentificationConfig
import java.net.ServerSocket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class CarPlayWirelessTeardownTest {
    @Test
    fun cleanupFinishingAfterControllerCloseCannotDetachReplacementServiceOwner() {
        val fixture = Fixture()
        val serviceLifecycle = Robolectric.buildService(CarPlayVpnService::class.java).create()
        val service = serviceLifecycle.get()
        val workerFailure = AtomicReference<Throwable?>()
        fixture.field("vpnService").set(fixture.controller, service)
        fixture.attach(service, fixture.controller)
        val previousCleanup = Thread {
            try {
                fixture.method("closeWirelessStack", CarPlayVpnService::class.java)
                    .invoke(fixture.controller, service)
            } catch (failure: Throwable) { workerFailure.set(failure) }
        }.apply { start() }
        try {
            assertTrue(fixture.hotspot.closing.await(3, TimeUnit.SECONDS))
            fixture.controller.close()
            assertTrue(fixture.controller.awaitClosed(3_000))
            assertTrue("The earlier cleanup is still waiting on its old hotspot", previousCleanup.isAlive)
            assertFalse(service.isAttached())

            val replacementOwner = Any()
            fixture.attach(service, replacementOwner)
            fixture.hotspot.release.countDown()
            previousCleanup.join(3_000)

            assertFalse(previousCleanup.isAlive)
            assertNull(workerFailure.get())
            assertTrue("Late cleanup must preserve the replacement listener", service.isAttached())
            service.detach(replacementOwner)
            assertFalse(service.isAttached())
        } finally {
            fixture.hotspot.release.countDown()
            previousCleanup.join(3_000)
            fixture.close()
            service.detach()
            serviceLifecycle.destroy()
        }
    }

    @Test
    fun restartWaitingOnCleanupCannotStartAfterControllerCloses() {
        val fixture = Fixture()
        fixture.setWirelessPhase()
        fixture.generation.set(7)
        try {
            fixture.method("restartWireless").invoke(fixture.controller)
            assertTrue(fixture.hotspot.closing.await(3, TimeUnit.SECONDS))
            val restarting = fixture.hotspot.closingThread.get()
            assertNotNull(restarting)

            fixture.controller.close()
            assertTrue(fixture.controller.awaitClosed(3_000))
            val closedGeneration = fixture.generation.get()
            fixture.hotspot.release.countDown()
            restarting!!.join(3_000)

            assertFalse(restarting.isAlive)
            assertEquals(closedGeneration, fixture.generation.get())
            assertEquals(0, fixture.hotspot.starts.get())
        } finally { fixture.close() }
    }

    @Test
    fun directOrQueuedStartAfterCloseCannotCreateAnotherGeneration() {
        val fixture = Fixture()
        fixture.hotspot.release.countDown()
        fixture.close()
        val closedGeneration = fixture.generation.get()

        fixture.method("startWireless").invoke(fixture.controller)
        fixture.method("restartWireless").invoke(fixture.controller)

        assertEquals(closedGeneration, fixture.generation.get())
        assertEquals(0, fixture.hotspot.starts.get())
    }

    private class BlockingHotspot : WirelessHotspotManager {
        val closing = CountDownLatch(1)
        val release = CountDownLatch(1)
        val closingThread = AtomicReference<Thread?>()
        val starts = AtomicInteger(0)
        override fun start(timeoutMillis: Long): WirelessHotspotInfo {
            starts.incrementAndGet()
            error("This test must not start a radio")
        }
        override fun close() {
            closingThread.set(Thread.currentThread())
            closing.countDown()
            check(release.await(10, TimeUnit.SECONDS))
        }
    }

    private class Fixture {
        val hotspot = BlockingHotspot()
        private val config = AirPlayConfig(
            "test", "test", "", "1", AirPlayDisplayConfig(800, 480),
            port = ServerSocket(0).use { it.localPort },
        )
        private val identity = AirPlayIdentity.generate()
        val controller = CarPlayController(
            RuntimeEnvironment.getApplication(),
            CarPlayRuntimeConfig(mfiTarget = MfiTarget.REMOTE, remoteMfiServer = "https://mfi.example.test",
                transport = CarPlayTransport.WIRELESS,
                identification = Iap2IdentificationConfig("test", "test", "test", "test", "1", "1", 3)),
            config, identity, PairingStore(), object : AirPlaySessionListener {}, object : AirPlayMediaHandler {}, {},
        )
        val generation = field("wirelessGeneration").get(controller) as AtomicInteger
        init { field("hotspot").set(controller, hotspot) }
        fun attach(service: CarPlayVpnService, owner: Any) {
            assertEquals(CarPlayVpnService.AttachResult.Started,
                service.attachWireless(config, identity, PairingStore(), null,
                    object : AirPlaySessionListener {}, object : AirPlayMediaHandler {}, owner))
        }
        fun setWirelessPhase() {
            val phase = field("phase")
            phase.set(controller, phase.type.enumConstants.single { it.toString() == "WIRELESS" })
        }
        fun close() {
            hotspot.release.countDown()
            controller.close()
            assertTrue(controller.awaitClosed(3_000))
        }
        fun field(name: String) = CarPlayController::class.java.getDeclaredField(name).apply { isAccessible = true }
        fun method(name: String, vararg types: Class<*>) = CarPlayController::class.java
            .getDeclaredMethod(name, *types).apply { isAccessible = true }
    }
}
