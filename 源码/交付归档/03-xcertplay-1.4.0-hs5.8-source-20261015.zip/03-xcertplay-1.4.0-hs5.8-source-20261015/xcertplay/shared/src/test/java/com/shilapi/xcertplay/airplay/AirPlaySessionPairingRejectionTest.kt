package com.shilapi.xcertplay.airplay

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.Socket
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class AirPlaySessionPairingRejectionTest {
    private data class Rejection(
        val operation: String,
        val errorCode: Int,
        val written: ByteArray,
        val flushed: ByteArray?,
        val socketClosed: Boolean,
    )

    private class RecordingSocket(requests: ByteArray, failFlush: Boolean = false) : Socket() {
        private val input = ByteArrayInputStream(requests)
        val flushes = CopyOnWriteArrayList<ByteArray>()
        val output = object : ByteArrayOutputStream() {
            override fun flush() {
                if (failFlush) throw IOException("Test flush failure")
                flushes.add(toByteArray())
            }
        }
        override fun getInputStream() = input
        override fun getOutputStream() = output
    }

    private class Fixture(requests: ByteArray, failFlush: Boolean = false) {
        val socket = RecordingSocket(requests, failFlush)
        val rejections = CopyOnWriteArrayList<Rejection>()
        val stages = CopyOnWriteArrayList<Boolean>()
        val active = AtomicInteger()
        val ended = CountDownLatch(1)
        val session = AirPlaySession(
            socket,
            AirPlayConfig("test", "test", "", "1", AirPlayDisplayConfig(800, 480)),
            AirPlayIdentity.generate(),
            PairingStore(),
            null,
            object : AirPlaySessionListener {
                override fun onConnectionStage(session: AirPlaySession, pairing: Boolean) {
                    stages.add(pairing)
                }
                override fun onPairingRejected(session: AirPlaySession, operation: String, errorCode: Int) {
                    rejections.add(Rejection(operation, errorCode, socket.output.toByteArray(),
                        socket.flushes.lastOrNull(), socket.isClosed))
                }
                override fun onSessionActive(session: AirPlaySession) { active.incrementAndGet() }
                override fun onSessionEnded(session: AirPlaySession) { ended.countDown() }
            },
            object : AirPlayMediaHandler {},
        )

        fun run() {
            session.start()
            try {
                assertTrue("Control loop must exit", ended.await(3, TimeUnit.SECONDS))
            } finally {
                session.close()
            }
        }
    }

    @Test
    fun pairSetupHttp200TlvErrorIsFlushedBeforeRejectionAndCannotActivatePipelinedRecord() {
        val body = Tlv8Codec.encode(listOf(Tlv8Item(0x06, byteArrayOf(3))))
        val fixture = Fixture(request("POST", "/pair-setup", "HTTP/1.1", body) +
            request("RECORD", "/", "HTTP/1.1", cseq = 2))
        fixture.run()
        assertFlushedRejection(fixture, "setup", 2, "HTTP/1.1", 200)
        val response = RtspMessage.parseMessages(fixture.rejections.single().written).messages.single()
        assertArrayEquals(byteArrayOf(2), Tlv8Codec.decode(response.body)[0x07])
    }

    @Test
    fun pairVerifyRtsp200TlvErrorIsFlushedBeforeRejectionAndCannotActivatePipelinedRecord() {
        val body = Tlv8Codec.encode(listOf(Tlv8Item(0x06, byteArrayOf(3))))
        val fixture = Fixture(request("POST", "/pair-verify", "RTSP/1.0", body) +
            request("RECORD", "/", "RTSP/1.0", cseq = 2))
        fixture.run()
        assertFlushedRejection(fixture, "verify", 2, "RTSP/1.0", 200)
    }

    @Test
    fun pairingHttp400WithoutTlvErrorStillReportsRejectionAfterFlush() {
        // SETUP is routed before the path handler and its empty plist returns a real HTTP 400.
        val fixture = Fixture(request("SETUP", "/pair-setup", "HTTP/1.1") +
            request("RECORD", "/", "HTTP/1.1", cseq = 2))
        fixture.run()
        assertFlushedRejection(fixture, "setup", 0, "HTTP/1.1", 400)
    }

    @Test
    fun missingMfiAuthenticatorReportsAuthSetup400AfterFlushAndStopsPipelinedRecord() {
        val fixture = Fixture(request("POST", "/auth-setup", "HTTP/1.1", byteArrayOf(1) + ByteArray(32)) +
            request("RECORD", "/", "HTTP/1.1", cseq = 2))
        fixture.run()
        assertFlushedRejection(fixture, "auth-setup", 400, "HTTP/1.1", 400)
        assertEquals("MFi authentication belongs to the pairing stage", listOf(true), fixture.stages.toList())
    }

    @Test
    fun authSetupFlushFailureDoesNotReportRejectionBeforeResponseIsDelivered() {
        val fixture = Fixture(request("POST", "/auth-setup", "RTSP/1.0"), failFlush = true)
        fixture.run()
        assertTrue(fixture.rejections.isEmpty())
        assertTrue(fixture.socket.flushes.isEmpty())
        assertTrue(fixture.session.isClosed())
    }

    @Test
    fun successfulOpaqueSapBodyThatLooksLikeTlvErrorIsNotARejection() {
        val opaqueBody = byteArrayOf(0x07, 0x01, 0x02)
        assertArrayEquals(byteArrayOf(2), Tlv8Codec.decode(opaqueBody)[0x07])
        assertNull(authenticationRejectionCode("auth-setup", RtspMessage.Response(body = opaqueBody)))
    }

    @Test
    fun rejectedOpaqueSapResponseReportsHttpStatusWithoutInterpretingItsBody() {
        val opaqueBody = byteArrayOf(0x07, 0x01, 0x02)
        assertEquals(500, authenticationRejectionCode("auth-setup",
            RtspMessage.Response(status = 500, body = opaqueBody)))
    }

    @Test
    fun failedResponseFlushDoesNotReportDeliveredPairingRejection() {
        val body = Tlv8Codec.encode(listOf(Tlv8Item(0x06, byteArrayOf(3))))
        val fixture = Fixture(request("POST", "/pair-setup", "HTTP/1.1", body), failFlush = true)
        fixture.run()
        assertTrue(fixture.rejections.isEmpty())
        assertTrue(fixture.socket.flushes.isEmpty())
        assertTrue(fixture.session.isClosed())
    }

    @Test
    fun successfulPairSetupStepDoesNotReportRejection() {
        val body = Tlv8Codec.encode(listOf(Tlv8Item(0x06, byteArrayOf(1))))
        val fixture = Fixture(request("POST", "/pair-setup", "HTTP/1.1", body))
        fixture.run()
        assertTrue(fixture.rejections.isEmpty())
        val response = RtspMessage.parseMessages(fixture.socket.output.toByteArray()).messages.single()
        assertEquals("200", response.path)
        val tlv = Tlv8Codec.decode(response.body)
        assertArrayEquals(byteArrayOf(2), tlv[0x06])
        assertNull(tlv[0x07])
    }

    private fun assertFlushedRejection(fixture: Fixture, operation: String, code: Int,
        protocol: String, status: Int) {
        val rejection = fixture.rejections.single()
        assertEquals(operation, rejection.operation)
        assertEquals(code, rejection.errorCode)
        assertArrayEquals("Protocol response must be fully flushed before callback", rejection.written,
            rejection.flushed)
        assertFalse("Driver gets the rejection before transport close", rejection.socketClosed)
        val parsed = RtspMessage.parseMessages(rejection.written)
        assertTrue("Response cannot be truncated", parsed.rest.isEmpty())
        assertEquals("Pipelined requests after rejection must not run", 1, parsed.messages.size)
        assertEquals(protocol, parsed.messages.single().method)
        assertEquals(status.toString(), parsed.messages.single().path)
        assertEquals("1", parsed.messages.single().headers["cseq"])
        assertEquals(0, fixture.active.get())
        assertTrue(fixture.session.isClosed())
    }

    private fun request(method: String, path: String, protocol: String, body: ByteArray = ByteArray(0),
        cseq: Int = 1): ByteArray =
        "$method $path $protocol\r\nCSeq: $cseq\r\nContent-Length: ${body.size}\r\n\r\n"
            .toByteArray(Charsets.US_ASCII) + body
}
