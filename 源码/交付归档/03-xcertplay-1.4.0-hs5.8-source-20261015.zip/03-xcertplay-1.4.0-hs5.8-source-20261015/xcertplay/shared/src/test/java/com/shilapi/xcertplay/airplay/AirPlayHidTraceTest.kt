package com.shilapi.xcertplay.airplay

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.OutputStream
import java.net.Socket
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito.*
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowLog

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class AirPlayHidTraceTest {
    @Test fun repeatedHidCommandsRemainWritableWithoutRawTraceAndFailuresRemainVisible() {
        val logs = mutableListOf<String>()
        var disconnected = false
        val session = AirPlaySession(Socket(),
            AirPlayConfig("test", "test", "", "1", AirPlayDisplayConfig(800, 480)),
            AirPlayIdentity.generate(), PairingStore(), null,
            object : AirPlaySessionListener {
                override fun onDebugLog(message: String) { logs.add(message) }
                override fun onSessionDisconnected(session: AirPlaySession) { disconnected = true }
            }, object : AirPlayMediaHandler {})
        val eventSocket = mock(Socket::class.java)
        val output = ByteArrayOutputStream()
        `when`(eventSocket.getOutputStream()).thenReturn(output)
        field(session, "eventSocket").set(session, eventSocket)
        field(session, "eventCipher").set(session, ControlCipher(ByteArray(32), ByteArray(32)))
        try {
            repeat(100) { assertTrue(session.sendTouch(listOf(AirPlayContact(0, .5, .5, true)))) }
            assertTrue(output.size() > 0)
            assertTrue("Routine HID must not reach diagnostic listeners", logs.isEmpty())
            assertTrue(session.sendCommand(mapOf("type" to "requestUI")))
            assertTrue(logs.any { it.contains("airplay event tx") && it.contains("bodyHex=") })
            val traceCount = logs.size
            `when`(eventSocket.getOutputStream()).thenReturn(object : OutputStream() {
                override fun write(value: Int) { throw IOException("injected write failure") }
            })
            assertFalse(session.sendTouch(emptyList()))
            assertTrue(session.isClosed())
            assertTrue(disconnected)
            assertFalse(logs.drop(traceCount).any { it.contains("airplay event tx") })
            assertTrue(ShadowLog.getLogs().any { it.msg.contains("event command failed type=hidSendReport") })
        } finally { session.close() }
    }

    private fun field(session: AirPlaySession, name: String) =
        session.javaClass.getDeclaredField(name).apply { isAccessible = true }
}
