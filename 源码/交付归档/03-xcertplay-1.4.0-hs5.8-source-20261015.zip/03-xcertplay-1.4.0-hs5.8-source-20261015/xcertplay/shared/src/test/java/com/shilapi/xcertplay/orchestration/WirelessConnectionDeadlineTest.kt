package com.shilapi.xcertplay.orchestration

import org.junit.Assert.*
import org.junit.Test

class WirelessConnectionDeadlineTest {
    @Test
    fun repeatedAndEarlierStageMessagesDoNotRenewStageDeadline() {
        val deadline = WirelessConnectionDeadline()
        deadline.start(4, 0)
        assertTrue(deadline.advance(4, WirelessConnectionStage.HOTSPOT, 0))
        assertTrue(deadline.advance(4, WirelessConnectionStage.BLUETOOTH, 5_000))

        assertFalse(deadline.advance(4, WirelessConnectionStage.BLUETOOTH, 10_000))
        assertFalse(deadline.advance(4, WirelessConnectionStage.HOTSPOT, 15_000))
        assertEquals(WirelessConnectionStage.BLUETOOTH, deadline.current(4))
        assertNull(deadline.expire(4, 24_999))
        assertEquals(
            WirelessConnectionDeadline.Expired(WirelessConnectionStage.BLUETOOTH, 20_000, false),
            deadline.expire(4, 25_000),
        )
    }

    @Test
    fun lateAdvanceCannotEscapeStageTimeoutBeforeTimerChecksIt() {
        val deadline = WirelessConnectionDeadline()
        deadline.start(4, 1_000)
        assertTrue(deadline.advance(4, WirelessConnectionStage.HOTSPOT, 1_000))
        // The protocol event wins the scheduling race against expire(), at the exact deadline.
        assertFalse(deadline.advance(4, WirelessConnectionStage.BLUETOOTH, 21_000))
        assertFalse(deadline.advance(4, WirelessConnectionStage.CONNECTED, 21_001))
        assertEquals(WirelessConnectionStage.HOTSPOT, deadline.current(4))
        assertEquals(
            WirelessConnectionDeadline.Expired(WirelessConnectionStage.HOTSPOT, 20_001, false),
            deadline.expire(4, 21_001),
        )
    }

    @Test
    fun totalBudgetPersistsAcrossStagesAndRejectsLateConnectedEvent() {
        val deadline = WirelessConnectionDeadline()
        deadline.start(8, 0)
        assertTrue(deadline.advance(8, WirelessConnectionStage.HOTSPOT, 0))
        assertTrue(deadline.advance(8, WirelessConnectionStage.BLUETOOTH, 15_000))
        assertTrue(deadline.advance(8, WirelessConnectionStage.IDENTIFICATION, 30_000))
        assertTrue(deadline.advance(8, WirelessConnectionStage.AUTHENTICATION, 45_000))
        assertTrue(deadline.advance(8, WirelessConnectionStage.PHONE_WIFI, 60_000))
        assertTrue(deadline.advance(8, WirelessConnectionStage.PAIRING, 80_000))
        assertNull(deadline.expire(8, 89_999))

        // Pairing has used only 10 of its 30 seconds; the attempt's original 90 seconds still wins.
        assertFalse(deadline.advance(8, WirelessConnectionStage.CONNECTED, 90_000))
        assertEquals(
            WirelessConnectionDeadline.Expired(WirelessConnectionStage.PAIRING, 10_000, true),
            deadline.expire(8, 90_000),
        )
    }

    @Test
    fun connectedSessionStopsBringUpDeadlineAndIgnoresFurtherMessages() {
        val deadline = WirelessConnectionDeadline()
        deadline.start(5, 0)
        assertTrue(deadline.advance(5, WirelessConnectionStage.HOTSPOT, 0))
        assertTrue(deadline.advance(5, WirelessConnectionStage.BLUETOOTH, 1_000))
        assertTrue(deadline.advance(5, WirelessConnectionStage.IDENTIFICATION, 2_000))
        assertTrue(deadline.advance(5, WirelessConnectionStage.AUTHENTICATION, 3_000))
        assertTrue(deadline.advance(5, WirelessConnectionStage.PHONE_WIFI, 4_000))
        assertTrue(deadline.advance(5, WirelessConnectionStage.PAIRING, 5_000))
        assertTrue(deadline.advance(5, WirelessConnectionStage.SESSION, 6_000))
        assertTrue(deadline.advance(5, WirelessConnectionStage.CONNECTED, 7_000))

        assertNull(deadline.current(5))
        assertNull(deadline.expire(5, 1_000_000))
        assertFalse(deadline.advance(5, WirelessConnectionStage.PAIRING, 1_000_001))
        assertFalse(deadline.advance(5, WirelessConnectionStage.CONNECTED, 1_000_002))
    }

    @Test
    fun oldGenerationCannotAdvanceOrConsumeNewAttempt() {
        val deadline = WirelessConnectionDeadline()
        deadline.start(1, 0)
        assertTrue(deadline.advance(1, WirelessConnectionStage.HOTSPOT, 0))
        assertTrue(deadline.advance(1, WirelessConnectionStage.BLUETOOTH, 100))
        deadline.start(2, 1_000)
        assertTrue(deadline.advance(2, WirelessConnectionStage.HOTSPOT, 1_000))

        assertFalse(deadline.advance(1, WirelessConnectionStage.CONNECTED, 2_000))
        assertNull(deadline.current(1))
        assertNull(deadline.expire(1, 100_000))
        assertEquals(WirelessConnectionStage.HOTSPOT, deadline.current(2))
        assertNull(deadline.expire(2, 2_000))
        assertTrue(deadline.advance(2, WirelessConnectionStage.BLUETOOTH, 2_000))
        assertEquals(
            WirelessConnectionDeadline.Expired(WirelessConnectionStage.BLUETOOTH, 20_000, false),
            deadline.expire(2, 22_000),
        )
    }

    @Test
    fun timeoutIsDeliveredOnceAndLateMessagesCannotReviveAttempt() {
        val deadline = WirelessConnectionDeadline()
        deadline.start(3, 1_000)
        assertTrue(deadline.advance(3, WirelessConnectionStage.HOTSPOT, 1_000))
        assertNull(deadline.expire(3, 20_999))
        assertEquals(
            WirelessConnectionDeadline.Expired(WirelessConnectionStage.HOTSPOT, 20_000, false),
            deadline.expire(3, 21_000),
        )
        assertNull(deadline.expire(3, 21_001))
        assertNull(deadline.expire(3, 100_000))
        assertNull(deadline.current(3))
        assertFalse(deadline.advance(3, WirelessConnectionStage.BLUETOOTH, 21_002))
        assertFalse(deadline.advance(3, WirelessConnectionStage.CONNECTED, 21_003))

        deadline.start(4, 22_000)
        assertTrue(deadline.advance(4, WirelessConnectionStage.HOTSPOT, 22_000))
        assertEquals(WirelessConnectionStage.HOTSPOT, deadline.current(4))
        assertTrue(deadline.advance(4, WirelessConnectionStage.BLUETOOTH, 22_001))
    }

    @Test
    fun explicitStopCancelsPendingDeadlineAndAllowsFreshAttempt() {
        val deadline = WirelessConnectionDeadline()
        deadline.start(6, 0)
        assertTrue(deadline.advance(6, WirelessConnectionStage.HOTSPOT, 0))
        assertTrue(deadline.advance(6, WirelessConnectionStage.BLUETOOTH, 1_000))
        deadline.stop()

        assertNull(deadline.current(6))
        assertNull(deadline.expire(6, 100_000))
        assertFalse(deadline.advance(6, WirelessConnectionStage.CONNECTED, 100_001))

        deadline.start(7, 101_000)
        assertTrue(deadline.advance(7, WirelessConnectionStage.HOTSPOT, 101_000))
        assertEquals(WirelessConnectionStage.HOTSPOT, deadline.current(7))
        assertNull(deadline.expire(7, 120_999))
        assertNotNull(deadline.expire(7, 121_000))
    }
    @Test
    fun userPairingBudgetDoesNotConsumeProtocolBudget() {
        val deadline = WirelessConnectionDeadline()
        deadline.start(1, 0)
        assertEquals(WirelessConnectionStage.WAITING_FOR_PAIR, deadline.current(1))
        assertNull(deadline.expire(1, 119_999))
        assertTrue(deadline.advance(1, WirelessConnectionStage.HOTSPOT, 119_999))
        assertEquals(20_000, deadline.remainingMillis(1, 119_999))
        assertTrue(deadline.advance(1, WirelessConnectionStage.BLUETOOTH, 120_000))
        assertNull(deadline.expire(1, 139_999))
        assertEquals(WirelessConnectionStage.BLUETOOTH, deadline.expire(1, 140_000)?.stage)
    }

    @Test
    fun pairingTimeoutCannotBeEscapedByLateBondAndIsDeliveredOnce() {
        val deadline = WirelessConnectionDeadline()
        deadline.start(2, 1_000)
        assertFalse(deadline.advance(2, WirelessConnectionStage.HOTSPOT, 121_000))
        assertEquals(WirelessConnectionDeadline.Expired(WirelessConnectionStage.WAITING_FOR_PAIR, 120_000, false),
            deadline.expire(2, 121_000))
        assertNull(deadline.expire(2, 121_001))
        assertEquals(0, deadline.remainingMillis(2, 121_001))
    }

}
