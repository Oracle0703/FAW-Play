package com.shilapi.xcertplay.network

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import com.shilapi.xcertplay.airplay.AirPlayConfig
import com.shilapi.xcertplay.airplay.AirPlayDisplayConfig
import com.shilapi.xcertplay.airplay.AirPlayIdentity
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.BlockingQueue
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito.*
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class CarPlayBonjourProbeTest {
    @Test
    fun startupFailureDoesNotWaitForAnUnansweredResolution() {
        val resolving = CountDownLatch(1)
        val failed = CountDownLatch(1)
        val runtime = Runtime(onEvent = { if (it is CarPlayBonjourEvent.StartFailed) failed.countDown() })
        runtime.onResolve = { _, _ -> resolving.countDown() }
        try {
            runtime.bonjour.start()
            runtime.found("waiting-for-resolution")
            assertTrue(resolving.await(2, TimeUnit.SECONDS))
            runtime.discovery.get().onStartDiscoveryFailed("_carplay-ctrl._tcp", NsdManager.FAILURE_INTERNAL_ERROR)
            assertTrue("Failure delivery must not wait for the 10-second resolver timeout", failed.await(1, TimeUnit.SECONDS))
        } finally { runtime.bonjour.close() }
    }

    @Test
    fun blockedProbeDoesNotHoldFailureNotificationOrAnotherService() {
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val blocked = socket()
        doAnswer {
            entered.countDown()
            try { release.await(5, TimeUnit.SECONDS) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
            throw IOException("first control endpoint unavailable")
        }.`when`(blocked).connect(any(InetSocketAddress::class.java), anyInt())
        val available = socket()
        val sockets = ConcurrentLinkedQueue(listOf(blocked, available))
        val failed = CountDownLatch(1)
        val connected = CountDownLatch(1)
        val runtime = Runtime(socketFactory = { checkNotNull(sockets.poll()) }, onEvent = {
            if (it is CarPlayBonjourEvent.StartFailed) failed.countDown()
            if (it is CarPlayBonjourEvent.Probed && it.error == null && it.endpoint.port == 7002) connected.countDown()
        })
        try {
            runtime.bonjour.start()
            runtime.found("blocked", 7001)
            assertTrue(entered.await(2, TimeUnit.SECONDS))
            runtime.found("available", 7002)
            assertTrue("A second service must not queue behind the first probe", connected.await(2, TimeUnit.SECONDS))
            runtime.registration.get().onRegistrationFailed(NsdServiceInfo(), NsdManager.FAILURE_INTERNAL_ERROR)
            assertTrue(failed.await(1, TimeUnit.SECONDS))
            assertEquals(1L, release.count)
        } finally {
            release.countDown()
            runtime.bonjour.close()
        }
    }

    @Test
    @Config(sdk = [34], manifest = Config.NONE)
    fun ipv4ListenerTriesNextIpv4AddressBeforeRetryingFailedAddress() {
        val failed = socket()
        doThrow(IOException("first IPv4 address unavailable")).`when`(failed)
            .connect(any(InetSocketAddress::class.java), anyInt())
        val available = socket()
        val sockets = ConcurrentLinkedQueue(listOf(failed, available))
        val completed = CountDownLatch(1)
        val received = AtomicReference<CarPlayBonjourEvent.Probed>()
        val runtime = Runtime(advertisedHost = "192.0.2.1", socketFactory = { checkNotNull(sockets.poll()) }, onEvent = {
            if (it is CarPlayBonjourEvent.Probed && it.error == null) { received.set(it); completed.countDown() }
        })
        runtime.addresses = listOf("fe80::2", "192.0.2.2", "192.0.2.3").map(InetAddress::getByName)
        try {
            runtime.bonjour.start()
            runtime.found("dual-stack")
            assertTrue(completed.await(2, TimeUnit.SECONDS))
            assertEquals("192.0.2.3", received.get().endpoint.host)
            assertEquals(2, received.get().attempts)
            verify(failed).connect(InetSocketAddress(InetAddress.getByName("192.0.2.2"), 7000), 3000)
            verify(available).connect(InetSocketAddress(InetAddress.getByName("192.0.2.3"), 7000), 3000)
            verify(available).bind(InetSocketAddress(InetAddress.getByName("192.0.2.1"), 0))
        } finally { runtime.bonjour.close() }
    }

    @Test
    fun exhaustedServiceCanBeResolvedAgainWithoutWaitingForServiceLost() {
        val failedSocket = socket()
        doThrow(IOException("old endpoint unavailable")).`when`(failedSocket)
            .connect(any(InetSocketAddress::class.java), anyInt())
        val sockets = ConcurrentLinkedQueue(listOf(failedSocket, failedSocket, socket()))
        val failed = CountDownLatch(1)
        val connected = CountDownLatch(1)
        val runtime = Runtime(socketFactory = { checkNotNull(sockets.poll()) }, onEvent = {
            if (it is CarPlayBonjourEvent.Probed) {
                if (it.error == null) connected.countDown() else failed.countDown()
            }
        })
        try {
            runtime.bonjour.start()
            runtime.found("same-service")
            assertTrue(failed.await(3, TimeUnit.SECONDS))
            runtime.found("same-service")
            assertTrue(connected.await(2, TimeUnit.SECONDS))
            verify(failedSocket, times(2)).connect(any(InetSocketAddress::class.java), anyInt())
        } finally { runtime.bonjour.close() }
    }

    @Test
    fun closeClosesActiveProbeAndSuppressesItsLateResult() {
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val blocked = socket()
        doAnswer {
            entered.countDown()
            try { release.await(5, TimeUnit.SECONDS) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
            throw IOException("cancelled endpoint")
        }.`when`(blocked).connect(any(InetSocketAddress::class.java), anyInt())
        val events = CopyOnWriteArrayList<CarPlayBonjourEvent>()
        val runtime = Runtime(socketFactory = { blocked }, onEvent = events::add)
        try {
            runtime.bonjour.start()
            runtime.found("closing")
            assertTrue(entered.await(2, TimeUnit.SECONDS))
            runtime.bonjour.close()
            release.countDown()
            verify(blocked, atLeastOnce()).close()
            assertTrue(events.none { it is CarPlayBonjourEvent.Probed })
        } finally {
            release.countDown()
            runtime.bonjour.close()
        }
    }

    @Test
    fun closeAlsoClosesSocketReturnedByAnAlreadyRunningFactory() {
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val closed = CountDownLatch(1)
        val lateSocket = socket()
        doAnswer { closed.countDown(); null }.`when`(lateSocket).close()
        val runtime = Runtime(socketFactory = {
            entered.countDown()
            try { release.await(5, TimeUnit.SECONDS) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
            lateSocket
        }, onEvent = {})
        try {
            runtime.bonjour.start()
            runtime.found("closing-during-factory")
            assertTrue(entered.await(2, TimeUnit.SECONDS))
            runtime.bonjour.close()
            release.countDown()
            assertTrue("A socket created during teardown still belongs to teardown", closed.await(2, TimeUnit.SECONDS))
            verify(lateSocket, never()).connect(any(InetSocketAddress::class.java), anyInt())
        } finally { release.countDown(); runtime.bonjour.close() }
    }

    @Test
    fun serviceLostAndReplacedDiscardsAlreadyQueuedEventsFromPreviousGeneration() {
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val currentConnected = CountDownLatch(1)
        val events = CopyOnWriteArrayList<CarPlayBonjourEvent>()
        val runtime = Runtime(socketFactory = { socket() }, onEvent = { event ->
            events.add(event)
            if (event is CarPlayBonjourEvent.StartFailed) {
                entered.countDown()
                release.await(5, TimeUnit.SECONDS)
            }
            if (event is CarPlayBonjourEvent.Probed && event.endpoint.port == 7002 && event.error == null) {
                currentConnected.countDown()
            }
        })
        try {
            runtime.bonjour.start()
            runtime.registration.get().onRegistrationFailed(NsdServiceInfo(), NsdManager.FAILURE_INTERNAL_ERROR)
            assertTrue(entered.await(2, TimeUnit.SECONDS))
            runtime.found("replaced", 7001)
            runtime.awaitQueuedEvents(2)
            runtime.discovery.get().onServiceLost(NsdServiceInfo().apply {
                serviceName = "replaced"
                serviceType = "_carplay-ctrl._tcp"
            })
            runtime.found("replaced", 7002)
            runtime.awaitQueuedEvents(4)
            release.countDown()
            assertTrue(currentConnected.await(2, TimeUnit.SECONDS))
            assertTrue(events.filterIsInstance<CarPlayBonjourEvent.Resolved>().none { it.endpoint.port == 7001 })
            assertTrue(events.filterIsInstance<CarPlayBonjourEvent.Probed>().none { it.endpoint.port == 7001 })
        } finally { release.countDown(); runtime.bonjour.close() }
    }

    @Test
    fun rejectedAndIncompleteHttpResponsesCannotBecomeSuccessfulConnection() {
        val rejected = socket()
        val incomplete = socket()
        `when`(rejected.inputStream).thenReturn(ByteArrayInputStream("HTTP/1.1 503 Unavailable\r\n".toByteArray()))
        `when`(incomplete.inputStream).thenReturn(ByteArrayInputStream("HTTP/1.1 200 OK".toByteArray()))
        val sockets = ConcurrentLinkedQueue(listOf(rejected, incomplete))
        val finished = CountDownLatch(1)
        val result = AtomicReference<CarPlayBonjourEvent.Probed>()
        val runtime = Runtime(socketFactory = { checkNotNull(sockets.poll()) }, onEvent = {
            if (it is CarPlayBonjourEvent.Probed) { result.set(it); finished.countDown() }
        })
        try {
            runtime.bonjour.start()
            runtime.found("invalid-http-response")
            assertTrue(finished.await(3, TimeUnit.SECONDS))
            assertNotNull(result.get().error)
            assertEquals(2, result.get().attempts)
        } finally { runtime.bonjour.close() }
    }

    private fun socket() = mock(Socket::class.java).also {
        `when`(it.outputStream).thenReturn(ByteArrayOutputStream())
        `when`(it.inputStream).thenReturn(ByteArrayInputStream("HTTP/1.1 200 OK\r\n\r\n".toByteArray()))
    }

    private class Runtime(
        advertisedHost: String? = null,
        socketFactory: () -> Socket = { error("Unexpected network probe") },
        onEvent: (CarPlayBonjourEvent) -> Unit,
    ) {
        val nsd = mock(NsdManager::class.java)
        val registration = AtomicReference<NsdManager.RegistrationListener>()
        val discovery = AtomicReference<NsdManager.DiscoveryListener>()
        @Volatile var addresses = listOf(InetAddress.getByName("192.0.2.2"))
        @Volatile var onResolve: ((NsdServiceInfo, NsdManager.ResolveListener) -> Unit)? = null
        val bonjour: CarPlayBonjour

        init {
            val context = mock(Context::class.java)
            `when`(context.applicationContext).thenReturn(context)
            `when`(context.getSystemService(Context.NSD_SERVICE)).thenReturn(nsd)
            doAnswer { call -> registration.set(call.getArgument(2)); null }.`when`(nsd)
                .registerService(any(NsdServiceInfo::class.java), anyInt(), any(NsdManager.RegistrationListener::class.java))
            doAnswer { call -> discovery.set(call.getArgument(2)); null }.`when`(nsd)
                .discoverServices(anyString(), anyInt(), any(NsdManager.DiscoveryListener::class.java))
            doAnswer { call ->
                val service = call.getArgument<NsdServiceInfo>(0)
                val listener = call.getArgument<NsdManager.ResolveListener>(1)
                val resolver = onResolve
                if (resolver != null) resolver(service, listener)
                else {
                    @Suppress("DEPRECATION")
                    val resolved = NsdServiceInfo().apply {
                        serviceName = service.serviceName
                        serviceType = service.serviceType
                        port = service.port
                        if (Build.VERSION.SDK_INT >= 34) hostAddresses = addresses else host = addresses.first()
                    }
                    listener.onServiceResolved(resolved)
                }
                null
            }.`when`(nsd).resolveService(any(NsdServiceInfo::class.java), any(NsdManager.ResolveListener::class.java))
            bonjour = CarPlayBonjour(
                context,
                AirPlayConfig("test", "02:00:00:00:00:02", "", "366.0", AirPlayDisplayConfig(800, 480)),
                AirPlayIdentity(ByteArray(32), ByteArray(32), "test-pairing"),
                advertisedHost = advertisedHost,
                onEvent = onEvent,
                socketFactory = socketFactory,
            )
        }

        fun found(name: String, servicePort: Int = 7000) {
            discovery.get().onServiceFound(NsdServiceInfo().apply {
                serviceName = name
                serviceType = "_carplay-ctrl._tcp"
                port = servicePort
            })
        }

        fun awaitQueuedEvents(count: Int) {
            val queue = CarPlayBonjour::class.java.getDeclaredField("events").apply { isAccessible = true }
                .get(bonjour) as BlockingQueue<*>
            val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(2)
            while (queue.size < count && System.nanoTime() < deadline) Thread.sleep(1)
            assertTrue("Expected $count queued events, found ${queue.size}", queue.size >= count)
        }
    }
}
