package com.shilapi.xcertplay.network

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import com.shilapi.xcertplay.airplay.AirPlayConfig
import com.shilapi.xcertplay.airplay.AirPlayDisplayConfig
import com.shilapi.xcertplay.airplay.AirPlayIdentity
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.*
import org.mockito.Mockito.*
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class CarPlayBonjourLifecycleTest {
    private class Runtime(onEvent: (CarPlayBonjourEvent) -> Unit) {
        val context = mock(Context::class.java)
        val nsd = mock(NsdManager::class.java)
        val registration = AtomicReference<NsdManager.RegistrationListener>()
        val discovery = AtomicReference<NsdManager.DiscoveryListener>()
        val discoveryRequested = AtomicBoolean()
        val bonjour: CarPlayBonjour

        init {
            `when`(context.applicationContext).thenReturn(context)
            `when`(context.getSystemService(Context.NSD_SERVICE)).thenReturn(nsd)
            doAnswer { invocation ->
                registration.set(invocation.getArgument(2))
                null
            }.`when`(nsd).registerService(
                any(NsdServiceInfo::class.java),
                eq(NsdManager.PROTOCOL_DNS_SD),
                any(NsdManager.RegistrationListener::class.java),
            )
            doAnswer { invocation ->
                discovery.set(invocation.getArgument(2))
                discoveryRequested.set(true)
                null
            }.`when`(nsd).discoverServices(
                anyString(),
                eq(NsdManager.PROTOCOL_DNS_SD),
                any(NsdManager.DiscoveryListener::class.java),
            )
            bonjour = CarPlayBonjour(
                context,
                AirPlayConfig(
                    deviceName = "test-receiver",
                    deviceId = "02:00:00:00:00:02",
                    btMac = "02:00:00:00:00:02",
                    sourceVersion = "366.0",
                    main = AirPlayDisplayConfig(widthPixels = 1280, heightPixels = 720),
                    model = "LIVI",
                ),
                AirPlayIdentity(ByteArray(32), ByteArray(32), "test-pairing"),
                onEvent = onEvent,
            )
        }
    }

    @Test
    fun synchronousRegistrationFailureWaitsForStartRequestsAndRunsOnWorker() {
        val delivered = CountDownLatch(1)
        val received = AtomicReference<CarPlayBonjourEvent>()
        val callbackThread = AtomicReference<Thread>()
        val startRequestsCompleted = AtomicBoolean()
        lateinit var runtime: Runtime
        runtime = Runtime { event ->
            received.set(event)
            callbackThread.set(Thread.currentThread())
            startRequestsCompleted.set(runtime.discoveryRequested.get())
            delivered.countDown()
        }
        doAnswer { invocation ->
            val listener = invocation.getArgument<NsdManager.RegistrationListener>(2)
            runtime.registration.set(listener)
            listener.onRegistrationFailed(invocation.getArgument(0), NsdManager.FAILURE_INTERNAL_ERROR)
            null
        }.`when`(runtime.nsd).registerService(
            any(NsdServiceInfo::class.java), anyInt(), any(NsdManager.RegistrationListener::class.java),
        )
        try {
            runtime.bonjour.start()
            assertTrue(delivered.await(3, TimeUnit.SECONDS))
            assertEquals(
                CarPlayBonjourEvent.StartFailed(
                    CarPlayBonjourStartOperation.AIRPLAY_REGISTRATION,
                    NsdManager.FAILURE_INTERNAL_ERROR,
                ),
                received.get(),
            )
            assertNotSame(Thread.currentThread(), callbackThread.get())
            assertTrue(startRequestsCompleted.get())
        } finally {
            runtime.bonjour.close()
        }
    }

    @Test
    fun slowConsumerDoesNotBlockDiscoveryListenerCallback() {
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val listenerReturned = CountDownLatch(1)
        val runtime = Runtime {
            entered.countDown()
            release.await(3, TimeUnit.SECONDS)
        }
        try {
            runtime.bonjour.start()
            val caller = Thread {
                runtime.discovery.get().onStartDiscoveryFailed("_carplay-ctrl._tcp", NsdManager.FAILURE_INTERNAL_ERROR)
                listenerReturned.countDown()
            }
            caller.start()
            assertTrue(entered.await(3, TimeUnit.SECONDS))
            assertTrue(listenerReturned.await(1, TimeUnit.SECONDS))
            caller.join(1_000)
        } finally {
            release.countDown()
            runtime.bonjour.close()
        }
    }

    @Test
    fun duplicateFailuresAreReportedOnceForEachOperation() {
        val received = CopyOnWriteArrayList<CarPlayBonjourEvent>()
        val delivered = CountDownLatch(2)
        val runtime = Runtime {
            received.add(it)
            delivered.countDown()
        }
        try {
            runtime.bonjour.start()
            repeat(2) {
                runtime.registration.get().onRegistrationFailed(NsdServiceInfo(), NsdManager.FAILURE_INTERNAL_ERROR)
                runtime.discovery.get().onStartDiscoveryFailed("_carplay-ctrl._tcp", NsdManager.FAILURE_MAX_LIMIT)
            }
            assertTrue(delivered.await(3, TimeUnit.SECONDS))
            runtime.bonjour.close()
            assertEquals(
                listOf(
                    CarPlayBonjourEvent.StartFailed(
                        CarPlayBonjourStartOperation.AIRPLAY_REGISTRATION,
                        NsdManager.FAILURE_INTERNAL_ERROR,
                    ),
                    CarPlayBonjourEvent.StartFailed(
                        CarPlayBonjourStartOperation.CARPLAY_DISCOVERY,
                        NsdManager.FAILURE_MAX_LIMIT,
                    ),
                ),
                received.toList(),
            )
        } finally {
            runtime.bonjour.close()
        }
    }

    @Test
    fun closeDiscardsQueuedFailureAndLateCallbacks() {
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val received = CopyOnWriteArrayList<CarPlayBonjourEvent>()
        val runtime = Runtime {
            received.add(it)
            entered.countDown()
            release.await(3, TimeUnit.SECONDS)
        }
        try {
            runtime.bonjour.start()
            runtime.registration.get().onRegistrationFailed(NsdServiceInfo(), NsdManager.FAILURE_INTERNAL_ERROR)
            assertTrue(entered.await(3, TimeUnit.SECONDS))
            runtime.discovery.get().onStartDiscoveryFailed("_carplay-ctrl._tcp", NsdManager.FAILURE_MAX_LIMIT)
            runtime.bonjour.close()
            runtime.discovery.get().onStartDiscoveryFailed("_carplay-ctrl._tcp", NsdManager.FAILURE_INTERNAL_ERROR)
            assertEquals(1, received.size)
        } finally {
            release.countDown()
            runtime.bonjour.close()
        }
    }

    @Test
    fun synchronousStartExceptionDiscardsEarlierQueuedFailure() {
        val received = CopyOnWriteArrayList<CarPlayBonjourEvent>()
        val runtime = Runtime(received::add)
        doAnswer { invocation ->
            val listener = invocation.getArgument<NsdManager.RegistrationListener>(2)
            runtime.registration.set(listener)
            listener.onRegistrationFailed(invocation.getArgument(0), NsdManager.FAILURE_INTERNAL_ERROR)
            null
        }.`when`(runtime.nsd).registerService(
            any(NsdServiceInfo::class.java), anyInt(), any(NsdManager.RegistrationListener::class.java),
        )
        doThrow(IllegalStateException("NSD unavailable")).`when`(runtime.nsd).discoverServices(
            anyString(), anyInt(), any(NsdManager.DiscoveryListener::class.java),
        )
        assertThrows(IllegalStateException::class.java) { runtime.bonjour.start() }
        runtime.registration.get().onRegistrationFailed(NsdServiceInfo(), NsdManager.FAILURE_INTERNAL_ERROR)
        runtime.bonjour.close()
        assertTrue(received.isEmpty())
        verify(runtime.nsd).unregisterService(runtime.registration.get())
    }
}
