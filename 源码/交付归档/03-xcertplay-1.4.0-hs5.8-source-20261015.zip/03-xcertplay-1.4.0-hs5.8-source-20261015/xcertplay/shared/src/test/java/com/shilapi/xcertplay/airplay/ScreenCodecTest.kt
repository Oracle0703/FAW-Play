package com.shilapi.xcertplay.airplay

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertEquals
import org.junit.Test

class ScreenCodecTest {
    @Test
    fun validLengthPrefixesBecomeAnnexBInPlace() {
        val first = byteArrayOf(0x40, 0x01)
        val second = byteArrayOf(0x42, 0x01, 0x02)
        val payload =
            byteArrayOf(0, 0, 0, first.size.toByte()) + first +
                byteArrayOf(0, 0, 0, second.size.toByte()) + second

        val converted = ScreenCodec.lengthPrefixedToAnnexB(payload)

        assertSame(payload, converted)
        assertArrayEquals(
            byteArrayOf(0, 0, 0, 1) + first +
                byteArrayOf(0, 0, 0, 1) + second,
            converted,
        )
    }

    @Test
    fun malformedLengthsRejectTheAccessUnitWithoutMutatingInput() {
        val payload = byteArrayOf(0, 0, 0, 5, 0x40, 0x01)
        val original = payload.copyOf()

        assertEquals(0, ScreenCodec.lengthPrefixedToAnnexB(payload).size)
        assertArrayEquals(original, payload)
    }
    @Test
    fun negotiatedLengthSizesAreHonored() {
        for (lengthSize in listOf(1, 2, 4)) {
            val nal = byteArrayOf(0x26, 1, 0x80.toByte())
            val prefix = ByteArray(lengthSize).apply { this[lastIndex] = nal.size.toByte() }
            assertArrayEquals(byteArrayOf(0, 0, 0, 1) + nal,
                ScreenCodec.lengthPrefixedToAnnexB(prefix + nal, lengthSize))
        }
    }

    @Test
    fun oneByteAvcNalIsNotMistakenForAnAnnexBStartCode() {
        val payload = byteArrayOf(0, 0, 0, 1, 9, 0, 0, 0, 2, 0x65, 1)
        assertArrayEquals(byteArrayOf(0, 0, 0, 1, 9, 0, 0, 0, 1, 0x65, 1),
            ScreenCodec.lengthPrefixedToAnnexB(payload))
    }

    @Test
    fun aDamagedLaterNalCannotPartiallyRewriteEarlierValidPrefixes() {
        val validFirst = byteArrayOf(0, 0, 0, 2, 0x65, 1)
        val damagedTails = listOf(
            byteArrayOf(0, 0, 0),
            byteArrayOf(0, 0, 0, 0),
            byteArrayOf(-1, -1, -1, -1, 0x41, 1),
            byteArrayOf(0x7f, -1, -1, -1, 0x41, 1),
            byteArrayOf(0, 0, 0, 3, 0x41, 1),
        )
        for (tail in damagedTails) {
            val payload = validFirst + tail
            val original = payload.copyOf()
            assertEquals(0, ScreenCodec.lengthPrefixedToAnnexB(payload).size)
            assertArrayEquals(original, payload)
        }
    }

    @Test
    fun inPlaceConversionMatchesTheStrictConverterForLargeAndVariedAccessUnits() {
        val random = java.util.Random(2384)
        repeat(80) { sample ->
            val output = java.io.ByteArrayOutputStream()
            repeat(1 + random.nextInt(12)) { unit ->
                val size = if (sample == 0) 128 * 1024 else 1 + random.nextInt(8192)
                val nal = ByteArray(size).also(random::nextBytes)
                nal[0] = (if (unit == 0) 0x65 else 0x41).toByte()
                output.write(byteArrayOf((size ushr 24).toByte(), (size ushr 16).toByte(),
                    (size ushr 8).toByte(), size.toByte()))
                output.write(nal)
            }
            val payload = output.toByteArray()
            val expected = com.shilapi.xcertplay.media.MediaCodecSupport.toAnnexB(payload, allowAnnexB = false)
            assertSame(payload, ScreenCodec.lengthPrefixedToAnnexB(payload))
            assertArrayEquals(expected, payload)
        }
    }
}
