package com.shilapi.xcertplay.media

import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Looper
import java.util.concurrent.TimeUnit
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.any
import org.mockito.Mockito.doAnswer
import org.mockito.Mockito.mock
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.util.ReflectionHelpers

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class Hs5AudioFocusCoordinatorTest {
    @Test fun guidanceKeepsMediaFocusUnderItsTemporaryRequest() {
        val fixture = Fixture()
        val owner = Any()
        fixture.focus.retain(owner)
        fixture.stream(owner, AudioChannel.MEDIA)
        val media = fixture.requests.single()
        val navigation = fixture.stream(owner, AudioChannel.NAVIGATION)
        assertEquals(AudioManager.AUDIOFOCUS_GAIN, media.focusGain)
        assertEquals(AudioAttributes.USAGE_MEDIA, media.audioAttributes.usage)
        assertEquals(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK, fixture.requests.last().focusGain)
        assertEquals(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE, fixture.requests.last().audioAttributes.usage)
        assertFalse(fixture.requests.last().willPauseWhenDucked())
        assertFalse(fixture.abandoned.contains(media))
        fixture.focus.streamEnded(navigation)
        assertEquals(2, fixture.requests.size)
        assertFalse(fixture.abandoned.contains(media))
        fixture.focus.release(owner)
        assertTrue(fixture.abandoned.contains(media))
    }

    @Test fun callAndSiriHaveTheirOwnPriorityAndReturnToNavigation() {
        val fixture = Fixture()
        val owner = Any()
        fixture.focus.retain(owner)
        fixture.stream(owner, AudioChannel.MEDIA)
        val media = fixture.requests.single()
        fixture.stream(owner, AudioChannel.NAVIGATION)
        val siri = fixture.stream(owner, AudioChannel.ASSISTANT)
        assertEquals(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK, fixture.requests.last().focusGain)
        assertEquals(AudioAttributes.USAGE_ASSISTANT, fixture.requests.last().audioAttributes.usage)
        val call = fixture.stream(owner, AudioChannel.PHONE)
        assertEquals(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT, fixture.requests.last().focusGain)
        assertEquals(AudioAttributes.USAGE_VOICE_COMMUNICATION, fixture.requests.last().audioAttributes.usage)
        fixture.focus.streamEnded(call)
        assertEquals(AudioAttributes.USAGE_ASSISTANT, fixture.requests.last().audioAttributes.usage)
        fixture.focus.streamEnded(siri)
        assertEquals(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE, fixture.requests.last().audioAttributes.usage)
        assertFalse(fixture.abandoned.contains(media))
        fixture.focus.release(owner)
    }

    @Test fun cameraMusicFollowsTheActualMediaRouteAndCanLaterSwitchToSiri() {
        val fixture = Fixture()
        val owner = Any()
        fixture.focus.retain(owner)
        // The renderer classified the speechRecognition output as camera music.
        val speechStream = fixture.stream(owner, AudioChannel.MEDIA)
        assertEquals(1, fixture.requests.size)
        assertEquals(AudioAttributes.USAGE_MEDIA, fixture.requests.single().audioAttributes.usage)
        fixture.focus.updateChannel(speechStream, AudioChannel.ASSISTANT)
        assertEquals(AudioAttributes.USAGE_ASSISTANT, fixture.requests.last().audioAttributes.usage)
        assertEquals(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK, fixture.requests.last().focusGain)
        fixture.focus.updateChannel(speechStream, AudioChannel.ASSISTANT)
        assertEquals(2, fixture.requests.size)
        fixture.focus.release(owner)
    }

    @Test fun mediaArrivingDuringACallLeavesTheCallAtTheTopOfTheFocusStack() {
        val fixture = Fixture()
        val owner = Any()
        fixture.focus.retain(owner)
        fixture.stream(owner, AudioChannel.PHONE)
        fixture.stream(owner, AudioChannel.MEDIA)
        assertEquals(listOf(AudioAttributes.USAGE_VOICE_COMMUNICATION, AudioAttributes.USAGE_MEDIA,
            AudioAttributes.USAGE_VOICE_COMMUNICATION), fixture.requests.map { it.audioAttributes.usage })
        fixture.focus.requestFromHost()
        assertEquals(3, fixture.requests.size)
        fixture.focus.release(owner)
    }

    @Test fun closingAnOldRendererCannotRemoveOrReclaimItsReplacement() {
        val fixture = Fixture()
        val owner = Any()
        fixture.focus.retain(owner)
        val old = fixture.stream(owner, AudioChannel.PHONE)
        fixture.focus.streamEnded(old)
        val replacement = fixture.stream(owner, AudioChannel.PHONE)
        val call = fixture.requests.last()
        fixture.focus.streamEnded(old)
        fixture.focus.updateChannel(old, AudioChannel.MEDIA)
        assertFalse(fixture.abandoned.contains(call))
        assertEquals(2, fixture.requests.size)
        fixture.focus.streamEnded(replacement)
        assertTrue(fixture.abandoned.contains(call))
        fixture.focus.release(owner)
    }

    @Test fun releasingTheHostPreservesTheBackgroundSinkAndRejectsLateUpdatesAfterSinkClose() {
        val fixture = Fixture()
        val host = Any()
        val sink = Any()
        fixture.focus.retain(host)
        fixture.focus.retain(sink)
        fixture.focus.requestFromHost()
        val media = fixture.requests.single()
        val call = fixture.stream(sink, AudioChannel.PHONE)
        fixture.focus.release(host)
        assertTrue(fixture.abandoned.isEmpty())
        fixture.focus.release(sink)
        assertTrue(fixture.abandoned.contains(media))
        assertEquals(2, fixture.abandoned.size)
        fixture.focus.updateChannel(call, AudioChannel.PHONE)
        shadowOf(Looper.getMainLooper()).idleFor(31, TimeUnit.SECONDS)
        assertEquals(2, fixture.requests.size)
    }

    @Test fun initialDeniedRequestRetriesAndStopsAfterItsStreamEnds() {
        val fixture = Fixture(AudioManager.AUDIOFOCUS_REQUEST_FAILED, AudioManager.AUDIOFOCUS_REQUEST_GRANTED)
        val owner = Any()
        fixture.focus.retain(owner)
        val call = fixture.stream(owner, AudioChannel.PHONE)
        shadowOf(Looper.getMainLooper()).idleFor(999, TimeUnit.MILLISECONDS)
        assertEquals(1, fixture.requests.size)
        shadowOf(Looper.getMainLooper()).idleFor(1, TimeUnit.MILLISECONDS)
        assertEquals(2, fixture.requests.size)
        fixture.focus.streamEnded(call)
        shadowOf(Looper.getMainLooper()).idleFor(31, TimeUnit.SECONDS)
        assertEquals(2, fixture.requests.size)
        fixture.focus.release(owner)
    }

    @Test fun grantedFocusLossDoesNotStartRetriesOrSendPlaybackCommands() {
        val fixture = Fixture()
        val owner = Any()
        fixture.focus.retain(owner)
        fixture.focus.requestFromHost()
        val request = fixture.requests.single()
        listener(request).onAudioFocusChange(AudioManager.AUDIOFOCUS_LOSS)
        shadowOf(Looper.getMainLooper()).idleFor(31, TimeUnit.SECONDS)
        assertEquals(1, fixture.requests.size)
        // Only an explicit host action selects media again.
        fixture.focus.requestFromHost()
        assertEquals(2, fixture.requests.size)
        fixture.focus.release(owner)
    }

    @Test fun staleCallFocusCallbackCannotCancelANewNavigationRetry() {
        val fixture = Fixture(AudioManager.AUDIOFOCUS_REQUEST_GRANTED,
            AudioManager.AUDIOFOCUS_REQUEST_FAILED, AudioManager.AUDIOFOCUS_REQUEST_GRANTED)
        val owner = Any()
        fixture.focus.retain(owner)
        val call = fixture.stream(owner, AudioChannel.PHONE)
        val old = fixture.requests.single()
        fixture.stream(owner, AudioChannel.NAVIGATION)
        fixture.focus.streamEnded(call)
        listener(old).onAudioFocusChange(AudioManager.AUDIOFOCUS_GAIN)
        shadowOf(Looper.getMainLooper()).idleFor(1, TimeUnit.SECONDS)
        assertEquals(3, fixture.requests.size)
        assertEquals(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE, fixture.requests.last().audioAttributes.usage)
        fixture.focus.release(owner)
    }

    @Test fun genericDeviceKeepsTheUpstreamHostFocusContract() {
        val fixture = Fixture()
        val generic = AndroidMediaSink.AudioFocusSession(fixture.manager)
        val host = Any()
        generic.retain(host)
        generic.requestFromHost()
        val request = fixture.requests.single()
        assertEquals(AudioManager.AUDIOFOCUS_GAIN, request.focusGain)
        assertTrue(request.willPauseWhenDucked())
        val stream = Any()
        generic.streamCreated(host, stream)
        generic.updateChannel(stream, AudioChannel.PHONE)
        assertEquals(1, fixture.requests.size)
        generic.release(host)
        assertEquals(listOf(request), fixture.abandoned)
    }

    private fun listener(request: AudioFocusRequest): AudioManager.OnAudioFocusChangeListener =
        ReflectionHelpers.callInstanceMethod(request, "getOnAudioFocusChangeListener")

    private class Fixture(vararg results: Int) {
        val requests = mutableListOf<AudioFocusRequest>()
        val abandoned = mutableListOf<AudioFocusRequest>()
        private val nextResults = ArrayDeque(results.toList())
        val manager = mock(AudioManager::class.java).also { manager ->
            doAnswer { invocation ->
                requests.add(invocation.getArgument(0))
                nextResults.removeFirstOrNull() ?: AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            }.`when`(manager).requestAudioFocus(any(AudioFocusRequest::class.java))
            doAnswer { invocation ->
                abandoned.add(invocation.getArgument(0))
                AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            }.`when`(manager).abandonAudioFocusRequest(any(AudioFocusRequest::class.java))
        }
        val focus = Hs5AudioFocusCoordinator(manager)
        fun stream(owner: Any, channel: AudioChannel) = Any().also {
            focus.streamCreated(owner, it)
            focus.updateChannel(it, channel)
        }
    }
}
