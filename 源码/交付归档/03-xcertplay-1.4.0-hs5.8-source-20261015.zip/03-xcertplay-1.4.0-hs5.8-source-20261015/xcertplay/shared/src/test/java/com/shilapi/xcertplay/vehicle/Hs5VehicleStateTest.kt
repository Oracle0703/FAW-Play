package com.shilapi.xcertplay.vehicle

import org.junit.Assert.*
import org.junit.Test

class Hs5VehicleStateTest {
    private val now = 10_000L
    private val snapshot = Hs5VehicleSnapshot(
        Hs5VehicleConnectionStatus.CONNECTED, Hs5VehicleCapabilities(true, true, true),
        Hs5VehicleField.entries.associateWith { Hs5VehicleValue(0.0, now) },
    )

    @Test fun missingExpiredDisconnectedAndNonFiniteSamplesAreUnknown() {
        val field = Hs5VehicleField.HVAC_FAN
        assertEquals(0.0, snapshot.value(field, now))
        assertEquals(0.0, snapshot.value(field, now + 5_000))
        assertNull(snapshot.value(field, now + 5_001))
        assertNull(snapshot.value(field, now - 1))
        assertNull(snapshot.copy(status = Hs5VehicleConnectionStatus.UNAVAILABLE).value(field, now))
        assertNull(snapshot.copy(values = emptyMap()).value(field, now))
        assertNull(snapshot.copy(values = mapOf(field to Hs5VehicleValue(Double.NaN, now))).value(field, now))
    }

    @Test fun commandRequiresCurrentKnownStateAndVerifiedModelAndCapability() {
        val command = Hs5VehicleCommand.SeatLevel(0, true, 4)
        assertNull(command.rejection(snapshot, now))
        assertEquals("vehicle-disconnected", command.rejection(snapshot.copy(status = Hs5VehicleConnectionStatus.CONNECTING), now))
        assertEquals("vehicle-model-unverified", command.rejection(snapshot.copy(capabilities = Hs5VehicleCapabilities()), now))
        assertEquals("feature-unavailable", command.rejection(snapshot.copy(capabilities = Hs5VehicleCapabilities(true, false, true)), now))
        assertEquals("state-unavailable", command.rejection(snapshot, now + 5_001))
        assertEquals("state-unavailable", command.rejection(snapshot.copy(values = emptyMap()), now))
    }

    @Test fun independentSeatCapabilityDoesNotAuthorizeTheOtherFeature() {
        val heatOnly = snapshot.copy(capabilities = Hs5VehicleCapabilities(true, true, false))
        assertNull(Hs5VehicleCommand.SeatLevel(0, true, 1).rejection(heatOnly, now))
        assertEquals("feature-unavailable", Hs5VehicleCommand.SeatLevel(0, false, 1).rejection(heatOnly, now))
    }

    @Test fun validationPreservesOemEncodingAndRejectsInvalidOrAmbiguousRequests() {
        val invalid = listOf(
            Hs5VehicleCommand.ClimateTemperature(-1, 20f), Hs5VehicleCommand.ClimateTemperature(1, Float.POSITIVE_INFINITY),
            Hs5VehicleCommand.ClimateTemperature(0, 20.25f), Hs5VehicleCommand.ClimateTemperature(0, 35.5f),
            Hs5VehicleCommand.ClimateFan(8), Hs5VehicleCommand.SeatLevel(0, true, 0),
            Hs5VehicleCommand.SeatLevel(2, false, 1),
            Hs5VehicleCommand.ClimateSetting(Hs5ClimateSetting.POWER, 0),
            Hs5VehicleCommand.ClimateSetting(Hs5ClimateSetting.RECIRCULATION, 3),
            Hs5VehicleCommand.ClimateBlowMode(2),
        )
        invalid.forEach { assertEquals(it.toString(), "invalid-parameter", it.rejection(snapshot, now)) }
        val valid = listOf(
            Hs5VehicleCommand.ClimateTemperature(0, 15f), Hs5VehicleCommand.ClimateTemperature(1, 35f),
            Hs5VehicleCommand.ClimateFan(0), Hs5VehicleCommand.SeatLevel(1, false, 4),
            Hs5VehicleCommand.ClimateSetting(Hs5ClimateSetting.POWER, 2),
            Hs5VehicleCommand.ClimateSetting(Hs5ClimateSetting.RECIRCULATION, 0),
            Hs5VehicleCommand.ClimateBlowMode(7),
        )
        valid.forEach { assertNull(it.toString(), it.rejection(snapshot, now)) }
    }
}
