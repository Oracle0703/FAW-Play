package com.shilapi.xcertplay.vehicle

import android.os.IBinder
import android.os.Parcel
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class Hs5ComfortProtocolTest {
    @Test fun readsEachPrimitiveIndependentlyAndUsesSccuSeatPath() {
        val rpc = RecordingRpc()
        rpc.ints[Key(33, 1)] = SecurityException("denied")
        rpc.floats[Key(33, 11, listOf(0))] = 22.5f
        rpc.floats[Key(33, 11, listOf(1))] = 24f
        rpc.floats[Key(33, 93)] = -2f // A negative ambient temperature is a real value.
        rpc.ints[Key(33, 13)] = 7
        rpc.ints[Key(49, 7, listOf(0))] = 3
        rpc.ints[Key(49, 3, listOf(1))] = 4
        val result = Hs5ComfortProtocol.read(rpc)
        assertEquals(15, result.size)
        assertNull(result[Hs5VehicleField.HVAC_POWER])
        assertEquals(22.5, result[Hs5VehicleField.HVAC_LEFT_TEMPERATURE])
        assertEquals(24.0, result[Hs5VehicleField.HVAC_RIGHT_TEMPERATURE])
        assertEquals(-2.0, result[Hs5VehicleField.AMBIENT_TEMPERATURE])
        assertEquals(7.0, result[Hs5VehicleField.HVAC_FAN])
        assertEquals(3.0, result[Hs5VehicleField.DRIVER_SEAT_HEAT])
        assertEquals(4.0, result[Hs5VehicleField.PASSENGER_SEAT_VENT])
        assertTrue(rpc.calls.contains(Key(33, 3, listOf(-1))))
        assertTrue(rpc.calls.contains(Key(33, 5, listOf(-1))))
        assertTrue(rpc.calls.contains(Key(33, 7, listOf(-1))))
        assertFalse(rpc.calls.any { it.module == 33 && it.method in 53..60 })
    }

    @Test fun unavailableAndOutOfRangeReadingsNeverBecomeRealValues() {
        val rpc = RecordingRpc()
        rpc.ints[Key(33, 1)] = -65533
        rpc.ints[Key(33, 13)] = 255
        rpc.floats[Key(33, 11, listOf(0))] = -65533f
        rpc.floats[Key(33, 11, listOf(1))] = Float.NaN
        rpc.floats[Key(33, 93)] = -65533f
        rpc.ints[Key(49, 7, listOf(0))] = -2
        rpc.ints[Key(49, 3, listOf(1))] = 255
        val result = Hs5ComfortProtocol.read(rpc)
        for (field in listOf(Hs5VehicleField.HVAC_POWER, Hs5VehicleField.HVAC_FAN,
            Hs5VehicleField.HVAC_LEFT_TEMPERATURE, Hs5VehicleField.HVAC_RIGHT_TEMPERATURE,
            Hs5VehicleField.AMBIENT_TEMPERATURE, Hs5VehicleField.DRIVER_SEAT_HEAT,
            Hs5VehicleField.PASSENGER_SEAT_VENT)) assertNull(field.name, result[field])
    }

    @Test fun capabilitiesUseExactOemModelBranchesAndIndependentFeatureFlags() {
        val rpc = RecordingRpc()
        rpc.pdsn = "7901010DD52B"
        rpc.ints[Key(31, 49)] = 1
        rpc.ints[Key(31, 50)] = SecurityException("denied")
        assertEquals(Hs5VehicleCapabilities(true, true, false), Hs5ComfortProtocol.capability(rpc))
        rpc.pdsn = "7901010DD42B"
        rpc.ints[Key(31, 50)] = 1
        assertEquals(Hs5VehicleCapabilities(true, true, true), Hs5ComfortProtocol.capability(rpc))
        rpc.pdsn = "7901010DD22B"
        assertEquals(Hs5VehicleCapabilities(), Hs5ComfortProtocol.capability(rpc))
        rpc.pdsn = null
        assertEquals(Hs5VehicleCapabilities(), Hs5ComfortProtocol.capability(rpc))
    }

    @Test fun commandsPreserveTheVerifiedTransactionTypesAndOemAcknowledgement() {
        val rpc = RecordingRpc()
        rpc.ints[Key(33, 14, listOf(7))] = -2
        assertEquals(-2, Hs5ComfortProtocol.execute(rpc, Hs5VehicleCommand.ClimateFan(7)))
        Hs5ComfortProtocol.execute(rpc, Hs5VehicleCommand.ClimateTemperature(1, 22.5f))
        assertEquals(Triple(12, 1, 22.5f), rpc.floatWrite)
        Hs5ComfortProtocol.execute(rpc, Hs5VehicleCommand.SeatLevel(0, true, 4))
        Hs5ComfortProtocol.execute(rpc, Hs5VehicleCommand.SeatLevel(1, false, 1))
        assertEquals(listOf(Key(33, 14, listOf(7)), Key(49, 8, listOf(0, 4)), Key(49, 4, listOf(1, 1))), rpc.calls)
    }

    @Test fun invalidCommandsDoNotReachTheVehicleService() {
        val rpc = RecordingRpc()
        val bad = listOf(
            Hs5VehicleCommand.ClimateTemperature(-1, 20f), Hs5VehicleCommand.ClimateTemperature(0, 14.5f),
            Hs5VehicleCommand.ClimateTemperature(0, 35.5f), Hs5VehicleCommand.ClimateTemperature(0, 21.25f),
            Hs5VehicleCommand.ClimateTemperature(0, Float.NaN), Hs5VehicleCommand.ClimateFan(-1),
            Hs5VehicleCommand.ClimateFan(8), Hs5VehicleCommand.SeatLevel(2, true, 1),
            Hs5VehicleCommand.SeatLevel(0, false, 0), Hs5VehicleCommand.SeatLevel(1, true, 5),
        )
        bad.forEach { command -> assertThrows(IllegalArgumentException::class.java) { Hs5ComfortProtocol.execute(rpc, command) } }
        assertTrue(rpc.calls.isEmpty())
        assertNull(rpc.floatWrite)
    }

    @Test fun allClimateSettingsUseOemEncodedValuesAndPreciseTransactions() {
        val rpc = RecordingRpc()
        val methods = mapOf(Hs5ClimateSetting.POWER to 2, Hs5ClimateSetting.AUTO to 4,
            Hs5ClimateSetting.SYNC to 6, Hs5ClimateSetting.COMPRESSOR to 8,
            Hs5ClimateSetting.RECIRCULATION to 16, Hs5ClimateSetting.FRONT_DEFROST to 18)
        for ((setting, method) in methods) {
            val range = if (setting == Hs5ClimateSetting.RECIRCULATION) 0..2 else 1..2
            for (encoded in range) {
                Hs5ComfortProtocol.execute(rpc, Hs5VehicleCommand.ClimateSetting(setting, encoded))
                assertEquals(Key(33, method, listOf(encoded)), rpc.calls.last())
            }
            for (invalid in listOf(-1, range.first - 1, 3, 254, 255)) {
                assertThrows(IllegalArgumentException::class.java) {
                    Hs5ComfortProtocol.execute(rpc, Hs5VehicleCommand.ClimateSetting(setting, invalid))
                }
            }
        }
    }

    @Test fun blowModesUseTwoIntegersAndRejectUnverifiedCodes() {
        val rpc = RecordingRpc()
        for (mode in listOf(1, 3, 5, 6, 7)) {
            Hs5ComfortProtocol.execute(rpc, Hs5VehicleCommand.ClimateBlowMode(mode))
            assertEquals(Key(33, 10, listOf(0, mode)), rpc.calls.last())
        }
        for (mode in listOf(-1, 0, 2, 4, 8, 255)) assertThrows(IllegalArgumentException::class.java) {
            Hs5ComfortProtocol.execute(rpc, Hs5VehicleCommand.ClimateBlowMode(mode))
        }
    }

    @Test fun climateFlagsRejectInvalidAndUninitialisedSentinelValues() {
        val rpc = RecordingRpc()
        rpc.ints[Key(33, 1)] = 255
        rpc.ints[Key(33, 3, listOf(-1))] = 254
        rpc.ints[Key(33, 5, listOf(-1))] = 3
        rpc.ints[Key(33, 7, listOf(-1))] = -2
        rpc.ints[Key(33, 15)] = 255
        rpc.ints[Key(33, 17)] = 254
        val result = Hs5ComfortProtocol.read(rpc)
        for (field in listOf(Hs5VehicleField.HVAC_POWER, Hs5VehicleField.HVAC_AUTO,
            Hs5VehicleField.HVAC_SYNC, Hs5VehicleField.HVAC_COMPRESSOR,
            Hs5VehicleField.HVAC_RECIRCULATION, Hs5VehicleField.HVAC_FRONT_DEFROST)) assertNull(result[field])
    }

    @Test fun subscribesOnlyToTheVerifiedOemManagers() {
        val subscriptions = Hs5ComfortProtocol.listeners { _, _ -> }
        assertEquals(listOf(33, 49), subscriptions.map { it.module })
        assertEquals(listOf(85, 29), subscriptions.map { it.registerMethod })
        assertEquals(listOf(86, 30), subscriptions.map { it.unregisterMethod })
        assertEquals(Hs5ComfortProtocol.ATC_LISTENER, subscriptions[0].listener.interfaceDescriptor)
        assertEquals(Hs5ComfortProtocol.SCCU_LISTENER, subscriptions[1].listener.interfaceDescriptor)
    }

    @Test fun temperatureCallbackReadsFloatAndSeatCallbacksKeepTheirRawCode() {
        val events = mutableListOf<Pair<Hs5VehicleField, Double?>>()
        val subs = Hs5ComfortProtocol.listeners { field, value -> events.add(field to value) }
        assertTrue(deliver(subs[0].listener, Hs5ComfortProtocol.ATC_LISTENER, 6) { it.writeInt(1); it.writeFloat(23.5f) })
        assertTrue(deliver(subs[0].listener, Hs5ComfortProtocol.ATC_LISTENER, 5) { it.writeInt(0); it.writeInt(6) })
        assertTrue(deliver(subs[1].listener, Hs5ComfortProtocol.SCCU_LISTENER, 4) { it.writeInt(0); it.writeInt(4) })
        assertTrue(deliver(subs[1].listener, Hs5ComfortProtocol.SCCU_LISTENER, 2) { it.writeInt(1); it.writeInt(1) })
        assertEquals(listOf(Hs5VehicleField.HVAC_RIGHT_TEMPERATURE to 23.5,
            Hs5VehicleField.HVAC_BLOW_MODE to 6.0, Hs5VehicleField.DRIVER_SEAT_HEAT to 4.0,
            Hs5VehicleField.PASSENGER_SEAT_VENT to 1.0), events)
    }

    @Test fun invalidSamplesClearTheFieldAndUnknownCallbacksDoNotInventValues() {
        val events = mutableListOf<Pair<Hs5VehicleField, Double?>>()
        val subs = Hs5ComfortProtocol.listeners { field, value -> events.add(field to value) }
        deliver(subs[0].listener, Hs5ComfortProtocol.ATC_LISTENER, 7) { it.writeInt(255) }
        deliver(subs[1].listener, Hs5ComfortProtocol.SCCU_LISTENER, 4) { it.writeInt(0); it.writeInt(-2) }
        assertFalse(deliver(subs[1].listener, Hs5ComfortProtocol.SCCU_LISTENER, 3) { it.writeInt(0); it.writeInt(1) })
        assertEquals(listOf(Hs5VehicleField.HVAC_FAN to null, Hs5VehicleField.DRIVER_SEAT_HEAT to null), events)
    }

    @Test fun synchronousCompatibilityCallsPublishAndWriteSuccessfulAcknowledgements() {
        val events = mutableListOf<Pair<Hs5VehicleField, Double?>>()
        val subs = Hs5ComfortProtocol.listeners { field, value -> events.add(field to value) }
        // 3222 uses FLAG_ONEWAY=1; verify the separate compatibility branch also writes
        // a valid exception header, so a synchronous caller does not stall or misread a reply.
        deliverSync(subs[0].listener, Hs5ComfortProtocol.ATC_LISTENER, 6) { it.writeInt(0); it.writeFloat(24.5f) }
        deliverSync(subs[1].listener, Hs5ComfortProtocol.SCCU_LISTENER, 2) { it.writeInt(1); it.writeInt(3) }
        assertEquals(listOf(Hs5VehicleField.HVAC_LEFT_TEMPERATURE to 24.5,
            Hs5VehicleField.PASSENGER_SEAT_VENT to 3.0), events)
    }

    @Test fun callbacksRejectWrongTokensTruncationTrailingDataAndInvalidAreas() {
        val events = mutableListOf<Pair<Hs5VehicleField, Double?>>()
        val subs = Hs5ComfortProtocol.listeners { field, value -> events.add(field to value) }
        // Binder logs exceptions from real one-way calls. Use a synchronous transaction here
        // to decode the precise rejection while valid callback tests retain FLAG_ONEWAY.
        assertThrows(SecurityException::class.java) { deliverSync(subs[0].listener, "wrong", 7) { it.writeInt(1) } }
        assertThrows(IllegalArgumentException::class.java) { deliverSync(subs[0].listener, Hs5ComfortProtocol.ATC_LISTENER, 6) { it.writeInt(1) } }
        assertThrows(IllegalArgumentException::class.java) { deliverSync(subs[0].listener, Hs5ComfortProtocol.ATC_LISTENER, 7) { it.writeInt(1); it.writeInt(2) } }
        assertThrows(IllegalArgumentException::class.java) { deliverSync(subs[1].listener, Hs5ComfortProtocol.SCCU_LISTENER, 4) { it.writeInt(2); it.writeInt(1) } }
        assertTrue(events.isEmpty())
    }

    private fun deliver(binder: IBinder, token: String, code: Int, write: (Parcel) -> Unit): Boolean {
        val data = Parcel.obtain()
        return try {
            data.writeInterfaceToken(token)
            write(data)
            data.setDataPosition(0)
            binder.transact(code, data, null, IBinder.FLAG_ONEWAY)
        } finally { data.recycle() }
    }

    private fun deliverSync(binder: IBinder, token: String, code: Int, write: (Parcel) -> Unit) {
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(token)
            write(data)
            data.setDataPosition(0)
            assertTrue(binder.transact(code, data, reply, 0))
            reply.setDataPosition(0)
            reply.readException()
        } finally { data.recycle(); reply.recycle() }
    }

    private data class Key(val module: Int, val method: Int, val args: List<Int> = emptyList())
    private class RecordingRpc : Hs5VehicleRpc {
        val ints = mutableMapOf<Key, Any>()
        val floats = mutableMapOf<Key, Float>()
        val calls = mutableListOf<Key>()
        var pdsn: String? = null
        var floatWrite: Triple<Int, Int, Float>? = null
        override fun int(module: Int, method: Int, vararg args: Int): Int {
            val key = Key(module, method, args.toList())
            calls.add(key)
            val result = ints[key] ?: 0
            if (result is Exception) throw result
            return result as Int
        }
        override fun float(module: Int, method: Int, vararg args: Int): Float = floats[Key(module, method, args.toList())] ?: -65533f
        override fun string(module: Int, method: Int): String? { assertEquals(31, module); assertEquals(4, method); return pdsn }
        override fun callIntFloat(module: Int, method: Int, area: Int, value: Float): Int {
            assertEquals(33, module)
            floatWrite = Triple(method, area, value)
            return 0
        }
        override fun register(module: Int, method: Int, listener: IBinder) = error("Not a write command")
        override fun unregister(module: Int, method: Int, listener: IBinder) = error("Not a write command")
    }
}
