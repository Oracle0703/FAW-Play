package com.shilapi.xcertplay.media

import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread
import org.junit.Assert.*
import org.junit.Test

class VideoRecoveryDispatcherTest {
    @Test(timeout = 5_000) fun blockedNetworkWriteCannotBlockDecoderAndRequestsRemainBounded() {
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val completed = CountDownLatch(1)
        val sends = AtomicInteger()
        VideoRecoveryDispatcher().use { dispatcher ->
            try {
                val callingThread = Thread.currentThread()
                assertTrue(dispatcher.request({ true }, {
                    assertNotSame(callingThread, Thread.currentThread())
                    sends.incrementAndGet()
                    entered.countDown()
                    check(release.await(3, TimeUnit.SECONDS))
                    true
                }, { completed.countDown() }))
                assertTrue(entered.await(1, TimeUnit.SECONDS))
                val admitted = AtomicInteger()
                val attempted = CountDownLatch(1)
                thread(isDaemon = true) {
                    repeat(1_000) {
                        if (dispatcher.request({ true }, { sends.incrementAndGet(); true })) admitted.incrementAndGet()
                    }
                    attempted.countDown()
                }
                assertTrue("admission must not wait for the event socket", attempted.await(1, TimeUnit.SECONDS))
                assertEquals(0, admitted.get())
                assertEquals(1, sends.get())
                release.countDown()
                assertTrue(completed.await(1, TimeUnit.SECONDS))
            } finally { release.countDown() }
        }
    }

    @Test(timeout = 5_000) fun ownerIsCheckedAgainOnWorkerAndStaleRequestDoesNotSend() {
        val owner = AtomicBoolean(true)
        val checks = AtomicInteger()
        val checkedOnWorker = CountDownLatch(1)
        val release = CountDownLatch(1)
        val completed = CountDownLatch(1)
        val sends = AtomicInteger()
        VideoRecoveryDispatcher().use { dispatcher ->
            try {
                assertTrue(dispatcher.request({
                    if (checks.incrementAndGet() == 2) {
                        checkedOnWorker.countDown()
                        check(release.await(3, TimeUnit.SECONDS))
                    }
                    owner.get()
                }, { sends.incrementAndGet(); true }, {
                    assertFalse(it)
                    completed.countDown()
                }))
                assertTrue(checkedOnWorker.await(1, TimeUnit.SECONDS))
                owner.set(false)
                release.countDown()
                assertTrue(completed.await(1, TimeUnit.SECONDS))
                assertEquals(0, sends.get())
            } finally { release.countDown() }
        }
    }

    @Test(timeout = 5_000) fun failedWriteReleasesAdmissionAndCloseRejectsFurtherWork() {
        val failed = CountDownLatch(1)
        val recovered = CountDownLatch(1)
        val dispatcher = VideoRecoveryDispatcher()
        try {
            assertTrue(dispatcher.request({ true }, { throw IllegalStateException("event unavailable") }, {
                assertFalse(it)
                failed.countDown()
            }))
            assertTrue(failed.await(1, TimeUnit.SECONDS))
            // Completion runs before the in-flight slot is released; allow that worker to exit.
            val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(1)
            var admitted = false
            while (!admitted && System.nanoTime() < deadline) {
                admitted = dispatcher.request({ true }, { true }, { recovered.countDown() })
                if (!admitted) Thread.yield()
            }
            assertTrue(admitted)
            assertTrue(recovered.await(1, TimeUnit.SECONDS))
            dispatcher.close()
            assertFalse(dispatcher.request({ true }, { fail("closed dispatcher wrote a request"); true }))
        } finally { dispatcher.close() }
    }
}
