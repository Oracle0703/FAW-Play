package com.shilapi.xcertplay.network

import android.content.Context
import android.content.BroadcastReceiver
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pGroup
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Looper
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.*
import org.mockito.Mockito.*
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicReference
import java.net.InetAddress

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [29], manifest = Config.NONE)
class WifiP2pGroupManagerTest {
    private class Radio {
        val context = mock(Context::class.java)
        val manager = mock(WifiP2pManager::class.java)
        val channel = mock(WifiP2pManager.Channel::class.java)
        val current = AtomicReference<WifiP2pGroup?>()
        val receiver = AtomicReference<BroadcastReceiver>()
        var createdGroup: WifiP2pGroup? = null
        val requestedConfig = AtomicReference<WifiP2pConfig>()
        val createCalled = CountDownLatch(1)
        val executor = Executors.newSingleThreadExecutor()
        init {
            `when`(context.applicationContext).thenReturn(context)
            `when`(context.getSystemService(WifiP2pManager::class.java)).thenReturn(manager)
            doAnswer { call -> receiver.set(call.getArgument(0)); null }
                .`when`(context).registerReceiver(any(BroadcastReceiver::class.java), any(IntentFilter::class.java))
            `when`(manager.initialize(eq(context), any(Looper::class.java), any(WifiP2pManager.ChannelListener::class.java))).thenReturn(channel)
            doAnswer { call ->
                call.getArgument<WifiP2pManager.GroupInfoListener>(1).onGroupInfoAvailable(current.get()); null
            }.`when`(manager).requestGroupInfo(eq(channel), any(WifiP2pManager.GroupInfoListener::class.java))
            doAnswer { call ->
                current.set(null)
                call.getArgument<WifiP2pManager.ActionListener>(1).onSuccess(); null
            }.`when`(manager).removeGroup(eq(channel), any(WifiP2pManager.ActionListener::class.java))
            doAnswer { call ->
                assertNull("Previous group must be gone before creating a replacement", current.get())
                requestedConfig.set(call.getArgument(1))
                createCalled.countDown()
                if (createdGroup != null) {
                    current.set(createdGroup)
                    call.getArgument<WifiP2pManager.ActionListener>(2).onSuccess()
                } else {
                    call.getArgument<WifiP2pManager.ActionListener>(2).onFailure(WifiP2pManager.ERROR)
                }
                null
            }.`when`(manager).createGroup(eq(channel), any(WifiP2pConfig::class.java), any(WifiP2pManager.ActionListener::class.java))
            doAnswer { call ->
                val info = WifiP2pInfo().apply { groupFormed = true; isGroupOwner = true; groupOwnerAddress = InetAddress.getByName("192.168.49.1") }
                call.getArgument<WifiP2pManager.ConnectionInfoListener>(1).onConnectionInfoAvailable(info); null
            }.`when`(manager).requestConnectionInfo(eq(channel), any(WifiP2pManager.ConnectionInfoListener::class.java))
        }
        fun group(name: String = "DIRECT-test", password: String? = "test-password", owner: Boolean = true, frequencyMHz: Int = 5180) =
            mock(WifiP2pGroup::class.java).also {
                `when`(it.isGroupOwner).thenReturn(owner)
                `when`(it.networkName).thenReturn(name)
                `when`(it.passphrase).thenReturn(password)
                `when`(it.`interface`).thenReturn("p2p-test")
                `when`(it.frequency).thenReturn(frequencyMHz)
            }
        fun startFailure(receiver: WifiP2pGroupManager): Throwable? =
            runCatching { executor.submit<WirelessHotspotInfo> { receiver.start(3_000) }.get(5, TimeUnit.SECONDS) }
                .exceptionOrNull()?.cause
        fun startReady(receiver: WifiP2pGroupManager, group: WifiP2pGroup = group()): WifiP2pGroup {
            createdGroup = group
            executor.submit<WirelessHotspotInfo> { receiver.start(3_000) }.get(5, TimeUnit.SECONDS)
            return group
        }
        fun restoreGroupQuery() {
            doAnswer { call ->
                call.getArgument<WifiP2pManager.GroupInfoListener>(1).onGroupInfoAvailable(current.get()); null
            }.`when`(manager).requestGroupInfo(eq(channel), any(WifiP2pManager.GroupInfoListener::class.java))
        }
        fun assertUntouched() {
            verify(manager, never()).removeGroup(any(), any())
            verify(manager, never()).createGroup(any(), any(WifiP2pConfig::class.java), any())
        }
    }

    @Test fun leftoverConfiguredOwnerGroupIsRemovedBeforeNewCreation() {
        val radio = Radio(); val receiver = WifiP2pGroupManager(radio.context, "DIRECT-test", "test-password")
        try {
            radio.current.set(radio.group())
            assertNotNull(radio.startFailure(receiver))
            assertEquals(0L, radio.createCalled.count)
            verify(radio.manager, times(1)).removeGroup(eq(radio.channel), any())
        } finally { receiver.close(); radio.executor.shutdownNow() }
    }

    @Test @Config(sdk = [30]) fun defaultRequestsSystemSelected5GhzWithNoFixedFrequency() {
        val radio = Radio(); val receiver = WifiP2pGroupManager(radio.context, "DIRECT-test", "test-password")
        try {
            assertNotNull(radio.startFailure(receiver))
            assertEquals(WifiP2pConfig.GROUP_OWNER_BAND_5GHZ, radio.requestedConfig.get().groupOwnerBand)
        } finally { receiver.close(); radio.executor.shutdownNow() }
    }

    @Test @Config(sdk = [30]) fun explicitFrequencyIsRequestedWithoutConflictingBandAndObservedInReturnedGroup() {
        val radio = Radio()
        val receiver = WifiP2pGroupManager(radio.context, "DIRECT-test", "test-password", WirelessRadioSelection.Frequency(5745))
        try {
            radio.createdGroup = radio.group(frequencyMHz = 5745)
            val info = radio.executor.submit<WirelessHotspotInfo> { receiver.start(3_000) }.get(5, TimeUnit.SECONDS)
            // Android stores an exact MHz request in the same slot exposed by getGroupOwnerBand().
            assertEquals(5745, radio.requestedConfig.get().groupOwnerBand)
            assertEquals(5745, info.frequencyMHz)
            assertEquals(149, info.channel)
        } finally { receiver.close(); radio.executor.shutdownNow() }
    }

    @Test fun androidFrequencyRejectionPreservesTypedFailureInsteadOfClaimingSuccess() {
        val radio = Radio()
        val receiver = WifiP2pGroupManager(radio.context, "DIRECT-test", "test-password", WirelessRadioSelection.Frequency(5745))
        try {
            val failure = radio.startFailure(receiver)
            assertTrue(failure is WifiP2pGroupCreationException)
            assertEquals(WifiP2pManager.ERROR, (failure as WifiP2pGroupCreationException).reason)
        } finally { receiver.close(); radio.executor.shutdownNow() }
    }

    @Test fun unrelatedOwnerGroupIsPreserved() {
        val radio = Radio(); val receiver = WifiP2pGroupManager(radio.context, "DIRECT-test", "test-password")
        try {
            radio.current.set(radio.group(name = "DIRECT-other"))
            assertTrue(radio.startFailure(receiver) is P2pResetRequiredException)
            receiver.close(); radio.assertUntouched()
        } finally { receiver.close(); radio.executor.shutdownNow() }
    }

    @Test fun sameNameWithoutMatchingCredentialsIsPreserved() {
        val radio = Radio(); val receiver = WifiP2pGroupManager(radio.context, "DIRECT-test", "test-password")
        try {
            radio.current.set(radio.group(password = null))
            assertTrue(radio.startFailure(receiver) is P2pResetRequiredException)
            receiver.close(); radio.assertUntouched()
        } finally { receiver.close(); radio.executor.shutdownNow() }
    }

    @Test fun clientConnectionIsPreservedEvenWithMatchingCredentials() {
        val radio = Radio(); val receiver = WifiP2pGroupManager(radio.context, "DIRECT-test", "test-password")
        try {
            radio.current.set(radio.group(owner = false))
            assertTrue(radio.startFailure(receiver) is P2pResetRequiredException)
            receiver.close(); radio.assertUntouched()
        } finally { receiver.close(); radio.executor.shutdownNow() }
    }

    @Test fun observedLegacyPeerDepartureReachesCallbackWithoutRemovingOwnerGroup() {
        val radio = Radio(); val receiver = WifiP2pGroupManager(radio.context, "DIRECT-test", "test-password")
        var disconnected = 0
        val mac = "12:34:56:78:ab:cd"
        receiver.setOnPeerDisconnected { assertEquals(mac, it); disconnected++ }
        try {
            val group = radio.group()
            `when`(group.clientList).thenReturn(listOf(WifiP2pDevice().apply { deviceAddress = mac }))
            radio.createdGroup = group
            radio.executor.submit<WirelessHotspotInfo> { receiver.start(3_000) }.get(5, TimeUnit.SECONDS)
            receiver.setActivePeer(mac)
            `when`(group.clientList).thenReturn(emptyList())
            radio.receiver.get().onReceive(radio.context, Intent(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION))
            assertEquals(1, disconnected)
            verify(radio.manager, never()).removeGroup(any(), any())
        } finally { receiver.close(); radio.executor.shutdownNow() }
    }

    @Test fun associationQueryReadsCurrentOwnedClientsWithoutRequiringAnActiveSession() {
        val radio = Radio(); val receiver = WifiP2pGroupManager(radio.context, "DIRECT-test", "test-password")
        try {
            val group = radio.startReady(receiver)
            `when`(group.clientList).thenReturn(listOf(WifiP2pDevice()))
            val results = mutableListOf<Boolean?>()
            receiver.queryHasAssociatedClients { results.add(it) }
            `when`(group.clientList).thenReturn(emptyList())
            receiver.queryHasAssociatedClients { results.add(it) }
            radio.current.set(null)
            receiver.queryHasAssociatedClients { results.add(it) }
            assertEquals(listOf(true, false, false), results)
        } finally { receiver.close(); radio.executor.shutdownNow() }
    }

    @Test fun associationQueryBeforeStartupOrAfterCloseIsUnknownWithoutSystemQuery() {
        val radio = Radio(); val receiver = WifiP2pGroupManager(radio.context, "DIRECT-test", "test-password")
        try {
            val results = mutableListOf<Boolean?>()
            receiver.queryHasAssociatedClients { results.add(it) }
            receiver.close()
            receiver.queryHasAssociatedClients { results.add(it) }
            assertEquals(listOf(null, null), results)
            verify(radio.manager, never()).requestGroupInfo(any(), any())
        } finally { receiver.close(); radio.executor.shutdownNow() }
    }

    @Test fun associationQueryPreservesUnknownForForeignCredentialsOrClientRole() {
        val radio = Radio(); val receiver = WifiP2pGroupManager(radio.context, "DIRECT-test", "test-password")
        try {
            radio.startReady(receiver)
            val results = mutableListOf<Boolean?>()
            for (foreign in listOf(radio.group(name = "DIRECT-other"), radio.group(password = "other-password"), radio.group(owner = false))) {
                `when`(foreign.clientList).thenReturn(listOf(WifiP2pDevice()))
                radio.current.set(foreign)
                receiver.queryHasAssociatedClients { results.add(it) }
            }
            assertEquals(listOf(null, null, null), results)
            verify(radio.manager, never()).removeGroup(any(), any())
        } finally { receiver.close(); radio.executor.shutdownNow() }
    }

    @Test fun associationQueryExceptionAndClientListReadExceptionReturnUnknown() {
        val radio = Radio(); val receiver = WifiP2pGroupManager(radio.context, "DIRECT-test", "test-password")
        try {
            val group = radio.startReady(receiver)
            val results = mutableListOf<Boolean?>()
            doThrow(SecurityException()).`when`(radio.manager).requestGroupInfo(eq(radio.channel), any(WifiP2pManager.GroupInfoListener::class.java))
            receiver.queryHasAssociatedClients { results.add(it) }
            radio.restoreGroupQuery()
            `when`(group.clientList).thenThrow(IllegalStateException())
            receiver.queryHasAssociatedClients { results.add(it) }
            assertEquals(listOf(null, null), results)
        } finally { receiver.close(); radio.executor.shutdownNow() }
    }

    @Test fun duplicateAssociationResponsesAndExceptionAfterResponseCompleteOnlyOnce() {
        val radio = Radio(); val receiver = WifiP2pGroupManager(radio.context, "DIRECT-test", "test-password")
        try {
            val group = radio.startReady(receiver)
            `when`(group.clientList).thenReturn(listOf(WifiP2pDevice()))
            doAnswer { call ->
                val listener = call.getArgument<WifiP2pManager.GroupInfoListener>(1)
                listener.onGroupInfoAvailable(group)
                listener.onGroupInfoAvailable(null)
                throw SecurityException()
            }.`when`(radio.manager).requestGroupInfo(eq(radio.channel), any(WifiP2pManager.GroupInfoListener::class.java))
            val results = mutableListOf<Boolean?>()
            receiver.queryHasAssociatedClients { results.add(it) }
            assertEquals(listOf(true), results)
            radio.restoreGroupQuery()
        } finally { receiver.close(); radio.executor.shutdownNow() }
    }

    @Test fun associationResponseAfterCloseCannotDescribeRetiredGroup() {
        val radio = Radio(); val receiver = WifiP2pGroupManager(radio.context, "DIRECT-test", "test-password")
        try {
            val group = radio.startReady(receiver)
            `when`(group.clientList).thenReturn(listOf(WifiP2pDevice()))
            val pending = AtomicReference<WifiP2pManager.GroupInfoListener>()
            doAnswer { call -> pending.set(call.getArgument(1)); null }
                .`when`(radio.manager).requestGroupInfo(eq(radio.channel), any(WifiP2pManager.GroupInfoListener::class.java))
            val results = mutableListOf<Boolean?>()
            receiver.queryHasAssociatedClients { results.add(it) }
            assertTrue(results.isEmpty())
            radio.restoreGroupQuery(); receiver.close()
            pending.get().onGroupInfoAvailable(group)
            assertEquals(listOf(null), results)
        } finally { receiver.close(); radio.executor.shutdownNow() }
    }
}
