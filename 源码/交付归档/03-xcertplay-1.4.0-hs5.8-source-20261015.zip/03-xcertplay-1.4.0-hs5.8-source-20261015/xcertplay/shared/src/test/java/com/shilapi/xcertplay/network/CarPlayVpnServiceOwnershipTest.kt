package com.shilapi.xcertplay.network

import com.shilapi.xcertplay.airplay.*
import java.net.ServerSocket
import java.net.InetAddress
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class CarPlayVpnServiceOwnershipTest {
    @Test
    fun wirelessListenerBindsToTheAdvertisedHotspotAddress() {
        val fixture = Fixture()
        try {
            val hotspotAddress = InetAddress.getByName("127.0.0.1")
            fixture.attach(bindAddress = hotspotAddress)
            val socket = fixture.service.javaClass.getDeclaredField("serverSocket").apply {
                isAccessible = true
            }.get(fixture.service) as ServerSocket
            assertEquals(hotspotAddress, socket.inetAddress)
        } finally { fixture.close() }
    }

    @Test
    fun wirelessAttachDoesNotEstablishAnAndroidVpnTunnel() {
        val fixture = Fixture()
        try {
            fixture.attach()
            val tun = fixture.service.javaClass.getDeclaredField("tun").apply {
                isAccessible = true
            }.get(fixture.service)
            val bridge = fixture.service.javaClass.getDeclaredField("bridge").apply {
                isAccessible = true
            }.get(fixture.service)
            assertNull(tun)
            assertNull(bridge)
        } finally { fixture.close() }
    }

    @Test
    fun staleOwnerCannotDetachReplacementEvenWhenOwnersCompareEqual() {
        val fixture = Fixture()
        data class Owner(val value: Int)
        val previous = Owner(1)
        val replacement = Owner(1)
        assertEquals(previous, replacement)
        assertNotSame(previous, replacement)
        try {
            fixture.attach(previous)
            fixture.attach(replacement)

            fixture.service.detach(previous)
            assertTrue(fixture.service.isAttached())

            fixture.service.detach(replacement)
            assertFalse(fixture.service.isAttached())
        } finally { fixture.close() }
    }

    @Test
    fun scopedCleanupCannotReleaseAnUnownedLegacyAttachment() {
        val fixture = Fixture()
        try {
            fixture.attach()
            fixture.service.detach(Any())
            assertTrue(fixture.service.isAttached())

            fixture.service.detach()
            assertFalse(fixture.service.isAttached())
        } finally { fixture.close() }
    }

    @Test
    fun unscopedDetachRetainsItsLegacyBehaviorForOwnedAttachments() {
        val fixture = Fixture()
        try {
            fixture.attach(Any())
            fixture.service.detach()
            assertFalse(fixture.service.isAttached())
        } finally { fixture.close() }
    }

    private class Fixture {
        private val lifecycle = Robolectric.buildService(CarPlayVpnService::class.java).create()
        val service = lifecycle.get()
        private val config = AirPlayConfig(
            "test", "test", "", "1", AirPlayDisplayConfig(800, 480),
            port = ServerSocket(0).use { it.localPort },
        )
        private val identity = AirPlayIdentity.generate()
        fun attach(owner: Any? = null, bindAddress: InetAddress? = null) {
            assertEquals(
                CarPlayVpnService.AttachResult.Started,
                service.attachWireless(config, identity, PairingStore(), null,
                    object : AirPlaySessionListener {}, object : AirPlayMediaHandler {}, owner,
                    bindAddress),
            )
        }
        fun close() {
            service.detach()
            lifecycle.destroy()
        }
    }
}
