package com.shilapi.xcertplay.orchestration

import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import org.junit.Assert.*
import org.junit.Test

class WirelessPairingSignalTest {
    @Test
    fun timeoutDoesNotPretendThatAnotherPairingEventOccurred() {
        val signal = WirelessPairingSignal()
        try { assertFalse(signal.awaitChange(signal.revision(), 10)) } finally { signal.close() }
    }

    @Test
    fun retryRevisionChangesOnlyForTheDeviceNamedByAnEvent() {
        val signal = WirelessPairingSignal()
        try {
            signal.signal("phone-a")
            val first = signal.deviceRevision("phone-a")
            signal.signal("phone-b")
            signal.signal()
            assertEquals(first, signal.deviceRevision("phone-a"))
            assertTrue(signal.deviceRevision("phone-b") > first)
            assertEquals(0L, signal.deviceRevision("unrelated"))
        } finally { signal.close() }
    }

    @Test
    fun completedBondDuringDeviceReadIsNotLost() {
        val signal = WirelessPairingSignal()
        val beforeRead = signal.revision()
        signal.signal()
        assertTrue(signal.awaitChange(beforeRead, 120_000))
        signal.close()
    }

    @Test
    fun closePromptlyEndsLongPairingWait() {
        val signal = WirelessPairingSignal()
        val worker = Executors.newSingleThreadExecutor()
        val started = CountDownLatch(1)
        try {
            val waiting = worker.submit<Boolean> {
                val revision = signal.revision()
                started.countDown()
                signal.awaitChange(revision, 120_000)
            }
            assertTrue(started.await(1, TimeUnit.SECONDS))
            signal.close()
            assertFalse(waiting.get(1, TimeUnit.SECONDS))
        } finally { signal.close(); worker.shutdownNow() }
    }
}
