package com.shilapi.xcertplay.network

import android.content.Context
import android.content.BroadcastReceiver
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pGroup
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Looper
import android.provider.Settings
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.*
import org.mockito.Mockito.*
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.net.InetAddress
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicReference

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class HongqiWifiP2pGroupManagerTest {
    private class Radio {
        val app = RuntimeEnvironment.getApplication()
        val context = mock(Context::class.java)
        val manager = mock(WifiP2pManager::class.java)
        val channel = mock(WifiP2pManager.Channel::class.java)
        val current = AtomicReference<WifiP2pGroup?>()
        val receiver = AtomicReference<BroadcastReceiver>()
        val action = AtomicReference<WifiP2pManager.ActionListener>()
        val createCalled = CountDownLatch(1)
        val removed = CountDownLatch(1)
        val prefs = app.getSharedPreferences("hs5_p2p_ownership", 0)
        val executor = Executors.newSingleThreadExecutor()
        init {
            prefs.edit().clear().commit()
            `when`(context.applicationContext).thenReturn(context)
            `when`(context.packageName).thenReturn("test.hs5")
            `when`(context.contentResolver).thenReturn(app.contentResolver)
            `when`(context.getSharedPreferences(anyString(), anyInt())).thenReturn(prefs)
            `when`(context.getSystemService(WifiP2pManager::class.java)).thenReturn(manager)
            doAnswer { call -> receiver.set(call.getArgument(0)); null }
                .`when`(context).registerReceiver(any(BroadcastReceiver::class.java), any(IntentFilter::class.java))
            `when`(manager.initialize(eq(context), any(Looper::class.java), any(WifiP2pManager.ChannelListener::class.java))).thenReturn(channel)
            doAnswer { call ->
                call.getArgument<WifiP2pManager.GroupInfoListener>(1).onGroupInfoAvailable(current.get()); null
            }.`when`(manager).requestGroupInfo(eq(channel), any(WifiP2pManager.GroupInfoListener::class.java))
            doAnswer { call ->
                action.set(call.getArgument(1)); createCalled.countDown(); null
            }.`when`(manager).createGroup(eq(channel), any(WifiP2pManager.ActionListener::class.java))
            doAnswer { call ->
                current.set(null)
                call.getArgument<WifiP2pManager.ActionListener>(1).onSuccess(); removed.countDown(); null
            }.`when`(manager).removeGroup(eq(channel), any(WifiP2pManager.ActionListener::class.java))
            doAnswer { call ->
                val info = WifiP2pInfo().apply { groupFormed = true; isGroupOwner = true; groupOwnerAddress = InetAddress.getByName("192.168.49.1") }
                call.getArgument<WifiP2pManager.ConnectionInfoListener>(1).onConnectionInfoAvailable(info); null
            }.`when`(manager).requestConnectionInfo(eq(channel), any(WifiP2pManager.ConnectionInfoListener::class.java))
        }
        fun group(ours: Boolean = true): WifiP2pGroup {
            val id = Settings.Secure.getString(app.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
            val name = if (ours) "DIRECT-ab-${P2pOwnership.deviceName(P2pOwnership.prefix("test.hs5", id))}" else "DIRECT-ab-other-device"
            return mock(WifiP2pGroup::class.java).also {
                `when`(it.isGroupOwner).thenReturn(true)
                `when`(it.networkName).thenReturn(name)
                `when`(it.passphrase).thenReturn("test-password")
                `when`(it.`interface`).thenReturn("hs5-test")
            }
        }
        fun assertNotRemoved() { verify(manager, never()).removeGroup(any(), any()) }
        fun startReady(receiver: HongqiWifiP2pGroupManager, group: WifiP2pGroup = group()): WifiP2pGroup {
            val startup = executor.submit<WirelessHotspotInfo> { receiver.start(5_000) }
            assertTrue(createCalled.await(3, TimeUnit.SECONDS))
            current.set(group); action.get().onSuccess()
            startup.get(3, TimeUnit.SECONDS)
            return group
        }
        fun restoreGroupQuery() {
            doAnswer { call ->
                call.getArgument<WifiP2pManager.GroupInfoListener>(1).onGroupInfoAvailable(current.get()); null
            }.`when`(manager).requestGroupInfo(eq(channel), any(WifiP2pManager.GroupInfoListener::class.java))
        }
        fun close() { executor.shutdownNow() }
    }

    @Test fun foreignGroupIsLeftIntact() {
        val radio = Radio(); val receiver = HongqiWifiP2pGroupManager(radio.context)
        try {
            radio.current.set(radio.group(false))
            val startup = radio.executor.submit<WirelessHotspotInfo> { receiver.start(3_000) }
            val error = runCatching { startup.get(5, TimeUnit.SECONDS) }.exceptionOrNull()
            assertTrue(error is ExecutionException && error.cause is P2pResetRequiredException)
            receiver.close(); radio.assertNotRemoved()
            verify(radio.manager, never()).createGroup(any(), any())
        } finally { receiver.close(); radio.close() }
    }

    @Test fun cancellationRemovesLateSuccessfulOwnedGroup() {
        val radio = Radio(); val receiver = HongqiWifiP2pGroupManager(radio.context)
        try {
            val startup = radio.executor.submit<WirelessHotspotInfo> { receiver.start(5_000) }
            assertTrue(radio.createCalled.await(3, TimeUnit.SECONDS))
            receiver.close()
            assertNotNull(runCatching { startup.get(3, TimeUnit.SECONDS) }.exceptionOrNull())
            radio.current.set(radio.group())
            radio.action.get().onSuccess()
            assertTrue(radio.removed.await(3, TimeUnit.SECONDS))
        } finally { receiver.close(); radio.close() }
    }

    @Test fun canceledCallbackCannotRemoveAnotherReceiversGroup() {
        val radio = Radio(); val receiver = HongqiWifiP2pGroupManager(radio.context)
        try {
            val startup = radio.executor.submit<WirelessHotspotInfo> { receiver.start(5_000) }
            assertTrue(radio.createCalled.await(3, TimeUnit.SECONDS))
            receiver.close(); runCatching { startup.get(3, TimeUnit.SECONDS) }
            radio.current.set(radio.group())
            radio.prefs.edit().putString("owner_token", "replacement-owner").commit()
            radio.action.get().onSuccess()
            radio.assertNotRemoved()
        } finally { receiver.close(); radio.close() }
    }

    @Test fun systemCredentialsAndUnknownChannelAreImmediatelyUsable() {
        val radio = Radio(); val receiver = HongqiWifiP2pGroupManager(radio.context)
        try {
            val startup = radio.executor.submit<WirelessHotspotInfo> { receiver.start(5_000) }
            assertTrue(radio.createCalled.await(3, TimeUnit.SECONDS))
            radio.current.set(radio.group()); radio.action.get().onSuccess()
            val info = startup.get(3, TimeUnit.SECONDS)
            assertEquals("test-password", info.passphrase)
            assertEquals(0, info.channel); assertNull(info.frequencyMHz)
            assertEquals("192.168.49.1", info.hostAddress!!.hostAddress)
            receiver.close(); assertTrue(radio.removed.await(3, TimeUnit.SECONDS))
        } finally { receiver.close(); radio.close() }
    }

    @Test fun explicitFrequencyOnApi28IsNotReportedAsApplied() {
        val radio = Radio()
        val diagnostics = mutableListOf<String>()
        val receiver = HongqiWifiP2pGroupManager(radio.context, diagnostics::add, WirelessRadioSelection.Frequency(5745))
        try {
            val startup = radio.executor.submit<WirelessHotspotInfo> { receiver.start(5_000) }
            assertTrue(radio.createCalled.await(3, TimeUnit.SECONDS))
            radio.current.set(radio.group()); radio.action.get().onSuccess()
            val info = startup.get(3, TimeUnit.SECONDS)
            assertEquals(0, info.channel); assertNull(info.frequencyMHz)
            assertTrue(diagnostics.any { it.contains("no_public_frequency_control") })
            assertTrue(diagnostics.any { it.contains("explicit frequency request ignored") })
        } finally { receiver.close(); radio.close() }
    }

    @Test fun observedLegacyPeerDepartureReachesCallbackWithoutRemovingOwnerGroup() {
        val radio = Radio(); val receiver = HongqiWifiP2pGroupManager(radio.context)
        var disconnected = 0
        val mac = "12:34:56:78:ab:cd"
        receiver.setOnPeerDisconnected { assertEquals(mac, it); disconnected++ }
        try {
            val startup = radio.executor.submit<WirelessHotspotInfo> { receiver.start(5_000) }
            assertTrue(radio.createCalled.await(3, TimeUnit.SECONDS))
            val group = radio.group()
            `when`(group.clientList).thenReturn(listOf(WifiP2pDevice().apply { deviceAddress = mac }))
            radio.current.set(group); radio.action.get().onSuccess()
            startup.get(3, TimeUnit.SECONDS)
            receiver.setActivePeer(mac)
            `when`(group.clientList).thenReturn(emptyList())
            radio.receiver.get().onReceive(radio.context, Intent(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION))
            assertEquals(1, disconnected)
            radio.assertNotRemoved()
        } finally { receiver.close(); radio.close() }
    }

    @Test fun associationQueryReadsCurrentOwnedClientsBeforeAnAirPlaySessionExists() {
        val radio = Radio(); val receiver = HongqiWifiP2pGroupManager(radio.context)
        try {
            val group = radio.startReady(receiver)
            `when`(group.clientList).thenReturn(listOf(WifiP2pDevice()))
            val results = mutableListOf<Boolean?>()
            receiver.queryHasAssociatedClients { results.add(it) }
            `when`(group.clientList).thenReturn(emptyList())
            receiver.queryHasAssociatedClients { results.add(it) }
            radio.current.set(null)
            receiver.queryHasAssociatedClients { results.add(it) }
            assertEquals(listOf(true, false, false), results)
        } finally { receiver.close(); radio.close() }
    }

    @Test fun associationQueryBeforeStartupAndAfterCloseIsUnknownWithoutQueryingSystem() {
        val radio = Radio(); val receiver = HongqiWifiP2pGroupManager(radio.context)
        try {
            val results = mutableListOf<Boolean?>()
            receiver.queryHasAssociatedClients { results.add(it) }
            receiver.close()
            receiver.queryHasAssociatedClients { results.add(it) }
            assertEquals(listOf(null, null), results)
            verify(radio.manager, never()).requestGroupInfo(any(), any())
        } finally { receiver.close(); radio.close() }
    }

    @Test fun associationQueryFromForeignGroupOrClientRoleIsUnknown() {
        val radio = Radio(); val receiver = HongqiWifiP2pGroupManager(radio.context)
        try {
            radio.startReady(receiver)
            val foreign = radio.group(false)
            `when`(foreign.clientList).thenReturn(listOf(WifiP2pDevice()))
            radio.current.set(foreign)
            val results = mutableListOf<Boolean?>()
            receiver.queryHasAssociatedClients { results.add(it) }
            val client = radio.group()
            `when`(client.isGroupOwner).thenReturn(false)
            radio.current.set(client)
            receiver.queryHasAssociatedClients { results.add(it) }
            assertEquals(listOf(null, null), results)
            verify(radio.manager, never()).removeGroup(any(), any())
        } finally { receiver.close(); radio.close() }
    }

    @Test fun associationQueryExceptionAndClientListReadExceptionAreUnknown() {
        val radio = Radio(); val receiver = HongqiWifiP2pGroupManager(radio.context)
        try {
            val group = radio.startReady(receiver)
            val results = mutableListOf<Boolean?>()
            doThrow(SecurityException()).`when`(radio.manager).requestGroupInfo(eq(radio.channel), any(WifiP2pManager.GroupInfoListener::class.java))
            receiver.queryHasAssociatedClients { results.add(it) }
            radio.restoreGroupQuery()
            `when`(group.clientList).thenThrow(IllegalStateException())
            receiver.queryHasAssociatedClients { results.add(it) }
            assertEquals(listOf(null, null), results)
        } finally { receiver.close(); radio.close() }
    }

    @Test fun duplicateAssociationCallbacksAndLateExceptionCompleteOnlyOnce() {
        val radio = Radio(); val receiver = HongqiWifiP2pGroupManager(radio.context)
        try {
            val group = radio.startReady(receiver)
            `when`(group.clientList).thenReturn(listOf(WifiP2pDevice()))
            doAnswer { call ->
                val listener = call.getArgument<WifiP2pManager.GroupInfoListener>(1)
                listener.onGroupInfoAvailable(group)
                listener.onGroupInfoAvailable(null)
                throw SecurityException()
            }.`when`(radio.manager).requestGroupInfo(eq(radio.channel), any(WifiP2pManager.GroupInfoListener::class.java))
            val results = mutableListOf<Boolean?>()
            receiver.queryHasAssociatedClients { results.add(it) }
            assertEquals(listOf(true), results)
            radio.restoreGroupQuery()
        } finally { receiver.close(); radio.close() }
    }

    @Test fun associationResponseAfterCloseIsUnknown() {
        val radio = Radio(); val receiver = HongqiWifiP2pGroupManager(radio.context)
        try {
            val group = radio.startReady(receiver)
            `when`(group.clientList).thenReturn(listOf(WifiP2pDevice()))
            val pending = AtomicReference<WifiP2pManager.GroupInfoListener>()
            doAnswer { call -> pending.set(call.getArgument(1)); null }
                .`when`(radio.manager).requestGroupInfo(eq(radio.channel), any(WifiP2pManager.GroupInfoListener::class.java))
            val results = mutableListOf<Boolean?>()
            receiver.queryHasAssociatedClients { results.add(it) }
            assertTrue(results.isEmpty())
            radio.restoreGroupQuery(); receiver.close()
            pending.get().onGroupInfoAvailable(group)
            assertEquals(listOf(null), results)
        } finally { receiver.close(); radio.close() }
    }

    @Test fun associationResponseAfterOwnershipReplacementIsUnknown() {
        val radio = Radio(); val receiver = HongqiWifiP2pGroupManager(radio.context)
        try {
            val group = radio.startReady(receiver)
            `when`(group.clientList).thenReturn(listOf(WifiP2pDevice()))
            val pending = AtomicReference<WifiP2pManager.GroupInfoListener>()
            doAnswer { call -> pending.set(call.getArgument(1)); null }
                .`when`(radio.manager).requestGroupInfo(eq(radio.channel), any(WifiP2pManager.GroupInfoListener::class.java))
            val results = mutableListOf<Boolean?>()
            receiver.queryHasAssociatedClients { results.add(it) }
            radio.prefs.edit().putString("owner_token", "replacement-owner").commit()
            pending.get().onGroupInfoAvailable(group)
            assertEquals(listOf(null), results)
            radio.restoreGroupQuery()
        } finally { receiver.close(); radio.close() }
    }
}
