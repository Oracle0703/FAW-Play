package com.shilapi.xcertplay.airplay

import java.net.InetAddress
import org.junit.Assert.*
import org.junit.Test

class MicrophoneRtpClockTest {
    @Test fun fiftyPacketsAdvanceOneSecondAtEachExplicitClock() {
        for (clock in listOf(16_000, 24_000, 48_000)) {
            val config = config(clock)
            val counters = MicrophoneCounters()
            repeat(50) { index ->
                val body = byteArrayOf(index.toByte())
                val packet = MicrophonePacketizer.sealPacket(config.key, config.payloadType, counters, body, config.rtpSamplesPerPacket)
                val timestamp = (4..7).fold(0) { value, i -> (value shl 8) or (packet[i].toInt() and 255) }
                assertEquals(index * config.rtpSamplesPerPacket, timestamp)
                val sealedEnd = packet.size - MicrophonePacketizer.NONCE_LEN
                val nonce = ByteArray(12)
                packet.copyInto(nonce, 4, sealedEnd, packet.size)
                assertArrayEquals(body, AirPlayCrypto.chachaOpen(config.key, nonce,
                    packet.copyOfRange(MicrophonePacketizer.RTP_HEADER_LEN, sealedEnd),
                    packet.copyOfRange(4, MicrophonePacketizer.RTP_HEADER_LEN)))
            }
            assertEquals(clock, counters.timestamp)
            assertEquals(50, counters.sequence)
            assertEquals(50L, counters.nonce)
        }
    }

    @Test fun originalJavaConstructorKeepsGenericOpusClock() {
        val ctor = MicrophoneConfig::class.java.getConstructor(String::class.java,
            Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType,
            Int::class.javaPrimitiveType, InetAddress::class.java, Int::class.javaPrimitiveType,
            ByteArray::class.java, AudioCodecKind::class.java, Integer::class.java)
        val generic = ctor.newInstance("telephony", 16_000, 1, 100, 20,
            InetAddress.getLoopbackAddress(), 32001, ByteArray(32), AudioCodecKind.OPUS, 48_000)
        assertEquals(16_000, generic.sampleRate)
        assertEquals(48_000, generic.rtpClockRate)
        assertEquals(960, generic.rtpSamplesPerPacket)
    }

    private fun config(clock: Int) = MicrophoneConfig(
        "telephony", 48_000, 1, 100, 20, InetAddress.getLoopbackAddress(), 32001,
        ByteArray(32), AudioCodecKind.OPUS, 48_000, clock,
    )
}
