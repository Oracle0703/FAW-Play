package com.shilapi.xcertplay.media

import android.media.AudioManager
import org.junit.Assert.*
import org.junit.Test

class AudioModeLeaseManagerTest {
    @Test fun hs5ReleasesItsRequestInsteadOfAdoptingAnEndedFactoryCall() {
        val server = ModeServer().apply { factoryMode = AudioManager.MODE_IN_CALL }
        val manager = hs5(server)
        val lease = manager.acquire()
        assertEquals(AudioManager.MODE_IN_COMMUNICATION, server.appMode)
        server.factoryMode = AudioManager.MODE_NORMAL
        lease.close()
        assertEquals(AudioManager.MODE_NORMAL, server.appMode)
        assertEquals(AudioManager.MODE_NORMAL, server.globalMode())
    }

    @Test fun hs5ReleaseLeavesALiveFactoryCallInControlOfGlobalMode() {
        val server = ModeServer().apply { factoryMode = AudioManager.MODE_IN_CALL }
        val lease = hs5(server).acquire()
        // The factory may keep the global call mode while our communication request exists.
        assertEquals(AudioManager.MODE_IN_CALL, server.globalMode())
        lease.close()
        assertEquals(AudioManager.MODE_NORMAL, server.appMode)
        assertEquals(AudioManager.MODE_IN_CALL, server.globalMode())
    }

    @Test fun hs5ClaimsItsOwnRequestEvenWhenCommunicationModeIsAlreadyGlobal() {
        val server = ModeServer().apply { factoryMode = AudioManager.MODE_IN_COMMUNICATION }
        val lease = hs5(server).acquire()
        assertEquals(listOf(AudioManager.MODE_IN_COMMUNICATION), server.writes)
        server.factoryMode = AudioManager.MODE_NORMAL
        assertEquals(AudioManager.MODE_IN_COMMUNICATION, server.globalMode())
        lease.close()
        assertEquals(AudioManager.MODE_NORMAL, server.globalMode())
    }

    @Test fun overlappingRecordersReleaseOnceAfterTheLastClose() {
        val server = ModeServer()
        val manager = hs5(server)
        val first = manager.acquire()
        val second = manager.acquire()
        first.close()
        first.close()
        assertEquals(AudioManager.MODE_IN_COMMUNICATION, server.appMode)
        second.close()
        second.close()
        assertEquals(listOf(AudioManager.MODE_IN_COMMUNICATION, AudioManager.MODE_NORMAL), server.writes)
    }

    @Test fun genericDeviceRetainsItsPreviousModeRestoration() {
        var mode = AudioManager.MODE_RINGTONE
        val writes = mutableListOf<Int>()
        val manager = AudioModeLeaseManager(
            readMode = { mode }, writeMode = { writes.add(it); mode = it },
            communicationMode = AudioManager.MODE_IN_COMMUNICATION,
        )
        val first = manager.acquire()
        val second = manager.acquire()
        first.close()
        assertEquals(AudioManager.MODE_IN_COMMUNICATION, mode)
        second.close()
        assertEquals(AudioManager.MODE_RINGTONE, mode)
        assertEquals(listOf(AudioManager.MODE_IN_COMMUNICATION, AudioManager.MODE_RINGTONE), writes)
    }

    private fun hs5(server: ModeServer) = AudioModeLeaseManager(
        readMode = server::globalMode,
        writeMode = { server.writes.add(it); server.appMode = it },
        communicationMode = AudioManager.MODE_IN_COMMUNICATION,
        releaseMode = AudioManager.MODE_NORMAL,
    )

    /** Models the platform's caller ownership, rather than treating mode as a plain global field. */
    private class ModeServer {
        var factoryMode = AudioManager.MODE_NORMAL
        var appMode = AudioManager.MODE_NORMAL
        val writes = mutableListOf<Int>()
        fun globalMode(): Int = if (factoryMode != AudioManager.MODE_NORMAL) factoryMode else appMode
    }
}
