package com.shilapi.xcertplay.orchestration

import android.os.Looper
import com.shilapi.xcertplay.airplay.AirPlayConfig
import com.shilapi.xcertplay.airplay.AirPlayDisplayConfig
import com.shilapi.xcertplay.airplay.AirPlayIdentity
import com.shilapi.xcertplay.airplay.AirPlayMediaHandler
import com.shilapi.xcertplay.airplay.AirPlaySession
import com.shilapi.xcertplay.airplay.AirPlaySessionListener
import com.shilapi.xcertplay.airplay.PairingStore
import com.shilapi.xcertplay.transport.Iap2IdentificationConfig
import java.net.Socket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class CarPlayUiAttachmentTest {
    @Test
    fun attachingDuringDetachedSessionCleanupReplaysDisconnectBeforeOldStatus() {
        val fixture = Fixture()
        val release = CountDownLatch(1)
        val cleaning = CountDownLatch(1)
        val session = fixture.session(object : AirPlayMediaHandler {
            override fun onSessionClosed(session: AirPlaySession) {
                cleaning.countDown()
                check(release.await(5, TimeUnit.SECONDS))
            }
        })
        fixture.internalListener.onSessionActive(session)
        assertTrue(fixture.controller.detachUi(fixture.originalUi))
        val worker = Thread { session.close() }.apply { start() }
        try {
            assertTrue(cleaning.await(3, TimeUnit.SECONDS))
            val reattached = RecordingUi()
            fixture.controller.attachUi(reattached, reattached::status)
            shadowOf(Looper.getMainLooper()).idle()

            assertEquals(listOf("disconnected"), reattached.events)
            assertSame(session, reattached.disconnectedSession)
            assertTrue("The media cleanup is still blocked", worker.isAlive)
        } finally {
            release.countDown()
            worker.join(3_000)
            fixture.close()
        }
        assertFalse(worker.isAlive)
    }

    @Test
    fun supersededAndDetachedAttachmentsCannotReceiveQueuedDisconnectReplay() {
        val fixture = Fixture()
        val session = fixture.session()
        session.close()
        fixture.setActiveSession(session)
        val superseded = RecordingUi()
        val detached = RecordingUi()
        val current = RecordingUi()
        try {
            fixture.controller.attachUi(superseded, superseded::status)
            fixture.controller.attachUi(detached, detached::status)
            assertTrue(fixture.controller.detachUi(detached))
            shadowOf(Looper.getMainLooper()).idle()
            assertTrue(superseded.events.isEmpty())
            assertTrue(detached.events.isEmpty())

            fixture.controller.attachUi(current, current::status)
            shadowOf(Looper.getMainLooper()).idle()
            assertEquals(listOf("disconnected"), current.events)
        } finally { fixture.close() }
    }

    @Test
    fun replacementSessionBeforeAttachmentReplayDoesNotReplayOldDisconnect() {
        val fixture = Fixture()
        val old = fixture.session()
        val replacement = fixture.session()
        old.close()
        fixture.setActiveSession(old)
        val current = RecordingUi()
        try {
            fixture.controller.attachUi(current, current::status)
            fixture.internalListener.onSessionActive(replacement)
            shadowOf(Looper.getMainLooper()).idle()

            assertEquals(listOf("active", "status"), current.events)
            assertNull(current.disconnectedSession)
        } finally { replacement.close(); fixture.close() }
    }

    private class RecordingUi : AirPlaySessionListener {
        val events = mutableListOf<String>()
        var disconnectedSession: AirPlaySession? = null
        override fun onSessionActive(session: AirPlaySession) { events += "active" }
        override fun onSessionDisconnected(session: AirPlaySession) {
            assertSame(Looper.getMainLooper(), Looper.myLooper())
            disconnectedSession = session
            events += "disconnected"
        }
        fun status(status: CarPlayStatus) {
            assertEquals(CarPlayStatus.WirelessActive, status)
            events += "status"
        }
    }

    private class Fixture {
        val originalUi = RecordingUi()
        private val config = AirPlayConfig("test", "test", "", "1", AirPlayDisplayConfig(800, 480))
        private val identity = AirPlayIdentity.generate()
        val controller = CarPlayController(
            context = RuntimeEnvironment.getApplication(),
            config = CarPlayRuntimeConfig(
                mfiTarget = MfiTarget.REMOTE,
                remoteMfiServer = "https://mfi.example.test",
                identification = Iap2IdentificationConfig("test", "test", "test", "test", "1", "1", 3),
            ),
            airPlayConfig = config,
            identity = identity,
            pairings = PairingStore(),
            listener = originalUi,
            media = object : AirPlayMediaHandler {},
            reportStatus = originalUi::status,
        )
        val internalListener = field("sessionListener").get(controller) as AirPlaySessionListener
        init { field("lastReportedStatus").set(controller, CarPlayStatus.WirelessActive) }
        fun session(media: AirPlayMediaHandler = object : AirPlayMediaHandler {}) = AirPlaySession(
            Socket(), config, identity, PairingStore(), null, internalListener, media,
        )
        fun setActiveSession(session: AirPlaySession) { field("activeSession").set(controller, session) }
        fun close() {
            controller.close()
            assertTrue(controller.awaitClosed(3_000))
            shadowOf(Looper.getMainLooper()).idle()
        }
        private fun field(name: String) = CarPlayController::class.java.getDeclaredField(name)
            .apply { isAccessible = true }
    }
}
