package com.shilapi.xcertplay.network

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.p2p.WifiP2pGroup
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.*
import org.mockito.Mockito.*
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.atomic.AtomicReference

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28, 33], manifest = Config.NONE)
class P2pGroupLossMonitorTest {
    private class Radio {
        val context = mock(Context::class.java)
        val manager = mock(WifiP2pManager::class.java)
        val channel = mock(WifiP2pManager.Channel::class.java)
        val group = mock(WifiP2pGroup::class.java)
        val current = AtomicReference<WifiP2pGroup?>(group)
        val receiver = AtomicReference<BroadcastReceiver>()
        val pending = AtomicReference<WifiP2pManager.GroupInfoListener>()
        var deferQuery = false
        var queryFailure = false
        var lost = 0
        var peerLost = 0
        val monitor = P2pGroupLossMonitor(context, manager, channel,
            onGroupLost = { lost++ }, onPeerDisconnected = { peerLost++ })
        init {
            `when`(group.clientList).thenReturn(emptyList())
            doAnswer { call -> receiver.set(call.getArgument(0)); null }
                .`when`(context).registerReceiver(any(BroadcastReceiver::class.java), any(IntentFilter::class.java))
            doAnswer { call -> receiver.set(call.getArgument(0)); null }
                .`when`(context).registerReceiver(any(BroadcastReceiver::class.java), any(IntentFilter::class.java), anyInt())
            doAnswer { call ->
                if (queryFailure) throw SecurityException("test query unavailable")
                val listener = call.getArgument<WifiP2pManager.GroupInfoListener>(1)
                if (deferQuery) pending.set(listener) else listener.onGroupInfoAvailable(current.get())
                null
            }.`when`(manager).requestGroupInfo(eq(channel), any(WifiP2pManager.GroupInfoListener::class.java))
        }
        fun broadcast(action: String = WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION) {
            receiver.get().onReceive(context, Intent(action))
        }
        fun clients(vararg addresses: String) {
            `when`(group.clientList).thenReturn(addresses.map { WifiP2pDevice().apply { deviceAddress = it } })
        }
    }

    @Test fun confirmedGroupRemovalReportsOnceWithoutChangingRadio() {
        val radio = Radio()
        try {
            radio.monitor.start()
            assertEquals(0, radio.lost)
            radio.current.set(null)
            radio.broadcast()
            radio.broadcast(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            assertEquals(1, radio.lost)
            verify(radio.manager, never()).removeGroup(any(), any())
        } finally { radio.monitor.close() }
    }

    @Test fun existingGroupWithNoP2pClientsDoesNotEndLegacyStaSession() {
        val radio = Radio()
        try {
            radio.monitor.start()
            radio.broadcast()
            radio.broadcast(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            assertEquals(0, radio.lost)
            verify(radio.group, never()).clientList
        } finally { radio.monitor.close() }
    }

    @Test fun queryFailureDoesNotClaimLinkLoss() {
        val radio = Radio()
        try {
            radio.monitor.start()
            radio.queryFailure = true
            radio.current.set(null)
            radio.broadcast()
            assertEquals(0, radio.lost)
        } finally { radio.monitor.close() }
    }

    @Test fun intentionalCloseDisarmsPendingQueriesAndUnregisters() {
        val radio = Radio()
        radio.monitor.start()
        radio.deferQuery = true
        radio.broadcast()
        radio.monitor.close()
        radio.pending.get().onGroupInfoAvailable(null)
        radio.current.set(null)
        radio.broadcast()
        assertEquals(0, radio.lost)
        verify(radio.context, times(1)).unregisterReceiver(eq(radio.receiver.get()))
    }

    @Test fun groupLostBeforeReceiverRegistrationIsDetected() {
        val radio = Radio()
        try {
            radio.current.set(null)
            radio.monitor.start()
            assertEquals(1, radio.lost)
        } finally { radio.monitor.close() }
    }

    @Test fun receiverUsesFlagsRequiredOnNewAndroid() {
        val radio = Radio()
        try {
            radio.monitor.start()
            if (Build.VERSION.SDK_INT >= 33) {
                verify(radio.context).registerReceiver(any(), any(), eq(Context.RECEIVER_EXPORTED))
            } else {
                verify(radio.context).registerReceiver(any(), any(IntentFilter::class.java))
            }
        } finally { radio.monitor.close() }
    }

    @Test fun trackedPeerDepartureReportsOnceWhileOwnerGroupRemains() {
        val radio = Radio()
        try {
            radio.clients(PEER)
            radio.monitor.start()
            radio.monitor.setActivePeer(PEER.uppercase())
            assertEquals(0, radio.peerLost)
            radio.clients()
            radio.broadcast()
            radio.broadcast()
            assertEquals(1, radio.peerLost)
            assertEquals(0, radio.lost)
            verify(radio.manager, never()).removeGroup(any(), any())
        } finally { radio.monitor.close() }
    }

    @Test fun initiallyEmptyOrUnmatchedClientsNeverClaimPeerDeparture() {
        val radio = Radio()
        try {
            radio.monitor.start()
            radio.monitor.setActivePeer(PEER)
            radio.broadcast()
            radio.clients(OTHER)
            radio.broadcast()
            radio.clients()
            radio.broadcast()
            assertEquals(0, radio.peerLost)
        } finally { radio.monitor.close() }
    }

    @Test fun anotherClientLeavingDoesNotDisconnectObservedPeer() {
        val radio = Radio()
        try {
            radio.clients(PEER, OTHER)
            radio.monitor.start()
            radio.monitor.setActivePeer(PEER)
            radio.clients(PEER)
            radio.broadcast()
            assertEquals(0, radio.peerLost)
        } finally { radio.monitor.close() }
    }

    @Test fun clearingOrReplacingPeerResetsPreviouslyObservedAssociation() {
        val radio = Radio()
        try {
            radio.clients(PEER)
            radio.monitor.start()
            radio.monitor.setActivePeer(PEER)
            radio.monitor.setActivePeer(null)
            radio.clients()
            radio.broadcast()
            radio.monitor.setActivePeer(OTHER)
            radio.broadcast()
            assertEquals(0, radio.peerLost)
            radio.clients(OTHER)
            radio.broadcast()
            radio.clients()
            radio.broadcast()
            assertEquals(1, radio.peerLost)
        } finally { radio.monitor.close() }
    }

    @Test fun delayedQueryFromPreviousPeerCannotEndReplacementSession() {
        val radio = Radio()
        try {
            radio.clients(PEER)
            radio.monitor.start()
            radio.monitor.setActivePeer(PEER)
            radio.deferQuery = true
            radio.broadcast()
            val oldQuery = radio.pending.get()
            radio.deferQuery = false
            radio.clients(OTHER)
            radio.monitor.setActivePeer(OTHER)
            radio.clients()
            oldQuery.onGroupInfoAvailable(radio.group)
            assertEquals(0, radio.peerLost)
            radio.broadcast()
            assertEquals(1, radio.peerLost)
        } finally { radio.monitor.close() }
    }

    @Test fun staleAbsentQueryCannotOverrideNewerConfirmedAssociation() {
        val radio = Radio()
        try {
            radio.monitor.start()
            radio.deferQuery = true
            radio.monitor.setActivePeer(PEER)
            val oldQuery = radio.pending.get()
            radio.deferQuery = false
            radio.clients(PEER)
            radio.broadcast()
            radio.clients()
            oldQuery.onGroupInfoAvailable(radio.group)
            assertEquals(0, radio.peerLost)
            radio.broadcast()
            assertEquals(1, radio.peerLost)
        } finally { radio.monitor.close() }
    }

    @Test fun queryFailureAfterAssociationDoesNotClaimPeerDeparture() {
        val radio = Radio()
        try {
            radio.clients(PEER)
            radio.monitor.start()
            radio.monitor.setActivePeer(PEER)
            radio.clients()
            radio.queryFailure = true
            radio.broadcast()
            assertEquals(0, radio.peerLost)
            radio.queryFailure = false
            radio.broadcast()
            assertEquals(1, radio.peerLost)
        } finally { radio.monitor.close() }
    }

    @Test fun closingDisarmsDelayedPeerDepartureCallback() {
        val radio = Radio()
        radio.clients(PEER)
        radio.monitor.start()
        radio.monitor.setActivePeer(PEER)
        radio.deferQuery = true
        radio.broadcast()
        radio.monitor.close()
        radio.clients()
        radio.pending.get().onGroupInfoAvailable(radio.group)
        assertEquals(0, radio.peerLost)
    }

    private companion object {
        const val PEER = "12:34:56:78:ab:cd"
        const val OTHER = "12:34:56:78:ab:ef"
    }
}
