package com.shilapi.xcertplay.media

import android.graphics.SurfaceTexture
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.view.Surface
import java.nio.ByteBuffer
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentCaptor
import org.mockito.ArgumentMatchers.*
import org.mockito.Mockito.*
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.MediaCodecInfoBuilder
import org.robolectric.shadows.ShadowMediaCodecList

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE, sdk = [30])
class VideoDecoderStartupTest {
    private lateinit var texture: SurfaceTexture
    private lateinit var surface: Surface

    @Before fun setup() {
        ShadowMediaCodecList.reset()
        texture = SurfaceTexture(0)
        surface = Surface(texture)
    }

    @After fun cleanup() {
        ShadowMediaCodecList.reset()
        surface.release()
        texture.release()
    }

    @Test fun choosesOnlyHardwareLowLatencySupportingTheSpsSizeAndFormat() {
        add("c2.ordinary", lowLatency = false)
        add("c2.software", hardware = false)
        add("c2.small", width = 640, height = 480)
        add("c2.low_latency")
        assertEquals("c2.low_latency", VideoDecoderStartup.lowLatencyDecoderName(MIME, format()))
        val unsupportedProfile = format().apply { setInteger(MediaFormat.KEY_PROFILE, 10_000) }
        assertNull(VideoDecoderStartup.lowLatencyDecoderName(MIME, unsupportedProfile))
    }

    @Test fun absentLowLatencyCapabilityKeepsTheDefaultDecoder() {
        val codec = mockCodec(add("c2.ordinary", lowLatency = false))
        assertSame(codec, VideoDecoderStartup.start(MIME, format(), surface, false,
            createDefault = { codec }, createNamed = { error("Unexpected named decoder $it") }))
        val configured = configuredFormat(codec)
        assertFalse(configured.containsKey(MediaFormat.KEY_LOW_LATENCY))
        verify(codec).start()
    }

    @Test fun dedicatedHardwareIsPreferredAndDoesNotMutateTheCallerFormat() {
        val codec = mockCodec(add("c2.low_latency"))
        val source = format()
        assertSame(codec, VideoDecoderStartup.start(MIME, source, surface, false,
            createDefault = { error("Default must not replace a working low-latency decoder") },
            createNamed = { assertEquals("c2.low_latency", it); codec }))
        assertEquals(1, configuredFormat(codec).getInteger(MediaFormat.KEY_LOW_LATENCY))
        assertFalse(source.containsKey(MediaFormat.KEY_LOW_LATENCY))
    }

    @Test fun failedDedicatedStartReleasesTheComponentAndFallsBackToDefault() {
        val dedicated = mockCodec(add("c2.low_latency"))
        val fallback = mockCodec(add("c2.ordinary", lowLatency = false))
        doThrow(IllegalStateException("Vendor start rejected")).`when`(dedicated).start()
        assertSame(fallback, VideoDecoderStartup.start(MIME, format(), surface, false,
            createDefault = { fallback }, createNamed = { dedicated }))
        verify(dedicated).release()
        verify(fallback).start()
    }

    @Test fun rejectedDefaultHardwareRetriesTheSameComponentWithMinimalFormat() {
        val info = add("c2.ordinary", lowLatency = false)
        val rejected = mockCodec(info)
        val minimal = mockCodec(info)
        doThrow(IllegalArgumentException("BAD_VALUE")).`when`(rejected)
            .configure(any(MediaFormat::class.java), same(surface), isNull(), eq(0))
        val csd = byteArrayOf(0, 0, 0, 1, 0x67, 1)
        val source = format().apply {
            setByteBuffer("csd-0", ByteBuffer.wrap(csd))
            setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
        }
        assertSame(minimal, VideoDecoderStartup.start(MIME, source, surface, false,
            createDefault = { rejected }, createNamed = { assertEquals(info.name, it); minimal }))
        verify(rejected).release()
        val actual = configuredFormat(minimal)
        assertEquals(1280, actual.getInteger(MediaFormat.KEY_WIDTH))
        assertEquals(720, actual.getInteger(MediaFormat.KEY_HEIGHT))
        assertEquals(ByteBuffer.wrap(csd), actual.getByteBuffer("csd-0"))
        assertEquals(MediaFormat.COLOR_RANGE_LIMITED, actual.getInteger(MediaFormat.KEY_COLOR_RANGE))
        assertFalse(actual.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE))
        assertFalse(actual.containsKey(MediaFormat.KEY_PRIORITY))
        assertFalse(actual.containsKey(MediaFormat.KEY_LOW_LATENCY))
    }

    @Test fun aFailedSoftwareDefaultDoesNotCreateAnyNewSoftwareFallback() {
        val codec = mockCodec(add("c2.software", hardware = false, lowLatency = false))
        doThrow(IllegalStateException("rejected")).`when`(codec).start()
        assertThrows(IllegalStateException::class.java) {
            VideoDecoderStartup.start(MIME, format(), surface, false,
                createDefault = { codec }, createNamed = { error("Unexpected fallback $it") })
        }
        verify(codec).release()
    }

    @Test @Config(sdk = [28]) fun androidNineRetainsTheOriginalDefaultFormatAndFailureBehavior() {
        val codec = mock(MediaCodec::class.java)
        `when`(codec.name).thenReturn("OMX.Intel.hw_vd.h264")
        val source = format()
        val failure = IllegalArgumentException("original configure error")
        doThrow(failure).`when`(codec).configure(same(source), same(surface), isNull(), eq(0))
        assertSame(failure, assertThrows(IllegalArgumentException::class.java) {
            VideoDecoderStartup.start(MIME, source, surface, false,
                createDefault = { codec }, createNamed = { error("Android 9 must retain default selection") })
        })
        verify(codec).release()
        verify(codec, never()).start()
    }

    private fun format() = MediaFormat.createVideoFormat(MIME, 1280, 720).apply {
        setInteger(MediaFormat.KEY_PRIORITY, 0)
        setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 8 * 1024 * 1024)
    }

    private fun mockCodec(info: MediaCodecInfo) = mock(MediaCodec::class.java).apply {
        `when`(name).thenReturn(info.name)
        `when`(codecInfo).thenReturn(info)
    }

    private fun configuredFormat(codec: MediaCodec): MediaFormat {
        val captured = ArgumentCaptor.forClass(MediaFormat::class.java)
        verify(codec).configure(captured.capture(), same(surface), isNull(), eq(0))
        return captured.value
    }

    private fun add(name: String, hardware: Boolean = true, lowLatency: Boolean = true,
        width: Int = 1920, height: Int = 1080): MediaCodecInfo {
        val supported = MediaFormat.createVideoFormat(MIME, width, height)
            .apply { setFeatureEnabled(MediaCodecInfo.CodecCapabilities.FEATURE_LowLatency, lowLatency) }
        val profile = MediaCodecInfo.CodecProfileLevel().apply {
            this.profile = MediaCodecInfo.CodecProfileLevel.AVCProfileHigh
            level = MediaCodecInfo.CodecProfileLevel.AVCLevel52
        }
        val caps = MediaCodecInfoBuilder.CodecCapabilitiesBuilder.newBuilder().setMediaFormat(supported)
            .setProfileLevels(arrayOf(profile)).setColorFormats(intArrayOf(MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)).build()
        return MediaCodecInfoBuilder.newBuilder().setName(name).setIsEncoder(false)
            .setIsHardwareAccelerated(hardware).setIsSoftwareOnly(!hardware).setCapabilities(caps).build()
            .also(ShadowMediaCodecList::addCodec)
    }

    private companion object { const val MIME = MediaFormat.MIMETYPE_VIDEO_AVC }
}
