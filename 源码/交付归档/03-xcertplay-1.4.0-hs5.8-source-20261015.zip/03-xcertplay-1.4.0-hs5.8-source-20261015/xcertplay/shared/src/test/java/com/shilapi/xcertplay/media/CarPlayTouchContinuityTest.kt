package com.shilapi.xcertplay.media

import android.view.InputDevice
import android.view.MotionEvent
import com.shilapi.xcertplay.airplay.AirPlayHid
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class CarPlayTouchContinuityTest {
    private val mapper = CarPlayTouchMapper()

    @Test fun remainingPointerRetainsItsHidSlotWhenFirstPointerLifts() {
        report(MotionEvent.ACTION_DOWN, intArrayOf(10), floatArrayOf(200f))
        report(MotionEvent.ACTION_POINTER_DOWN or (1 shl MotionEvent.ACTION_POINTER_INDEX_SHIFT),
            intArrayOf(10, 20), floatArrayOf(200f, 1400f))
        val lifted = report(MotionEvent.ACTION_POINTER_UP, intArrayOf(10, 20), floatArrayOf(200f, 1400f))
        assertFalse(down(lifted, 0))
        assertTrue(down(lifted, 1))
        val remaining = report(MotionEvent.ACTION_MOVE, intArrayOf(20), floatArrayOf(1450f))
        assertEquals(12, remaining.size)
        assertEquals(0, remaining[0].toInt())
        assertEquals(1, remaining[6].toInt())
        assertFalse(down(remaining, 0))
        assertTrue(down(remaining, 1))
        assertEquals(1450, x(remaining, 1))
        val ended = report(MotionEvent.ACTION_UP, intArrayOf(20), floatArrayOf(1450f))
        assertFalse(down(ended, 0))
        assertFalse(down(ended, 1))
    }

    @Test fun releasedSlotCanBeReusedWithoutReassigningRemainingPointer() {
        report(MotionEvent.ACTION_DOWN, intArrayOf(10), floatArrayOf(200f))
        report(MotionEvent.ACTION_POINTER_DOWN or (1 shl MotionEvent.ACTION_POINTER_INDEX_SHIFT),
            intArrayOf(10, 20), floatArrayOf(200f, 1400f))
        report(MotionEvent.ACTION_POINTER_UP, intArrayOf(10, 20), floatArrayOf(200f, 1400f))
        val added = report(MotionEvent.ACTION_POINTER_DOWN or (1 shl MotionEvent.ACTION_POINTER_INDEX_SHIFT),
            intArrayOf(20, 30), floatArrayOf(1400f, 600f))
        assertTrue(down(added, 0))
        assertEquals(600, x(added, 0))
        assertTrue(down(added, 1))
        assertEquals(1400, x(added, 1))
    }

    @Test fun cancellationAndHostReleaseRequireANewDown() {
        report(MotionEvent.ACTION_DOWN, intArrayOf(10), floatArrayOf(200f))
        val cancel = report(MotionEvent.ACTION_CANCEL, intArrayOf(10), floatArrayOf(200f))
        assertFalse(down(cancel, 0))
        assertFalse(down(report(MotionEvent.ACTION_MOVE, intArrayOf(10), floatArrayOf(300f)), 0))
        report(MotionEvent.ACTION_DOWN, intArrayOf(20), floatArrayOf(300f))
        mapper.clear()
        assertFalse(down(report(MotionEvent.ACTION_MOVE, intArrayOf(20), floatArrayOf(400f)), 0))
        assertTrue(down(report(MotionEvent.ACTION_DOWN, intArrayOf(30), floatArrayOf(400f)), 0))
    }

    @Test fun aGestureStartingInLetterboxRemainsIgnoredUntilItsEnd() {
        val contacts = listOf(MotionEvent.ACTION_DOWN to 10f, MotionEvent.ACTION_MOVE to 500f,
            MotionEvent.ACTION_UP to 500f).map { (action, y) ->
            event(action, intArrayOf(10), floatArrayOf(500f), y).let {
                try { mapper.contacts(it, 1000, 1000, 1000, 500) } finally { it.recycle() }
            }
        }
        assertTrue(contacts.all { it.isEmpty() })
        val next = event(MotionEvent.ACTION_DOWN, intArrayOf(20), floatArrayOf(500f), 500f)
        try { assertTrue(mapper.contacts(next, 1000, 1000, 1000, 500).single().down) }
        finally { next.recycle() }
    }

    private fun report(action: Int, ids: IntArray, xs: FloatArray): ByteArray {
        val event = event(action, ids, xs)
        return try {
            AirPlayHid.touchReport(mapper.contacts(event, 1920, 720)
                .map { it.copy(x = it.x * 1920, y = it.y * 720) })
        } finally { event.recycle() }
    }

    private fun event(action: Int, ids: IntArray, xs: FloatArray, y: Float = 300f): MotionEvent = MotionEvent.obtain(
        0, 16, action, ids.size,
        Array(ids.size) { i -> MotionEvent.PointerProperties().apply { id = ids[i]; toolType = MotionEvent.TOOL_TYPE_FINGER } },
        Array(ids.size) { i -> MotionEvent.PointerCoords().apply { x = xs[i]; this.y = y; pressure = 1f; size = 1f } },
        0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0,
    )
    private fun down(report: ByteArray, slot: Int) = (report[slot * 6 + 1].toInt() and 1) != 0
    private fun x(report: ByteArray, slot: Int) = (report[slot * 6 + 2].toInt() and 255) or
        ((report[slot * 6 + 3].toInt() and 255) shl 8)
}
