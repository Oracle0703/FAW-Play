package com.shilapi.xcertplay.airplay

import java.net.Socket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class AirPlaySessionDisconnectTest {
    @Test fun disconnectNotificationPrecedesSlowMediaCleanupAndOccursOnce() {
        val cleaning = CountDownLatch(1)
        val release = CountDownLatch(1)
        val disconnected = AtomicInteger()
        val ended = AtomicInteger()
        val socket = Socket()
        val session = session(socket, object : AirPlaySessionListener {
            override fun onSessionDisconnected(session: AirPlaySession) {
                assertTrue(session.isClosed())
                assertTrue(socket.isClosed)
                assertFalse(session.sendCommand(mapOf("type" to "requestUI")))
                disconnected.incrementAndGet()
            }
            override fun onSessionEnded(session: AirPlaySession) { ended.incrementAndGet() }
        }, object : AirPlayMediaHandler {
            override fun onSessionClosed(session: AirPlaySession) {
                cleaning.countDown()
                check(release.await(3, TimeUnit.SECONDS))
            }
        })
        val worker = Thread { session.close() }.apply { start() }
        try {
            assertTrue(cleaning.await(3, TimeUnit.SECONDS))
            assertEquals(1, disconnected.get())
            assertEquals(0, ended.get())
            session.close()
            assertEquals(1, disconnected.get())
        } finally { release.countDown(); worker.join(3_000); session.close() }
        assertFalse(worker.isAlive)
        assertEquals(1, ended.get())
    }

    @Test fun failedDisconnectListenerAndMediaCleanupDoNotPreventFinalNotification() {
        val cleaned = AtomicInteger()
        val ended = AtomicInteger()
        val socket = Socket()
        val session = session(socket, object : AirPlaySessionListener {
            override fun onSessionDisconnected(session: AirPlaySession) { throw IllegalStateException("UI gone") }
            override fun onSessionEnded(session: AirPlaySession) {
                ended.incrementAndGet()
                throw IllegalStateException("UI gone")
            }
        }, object : AirPlayMediaHandler {
            override fun onSessionClosed(session: AirPlaySession) {
                cleaned.incrementAndGet()
                throw IllegalStateException("decoder unavailable")
            }
        })
        session.close()
        session.close()
        assertTrue(socket.isClosed)
        assertEquals(1, cleaned.get())
        assertEquals(1, ended.get())
    }

    private fun session(socket: Socket, listener: AirPlaySessionListener, media: AirPlayMediaHandler) =
        AirPlaySession(socket, AirPlayConfig("test", "test", "", "1", AirPlayDisplayConfig(800, 480)),
            AirPlayIdentity.generate(), PairingStore(), null, listener, media)
}
