package com.shilapi.xcertplay.network

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.WifiAvailableChannel
import android.net.wifi.WifiManager
import android.os.Build
import androidx.annotation.RequiresApi

/**
 * Alternates system selection and a non-DFS request after a failed network attempt.
 * Callers must not apply it to an associated peer, active session, or an authentication failure.
 */
object WirelessRadioSelectionPolicy {
    internal data class GoChannel(val frequencyMHz: Int, val operationalModes: Int)

    internal fun selectFromCandidates(
        networkRetry: Int,
        failedFrequencyMHz: Int? = null,
        candidates: List<Int>,
        source: WirelessRadioSelection.Source = WirelessRadioSelection.Source.SYSTEM_USABLE_CHANNELS,
    ): WirelessRadioSelection {
        require(networkRetry >= 0) { "networkRetry must not be negative" }
        if (networkRetry % 2 == 0) return WirelessRadioSelection.System5Ghz
        val alternatives = candidates.filter(::isCompatibleNonDfs5GhzFrequency)
            .filter { it != failedFrequencyMHz }.distinct()
            .sortedWith(compareBy<Int> { preferredFrequencyRank(it) }.thenBy { it })
        if (alternatives.isEmpty()) return WirelessRadioSelection.System5Ghz
        return WirelessRadioSelection.Frequency(
            alternatives[((networkRetry - 1) / 2) % alternatives.size],
            source,
        )
    }

    fun select(
        context: Context,
        networkRetry: Int,
        failedFrequencyMHz: Int? = null,
        diagnostic: (String) -> Unit = {},
    ): WirelessRadioSelection {
        return selectForPlatform(
            sdkInt = Build.VERSION.SDK_INT,
            networkRetry = networkRetry,
            failedFrequencyMHz = failedFrequencyMHz,
            hasNearbyWifiPermission = {
                context.checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED
            },
            queryGoChannels = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    queryUsableChannels(context, diagnostic)
                } else {
                    emptyList()
                }
            },
            diagnostic = diagnostic,
        )
    }

    /** Platform policy shared by the Android entry point and tests without a newer framework jar. */
    internal fun selectForPlatform(
        sdkInt: Int,
        networkRetry: Int,
        failedFrequencyMHz: Int? = null,
        hasNearbyWifiPermission: () -> Boolean,
        queryGoChannels: () -> List<GoChannel>,
        diagnostic: (String) -> Unit = {},
    ): WirelessRadioSelection {
        require(networkRetry >= 0) { "networkRetry must not be negative" }
        if (sdkInt < Build.VERSION_CODES.Q) {
            diagnostic("P2P radio selection: no_public_frequency_control")
            return WirelessRadioSelection.System5Ghz
        }
        if (networkRetry % 2 == 0) {
            diagnostic("P2P radio selection: system_5ghz retry=$networkRetry")
            return selectFromCandidates(networkRetry, candidates = emptyList())
        }

        val candidates: List<Int>
        val source: WirelessRadioSelection.Source
        if (sdkInt >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            candidates = usableGoFrequencies(hasNearbyWifiPermission, queryGoChannels, diagnostic)
            source = WirelessRadioSelection.Source.SYSTEM_USABLE_CHANNELS
        } else {
            // No public channel query on API 29–33. These are requests, never assumed legal results.
            candidates = listOf(5180, 5745)
            source = WirelessRadioSelection.Source.LEGACY_REQUEST
        }
        val selection = selectFromCandidates(networkRetry, failedFrequencyMHz, candidates, source)
        if (selection == WirelessRadioSelection.System5Ghz) {
            diagnostic("P2P radio selection: no_alternative_non_dfs_go_channel")
        } else if (selection is WirelessRadioSelection.Frequency) {
            diagnostic("P2P radio selection: requestedFrequencyMHz=${selection.frequencyMHz} source=${selection.source} retry=$networkRetry")
        }
        return selection
    }

    private fun usableGoFrequencies(
        hasNearbyWifiPermission: () -> Boolean,
        queryGoChannels: () -> List<GoChannel>,
        diagnostic: (String) -> Unit,
    ): List<Int> {
        if (!hasNearbyWifiPermission()) {
            diagnostic("P2P radio selection: channel_query_permission_unavailable")
            return emptyList()
        }
        return try {
            queryGoChannels()
                .filter { it.operationalModes and GO_OPERATION_MODE != 0 }
                .map { it.frequencyMHz }
        } catch (_: SecurityException) {
            diagnostic("P2P radio selection: channel_query_permission_rejected")
            emptyList()
        } catch (_: UnsupportedOperationException) {
            diagnostic("P2P radio selection: channel_query_unsupported")
            emptyList()
        } catch (_: IllegalArgumentException) {
            diagnostic("P2P radio selection: channel_query_rejected")
            emptyList()
        }
    }

    @RequiresApi(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
    @SuppressLint("MissingPermission") // Checked before selectForPlatform invokes this query.
    private fun queryUsableChannels(context: Context, diagnostic: (String) -> Unit): List<GoChannel> {
        val manager = context.getSystemService(WifiManager::class.java)
        if (manager == null) {
            diagnostic("P2P radio selection: channel_query_unavailable")
            return emptyList()
        }
        return manager.getUsableChannels(BAND_5_GHZ_WITH_DFS, WifiAvailableChannel.OP_MODE_WIFI_DIRECT_GO)
            .map { GoChannel(it.frequencyMhz, it.operationalModes) }
    }

    private fun preferredFrequencyRank(frequencyMHz: Int): Int = when (frequencyMHz) {
        5180 -> 0
        5745 -> 1
        else -> 2
    }

    // Value specified by WifiManager's public API; WifiScanner is not itself a public SDK class.
    private const val BAND_5_GHZ_WITH_DFS = 6
    private const val GO_OPERATION_MODE = 1 shl 3
}
