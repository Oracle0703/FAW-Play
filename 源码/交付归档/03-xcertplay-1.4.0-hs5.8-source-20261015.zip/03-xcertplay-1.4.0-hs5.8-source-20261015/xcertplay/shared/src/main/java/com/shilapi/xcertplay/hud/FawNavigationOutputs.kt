package com.shilapi.xcertplay.hud

import android.content.Context
import com.shilapi.xcertplay.iap2.wire.Iap2Frame
import com.shilapi.xcertplay.licensing.LicenseFeatures
import com.shilapi.xcertplay.licensing.ProductLicense

/** Nonblocking boundary between phone control messages and vendor services. */
object FawNavigationOutputs {
    @Volatile private var overlayListener: ((ClusterTurnGuidance?) -> Unit)? = null
    @Volatile private var laneListener: ((ClusterLaneGuidance?) -> Unit)? = null
    private val overlayLock = Any()
    private var publishedOverlay: ClusterTurnGuidance? = null
    private var publishedNativeGuidance: ClusterTurnGuidance? = null
    private var publishedLanes: ClusterLaneGuidance? = null
    private val laneRoute = FawLaneGuidanceState()
    private val overlayRoute = FawHudRouteState(
        staleRouteNs = 120_000_000_000L,
        emptyListHideNs = 8_000_000_000L,
    )
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    @Volatile private var owner: Any? = null
    @Volatile private var appContext: Context? = null
    private val refresh = object : Runnable {
        override fun run() {
            if (owner == null) return
            refreshTurnOverlay()
            main.postDelayed(this, 500L)
        }
    }
    fun start(context: Context, nextOwner: Any) {
        synchronized(overlayLock) { owner = nextOwner; appContext = context.applicationContext }
        HongqiNavigation.start(context.applicationContext)
        main.removeCallbacks(refresh)
        main.post(refresh)
    }

    internal fun onFrame(frame: Iap2Frame) {
        if (!com.shilapi.xcertplay.shared.BuildConfig.FAW_NAVIGATION_OUTPUTS_ENABLED) return
        if (frame.messageId != FawHudRouteState.ROUTE_GUIDANCE_UPDATE &&
            frame.messageId != FawHudRouteState.ROUTE_GUIDANCE_MANEUVER_UPDATE &&
            frame.messageId != FawLaneGuidanceState.LANE_GUIDANCE_INFORMATION) return
        updateOverlay(frame)
    }

    /** Live next-turn state for the dashboard overlay. Called from the iAP2 thread. */
    fun setTurnOverlayListener(listener: ((ClusterTurnGuidance?) -> Unit)?) {
        if (!com.shilapi.xcertplay.shared.BuildConfig.FAW_NAVIGATION_OUTPUTS_ENABLED) {
            listener?.invoke(null)
            return
        }
        synchronized(overlayLock) {
            overlayListener = listener
            val guidance = currentOverlay()
            val next = guidance.takeIf { instrumentMapAllowed() }
            // A host can attach after the first route packet. Publish to both outputs before
            // recording the value, otherwise refresh treats undelivered guidance as unchanged.
            HongqiNavigation.onGuidance(guidance)
            publishedNativeGuidance = guidance
            publishedOverlay = next
            listener?.invoke(next)
        }
    }

    /** Independent of the custom turn card: native instruments also need vehicle lane metadata. */
    fun setLaneOverlayListener(listener: ((ClusterLaneGuidance?) -> Unit)?) {
        if (!com.shilapi.xcertplay.shared.BuildConfig.FAW_NAVIGATION_OUTPUTS_ENABLED) {
            listener?.invoke(null)
            return
        }
        synchronized(overlayLock) {
            laneListener = listener
            publishedLanes = laneRoute.current().takeIf { instrumentMapAllowed() }
            listener?.invoke(publishedLanes)
        }
    }

    fun clearLaneOverlayListener(listener: (ClusterLaneGuidance?) -> Unit) {
        synchronized(overlayLock) {
            if (laneListener === listener) laneListener = null
        }
    }

    fun clearTurnOverlayListener(listener: (ClusterTurnGuidance?) -> Unit) {
        synchronized(overlayLock) {
            if (overlayListener === listener) overlayListener = null
        }
    }

    private fun updateOverlay(frame: Iap2Frame) {
        synchronized(overlayLock) {
            if (frame.messageId == FawLaneGuidanceState.LANE_GUIDANCE_INFORMATION) {
                android.util.Log.i("FAW-Lanes", "received bytes=${frame.payload.size}")
            }
            overlayRoute.accept(frame.messageId, frame.payload)
            laneRoute.accept(frame.messageId, frame.payload)
            refreshTurnOverlay()
        }
    }

    /** Called by the retained controller even while the Activity is absent, even without incoming frames. */
    fun refreshTurnOverlay() {
        if (!com.shilapi.xcertplay.shared.BuildConfig.FAW_NAVIGATION_OUTPUTS_ENABLED) return
        synchronized(overlayLock) {
            val guidance = currentOverlay()
            if (guidance != publishedNativeGuidance) {
                HongqiNavigation.onGuidance(guidance)
                publishedNativeGuidance = guidance
            }
            val mapAllowed = instrumentMapAllowed()
            val current = guidance.takeIf { mapAllowed }
            if (current != publishedOverlay) {
                publishedOverlay = current
                overlayListener?.invoke(current)
            }
            val lanes = laneRoute.current().takeIf { mapAllowed }
            if (lanes != publishedLanes) {
                publishedLanes = lanes
                // Counts and indices are enough to diagnose the lane path; no road or route payload.
                android.util.Log.i("FAW-Lanes", if (lanes == null) "hidden" else
                    "display index=${lanes.index} lanes=${lanes.lanes.size}")
                laneListener?.invoke(lanes)
            }
        }
    }

    private fun instrumentMapAllowed(): Boolean = appContext?.let {
        ProductLicense.featureAllowed(it, LicenseFeatures.INSTRUMENT_MAP)
    } == true

    private fun currentOverlay(): ClusterTurnGuidance? = synchronized(overlayLock) {
        overlayRoute.currentApple()?.let { apple ->
            ClusterTurnGuidance.from(FawClusterFrame.from(apple)).copy(
                arrivalEpochSeconds = apple.arrivalEpochSeconds,
                remainingSeconds = apple.remainingSeconds,
                remainingMeters = apple.remainingMeters,
            )
        }
    }

    /** Best effort while alive; Android does not guarantee callbacks before force-stop. */
    fun endNow(expectedOwner: Any) {
        synchronized(overlayLock) {
            if (owner !== expectedOwner) return
            owner = null
            main.removeCallbacks(refresh)
            HongqiNavigation.clear()
            overlayRoute.clear()
            laneRoute.clear()
            refreshTurnOverlay()
            appContext = null
        }
    }
}
