package com.shilapi.xcertplay.network

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.util.Log
import java.io.Closeable
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/** Observes a group that was already established; never removes or changes Wi-Fi groups. */
internal class P2pGroupLossMonitor(
    private val context: Context,
    private val manager: WifiP2pManager,
    private val channel: WifiP2pManager.Channel,
    private val onGroupLost: () -> Unit,
    private val onPeerDisconnected: (String) -> Unit = {},
) : Closeable {
    private val closed = AtomicBoolean(false)
    private val reported = AtomicBoolean(false)
    private var registered = false
    @Volatile private var started = false
    private val peerLock = Any()
    private var peerMac: String? = null
    private var peerEpoch = 0L
    private var peerSeen = false
    private var peerReported = false
    private var peerQueryOrdinal = 0L
    private var lastPeerQueryOrdinal = 0L
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION ||
                intent.action == WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION
            ) {
                queryCurrentGroup()
            }
        }
    }

    fun start() {
        if (closed.get()) return
        val filter = IntentFilter(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION).apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
        }
        started = true
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                // Wi-Fi broadcasts may originate from a privileged framework UID. The
                // payload is never trusted: every event is confirmed through the manager.
                context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                context.registerReceiver(receiver, filter)
            }
            registered = true
        } catch (_: SecurityException) {
            Log.w(TAG, "Wi-Fi P2P lifecycle broadcast permission unavailable")
        } catch (_: RuntimeException) {
            Log.w(TAG, "Wi-Fi P2P lifecycle broadcasts are unavailable; using transport detection")
        }
        // Also covers removal between successful startup and receiver registration. Android
        // broadcasts can be stale: query live state instead of trusting their group payload.
        queryCurrentGroup()
    }

    fun setActivePeer(wifiMac: String?) {
        synchronized(peerLock) {
            peerEpoch++
            peerMac = normalizeMac(wifiMac)
            peerSeen = false
            peerReported = false
            peerQueryOrdinal = 0
            lastPeerQueryOrdinal = 0
        }
        if (started) queryCurrentGroup()
    }

    private fun queryCurrentGroup() {
        if (closed.get() || reported.get()) return
        val peerQuery = synchronized(peerLock) {
            peerMac?.let { PeerQuery(it, peerEpoch, ++peerQueryOrdinal) }
        }
        try {
            manager.requestGroupInfo(channel) { group ->
                if (closed.get()) return@requestGroupInfo
                if (group == null && !closed.get() && reported.compareAndSet(false, true)) {
                    onGroupLost()
                    return@requestGroupInfo
                }
                if (group == null || peerQuery == null) return@requestGroupInfo
                var associationObserved = false
                val peerLeft = synchronized(peerLock) {
                    if (closed.get() || peerQuery.epoch != peerEpoch || peerReported ||
                        peerQuery.ordinal <= lastPeerQueryOrdinal
                    ) {
                        false
                    } else {
                        lastPeerQueryOrdinal = peerQuery.ordinal
                        val present = group.clientList.any {
                            normalizeMac(it.deviceAddress) == peerQuery.mac
                        }
                        if (present) {
                            associationObserved = !peerSeen
                            peerSeen = true
                            false
                        } else if (peerSeen) {
                            peerReported = true
                            true
                        } else {
                            // Empty/unsupported client lists and MAC mismatches do not arm
                            // detection. Transport liveness remains the fallback.
                            false
                        }
                    }
                }
                if (associationObserved) Log.i(TAG, "Wi-Fi P2P active peer association observed")
                if (peerLeft) {
                    Log.i(TAG, "Wi-Fi P2P active peer left group")
                    onPeerDisconnected(peerQuery.mac)
                }
            }
        } catch (_: SecurityException) {
            // Permission can be revoked after startup without proving the group was removed.
            Log.w(TAG, "Wi-Fi P2P runtime group query permission unavailable")
        } catch (_: RuntimeException) {
            // A query/permission failure says nothing about whether the link is still alive.
            Log.w(TAG, "Wi-Fi P2P runtime group query unavailable")
        }
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        synchronized(peerLock) {
            peerEpoch++
            peerMac = null
            peerSeen = false
            peerReported = false
        }
        if (registered) {
            registered = false
            runCatching { context.unregisterReceiver(receiver) }
        }
    }

    private data class PeerQuery(val mac: String, val epoch: Long, val ordinal: Long)

    private companion object {
        const val TAG = "P2pGroupLossMonitor"
        val MAC_PATTERN = Regex("[0-9a-f]{2}(?::[0-9a-f]{2}){5}")
        fun normalizeMac(mac: String?): String? = mac?.trim()?.lowercase(Locale.ROOT)?.takeIf {
            MAC_PATTERN.matches(it) && it != "00:00:00:00:00:00" &&
                it != "ff:ff:ff:ff:ff:ff" && it != "02:00:00:00:00:00"
        }
    }
}
