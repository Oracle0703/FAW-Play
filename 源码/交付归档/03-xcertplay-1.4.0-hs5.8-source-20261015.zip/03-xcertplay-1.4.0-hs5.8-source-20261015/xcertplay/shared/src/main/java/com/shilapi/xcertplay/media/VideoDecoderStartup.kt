package com.shilapi.xcertplay.media

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.os.Build
import android.util.Log
import android.view.Surface

/** Select an advertised low-latency hardware decoder without requiring vendor-specific keys. */
internal object VideoDecoderStartup {
    fun lowLatencyDecoderName(mime: String, format: MediaFormat): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        return runCatching {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.firstOrNull { info ->
                !info.isEncoder && !info.isAlias && info.isHardwareAccelerated && !info.isSoftwareOnly &&
                    mime in info.supportedTypes && runCatching {
                    val capabilities = info.getCapabilitiesForType(mime)
                    capabilities.isFeatureSupported(MediaCodecInfo.CodecCapabilities.FEATURE_LowLatency) &&
                        capabilities.videoCapabilities?.isSizeSupported(
                            format.getInteger(MediaFormat.KEY_WIDTH), format.getInteger(MediaFormat.KEY_HEIGHT),
                        ) == true && capabilities.isFormatSupported(format)
                }.getOrDefault(false)
            }?.name
        }.getOrNull()
    }

    fun start(
        mime: String,
        format: MediaFormat,
        surface: Surface,
        preferSoftwareHevcDecoder: Boolean,
        createDefault: () -> MediaCodec,
        createNamed: (String) -> MediaCodec = MediaCodec::createByCodecName,
    ): MediaCodec {
        // Keep the existing Android 9/Intel configure path and its failure behavior unchanged.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            return startCandidate(createDefault(), format, surface, lowLatency = false)
        }
        var previousFailure: Exception? = null
        val dedicated = if (mime == MediaFormat.MIMETYPE_VIDEO_HEVC && preferSoftwareHevcDecoder) null
            else lowLatencyDecoderName(mime, format)
        if (dedicated != null) {
            try {
                return startCandidate(createNamed(dedicated), MediaFormat(format), surface, lowLatency = true)
            } catch (error: Exception) {
                previousFailure = error
                Log.w(TAG, "low-latency hardware decoder rejected configuration name=$dedicated; trying default", error)
            }
        }

        val fallback = try { createDefault() } catch (error: Exception) {
            previousFailure?.let(error::addSuppressed)
            throw error
        }
        val fallbackName = runCatching { fallback.name }.getOrNull()
        val hardware = runCatching { fallback.codecInfo.isHardwareAccelerated }.getOrDefault(false)
        val lowLatency = runCatching {
            fallback.codecInfo.getCapabilitiesForType(mime)
                .isFeatureSupported(MediaCodecInfo.CodecCapabilities.FEATURE_LowLatency)
        }.getOrDefault(false)
        return try {
            startCandidate(fallback, MediaFormat(format), surface, lowLatency)
        } catch (error: Exception) {
            previousFailure?.let(error::addSuppressed)
            if (!hardware || fallbackName == null) throw error
            // A vendor may advertise the feature but reject optional tuning. Retry the same
            // hardware component with CSD/color/size only, never add a software fallback.
            Log.w(TAG, "hardware decoder rejected tuned format name=$fallbackName; trying minimal format", error)
            try {
                startCandidate(createNamed(fallbackName), minimalFormat(mime, format), surface, lowLatency = false)
            } catch (minimalFailure: Exception) {
                minimalFailure.addSuppressed(error)
                throw minimalFailure
            }
        }
    }

    private fun startCandidate(codec: MediaCodec, format: MediaFormat, surface: Surface, lowLatency: Boolean): MediaCodec {
        try {
            if (lowLatency) format.setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
            codec.configure(format, surface, null, 0)
            codec.start()
            val info = runCatching { codec.codecInfo }.getOrNull()
            val hardware = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) info?.isHardwareAccelerated else null
            val software = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) info?.isSoftwareOnly else null
            val name = runCatching { codec.name }.getOrDefault("unknown")
            Log.i(TAG, "video decoder started name=$name hardware=$hardware software=$software lowLatency=$lowLatency")
            return codec
        } catch (error: Exception) {
            runCatching { codec.release() }
            throw error
        }
    }

    private fun minimalFormat(mime: String, source: MediaFormat): MediaFormat =
        MediaFormat.createVideoFormat(mime, source.getInteger(MediaFormat.KEY_WIDTH), source.getInteger(MediaFormat.KEY_HEIGHT)).apply {
            for (key in listOf("csd-0", "csd-1")) {
                source.getByteBuffer(key)?.let { setByteBuffer(key, it.duplicate()) }
            }
            for (key in listOf(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.KEY_COLOR_RANGE, MediaFormat.KEY_COLOR_TRANSFER)) {
                if (source.containsKey(key)) setInteger(key, source.getInteger(key))
            }
        }

    private const val TAG = "xcertplay-usb"
}
