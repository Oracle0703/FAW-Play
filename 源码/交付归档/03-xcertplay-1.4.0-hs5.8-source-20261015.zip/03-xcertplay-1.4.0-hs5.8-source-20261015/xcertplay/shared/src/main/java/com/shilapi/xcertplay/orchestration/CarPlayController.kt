package com.shilapi.xcertplay.orchestration

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothSocket
import android.content.ComponentName
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.content.ServiceConnection
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import com.shilapi.xcertplay.airplay.AirPlayConfig
import com.shilapi.xcertplay.airplay.AirPlayContact
import com.shilapi.xcertplay.airplay.AirPlayDeviceInfo
import com.shilapi.xcertplay.airplay.AirPlayIdentity
import com.shilapi.xcertplay.airplay.AirPlayMediaHandler
import com.shilapi.xcertplay.airplay.AirPlaySession
import com.shilapi.xcertplay.airplay.AirPlaySessionListener
import com.shilapi.xcertplay.airplay.PairingStore
import com.shilapi.xcertplay.iap2.message.Iap2HidMessages
import com.shilapi.xcertplay.iap2.message.Iap2MediaRemoteCommand
import com.shilapi.xcertplay.iap2.message.Iap2NowPlayingAccumulator
import com.shilapi.xcertplay.iap2.session.Iap2FileTransferReceiver
import com.shilapi.xcertplay.iap2.session.Iap2Session
import com.shilapi.xcertplay.iap2.wire.Iap2Frame
import com.shilapi.xcertplay.airplay.AirPlayPhoneState
import com.shilapi.xcertplay.airplay.AirPlaySpeechState
import com.shilapi.xcertplay.airplay.AirPlayKnobState
import com.shilapi.xcertplay.airplay.CarPlayMediaButton
import com.shilapi.xcertplay.hud.FawNavigationOutputs
import com.shilapi.xcertplay.hud.HongqiNavigation
import com.shilapi.xcertplay.media.HongqiBluetoothMediaHandoff
import com.shilapi.xcertplay.media.CarPlayPlaybackStatus
import com.shilapi.xcertplay.media.CarPlayMediaSessionBridge
import com.shilapi.xcertplay.mfi.Iap2MfiAuthenticationClient
import com.shilapi.xcertplay.mfi.LocalMfiAuthenticationClient
import com.shilapi.xcertplay.mfi.MfiAuthenticationClient
import com.shilapi.xcertplay.mfi.MfiAuthenticator
import com.shilapi.xcertplay.mfi.RemoteMfiAuthenticationClient
import com.shilapi.xcertplay.network.CarPlayBonjour
import com.shilapi.xcertplay.network.CarPlayVpnService
import com.shilapi.xcertplay.network.WifiP2pGroupManager
import com.shilapi.xcertplay.network.WirelessHotspotInfo
import com.shilapi.xcertplay.network.WirelessHotspotManager
import com.shilapi.xcertplay.network.mfiCertificateWifiP2pCredentials
import com.shilapi.xcertplay.transport.BlockingDuplexByteStream
import com.shilapi.xcertplay.transport.BluetoothRfcommDuplexStream
import com.shilapi.xcertplay.transport.Ch341DeviceMatcher
import com.shilapi.xcertplay.transport.Ch341I2cTransport
import com.shilapi.xcertplay.transport.Ch341UsbHost
import com.shilapi.xcertplay.transport.Ch341UsbSession
import com.shilapi.xcertplay.transport.Iap2IdentificationConfig
import com.shilapi.xcertplay.transport.Iap2LocationProvider
import com.shilapi.xcertplay.transport.Iap2UsbMuxHost
import com.shilapi.xcertplay.transport.Iap2UsbSession
import com.shilapi.xcertplay.transport.Iap2WiredCarPlayEndpoint
import com.shilapi.xcertplay.transport.Iap2WiredControlClient
import com.shilapi.xcertplay.transport.Iap2WiredControlTerminal
import com.shilapi.xcertplay.transport.Iap2WirelessCarPlayEndpoint
import com.shilapi.xcertplay.transport.Iap2WirelessControlClient
import com.shilapi.xcertplay.transport.Iap2WirelessControlTerminal
import com.shilapi.xcertplay.transport.Iap2WirelessBringUpStage
import com.shilapi.xcertplay.transport.Iap2WirelessIdentification
import com.shilapi.xcertplay.transport.I2cTransport
import com.shilapi.xcertplay.transport.I2cTransportException
import com.shilapi.xcertplay.transport.IphoneCarPlayConfiguration
import com.shilapi.xcertplay.transport.IphoneUsbException
import com.shilapi.xcertplay.transport.IphoneUsbHost
import com.shilapi.xcertplay.transport.IphoneUsbMatcher
import com.shilapi.xcertplay.transport.LinuxI2cTransport
import com.shilapi.xcertplay.transport.LockdownCarKitClient
import com.shilapi.xcertplay.transport.LockdownPairingClient
import com.shilapi.xcertplay.transport.LockdownPairRecord
import com.shilapi.xcertplay.transport.NcmFunctionDiscovery
import com.shilapi.xcertplay.transport.NcmUsbBridge
import java.io.Closeable
import java.io.IOException
import java.net.InetAddress
import java.net.Inet6Address
import java.util.IdentityHashMap
import java.util.Locale
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

sealed class CarPlayStatus {
    data object DiscoveringMfi : CarPlayStatus()
    data object WaitingForMfi : CarPlayStatus()
    data object RequestingMfiPermission : CarPlayStatus()
    data object MfiReady : CarPlayStatus()
    data object StartingHotspot : CarPlayStatus()
    data class HotspotReady(
        val ssid: String,
        val band: String,
        val channel: Int,
        val bssid: String,
        val address: String,
        val backend: String,
    ) : CarPlayStatus()
    data object WaitingForPairedIphone : CarPlayStatus()
    data object ConnectingBluetooth : CarPlayStatus()
    data object RunningWireless : CarPlayStatus()
    data object WirelessActive : CarPlayStatus()
    data class WirelessConnecting(val stage: WirelessConnectionStage) : CarPlayStatus()
    data object DiscoveringIphone : CarPlayStatus()
    data object WaitingForIphone : CarPlayStatus()
    data object RequestingIphonePermission : CarPlayStatus()
    data object WaitingForReenumeration : CarPlayStatus()
    data object SelectingConfiguration : CarPlayStatus()
    data object OpeningDataPaths : CarPlayStatus()
    data object Pairing : CarPlayStatus()
    data object ConnectingControl : CarPlayStatus()
    data object AttachingNetwork : CarPlayStatus()
    data object RunningControl : CarPlayStatus()
    data object ControlEnded : CarPlayStatus()
    data class Failed(
        val message: String,
        val wirelessStage: WirelessConnectionStage? = null,
        val radioRecovery: Boolean = false,
        val frequencyMHz: Int? = null,
        val retryable: Boolean = true,
    ) : CarPlayStatus()
}

internal fun isWirelessHandoffInProgress(
    handoffRequested: Boolean,
    tunnelActive: Boolean,
    sessionActive: Boolean,
): Boolean = handoffRequested || tunnelActive || sessionActive

/**
 * Wires the complete wired or wireless CarPlay path: MFi coprocessor discovery, iPhone bring-up,
 * iAP2 control, transport setup, and the AirPlay media/input sessions.
 *
 * All blocking USB/I2C work runs on one worker executor. Status callbacks are delivered on the
 * main thread. This class is the integration seam only and is not evidence of hardware operation.
 */
class CarPlayController(
    context: Context,
    private val config: CarPlayRuntimeConfig,
    private val airPlayConfig: AirPlayConfig,
    private val identity: AirPlayIdentity,
    private val pairings: PairingStore,
    listener: AirPlaySessionListener,
    private val media: AirPlayMediaHandler,
    reportStatus: (CarPlayStatus) -> Unit,
    private val loadPairRecord: () -> LockdownPairRecord? = { null },
    private val savePairRecord: (LockdownPairRecord) -> Unit = {},
    private val clearPairRecord: () -> Unit = {},
    private val locationProvider: Iap2LocationProvider? = null,
) : Closeable {
    init {
        require(!config.locationReportingEnabled || locationProvider != null) {
            "A location provider is required when location reporting is enabled"
        }
    }

    private enum class Phase { IDLE, MFI, WIRELESS, IPHONE, REENUMERATION, DATAPATHS, CONTROL }

    private val appContext = context.applicationContext
    private val usbManager = context.getSystemService(UsbManager::class.java)
    private val bluetoothAdapter =
        appContext.getSystemService(BluetoothManager::class.java)?.adapter
    private val iphoneHost = IphoneUsbHost(
        appContext,
        usbManager,
        if (config.iphoneDevices.isNotEmpty()) {
            IphoneUsbMatcher(config.iphoneDevices)
        } else {
            IphoneUsbMatcher.appleVendor()
        },
    )
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val touchExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val mediaButtonExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val tunnelExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val hostId = UUID.randomUUID().toString().uppercase(Locale.US)
    private val systemBuid = UUID.randomUUID().toString().uppercase(Locale.US)
    private val lifecycleLock = Any()
    @Volatile private var uiListener: AirPlaySessionListener? = listener
    @Volatile private var uiStatusReporter: ((CarPlayStatus) -> Unit)? = reportStatus
    private val permissionGrant = AtomicBoolean(false)
    private val availabilityPollGeneration = AtomicInteger(0)
    private var permissionPollGeneration = 0
    private var reenumerationAttempts = 0
    private var lastReportedStatus: CarPlayStatus? = null
    private var mfiResetLogged = false

    @Volatile private var closed = false
    @Volatile private var phase = Phase.IDLE
    @Volatile private var ch341Host: Ch341UsbHost? = null
    @Volatile private var mfiSession: MfiSession? = null
    @Volatile private var mux: Iap2UsbMuxHost? = null
    @Volatile private var csm: Iap2Session? = null
    @Volatile private var activeSession: AirPlaySession? = null
    @Volatile private var hotspot: WirelessHotspotManager? = null
    @Volatile private var bonjour: CarPlayBonjour? = null
    @Volatile private var bluetoothSocket: BluetoothSocket? = null
    @Volatile private var bluetoothStream: BluetoothRfcommDuplexStream? = null
    @Volatile private var wirelessTunnelChannel: Iap2Session? = null
    @Volatile private var activeMediaRemoteSession: Iap2Session? = null
    private val fileTransferReceivers = IdentityHashMap<Iap2Session, Iap2FileTransferReceiver>()
    @Volatile private var wirelessIdentification: Iap2IdentificationConfig? = null
    @Volatile private var wirelessAirPlayEndpoint: Iap2WirelessCarPlayEndpoint? = null
    @Volatile private var vpnService: CarPlayVpnService? = null
    @Volatile private var vpnBound = false
    private val wirelessHandoffRequested = AtomicBoolean(false)
    private val wirelessTunnelReady = AtomicBoolean(false)
    private val wirelessActiveReported = AtomicBoolean(false)
    private val wirelessGeneration = AtomicInteger(0)
    private val wirelessDeadline = WirelessConnectionDeadline()
    private val wirelessAttemptFailed = AtomicBoolean(false)
    @Volatile private var wirelessPairingSignal: WirelessPairingSignal? = null
    @Volatile private var wirelessFrequencyMHz: Int? = null
    private val nowPlaying = Iap2NowPlayingAccumulator()
    private val playbackStatus = CarPlayPlaybackStatus()
    private val navigationFrameLock = Any()
    @Volatile private var activeAirPlayToken: Any? = null
    // Owned by the serialized input executor; a gesture opens only one output-progress episode.
    private var touchEpisodeToken: Any? = null
    private var touchEpisodeDown = false
    private val hs5 = HongqiNavigation.supported()
    private val vehicleData = com.shilapi.xcertplay.vehicle.Hs5VehicleData.acquire(appContext, this)
    @Volatile private var connectedIphone: BluetoothDevice? = null
    private val wirelessPreferences = appContext.getSharedPreferences("carplay_wireless", Context.MODE_PRIVATE)
    private fun receiverIdentification() = config.identification.copy(
        routeGuidanceEnabled = hs5, laneGuidanceEnabled = hs5,
        vehicleSpeedEnabled = hs5 && config.locationReportingEnabled &&
            com.shilapi.xcertplay.hud.HongqiVehicleSpeed.available(appContext),
    )
    private val bluetoothMediaHandoff = HongqiBluetoothMediaHandoff(appContext)
    fun activeAirPlaySessionToken(): Any? = if (!closed && activeSession?.isClosed() == false) activeAirPlayToken else null
    fun sendMediaButton(index: Int): Boolean {
        val session = activeSession ?: return false
        val command = when (index) {
            CarPlayMediaButton.PLAY -> Iap2MediaRemoteCommand.PLAY
            CarPlayMediaButton.PAUSE -> Iap2MediaRemoteCommand.PAUSE
            CarPlayMediaButton.NEXT -> Iap2MediaRemoteCommand.NEXT
            CarPlayMediaButton.PREVIOUS -> Iap2MediaRemoteCommand.PREVIOUS
            CarPlayMediaButton.PLAY_PAUSE -> if (playbackStatus.playing) Iap2MediaRemoteCommand.PAUSE else Iap2MediaRemoteCommand.PLAY
            else -> return false
        }
        SiriPlaybackRecovery.onMediaButton(session, index)
        return sendMediaRemoteCommand(command)
    }
    fun sendKnob(state: AirPlayKnobState, momentary: Boolean = true): Boolean {
        val session = activeSession ?: return false
        val token = session.mainScreenSessionToken() ?: return false
        return try {
            touchExecutor.execute {
                if (!closed && activeSession === session && session.mainScreenSessionToken() === token &&
                    session.sendKnobForMainScreen(state, momentary, token)) {
                    media.onVideoInteraction(session, token)
                }
            }
            true
        } catch (_: java.util.concurrent.RejectedExecutionException) { false }
    }
    fun sendTelephonyButton(index: Int): Boolean = index in listOf(1, 3) && queueAirPlayControl { it.sendTelephony(index) }
    fun requestPhoneUi(): Boolean = queueAirPlayControl { it.requestPhoneUi() }
    fun requestSiri(): Boolean = queueAirPlayControl { session ->
        media.onSiriRequested(session)
        SiriPlaybackRecovery.onRequested(session, synchronized(playbackStatus) { playbackStatus.nowPlaying })
        session.invokeSiri()
    }
    private fun queueAirPlayControl(action: (AirPlaySession) -> Unit): Boolean {
        val session = activeSession ?: return false
        val token = activeAirPlaySessionToken() ?: return false
        return try {
            touchExecutor.execute {
                if (!closed && activeSession === session && activeAirPlaySessionToken() === token) action(session)
            }
            true
        } catch (_: java.util.concurrent.RejectedExecutionException) { false }
    }
    private fun publishAudioContext(session: AirPlaySession) {
        val phone = when (AirPlayPhoneState.callKeyState(session)) {
            AirPlayPhoneState.CallKeyState.RINGING, AirPlayPhoneState.CallKeyState.IN_CALL -> true
            else -> AirPlayPhoneState.active(session)
        }
        media.onPlaybackContext(session, synchronized(playbackStatus) { playbackStatus.nowPlaying }, phone, AirPlaySpeechState.active(session))
    }

    private var permissionCloseable: Closeable? = null
    private var attachCloseable: Closeable? = null
    private var ch341PermissionCloseable: Closeable? = null
    private var vpnLatch = CountDownLatch(1)
    private val teardownComplete = CountDownLatch(1)

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            vpnService = (binder as CarPlayVpnService.LocalBinder).service
            vpnLatch.countDown()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            vpnService = null
            fail(IphoneUsbException.DeviceUnavailable("CarPlay VPN service disconnected"))
        }
    }

    private val wirelessPeerAddresses = ConcurrentHashMap<AirPlaySession, String>()

    private val sessionListener = object : AirPlaySessionListener {
        override fun onSessionActive(session: AirPlaySession) {
            synchronized(navigationFrameLock) {
                if (closed || session.isClosed() || wirelessAttemptFailed.get()) return
                if (config.transport == CarPlayTransport.WIRELESS) {
                    advanceWireless(wirelessGeneration.get(), WirelessConnectionStage.CONNECTED)
                    if (wirelessAttemptFailed.get()) return
                    rememberSuccessfulWirelessPhone()
                }
                if (activeSession !== session) {
                    if (hs5) FawNavigationOutputs.endNow(this@CarPlayController)
                    activeAirPlayToken = Any()
                }
                activeSession = session
                if (config.transport == CarPlayTransport.WIRELESS) {
                    hotspot?.setActivePeer(wirelessPeerAddresses[session])
                }
                media.onSessionActive(session)
                if (hs5) FawNavigationOutputs.start(appContext, this@CarPlayController)
                publishAudioContext(session)
            }
            debugLog(
                "AirPlay session active controller=${session.controllerId ?: "unknown"} " +
                    "peer=${session.host}",
            )
            uiListener?.onSessionActive(session)
        }

        override fun onSessionDisconnected(session: AirPlaySession) {
            // Leave final resource cleanup to onSessionEnded, without delaying the home screen.
            if (!closed && activeSession === session) {
                uiListener?.onSessionDisconnected(session)
            }
        }

        override fun onSessionEnded(session: AirPlaySession) {
            val wasActive: Boolean
            synchronized(navigationFrameLock) {
                CallPlaybackRecovery.onSessionEnded(session)
                SiriPlaybackRecovery.onSessionEnded(session)
                AirPlayPhoneState.forgetCalls(session)
                wasActive = activeSession === session
                if (wasActive) {
                    activeSession = null
                    hotspot?.setActivePeer(null)
                    activeAirPlayToken = null
                    synchronized(playbackStatus) { playbackStatus.clearAll() }
                    if (hs5) FawNavigationOutputs.endNow(this@CarPlayController)
                    bluetoothMediaHandoff.stop()
                }
                wirelessPeerAddresses.remove(session)
            }
            debugLog("AirPlay session ended peer=${session.host}")
            if (wasActive) uiListener?.onSessionEnded(session)
        }

        override fun onTransportError(message: String) {
            debugLog("AirPlay transport error: $message")
            uiListener?.onTransportError(message)
        }

        override fun onDeviceInfo(session: AirPlaySession, info: AirPlayDeviceInfo) {
            synchronized(navigationFrameLock) {
                if (!closed && !session.isClosed() && config.transport == CarPlayTransport.WIRELESS && info.wifiMac.isNotBlank()) {
                    wirelessPeerAddresses[session] = info.wifiMac
                    if (activeSession === session) hotspot?.setActivePeer(info.wifiMac)
                }
            }
            debugLog(
                "AirPlay device info name=${info.name} deviceId=${info.deviceId} " +
                    "wifiMac=${info.wifiMac} model=${info.model}",
            )
            uiListener?.onDeviceInfo(session, info)
        }

        override fun onHostUiRequested(session: AirPlaySession) {
            uiListener?.onHostUiRequested(session)
        }

        override fun onCommand(session: AirPlaySession, type: String, params: Map<String, Any?>) {
            if (activeSession === session && !closed) {
                AirPlayPhoneState.observe(session, type, params)
                AirPlaySpeechState.observe(session, type, params)
                publishAudioContext(session)
                if (hs5) {
                    CallPlaybackRecovery.onPhoneState(this@CarPlayController, session, type)
                    SiriPlaybackRecovery.onModesChanged(this@CarPlayController, session, type)
                }
            }
            debugLog(
                "AirPlay command type=$type params=${params.keys.sorted().joinToString(",")}",
            )
            if (
                config.transport == CarPlayTransport.WIRELESS &&
                !closed &&
                activeSession === session &&
                isBluetoothHandoffCommand(type) &&
                wirelessHandoffRequested.compareAndSet(false, true)
            ) {
                debugLog(
                    "wireless CarPlay Bluetooth handoff requested; " +
                        "waiting for tunnel iAP2 readiness",
                )
                armWirelessHandoffWatchdog(wirelessGeneration.get())
                maybeCompleteWirelessHandoff()
            }
            uiListener?.onCommand(session, type, params)
        }

        override fun onDebugLog(message: String) {
            debugLog(message)
        }
    }

    fun attachUi(
        listener: AirPlaySessionListener,
        reportStatus: (CarPlayStatus) -> Unit,
    ) {
        synchronized(lifecycleLock) {
            uiListener = listener
            uiStatusReporter = reportStatus
        }
        mainHandler.post {
            if (closed || uiListener !== listener || uiStatusReporter !== reportStatus) return@post
            // A detached Activity misses the early disconnect while media is still closing.
            // Replay current lifecycle state before an older connected status can restore it.
            val session = activeSession
            if (session != null && session.isClosed()) {
                listener.onSessionDisconnected(session)
            } else {
                lastReportedStatus?.let(reportStatus)
            }
        }
    }

    fun detachUi(expected: AirPlaySessionListener): Boolean {
        synchronized(lifecycleLock) {
            if (uiListener !== expected) return false
            uiListener = null
            uiStatusReporter = null
            return true
        }
    }

    fun isClosed(): Boolean = closed

    fun hasActiveAirPlayAttachment(): Boolean = synchronized(lifecycleLock) {
        !closed && vpnService?.isAttached() == true
    }

    fun start() {
        synchronized(this) {
            if (closed) return
        }
        CarPlayMediaSessionBridge.attach(appContext, this, ::sendMediaRemoteCommand)
        if (config.transport == CarPlayTransport.WIRED) {
            permissionCloseable = iphoneHost.registerPermissionReceiver(::onIphonePermission)
            attachCloseable = iphoneHost.registerAttachReceiver(::onIphoneAttached)
        }
        startMfi()
    }

    /** Reopens the CH341/MFi path without restarting the app. */
    fun reconnectMfi() = synchronized(lifecycleLock) {
        if (closed) return
        closeMfiSession()
        startMfi()
    }

    /** Re-runs iPhone discovery/bring-up using the already-open MFi session. */
    fun reconnectIphone() = synchronized(lifecycleLock) {
        if (closed || wirelessAttemptFailed.get()) return
        if (mfiSession == null) {
            startMfi()
        } else if (config.transport == CarPlayTransport.WIRELESS) {
            restartWireless()
        } else {
            startIphone()
        }
    }

    fun sendTouch(contacts: List<AirPlayContact>): Boolean {
        if (closed) return false
        val session = activeSession ?: return false
        val token = session.mainScreenSessionToken() ?: return false
        val snapshot = contacts.toList()
        return try {
            touchExecutor.execute {
                if (!closed && activeSession === session && session.mainScreenSessionToken() === token &&
                    session.sendTouchForMainScreen(snapshot, token)) {
                    val down = snapshot.any { it.down }
                    if (down && (touchEpisodeToken !== token || !touchEpisodeDown)) {
                        media.onVideoInteraction(session, token)
                    }
                    touchEpisodeToken = token
                    touchEpisodeDown = down
                }
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun onIap2Incoming(frame: Iap2Frame) {
        synchronized(navigationFrameLock) {
            if (closed) return
            val session = activeSession
            if (session != null && !session.isClosed()) {
                AirPlayPhoneState.observeCallState(session, frame)
                if (hs5) FawNavigationOutputs.onFrame(frame)
                synchronized(playbackStatus) { playbackStatus.acceptUpdate(frame) }?.let {
                    CallPlaybackRecovery.onPlayback(session, it)
                    SiriPlaybackRecovery.onPlayback(session, it)
                }
                publishAudioContext(session)
            }
        }
        if (frame.messageId != NOW_PLAYING_UPDATE) return
        try {
            CarPlayMediaSessionBridge.publish(this, nowPlaying.update(frame))
        } catch (error: RuntimeException) {
            debugLog("Could not decode iAP2 NowPlayingUpdate", error)
        }
    }

    private fun activateMediaRemote(session: Iap2Session) {
        startFileTransferReceiver(session)
        activeMediaRemoteSession = session
        if (hs5 && config.transport == CarPlayTransport.WIRELESS) {
            connectedIphone?.let { device -> bluetoothMediaHandoff.start(device) { !closed && activeMediaRemoteSession === session } }
        }
        CarPlayMediaSessionBridge.setControlsAvailable(this, true)
    }

    private fun deactivateMediaRemote(session: Iap2Session) {
        stopFileTransferReceiver(session)
        if (activeMediaRemoteSession !== session) return
        activeMediaRemoteSession = null
        CarPlayMediaSessionBridge.setControlsAvailable(this, false)
    }

    private fun startFileTransferReceiver(session: Iap2Session) {
        val receiver = synchronized(fileTransferReceivers) {
            if (fileTransferReceivers.containsKey(session)) return
            Iap2FileTransferReceiver(
                session = session,
                isArtworkCached = { fileTransferId ->
                    CarPlayMediaSessionBridge.hasArtwork(this, fileTransferId)
                },
                onArtwork = { artwork ->
                    CarPlayMediaSessionBridge.publishArtwork(
                        this,
                        artwork.fileTransferId,
                        artwork.bytes,
                    )
                },
                onLog = ::debugLog,
            ).also { fileTransferReceivers[session] = it }
        }
        receiver.start()
    }

    private fun stopFileTransferReceiver(session: Iap2Session) {
        val receiver = synchronized(fileTransferReceivers) {
            fileTransferReceivers.remove(session)
        }
        receiver?.close()
    }

    private fun stopFileTransferReceivers() {
        val receivers = synchronized(fileTransferReceivers) {
            fileTransferReceivers.values.toList().also { fileTransferReceivers.clear() }
        }
        receivers.forEach { it.close() }
    }

    private fun sendMediaRemoteCommand(command: Iap2MediaRemoteCommand): Boolean {
        if (closed) return false
        val session = activeMediaRemoteSession ?: return false
        val airPlaySession = activeSession ?: return false
        val token = activeAirPlaySessionToken() ?: return false
        if (session.isClosed) return false
        if (hs5 && command == Iap2MediaRemoteCommand.PAUSE) airPlaySession.let {
            CallPlaybackRecovery.onMediaButton(it, CarPlayMediaButton.PAUSE)
            SiriPlaybackRecovery.onMediaButton(it, CarPlayMediaButton.PAUSE)
        }
        return try {
            mediaButtonExecutor.execute {
                if (closed || activeMediaRemoteSession !== session || session.isClosed ||
                    activeSession !== airPlaySession || activeAirPlaySessionToken() !== token) return@execute
                try {
                    session.send(Iap2HidMessages.mediaReport(command), MEDIA_REMOTE_SEND_TIMEOUT_MILLIS)
                    // Consumer Control buttons are momentary: hold the press long enough for the
                    // phone to register the 0→1 edge before releasing, otherwise it may debounce
                    // the button as a glitch and never change track.
                    Thread.sleep(HID_REPORT_HOLD_MILLIS)
                    if (closed || activeMediaRemoteSession !== session || session.isClosed ||
                        activeSession !== airPlaySession || activeAirPlaySessionToken() !== token) return@execute
                    session.send(Iap2HidMessages.releaseMediaButtons(), MEDIA_REMOTE_SEND_TIMEOUT_MILLIS)
                } catch (error: Exception) {
                    debugLog("Could not send iAP2 media command $command", error)
                }
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    override fun close() {
        synchronized(this) {
            if (closed) return
            closed = true
        }
        wirelessDeadline.stop()
        vehicleData.close()
        wirelessPairingSignal?.close()
        synchronized(navigationFrameLock) {
            activeAirPlayToken = null
            wirelessPeerAddresses.clear()
            activeSession?.let { CallPlaybackRecovery.onSessionEnded(it); SiriPlaybackRecovery.onSessionEnded(it) }
            if (hs5) FawNavigationOutputs.endNow(this@CarPlayController)
            bluetoothMediaHandoff.stop()
        }
        closeReceivers()
        stopFileTransferReceivers()
        availabilityPollGeneration.incrementAndGet()
        wirelessGeneration.incrementAndGet()
        permissionPollGeneration += 1
        activeMediaRemoteSession = null
        CarPlayMediaSessionBridge.detach(appContext, this)
        touchExecutor.shutdownNow()
        mediaButtonExecutor.shutdownNow()
        tunnelExecutor.shutdownNow()
        val service = vpnService
        unbindVpn()
        Thread(
            {
                try {
                    if (config.transport == CarPlayTransport.WIRELESS) {
                        closeBestEffort("wireless stack") { closeWirelessStack(service) }
                    } else {
                        closeBestEffort("CSM") { csm?.close() }
                        csm = null
                    }
                    closeBestEffort("USBMUX") { mux?.close() }
                    mux = null
                    if (config.transport == CarPlayTransport.WIRED) {
                        closeBestEffort("VPN/NCM") { service?.detach() }
                    }
                    closeBestEffort("MFi") { mfiSession?.close() }
                    mfiSession = null
                    wirelessIdentification = null
                    wirelessAirPlayEndpoint = null
                    closeBestEffort("location provider") { locationProvider?.close() }
                } finally {
                    executor.shutdownNow()
                    try {
                        executor.awaitTermination(EXECUTOR_CLOSE_TIMEOUT_MILLIS, TimeUnit.MILLISECONDS)
                    } catch (_: InterruptedException) {
                        Thread.currentThread().interrupt()
                    }
                    teardownComplete.countDown()
                }
            },
            "xcertplay-controller-teardown",
        ).apply {
            isDaemon = true
            start()
        }
    }

    /** Waits for USB, iAP2, MFi and VPN teardown; intended for a non-main lifecycle thread. */
    fun awaitClosed(timeoutMillis: Long): Boolean {
        require(timeoutMillis >= 0) { "timeoutMillis must not be negative" }
        return try {
            teardownComplete.await(timeoutMillis, TimeUnit.MILLISECONDS)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            false
        }
    }

    private fun startMfi() {
        availabilityPollGeneration.incrementAndGet()
        phase = Phase.MFI
        onStatus(CarPlayStatus.DiscoveringMfi)
        when (config.mfiTarget) {
            MfiTarget.USB_CH341 -> {
                debugLog("mfi discovery backend=CH341 devices=${config.ch341Devices}")
                val host = ch341Host ?: Ch341UsbHost(
                    appContext,
                    usbManager,
                    Ch341DeviceMatcher(config.ch341Devices),
                ).also {
                    ch341Host = it
                    ch341PermissionCloseable = it.registerPermissionReceiver(::onCh341Permission)
                }
                checkCh341Mfi(host)
            }
            MfiTarget.I2C -> {
                debugLog("mfi discovery backend=Linux I2C path=${config.linuxI2cPath}")
                openLinuxMfi()
            }
            MfiTarget.REMOTE -> {
                debugLog("mfi discovery backend=Remote server=${config.remoteMfiServer.orEmpty()}")
                openRemoteMfi()
            }
            MfiTarget.LOCAL_FILES -> {
                debugLog("mfi discovery backend=Local documents")
                openLocalMfi()
            }
        }
    }

    private fun openLocalMfi() {
        executor.execute {
            try {
                val resolver = appContext.contentResolver
                val certificateUri = Uri.parse(checkNotNull(config.localMfiCertificateUri))
                val privateKeyUri = Uri.parse(checkNotNull(config.localMfiPrivateKeyUri))
                val client = resolver.openInputStream(certificateUri)?.use { certificateInput ->
                    resolver.openInputStream(privateKeyUri)?.use { privateKeyInput ->
                        LocalMfiAuthenticationClient.load(certificateInput, privateKeyInput)
                    } ?: throw IOException("Could not open the selected local MFi private key")
                } ?: throw IOException("Could not open the selected local MFi certificate")
                val protocolMajor = client.protocolMajor()
                if (closed || phase != Phase.MFI) return@execute
                mfiSession = MfiSession(client, null)
                debugLog("mfi local documents ready protocolMajor=$protocolMajor")
                onStatus(CarPlayStatus.MfiReady)
                startPhone()
            } catch (error: Throwable) {
                fail(error)
            }
        }
    }

    private fun openRemoteMfi() {
        executor.execute {
            try {
                val client = RemoteMfiAuthenticationClient(
                    serverAddress = checkNotNull(config.remoteMfiServer),
                    token = config.remoteMfiToken,
                )
                client.reset()
                val protocolMajor = client.protocolMajor()
                if (closed || phase != Phase.MFI) return@execute
                mfiSession = MfiSession(client, null)
                debugLog(
                    "mfi remote service ready server=${config.remoteMfiServer} " +
                        "protocolMajor=$protocolMajor",
                )
                onStatus(CarPlayStatus.MfiReady)
                startPhone()
            } catch (error: Throwable) {
                fail(error)
            }
        }
    }

    private fun checkCh341Mfi(host: Ch341UsbHost) {
        if (closed || phase != Phase.MFI) return
        val device = host.discover().firstOrNull()
        if (device == null) {
            waitForMfi()
        } else {
            availabilityPollGeneration.incrementAndGet()
            requestCh341Permission(device)
        }
    }

    private fun openLinuxMfi() {
        executor.execute {
            try {
                val transport = LinuxI2cTransport.open(config.linuxI2cPath!!)
                try {
                    mfiSession = MfiSession(MfiRuntime.scan(transport), transport)
                    debugLog("mfi Linux I2C coprocessor ready path=${config.linuxI2cPath}")
                    onStatus(CarPlayStatus.MfiReady)
                    startPhone()
                } catch (error: Throwable) {
                    transport.close()
                    throw error
                }
            } catch (error: MfiCoprocessorNotFoundException) {
                debugLog("mfi Linux discovery failed: ${error.message}")
                waitForMfi()
            } catch (error: Throwable) {
                fail(error)
            }
        }
    }

    private fun requestCh341Permission(device: UsbDevice) {
        try {
            when (val request = ch341Host!!.requestPermission(device)) {
                is Ch341UsbHost.PermissionRequest.AlreadyGranted -> {
                    permissionGrant.set(false)
                    onCh341Permission(Ch341UsbHost.PermissionResult.Granted(request.device))
                }
                is Ch341UsbHost.PermissionRequest.Requested -> {
                    permissionGrant.set(false)
                    onStatus(CarPlayStatus.RequestingMfiPermission)
                    pollCh341Permission(device)
                }
            }
        } catch (error: Throwable) {
            fail(error)
        }
    }

    private fun onCh341Permission(result: Ch341UsbHost.PermissionResult) {
        if (closed || phase != Phase.MFI) return
        when (result) {
            is Ch341UsbHost.PermissionResult.Granted -> {
                // The system broadcast and CarUsbHandler's direct grant can both observe success.
                if (!permissionGrant.compareAndSet(false, true)) return
                permissionPollGeneration++
                openCh341(result.device)
            }
            is Ch341UsbHost.PermissionResult.Denied -> {
                permissionGrant.set(true)
                onStatus(CarPlayStatus.Failed("CH341 USB permission was denied"))
            }
        }
    }

    /** Some car systems grant USB access through CarUsbHandler without delivering a broadcast. */
    private fun pollCh341Permission(device: UsbDevice) {
        val generation = ++permissionPollGeneration
        val deadlineNanos = System.nanoTime() + PERMISSION_POLL_TIMEOUT_MILLIS * 1_000_000L
        val check = object : Runnable {
            override fun run() {
                if (closed || phase != Phase.MFI || generation != permissionPollGeneration) return
                if (usbManager.hasPermission(device)) {
                    onCh341Permission(Ch341UsbHost.PermissionResult.Granted(device))
                    return
                }
                if (System.nanoTime() >= deadlineNanos) {
                    if (permissionGrant.compareAndSet(false, true)) {
                        onStatus(
                            CarPlayStatus.Failed(
                                "MFi USB permission was not granted; reconnect the CH341 to retry",
                            ),
                        )
                    }
                    return
                }
                mainHandler.postDelayed(this, PERMISSION_POLL_INTERVAL_MILLIS)
            }
        }
        mainHandler.postDelayed(check, PERMISSION_POLL_INTERVAL_MILLIS)
    }

    private fun openCh341(device: UsbDevice) {
        ch341Host!!.openAsync(device, executor) { result ->
            when (result) {
                is Ch341UsbHost.OpenResult.Connected -> {
                    val session: Ch341UsbSession = result.session
                    if (closed || phase != Phase.MFI) {
                        session.close()
                        return@openAsync
                    }
                    try {
                        val transport = Ch341I2cTransport(session)
                        config.ch341MfiResetGpio?.let { gpio ->
                            transport.pulseActiveLowReset(gpio)
                            if (!mfiResetLogged) {
                                mfiResetLogged = true
                                debugLog("mfi reset pulse gpio=D$gpio mode=low/high-z")
                            }
                        }
                        val client = MfiRuntime.scan(transport)
                        val probes = mfiCandidateAddresses
                            .associateWith { address -> probeMfiCandidate(transport, address) }
                        for ((address, probe) in probes) {
                            debugLog("mfi probe address=0x${address.toString(16)} ${probe.describe()}")
                        }
                        val selected = preferCertificateBearingAddress(client, transport, probes)
                        debugLog(
                            "mfi coprocessor address=0x${selected.address7Bit.toString(16)} " +
                                "protocolMajor=${selected.protocolMajor()}",
                        )
                        mfiSession = MfiSession(selected, session)
                        debugLog("mfi CH341 session ready")
                        onStatus(CarPlayStatus.MfiReady)
                        startPhone()
                    } catch (error: MfiCoprocessorNotFoundException) {
                        debugLog("mfi CH341 discovery failed: ${error.message}")
                        Log.w(IphoneCarPlayConfiguration.TAG, error.message ?: "MFi discovery failed")
                        session.close()
                        waitForMfi()
                    } catch (error: Throwable) {
                        session.close()
                        fail(error)
                    }
                }
                is Ch341UsbHost.OpenResult.Failed -> when (result.error) {
                    is I2cTransportException.DeviceUnavailable -> waitForMfi()
                    else -> fail(result.error)
                }
            }
        }
    }

    private val mfiCandidateAddresses = listOf(0x10, 0x11)
    private val maxMfiCertificateBytes = 1280

    private data class MfiCandidateProbe(
        val deviceVersion: Int?,
        val firmwareVersion: Int?,
        val protocolMajor: Int?,
        val accessoryCertificateLength: Int?,
        val appleCertificateLength: Int?,
        val failure: String?,
    ) {
        val hasAccessoryCertificate: Boolean
            get() = (accessoryCertificateLength ?: 0) in 1..1280

        fun describe(): String {
            if (failure != null) return failure
            return "deviceVersion=" + hex(deviceVersion) +
                " firmwareVersion=" + hex(firmwareVersion) +
                " protocolMajor=" + hex(protocolMajor) +
                " accessoryCertificateLength=" + accessoryCertificateLength +
                " appleCertificateLength=" + appleCertificateLength
        }

        private fun hex(value: Int?): String =
            if (value == null) "?" else "0x" + value.toString(16).padStart(2, '0')
    }

    private fun probeMfiCandidate(transport: I2cTransport, address7Bit: Int): MfiCandidateProbe = try {
        MfiCandidateProbe(
            deviceVersion = readMfiRegister(transport, address7Bit, 0x00, 1),
            firmwareVersion = readMfiRegister(transport, address7Bit, 0x01, 1),
            protocolMajor = readMfiRegister(transport, address7Bit, 0x02, 1),
            accessoryCertificateLength = readMfiRegister(transport, address7Bit, 0x30, 2),
            appleCertificateLength = readMfiRegister(transport, address7Bit, 0x50, 2),
            failure = null,
        )
    } catch (error: Throwable) {
        MfiCandidateProbe(
            deviceVersion = null,
            firmwareVersion = null,
            protocolMajor = null,
            accessoryCertificateLength = null,
            appleCertificateLength = null,
            failure = "failed: " + error.javaClass.simpleName + ": " + error.message,
        )
    }

    private fun readMfiRegister(
        transport: I2cTransport,
        address7Bit: Int,
        register: Int,
        length: Int,
    ): Int {
        transport.transaction(address7Bit, byteArrayOf(register.toByte()), 0)
        var value = 0
        for (byte in transport.transaction(address7Bit, ByteArray(0), length)) {
            value = (value shl 8) or (byte.toInt() and 0xff)
        }
        return value
    }

    private fun preferCertificateBearingAddress(
        client: MfiAuthenticationClient,
        transport: I2cTransport,
        probes: Map<Int, MfiCandidateProbe>,
    ): MfiAuthenticationClient {
        if (probes[client.address7Bit]?.hasAccessoryCertificate == true) return client
        val alternative = probes.entries.firstOrNull { (address, probe) ->
            address != client.address7Bit && probe.hasAccessoryCertificate
        } ?: return client
        debugLog(
            "mfi address override: 0x" + client.address7Bit.toString(16) +
                " has no accessory certificate; using 0x" + alternative.key.toString(16),
        )
        return MfiAuthenticationClient(transport, alternative.key)
    }

    private fun waitForMfi() {
        if (closed || phase != Phase.MFI) return
        onStatus(CarPlayStatus.WaitingForMfi)
        scheduleAvailabilityPoll(Phase.MFI) {
            when (config.mfiTarget) {
                MfiTarget.USB_CH341 -> ch341Host?.let(::checkCh341Mfi)
                MfiTarget.I2C -> openLinuxMfi()
                MfiTarget.REMOTE, MfiTarget.LOCAL_FILES -> Unit
            }
        }
    }

    private fun startPhone() {
        if (config.locationReportingEnabled) {
            val started = try {
                locationProvider?.start() == true
            } catch (error: Throwable) {
                Log.w(
                    IphoneCarPlayConfiguration.TAG,
                    "Could not prewarm the Android location provider",
                    error,
                )
                false
            }
            debugLog("location provider prewarmed=$started")
        }
        if (config.transport == CarPlayTransport.WIRELESS) {
            startWireless()
        } else {
            startIphone()
        }
    }

    private fun startWireless() {
        // Share close()'s short state gate: a queued restart cannot revive a closed controller.
        synchronized(this) {
            if (closed) return
            availabilityPollGeneration.incrementAndGet()
            phase = Phase.WIRELESS
            wirelessHandoffRequested.set(false)
            wirelessTunnelReady.set(false)
            wirelessActiveReported.set(false)
            onStatus(CarPlayStatus.WaitingForPairedIphone)
            val generation = synchronized(navigationFrameLock) {
                wirelessAttemptFailed.set(false)
                wirelessGeneration.incrementAndGet()
            }
            wirelessFrequencyMHz = null
            wirelessDeadline.start(generation, SystemClock.elapsedRealtime())
            armWirelessDeadline(generation)
            executor.execute {
                runWireless(generation)
            }
        }
    }

    private fun restartWireless() {
        val owner = synchronized(this) {
            if (closed) return
            synchronized(navigationFrameLock) { wirelessGeneration.incrementAndGet() }
        }
        Thread(
            {
                closeWirelessStack()
                synchronized(this) {
                    if (!closed && owner == wirelessGeneration.get()) startWireless()
                }
            },
            "xcertplay-wireless-restart",
        ).apply {
            isDaemon = true
            start()
        }
    }

    private fun runWireless(generation: Int) {
        try {
            debugLog("wireless bring-up generation=$generation starting")
            closeWirelessStack()
            if (
                closed ||
                phase != Phase.WIRELESS ||
                generation != wirelessGeneration.get()
            ) {
                return
            }

            val mfi = mfiSession?.client
                ?: throw IOException("MFi coprocessor client is unavailable")
            val adapter = bluetoothAdapter
                ?: throw IOException("Bluetooth adapter is unavailable")
            if (!adapter.isEnabled) throw IOException("Bluetooth is not enabled")
            val devices = awaitWirelessBluetoothDevices(adapter, generation)
            if (isStaleWirelessRun(generation)) return
            advanceWireless(generation, WirelessConnectionStage.HOTSPOT)
            if (isStaleWirelessRun(generation)) return
            onStatus(CarPlayStatus.StartingHotspot)
            val hotspotInfo = startWirelessHotspot(generation, mfi)
            wirelessFrequencyMHz = hotspotInfo.frequencyMHz
            if (isStaleWirelessRun(generation)) {
                closeWirelessStack()
                return
            }
            val hostAddress = hotspotInfo.hostAddress
                ?: throw IOException(
                    "Wireless hotspot did not provide a usable host address",
                )
            if (
                hostAddress is Inet6Address &&
                (!hostAddress.isLinkLocalAddress || hostAddress.scopeId == 0)
            ) {
                throw IOException(
                    "Wireless hotspot link-local IPv6 address is not scoped",
                )
            }
            val hostAddressText = hostAddressText(hostAddress)
            val deviceIdentifier = hotspotInfo.bssid ?: airPlayConfig.deviceId
            debugLog(
                "wireless hotspot backend=${hotspotInfo.backend.label} " +
                    "iface=${hotspotInfo.interfaceName ?: "unknown"} " +
                    "host=$hostAddressText bssid=${hotspotInfo.bssid ?: "unavailable"} " +
                    "band=${hotspotInfo.bandLabel} channel=${hotspotInfo.channel} " +
                    "frequency=${hotspotInfo.frequencyMHz?.toString() ?: "unknown"}MHz",
            )
            onStatus(
                CarPlayStatus.HotspotReady(
                    ssid = hotspotInfo.ssid,
                    band = hotspotInfo.bandLabel,
                    channel = hotspotInfo.channel,
                    bssid = deviceIdentifier,
                    address = hostAddressText,
                    backend = hotspotInfo.backend.label,
                ),
            )
            advanceWireless(generation, WirelessConnectionStage.BLUETOOTH)
            val hostBluetoothMac = accessoryBluetoothMac(adapter)
            debugLog(
                "wireless Bluetooth PHONE_SMART candidates=${devices.size} " +
                    "localBt=$hostBluetoothMac",
            )
            val wirelessAirPlayConfig = airPlayConfig.copy(
                deviceId = deviceIdentifier,
                btMac = hostBluetoothMac,
                wirelessAudio = true,
            )

            onStatus(CarPlayStatus.AttachingNetwork)
            debugLog("wireless transport: binding AirPlay listener; Android VPN/TUN is not used")
            val service = awaitVpnService()
                ?: throw IOException("Could not bind the CarPlay AirPlay service")
            when (
                val result = synchronized(this) {
                    if (isStaleWirelessRun(generation)) return
                    service.attachWireless(
                        config = wirelessAirPlayConfig,
                        identity = identity,
                        pairings = pairings,
                        mfi = mfi,
                        listener = wirelessSessionListener(generation),
                        media = media,
                        owner = this,
                        bindAddress = hostAddress,
                    )
                }
            ) {
                CarPlayVpnService.AttachResult.Started -> Unit
                CarPlayVpnService.AttachResult.AlreadyStarted ->
                    throw IOException("Wireless AirPlay transport is already attached")
                is CarPlayVpnService.AttachResult.Failed ->
                    throw IOException(result.message)
            }
            debugLog(
                "wireless AirPlay listener attached bind=$hostAddressText " +
                    "port=${airPlayConfig.port}",
            )
            if (isStaleWirelessRun(generation)) {
                closeWirelessStack()
                return
            }

            val bonjourClient = CarPlayBonjour(
                context = appContext,
                config = wirelessAirPlayConfig,
                identity = identity,
                advertisedHost = hostAddress.hostAddress,
                onEvent = { event ->
                    if (!isStaleWirelessRun(generation)) {
                        when (event) {
                            is com.shilapi.xcertplay.network.CarPlayBonjourEvent.StartFailed ->
                                failWireless(generation, "连接服务启动失败：${event.operation}（${event.errorCode}）",
                                    retryable = true, radioRecovery = false)
                            else -> debugLog("wireless bonjour: $event")
                        }
                    }
                },
            )
            bonjour = bonjourClient
            bonjourClient.start()
            debugLog("wireless Bonjour startup requests submitted")
            if (isStaleWirelessRun(generation)) {
                closeWirelessStack()
                return
            }

            val channel = connectWirelessBluetoothDevices(devices, generation)
            if (isStaleWirelessRun(generation)) {
                closeWirelessStack()
                return
            }
            val identification = receiverIdentification().copy(
                wireless = Iap2WirelessIdentification(hostBluetoothMac, hotspotInfo.ssid),
            )
            val endpoint = Iap2WirelessCarPlayEndpoint(
                ssid = hotspotInfo.ssid,
                passphrase = hotspotInfo.passphrase,
                channel = hotspotInfo.channel,
                security = hotspotInfo.security,
                ipAddresses = listOf(hostAddressText),
                airPlayPort = airPlayConfig.port,
                deviceIdentifier = deviceIdentifier,
                publicKey = identity.publicKeyHex,
                sourceVersion = airPlayConfig.sourceVersion,
            )
            wirelessIdentification = identification
            wirelessAirPlayEndpoint = endpoint
            media.setIapTunnelHandler(::startWirelessTunnelControl)

            onStatus(CarPlayStatus.RunningWireless)
            debugLog("wireless Bluetooth iAP2 control starting")
            val result = Iap2WirelessControlClient(
                session = channel,
                mfi = Iap2MfiAuthenticationClient(mfi),
            ).run(
                identification = identification.copy(locationInformationEnabled = false, vehicleSpeedEnabled = false, routeGuidanceEnabled = false, laneGuidanceEnabled = false),
                endpoint = endpoint,
                bringUpTimeoutMillis = WIRELESS_CONTROL_TIMEOUT_MILLIS,
                // Location is owned by the type-130 control session; bootstrap teardown must not stop it.
                locationProvider = null,
                onReady = { if (!isStaleWirelessRun(generation)) activateMediaRemote(channel) },
                onStopped = { deactivateMediaRemote(channel) },
                onIncoming = { frame -> if (!isStaleWirelessRun(generation) && activeMediaRemoteSession === channel) onIap2Incoming(frame) },
                onProgress = ::debugLog,
                onStageChanged = { stage -> onWirelessBootstrapStage(generation, stage) },
            )
            if (isStaleWirelessRun(generation)) {
                closeWirelessStack()
                return
            }
            when (result.terminal) {
                Iap2WirelessControlTerminal.CHANNEL_CLOSED -> {
                    debugLog(
                        "wireless RFCOMM EOF: iap2State=${result.stage} " +
                            "wirelessCarPlayAvailable=${result.wirelessCarPlayAvailableSeen} " +
                            "transportIdentifier=${result.transportNotificationSeen} " +
                            "carPlayStartSessions=${result.carPlayStartSessionsSent} " +
                            "postTransportConfigs=${result.postTransportWiFiConfigurationsSent} " +
                            "handoffRequested=${wirelessHandoffRequested.get()} " +
                            "tunnelReady=${wirelessTunnelReady.get()} " +
                            "wirelessActive=${wirelessActiveReported.get()}",
                    )
                    if (!wirelessActiveReported.get()) {
                        val handoffInProgress = isWirelessHandoffInProgress(
                            handoffRequested = wirelessHandoffRequested.get(),
                            tunnelActive = wirelessTunnelChannel != null,
                            sessionActive = activeSession != null,
                        )
                        if (!handoffInProgress) {
                            throw IOException(
                                "Wireless CarPlay control channel closed before tunnel iAP2 ready",
                            )
                        }
                        debugLog(
                            "wireless Bluetooth bootstrap closed during handoff; " +
                                "keeping the Wi-Fi AirPlay tunnel alive",
                        )
                    }
                }
            }
        } catch (error: Throwable) {
            if (closed || generation != wirelessGeneration.get()) {
                return
            }
            if (wirelessActiveReported.get() && error !is Error) {
                debugLog("wireless RFCOMM control ended after tunnel handoff: ${error.message}")
            } else {
                debugLog("wireless bring-up failed", error)
                if (error is Error) throw error
                val detail = error.message
                val failureMessage = if (detail?.any { it in '\u4e00'..'\u9fff' } == true) detail
                    else "${wirelessDeadline.current(generation)?.label ?: "无线连接"}失败，请查看连接详情"
                failWireless(generation, failureMessage,
                    retryable = error !is SecurityException &&
                        error.cause !is SecurityException &&
                        error.cause !is com.shilapi.xcertplay.network.P2pResetRequiredException)
            }
        }
    }

    private fun startWirelessTunnelControl(stream: BlockingDuplexByteStream): Boolean {
        if (closed || config.transport != CarPlayTransport.WIRELESS) return false
        val identification = wirelessIdentification ?: return false
        val endpoint = wirelessAirPlayEndpoint ?: return false
        val mfi = mfiSession?.client ?: return false
        debugLog("wireless type-130 tunnel data stream accepted")
        val channel = try {
            Iap2Session.openTunnel(
                stream,
                traceContext = "wireless-tunnel",
                onTrace = ::debugLog,
            )
        } catch (error: Throwable) {
            debugLog("Could not open the tunneled iAP2 link", error)
            return false
        }
        wirelessTunnelChannel = channel
        val generation = wirelessGeneration.get()
        debugLog("wireless iAP2 tunnel control starting")
        return try {
            tunnelExecutor.execute {
                try {
                    val result = Iap2WirelessControlClient(
                        session = channel,
                        mfi = Iap2MfiAuthenticationClient(mfi),
                    ).run(
                        identification = identification,
                        endpoint = endpoint,
                        bringUpTimeoutMillis = WIRELESS_CONTROL_TIMEOUT_MILLIS,
                        locationProvider = locationProvider,
                        onReady = {
                            if (!isStaleWirelessRun(generation)) {
                                activateMediaRemote(channel)
                                onWirelessTunnelReady(generation)
                            }
                        },
                        onStopped = { deactivateMediaRemote(channel) },
                        onIncoming = { frame -> if (!isStaleWirelessRun(generation) && activeMediaRemoteSession === channel) onIap2Incoming(frame) },
                        onProgress = { message -> debugLog("iAP tunnel $message") },
                    )
                    if (closed || generation != wirelessGeneration.get()) return@execute
                    when (result.terminal) {
                        Iap2WirelessControlTerminal.CHANNEL_CLOSED ->
                            onStatus(CarPlayStatus.Failed("Wireless iAP2 tunnel closed"))
                    }
                } catch (error: Throwable) {
                    if (!closed && generation == wirelessGeneration.get()) {
                        debugLog("tunneled iAP2 control failed", error)
                        onStatus(
                            CarPlayStatus.Failed(
                                error.message ?: error.javaClass.simpleName,
                            ),
                        )
                    }
                } finally {
                    if (wirelessTunnelChannel === channel) wirelessTunnelChannel = null
                }
            }
            true
        } catch (error: Throwable) {
            if (wirelessTunnelChannel === channel) wirelessTunnelChannel = null
            closeBestEffort("tunneled iAP2 link") { channel.close() }
            debugLog("iAP2 tunnel executor rejected the link", error)
            false
        }
    }

    private fun onWirelessTunnelReady(generation: Int) {
        if (
            closed ||
            phase != Phase.WIRELESS ||
            generation != wirelessGeneration.get()
        ) {
            return
        }
        wirelessTunnelReady.set(true)
        debugLog(
            "wireless iAP2 tunnel ready; " +
                "handoffRequested=${wirelessHandoffRequested.get()}",
        )
        maybeCompleteWirelessHandoff()
    }

    private fun maybeCompleteWirelessHandoff() {
        if (!wirelessHandoffRequested.get() || !wirelessTunnelReady.get()) return
        if (!wirelessActiveReported.compareAndSet(false, true)) return
        val generation = wirelessGeneration.get()
        Thread(
            {
                if (
                    closed ||
                    phase != Phase.WIRELESS ||
                    generation != wirelessGeneration.get()
                ) {
                    return@Thread
                }
                debugLog("wireless handoff ready; closing Bluetooth bootstrap transport")
                closeBluetoothBootstrapTransport()
                onStatus(CarPlayStatus.WirelessActive)
            },
            "xcertplay-wireless-handoff",
        ).apply {
            isDaemon = true
            start()
        }
    }

    private fun armWirelessHandoffWatchdog(generation: Int) {
        mainHandler.postDelayed(
            {
                if (
                    closed ||
                    phase != Phase.WIRELESS ||
                    generation != wirelessGeneration.get() ||
                    !wirelessHandoffRequested.get() ||
                    wirelessActiveReported.get()
                ) {
                    return@postDelayed
                }
                debugLog(
                    "wireless handoff timed out waiting for tunnel iAP2 readiness; " +
                        "continuing with Bluetooth iAP2",
                )
            },
            WIRELESS_HANDOFF_TIMEOUT_MILLIS,
        )
    }

    private fun closeBluetoothBootstrapTransport() {
        val activeCsm = csm
        csm = null
        if (activeCsm != null) closeBestEffort("wireless CSM") { activeCsm.close() }

        val activeStream = bluetoothStream
        bluetoothStream = null
        if (activeStream != null) closeBestEffort("wireless RFCOMM stream") { activeStream.close() }

        val activeSocket = bluetoothSocket
        bluetoothSocket = null
        if (activeSocket != null) closeBestEffort("wireless Bluetooth socket") { activeSocket.close() }
    }

    private fun startIphone() {
        availabilityPollGeneration.incrementAndGet()
        phase = Phase.IPHONE
        reenumerationAttempts = 0
        onStatus(CarPlayStatus.DiscoveringIphone)
        checkIphoneAvailability()
    }

    private fun checkIphoneAvailability() {
        if (closed || phase != Phase.IPHONE) return
        val device = iphoneHost.discover().firstOrNull()
        if (device == null) {
            onStatus(CarPlayStatus.WaitingForIphone)
            scheduleAvailabilityPoll(Phase.IPHONE, ::checkIphoneAvailability)
        } else {
            debugLog(
                "wired iPhone discovered vid=0x${device.vendorId.toString(16)} " +
                    "pid=0x${device.productId.toString(16)}",
            )
            availabilityPollGeneration.incrementAndGet()
            requestIphonePermission(device)
        }
    }

    private fun requestIphonePermission(device: UsbDevice) {
        mainHandler.post { doRequestIphonePermission(device) }
    }

    private fun doRequestIphonePermission(device: UsbDevice) {
        if (closed) return
        try {
            when (val request = iphoneHost.requestPermission(device)) {
                is IphoneUsbHost.PermissionRequest.AlreadyGranted -> {
                    debugLog("wired iPhone USB permission already granted")
                    permissionGrant.set(false)
                    onIphonePermission(IphoneUsbHost.PermissionResult.Granted(request.device))
                }
                is IphoneUsbHost.PermissionRequest.Requested -> {
                    debugLog("wired iPhone USB permission requested")
                    permissionGrant.set(false)
                    onStatus(CarPlayStatus.RequestingIphonePermission)
                    pollIphonePermission(device)
                }
            }
        } catch (error: Throwable) {
            fail(error)
        }
    }

    private fun onIphonePermission(result: IphoneUsbHost.PermissionResult) {
        when (result) {
            is IphoneUsbHost.PermissionResult.Granted -> {
                // The system broadcast and the polling fallback can both observe the grant.
                if (!permissionGrant.compareAndSet(false, true)) return
                debugLog("wired iPhone USB permission granted")
                permissionPollGeneration++
                when (phase) {
                    Phase.REENUMERATION, Phase.IPHONE -> {
                        if (IphoneCarPlayConfiguration.find(result.device) != null) {
                            openDataPaths(result.device)
                        } else if (reenumerationAttempts < MAXIMUM_REENUMERATION_ATTEMPTS) {
                            beginReenumeration(result.device)
                        } else {
                            fail(
                                IphoneUsbException.Protocol(
                                    "iPhone did not expose a complete CarPlay USB configuration",
                                ),
                            )
                        }
                    }
                    else -> Unit
                }
            }
            is IphoneUsbHost.PermissionResult.Denied -> {
                permissionGrant.set(true)
                onStatus(CarPlayStatus.Failed("iPhone USB permission was denied"))
            }
        }
    }

    /** Some Android builds grant the dialog without delivering the permission broadcast. */
    private fun pollIphonePermission(device: UsbDevice) {
        val generation = ++permissionPollGeneration
        val deadlineNanos = System.nanoTime() + PERMISSION_POLL_TIMEOUT_MILLIS * 1_000_000L
        val check = object : Runnable {
            override fun run() {
                if (closed || generation != permissionPollGeneration) return
                if (usbManager.hasPermission(device)) {
                    onIphonePermission(IphoneUsbHost.PermissionResult.Granted(device))
                    return
                }
                if (System.nanoTime() >= deadlineNanos) {
                    if (permissionGrant.compareAndSet(false, true)) {
                        onStatus(
                            CarPlayStatus.Failed(
                                "iPhone USB permission was not granted; tap Reconnect iPhone to retry",
                            ),
                        )
                    }
                    return
                }
                mainHandler.postDelayed(this, PERMISSION_POLL_INTERVAL_MILLIS)
            }
        }
        mainHandler.postDelayed(check, PERMISSION_POLL_INTERVAL_MILLIS)
    }

    private fun beginReenumeration(device: UsbDevice) {
        phase = Phase.REENUMERATION
        reenumerationAttempts += 1
        onStatus(CarPlayStatus.SelectingConfiguration)
        iphoneHost.requestCarPlayReenumerationAsync(device, executor) { transition ->
            when (transition) {
                IphoneUsbHost.TransitionResult.ReenumerationRequested ->
                    onStatus(CarPlayStatus.WaitingForReenumeration)
                is IphoneUsbHost.TransitionResult.Failed -> fail(transition.error)
            }
        }
    }

    private fun onIphoneAttached(device: UsbDevice) {
        when (phase) {
            Phase.REENUMERATION, Phase.IPHONE -> {
                availabilityPollGeneration.incrementAndGet()
                requestIphonePermission(device)
            }
            else -> Unit
        }
    }

    private fun scheduleAvailabilityPoll(phase: Phase, check: () -> Unit) {
        val generation = availabilityPollGeneration.get()
        mainHandler.postDelayed(
            {
                if (
                    !closed &&
                    this.phase == phase &&
                    generation == availabilityPollGeneration.get()
                ) {
                    check()
                }
            },
            DEVICE_AVAILABILITY_POLL_INTERVAL_MILLIS,
        )
    }

    private fun openDataPaths(device: UsbDevice) {
        phase = Phase.DATAPATHS
        debugLog("wired opening iPhone USB data paths")
        onStatus(CarPlayStatus.SelectingConfiguration)
        onStatus(CarPlayStatus.OpeningDataPaths)
        iphoneHost.openIap2UsbSessionAsync(device, executor) { result ->
            when (result) {
                is IphoneUsbHost.Iap2SessionResult.Connected -> {
                    try {
                        val ncm = openNcm(device)
                        runStack(result.session, ncm)
                    } catch (error: Throwable) {
                        result.session.close()
                        fail(error)
                    }
                }
                is IphoneUsbHost.Iap2SessionResult.Failed -> fail(result.error)
            }
        }
    }

    private fun openNcm(device: UsbDevice): NcmUsbBridge {
        val configuration = IphoneCarPlayConfiguration.find(device)
            ?: throw IphoneUsbException.Protocol(
                "iPhone exposes no CarPlay configuration for NCM",
            )
        val function = NcmFunctionDiscovery.find(configuration)
            ?: throw IphoneUsbException.Protocol("iPhone configuration does not expose an NCM function")
        debugLog(
            "ncm config=${configuration.id} control=${function.control.id}/${function.control.alternateSetting}" +
                " data=${function.data.id}/${function.data.alternateSetting}" +
                " status=${function.statusIn?.address?.let { "0x${it.toString(16)}" } ?: "none"}" +
                " in=0x${function.bulkIn.address.toString(16)} out=0x${function.bulkOut.address.toString(16)}",
        )
        val connection = usbManager.openDevice(device)
            ?: throw IphoneUsbException.DeviceUnavailable("Could not open the iPhone NCM connection")
        return NcmUsbBridge.open(connection, function)
    }

    private fun runStack(usbSession: Iap2UsbSession, ncm: NcmUsbBridge) {
        phase = Phase.CONTROL
        var ncmOwnedLocally = true
        try {
            if (closed) return
            val mux = Iap2UsbMuxHost.open(usbSession)
            this.mux = mux
            debugLog("wired USBMUX host opened")
            onStatus(CarPlayStatus.Pairing)
            val pairingClient = LockdownPairingClient(mux)
            val savedPairRecord = loadPairRecord()
            var pairRecord = savedPairRecord ?: pairNewRecord(pairingClient)
            debugLog(
                if (savedPairRecord != null) {
                    "wired using saved Lockdown pair record"
                } else {
                    "wired created a new Lockdown pair record"
                },
            )
            onStatus(CarPlayStatus.ConnectingControl)
            val carKitClient = LockdownCarKitClient(mux)
            val carkit = try {
                carKitClient.open(pairRecord, config.label)
            } catch (error: Throwable) {
                if (!isInvalidPairRecord(error)) throw error
                debugLog("saved Lockdown pair record rejected; pairing again")
                clearPairRecord()
                pairRecord = pairNewRecord(pairingClient)
                carKitClient.open(pairRecord, config.label)
            }
            debugLog("wired com.apple.carkit.service stream opened")
            val csm = Iap2Session.open(
                carkit,
                traceContext = "wired",
                onTrace = ::debugLog,
            )
            this.csm = csm
            debugLog("wired iAP2 CSM channel opened")

            val ncmHostMac = ncm.hostMac ?: config.hostMac
            debugLog("ncm using hostMac=${ncmHostMac.macString()}")
            if (!attachVpn(ncm, ncmHostMac)) {
                throw IphoneUsbException.DeviceUnavailable("Could not attach the NCM/VPN AirPlay transport")
            }
            ncmOwnedLocally = false
            debugLog("wired NCM/VPN AirPlay transport attached")
            if (closed) {
                vpnService?.detach()
                return
            }

            val mfi = mfiSession?.client
                ?: throw IphoneUsbException.DeviceUnavailable("MFi coprocessor client is unavailable")
            val endpoint = Iap2WiredCarPlayEndpoint(
                ipv6Addresses = listOf(config.linkLocal),
                airPlayPort = airPlayConfig.port,
                publicKey = identity.publicKeyHex,
                sourceVersion = airPlayConfig.sourceVersion,
                deviceIdentifier = ncmHostMac.macString(),
            )
            onStatus(CarPlayStatus.RunningControl)
            debugLog("wired iAP2 control starting")
            val result = Iap2WiredControlClient(csm, Iap2MfiAuthenticationClient(mfi)).run(
                identification = receiverIdentification(),
                endpoint = endpoint,
                availableCurrentMilliAmps = config.availableCurrentMilliAmps,
                bringUpTimeoutMillis = CONTROL_BRING_UP_TIMEOUT_MILLIS,
                locationProvider = locationProvider,
                onReady = { activateMediaRemote(csm) },
                onStopped = { deactivateMediaRemote(csm) },
                onIncoming = { frame -> if (!closed && activeMediaRemoteSession === csm) onIap2Incoming(frame) },
                onProgress = { message -> debugLog("wired $message") },
            )
            onStatus(
                when (result.terminal) {
                    Iap2WiredControlTerminal.CHANNEL_CLOSED ->
                        CarPlayStatus.Failed("CarPlay control channel closed")
                },
            )
        } catch (error: Throwable) {
            debugLog("wired bring-up failed", error)
            if (!ncmOwnedLocally) vpnService?.detach()
            fail(error)
        } finally {
            if (ncmOwnedLocally) ncm.close()
        }
    }

    private fun pairNewRecord(client: LockdownPairingClient): LockdownPairRecord =
        client.pair(
            label = config.label,
            hostId = hostId,
            systemBuid = systemBuid,
            totalTimeoutMillis = PAIR_TIMEOUT_MILLIS,
            isCancelled = { closed },
        ).pairRecord.also(savePairRecord)

    private fun isInvalidPairRecord(error: Throwable): Boolean {
        var cause: Throwable? = error
        while (cause != null) {
            if (cause.message?.contains("InvalidPairRecord", ignoreCase = true) == true) return true
            cause = cause.cause
        }
        return false
    }

    private fun isBluetoothHandoffCommand(type: String): Boolean =
        type.equals("disableBluetooth", ignoreCase = true) ||
            type.equals("disable-bluetooth", ignoreCase = true)

    private fun startWirelessHotspot(
        generation: Int,
        mfi: MfiAuthenticator,
    ): WirelessHotspotInfo {
        // The HS5 product baseline uses the dedicated P2P group-owner path exclusively.
        val manager: WirelessHotspotManager = if (hs5) {
            com.shilapi.xcertplay.network.HongqiWifiP2pGroupManager(appContext, ::debugLog,
                com.shilapi.xcertplay.network.WirelessRadioSelectionPolicy.select(appContext,
                    config.wirelessRadioAttempt, config.wirelessFailedFrequencyMHz, ::debugLog))
        } else mfiCertificateWifiP2pCredentials(mfi.readCertificate()).let { credentials ->
                WifiP2pGroupManager(
                    context = appContext,
                    networkName = credentials.ssid,
                    passphrase = credentials.passphrase,
                    radioSelection = com.shilapi.xcertplay.network.WirelessRadioSelectionPolicy.select(appContext,
                        config.wirelessRadioAttempt, config.wirelessFailedFrequencyMHz, ::debugLog),
                )
            }
        hotspot = manager
        manager.setOnUnexpectedStopped {
            onWirelessHotspotStopped(generation, manager)
        }
        manager.setOnPeerDisconnected { mac ->
            onWirelessPeerDisconnected(generation, manager, mac)
        }
        return try {
            manager.start(WIFI_P2P_START_TIMEOUT_MILLIS)
        } catch (failure: Exception) {
            if (hotspot === manager) hotspot = null
            closeBestEffort("WIFI_P2P") { manager.close() }
            if (isStaleWirelessRun(generation)) throw failure
            throw IOException(
                "Could not establish WIFI_P2P hotspot: " +
                    (failure.message ?: failure.javaClass.simpleName),
                failure,
            )
        }
    }

    private fun isStaleWirelessRun(generation: Int): Boolean =
        closed || phase != Phase.WIRELESS || generation != wirelessGeneration.get()

    private fun advanceWireless(generation: Int, stage: WirelessConnectionStage) {
        if (isStaleWirelessRun(generation)) return
        val now = SystemClock.elapsedRealtime()
        val expired = wirelessDeadline.expire(generation, now)
        if (expired != null) {
            failWireless(generation,
                if (expired.stage == WirelessConnectionStage.WAITING_FOR_PAIR)
                    "等待手机蓝牙配对超时，请在 iPhone 蓝牙设置中完成车机配对后点击连接"
                else "${expired.stage.label}超时", expired.stage,
                retryable = expired.stage != WirelessConnectionStage.WAITING_FOR_PAIR)
            return
        }
        if (wirelessDeadline.advance(generation, stage, now)) {
            debugLog("wireless connection stage=${stage.name}")
            if (stage != WirelessConnectionStage.CONNECTED) onStatus(CarPlayStatus.WirelessConnecting(stage))
        }
    }

    private fun onWirelessBootstrapStage(generation: Int, stage: Iap2WirelessBringUpStage) {
        when (stage) {
            Iap2WirelessBringUpStage.IDENTIFYING -> advanceWireless(generation, WirelessConnectionStage.IDENTIFICATION)
            Iap2WirelessBringUpStage.AUTHENTICATING -> advanceWireless(generation, WirelessConnectionStage.AUTHENTICATION)
            Iap2WirelessBringUpStage.CONTROL_READY, Iap2WirelessBringUpStage.WAITING_FOR_WIFI ->
                advanceWireless(generation, WirelessConnectionStage.PHONE_WIFI)
            else -> Unit
        }
    }

    /** Each service attachment retains its attempt owner; late callbacks cannot advance a retry. */
    private fun wirelessSessionListener(generation: Int): AirPlaySessionListener =
        object : AirPlaySessionListener {
            private fun owned(action: () -> Unit) = synchronized(navigationFrameLock) {
                if (!isStaleWirelessRun(generation)) action()
            }
            override fun onConnectionStage(session: AirPlaySession, pairing: Boolean) = owned {
                if (activeSession == null) advanceWireless(generation,
                    if (pairing) WirelessConnectionStage.PAIRING else WirelessConnectionStage.SESSION)
            }
            override fun onPairingRejected(session: AirPlaySession, operation: String, errorCode: Int) = owned {
                if (activeSession == null) failWireless(generation,
                    if (operation == "auth-setup") "附件认证被拒绝（错误 $errorCode），请检查接收端身份配置"
                    else "安全配对被拒绝（$operation，错误 $errorCode），请检查 iPhone 的 CarPlay 配对记录",
                    WirelessConnectionStage.PAIRING, retryable = false, radioRecovery = false)
            }
            override fun onSessionActive(session: AirPlaySession) = owned { sessionListener.onSessionActive(session) }
            override fun onSessionDisconnected(session: AirPlaySession) = owned { sessionListener.onSessionDisconnected(session) }
            override fun onSessionEnded(session: AirPlaySession) { sessionListener.onSessionEnded(session) }
            override fun onDeviceInfo(session: AirPlaySession, info: AirPlayDeviceInfo) = owned { sessionListener.onDeviceInfo(session, info) }
            override fun onHostUiRequested(session: AirPlaySession) = owned { sessionListener.onHostUiRequested(session) }
            override fun onCommand(session: AirPlaySession, type: String, params: Map<String, Any?>) = owned {
                sessionListener.onCommand(session, type, params)
            }
            override fun onTransportError(message: String) = owned { sessionListener.onTransportError(message) }
            override fun onDebugLog(message: String) = owned { sessionListener.onDebugLog(message) }
        }

    private fun armWirelessDeadline(generation: Int) {
        val check = object : Runnable {
            override fun run() {
                if (isStaleWirelessRun(generation)) return
                val expired = wirelessDeadline.expire(generation, SystemClock.elapsedRealtime())
                if (expired != null) {
                    debugLog("wireless connection timed out stage=${expired.stage.name} elapsedMs=${expired.elapsedMillis}")
                    if (expired.stage == WirelessConnectionStage.WAITING_FOR_PAIR) {
                        failWireless(generation, "等待手机蓝牙配对超时，请在 iPhone 蓝牙设置中完成车机配对后点击连接",
                            stage = expired.stage, retryable = false, radioRecovery = false)
                    } else failWireless(generation, "${expired.stage.label}超时，请确认 iPhone 的 Wi-Fi、蓝牙和 CarPlay 已开启",
                        stage = expired.stage)
                } else if (wirelessDeadline.current(generation) != null) {
                    mainHandler.postDelayed(this, 250)
                }
            }
        }
        mainHandler.postDelayed(check, 250)
    }

    private fun failWireless(
        generation: Int,
        message: String,
        stage: WirelessConnectionStage? = wirelessDeadline.current(generation),
        retryable: Boolean = true,
        radioRecovery: Boolean = stage?.radioRecovery == true,
    ) {
        synchronized(navigationFrameLock) {
            if (isStaleWirelessRun(generation) || !wirelessGeneration.compareAndSet(generation, generation + 1)) return
            wirelessAttemptFailed.set(true)
            wirelessDeadline.stop()
        }
        wirelessPairingSignal?.close()
        val manager = hotspot
        Thread({
            var recoverRadio = radioRecovery
            var failureMessage = message
            if (radioRecovery && stage == WirelessConnectionStage.PHONE_WIFI) {
                // A joined phone waiting for Bonjour/RTSP is not evidence of an RF failure.
                // Unknown association also cannot justify changing frequency. Never block UI.
                val associated = AtomicReference<Boolean?>(null)
                val queried = CountDownLatch(1)
                runCatching {
                    manager?.queryHasAssociatedClients { value -> associated.set(value); queried.countDown() }
                }
                try {
                    queried.await(250, TimeUnit.MILLISECONDS)
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                }
                val association = associated.get()
                recoverRadio = association == false
                if (association == true) {
                    failureMessage = "Wi-Fi 已有连接，但 CarPlay 服务响应超时，请查看连接详情"
                }
                debugLog("wireless retry association=${association ?: "unknown"} radioRecovery=$recoverRadio")
            }
            onStatus(CarPlayStatus.Failed(failureMessage, stage, recoverRadio, wirelessFrequencyMHz, retryable))
            closeWirelessStack()
        }, "xcertplay-wireless-failed-attempt").apply { isDaemon = true; start() }
    }

    private fun onWirelessHotspotStopped(generation: Int, manager: WirelessHotspotManager) {
        onWirelessLinkLost(generation, manager, "Wireless hotspot disconnected")
    }

    private fun onWirelessPeerDisconnected(generation: Int, manager: WirelessHotspotManager, wifiMac: String) {
        synchronized(navigationFrameLock) {
            val session = activeSession ?: return
            if (session.isClosed() || wirelessPeerAddresses[session]?.equals(wifiMac, ignoreCase = true) != true) return
            onWirelessLinkLost(generation, manager, "Wireless iPhone Wi-Fi disconnected")
        }
    }

    private fun onWirelessLinkLost(generation: Int, manager: WirelessHotspotManager, reason: String) {
        if (isStaleWirelessRun(generation) || hotspot !== manager) return
        if (!wirelessGeneration.compareAndSet(generation, generation + 1)) return
        wirelessAttemptFailed.set(true)
        wirelessDeadline.stop()
        val session = activeSession
        debugLog(reason)
        onStatus(CarPlayStatus.Failed(reason))
        // Wi-Fi callbacks must not wait for media teardown. The host's failure path owns
        // controller cleanup/reconnect; closing this captured session also dismisses playback.
        Thread({
            if (activeSession === session) {
                session?.close()
            }
        }, "xcertplay-wireless-disconnect").apply { isDaemon = true; start() }
    }

    private fun selectWirelessBluetoothDevices(
        adapter: BluetoothAdapter,
        initialAddresses: Set<String>? = null,
        deadline: Long? = null,
    ): List<BluetoothDevice> {
        try {
            val bonded = adapter.bondedDevices.orEmpty()
            val smartPhones = bonded.filter { device ->
                val bluetoothClass = device.bluetoothClass
                debugLog(
                    "wireless Bluetooth bonded name=${device.name ?: "unknown"} " +
                        "address=${device.address} class=${bluetoothClass ?: "unknown"} " +
                        "deviceClass=${bluetoothClass?.deviceClass?.toString(16) ?: "unknown"}",
                )
                com.shilapi.xcertplay.transport.IphoneBluetoothDevices.isConnectionCandidate(device)
            }
            if (smartPhones.isEmpty()) return emptyList()
            val directlyConnectedSmartPhones = smartPhones.filter(::isBluetoothDeviceConnected)
            Log.i(
                IphoneCarPlayConfiguration.TAG,
                "wireless Bluetooth bondedSmartPhones=${smartPhones.size} " +
                    "directlyConnected=${directlyConnectedSmartPhones.size}",
            )
            val connectedAddresses = if (directlyConnectedSmartPhones.isNotEmpty()) {
                directlyConnectedSmartPhones.mapTo(mutableSetOf()) { it.address }
            } else {
                connectedBluetoothDevices(adapter, deadline).mapTo(mutableSetOf()) {
                    it.address
                }
            }
            val previousPhone = wirelessPreferences.getString(LAST_WIRELESS_PHONE, null)
            return smartPhones.sortedWith(
                compareByDescending<BluetoothDevice> { initialAddresses != null && it.address !in initialAddresses }
                    .thenByDescending { it.address in connectedAddresses }
                    .thenByDescending { it.address == previousPhone }
                    .thenByDescending { com.shilapi.xcertplay.transport.IphoneBluetoothDevices.isIphone(it) }
                    .thenBy { it.address },
            )
        } catch (error: SecurityException) { throw IOException("Bluetooth permission unavailable", error) }
    }

    private fun rememberSuccessfulWirelessPhone() {
        // Bonding, RFCOMM or authentication alone do not prove that projection actually started.
        val address = runCatching { connectedIphone?.address }.getOrNull() ?: return
        if (BLUETOOTH_ADDRESS.matches(address)) wirelessPreferences.edit().putString(LAST_WIRELESS_PHONE, address).apply()
    }

    @SuppressLint("MissingPermission")
    private fun awaitWirelessBluetoothDevices(adapter: BluetoothAdapter, generation: Int): List<BluetoothDevice> {
        selectWirelessBluetoothDevices(adapter).takeIf { it.isNotEmpty() }?.let { return it }
        onStatus(CarPlayStatus.WaitingForPairedIphone)
        return withWirelessPairingEvents { signal ->
            while (!isStaleWirelessRun(generation)) {
                val revision = signal.revision()
                if (!adapter.isEnabled) throw IOException("蓝牙已关闭，请开启车机蓝牙后点击连接")
                // Re-read after registration and every completed bond; the receiver never connects a device itself.
                val devices = selectWirelessBluetoothDevices(adapter)
                if (devices.isNotEmpty()) return@withWirelessPairingEvents devices
                val remaining = wirelessDeadline.remainingMillis(generation, SystemClock.elapsedRealtime())
                if (remaining <= 0) {
                    failWireless(generation, "等待手机蓝牙配对超时，请在 iPhone 蓝牙设置中完成车机配对后点击连接",
                        WirelessConnectionStage.WAITING_FOR_PAIR, retryable = false, radioRecovery = false)
                    return@withWirelessPairingEvents emptyList()
                }
                if (!signal.awaitChange(revision, remaining)) return@withWirelessPairingEvents emptyList()
            }
            return@withWirelessPairingEvents emptyList()
        }
    }

    private fun <T> withWirelessPairingEvents(block: (WirelessPairingSignal) -> T): T {
        val signal = WirelessPairingSignal()
        wirelessPairingSignal = signal
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action == BluetoothAdapter.ACTION_STATE_CHANGED ||
                    intent.action == BluetoothDevice.ACTION_ACL_CONNECTED ||
                    intent.action == BluetoothDevice.ACTION_UUID ||
                    (intent.action == BluetoothDevice.ACTION_BOND_STATE_CHANGED &&
                        intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.ERROR) == BluetoothDevice.BOND_BONDED)) {
                    @Suppress("DEPRECATION")
                    val device = if (Build.VERSION.SDK_INT >= 33) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                    signal.signal(runCatching { device?.address }.getOrNull())
                }
            }
        }
        var registered = false
        try {
            val filter = IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED).apply {
                addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
                addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
                addAction(BluetoothDevice.ACTION_UUID)
            }
            if (Build.VERSION.SDK_INT >= 33) appContext.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            else appContext.registerReceiver(receiver, filter)
            registered = true
            return block(signal)
        } finally {
            signal.close()
            if (wirelessPairingSignal === signal) wirelessPairingSignal = null
            if (registered) runCatching { appContext.unregisterReceiver(receiver) }
        }
    }

    private fun connectWirelessBluetoothDevices(
        devices: List<BluetoothDevice>,
        generation: Int,
    ): Iap2Session {
        advanceWireless(generation, WirelessConnectionStage.BLUETOOTH)
        val now = SystemClock.elapsedRealtime()
        val connectDeadline = now + minOf(WirelessConnectionStage.BLUETOOTH.timeoutMillis,
            wirelessDeadline.remainingMillis(generation, now))
        val initialAddresses = devices.mapTo(mutableSetOf()) { it.address }
        val attemptedRevisions = mutableMapOf<String, Long>()
        val addressAttempts = mutableMapOf<String, Int>()
        var attemptCount = 0
        var candidates = devices
        var lastFailure: Exception? = null
        // Discovery is a system-wide operation; it can be running even if this app did not start it.
        cancelBluetoothDiscoveryIfAllowed()
        return withWirelessPairingEvents { signal ->
            while (!isStaleWirelessRun(generation) && SystemClock.elapsedRealtime() < connectDeadline) {
                val revision = signal.revision()
                if (attemptedRevisions.isNotEmpty() || candidates.isEmpty()) {
                    bluetoothAdapter?.let { adapter ->
                        if (!adapter.isEnabled) throw IOException("蓝牙已关闭，请开启车机蓝牙后点击连接")
                        candidates = selectWirelessBluetoothDevices(adapter, initialAddresses, connectDeadline)
                    }
                }
                val pending = candidates.filter {
                    (addressAttempts[it.address] ?: 0) < MAX_BLUETOOTH_DEVICE_ATTEMPTS &&
                        (it.address !in attemptedRevisions || signal.deviceRevision(it.address) > attemptedRevisions.getValue(it.address))
                }.sortedByDescending { signal.deviceRevision(it.address) }
                val device = pending.firstOrNull()
                if (device == null) {
                    val adapter = bluetoothAdapter ?: break
                    if (!adapter.isEnabled) throw IOException("蓝牙已关闭，请开启车机蓝牙后点击连接")
                    val remaining = connectDeadline - SystemClock.elapsedRealtime()
                    if (remaining <= 0 || !signal.awaitChange(revision, minOf(remaining, BLUETOOTH_EVENT_GRACE_MILLIS))) break
                    continue
                }
                attemptedRevisions[device.address] = signal.deviceRevision(device.address)
                addressAttempts[device.address] = (addressAttempts[device.address] ?: 0) + 1
                attemptCount++
                onStatus(CarPlayStatus.ConnectingBluetooth)
                try {
                    val remaining = connectDeadline - SystemClock.elapsedRealtime()
                    if (remaining <= 0) break
                    debugLog(
                        "wireless RFCOMM attempt=$attemptCount " +
                            "name=${device.name ?: "unknown"} address=${device.address} " +
                            "uuid=$IAP2_IPHONE_UUID",
                    )
                    val socket = device
                        .createRfcommSocketToServiceRecord(UUID.fromString(IAP2_IPHONE_UUID))
                        .also { bluetoothSocket = it }
                    // Reserve a share for every currently known, untried candidate.
                    val candidateStartedAt = SystemClock.elapsedRealtime()
                    val candidateRemaining = connectDeadline - candidateStartedAt
                    if (candidateRemaining <= 0) throw IOException("连接手机蓝牙超时")
                    val candidateBudget = minOf(RFCOMM_CONNECT_TIMEOUT_MILLIS,
                        (candidateRemaining / pending.size).coerceAtLeast(1))
                    val candidateDeadline = candidateStartedAt + candidateBudget
                    connectBluetoothSocket(socket, device.address, candidateBudget)
                    if (isStaleWirelessRun(generation)) {
                        throw IOException("Wireless Bluetooth connection was cancelled")
                    }
                    debugLog("wireless RFCOMM connected address=${device.address}")
                    val stream = BluetoothRfcommDuplexStream(socket).also { bluetoothStream = it }
                    val channel = Iap2Session.openWireless(
                        stream,
                        traceContext = "wireless-rfcomm",
                        onTrace = ::debugLog,
                    ).also { csm = it }
                    val handshakeBudget = candidateDeadline - SystemClock.elapsedRealtime()
                    if (handshakeBudget <= 0 || !channel.awaitReady(handshakeBudget)) {
                        throw IOException("手机 iAP2 蓝牙握手超时")
                    }
                    debugLog("wireless iAP2 CSM channel opened address=${device.address}")
                    synchronized(navigationFrameLock) {
                        if (isStaleWirelessRun(generation)) throw IOException("Wireless Bluetooth connection was cancelled")
                        connectedIphone = device
                    }
                    return@withWirelessPairingEvents channel
                } catch (error: SecurityException) {
                    closeBluetoothBootstrapTransport()
                    throw IOException("Bluetooth permission unavailable", error)
                } catch (error: Exception) {
                    closeBluetoothBootstrapTransport()
                    if (isStaleWirelessRun(generation)) throw error
                    lastFailure = error
                    debugLog("wireless RFCOMM attempt failed address=${device.address}", error)
                }
            }
            if (isStaleWirelessRun(generation)) throw IOException("Wireless Bluetooth connection was cancelled")
            throw IOException(
                "未能连接已配对手机的 CarPlay 蓝牙服务，请确认 iPhone 蓝牙和 CarPlay 已开启",
                lastFailure,
            )
        }
    }

    private fun connectBluetoothSocket(socket: BluetoothSocket, address: String, timeoutMillis: Long) {
        val result = AtomicReference<Throwable?>()
        val connected = CountDownLatch(1)
        Thread(
            {
                try {
                    socket.connect()
                } catch (error: Throwable) {
                    result.set(error)
                } finally {
                    connected.countDown()
                }
            },
            "wireless-rfcomm-connect",
        ).apply {
            isDaemon = true
            start()
        }
        val completed = try {
            connected.await(timeoutMillis, TimeUnit.MILLISECONDS)
        } catch (error: InterruptedException) {
            Thread.currentThread().interrupt()
            runCatching { socket.close() }
            throw IOException("Interrupted while connecting RFCOMM to $address", error)
        }
        if (!completed) {
            debugLog(
                "wireless RFCOMM connect timed out after " +
                    "${timeoutMillis}ms address=$address",
            )
            runCatching { socket.close() }
            throw IOException(
                "Timed out after ${timeoutMillis}ms connecting RFCOMM to $address",
            )
        }
        when (val failure = result.get()) {
            null -> Unit
            is IOException -> throw failure
            else -> throw IOException("Could not connect RFCOMM to $address", failure)
        }
    }

    @SuppressLint("MissingPermission")
    private fun cancelBluetoothDiscoveryIfAllowed() {
        if (
            Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                appContext.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        ) {
            runCatching { bluetoothAdapter?.cancelDiscovery() }
        }
    }

    private fun closeWirelessStack(service: CarPlayVpnService? = vpnService) {
        wirelessPairingSignal?.close()
        media.setIapTunnelHandler(null)
        val activeTunnel = wirelessTunnelChannel
        wirelessTunnelChannel = null
        if (activeTunnel != null) closeBestEffort("tunneled iAP2 link") { activeTunnel.close() }

        closeBluetoothBootstrapTransport()
        connectedIphone = null

        val activeBonjour = bonjour
        bonjour = null
        if (activeBonjour != null) closeBestEffort("Bonjour") { activeBonjour.close() }

        val activeHotspot = hotspot
        hotspot = null
        if (activeHotspot != null) closeBestEffort("wireless hotspot") { activeHotspot.close() }
        wirelessIdentification = null
        wirelessAirPlayEndpoint = null
        wirelessHandoffRequested.set(false)
        wirelessTunnelReady.set(false)
        wirelessActiveReported.set(false)

        if (service != null) closeBestEffort("AirPlay service") { service.detach(this) }
    }

    @SuppressLint("MissingPermission")
    private fun isBluetoothDeviceConnected(device: BluetoothDevice): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            appContext.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) return false
        return try {
            if (Build.VERSION.SDK_INT >= 37) {
                device.isConnected(BluetoothDevice.TRANSPORT_BREDR)
            } else {
                val method = BluetoothDevice::class.java.getMethod("isConnected")
                method.invoke(device) as? Boolean == true
            }
        } catch (error: ReflectiveOperationException) {
            false
        } catch (error: RuntimeException) {
            Log.w(IphoneCarPlayConfiguration.TAG, "Could not read Bluetooth connection state", error)
            false
        }
    }

    private fun connectedBluetoothDevices(adapter: BluetoothAdapter, deadline: Long? = null): Set<BluetoothDevice> =
        buildSet {
            addAll(connectedBluetoothDevices(adapter, BluetoothProfile.HEADSET, BluetoothHeadset::class.java, deadline))
            addAll(connectedBluetoothDevices(adapter, BluetoothProfile.A2DP, BluetoothA2dp::class.java, deadline))
        }

    @SuppressLint("MissingPermission")
    private fun <T : BluetoothProfile> connectedBluetoothDevices(
        adapter: BluetoothAdapter,
        profile: Int,
        profileClass: Class<T>,
        deadline: Long?,
    ): Set<BluetoothDevice> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            appContext.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) return emptySet()
        // Disconnected profiles cannot supply a preferred phone; avoid two needless proxy waits.
        if (adapter.getProfileConnectionState(profile) != BluetoothAdapter.STATE_CONNECTED) return emptySet()
        val timeoutMillis = minOf(3_000L, deadline?.let { it - SystemClock.elapsedRealtime() } ?: 3_000L)
        if (timeoutMillis <= 0) return emptySet()
        val latch = CountDownLatch(1)
        val devices = java.util.Collections.synchronizedSet(mutableSetOf<BluetoothDevice>())
        val listener = object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profileId: Int, proxy: BluetoothProfile) {
                try {
                    if (profileClass.isInstance(proxy)) {
                        devices.addAll(proxy.connectedDevices.orEmpty())
                    }
                } catch (error: SecurityException) {
                    Log.w(IphoneCarPlayConfiguration.TAG, "Could not read connected Bluetooth devices", error)
                } finally {
                    adapter.closeProfileProxy(profileId, proxy)
                    latch.countDown()
                }
            }

            override fun onServiceDisconnected(profileId: Int) {
                latch.countDown()
            }
        }
        if (!adapter.getProfileProxy(appContext, listener, profile)) return emptySet()
        if (!latch.await(timeoutMillis, TimeUnit.MILLISECONDS)) {
            Log.w(IphoneCarPlayConfiguration.TAG, "Timed out reading Bluetooth profile $profile")
        }
        return synchronized(devices) { devices.toSet() }
    }

    // Vendor builds may expose the local MAC. Permission denial already falls back to configured identity.
    @android.annotation.SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private fun accessoryBluetoothMac(adapter: BluetoothAdapter): String {
        val address = try {
            adapter.address
        } catch (_: SecurityException) {
            null
        }
        return address
            ?.takeIf {
                BLUETOOTH_ADDRESS.matches(it) &&
                    !it.equals(ADAPTER_ADDRESS_PLACEHOLDER, ignoreCase = true)
            }
            ?: airPlayConfig.btMac
    }

    private fun hostAddressText(address: InetAddress): String {
        val text = address.hostAddress?.substringBefore('%')
        if (text.isNullOrBlank()) {
            throw IOException("Wi-Fi P2P host address is unavailable")
        }
        return text
    }

    private fun closeBestEffort(name: String, close: () -> Unit) {
        try {
            close()
        } catch (error: Throwable) {
            debugLog("$name teardown failed", error)
        }
    }

    private fun attachVpn(ncm: NcmUsbBridge, hostMac: ByteArray): Boolean {
        onStatus(CarPlayStatus.AttachingNetwork)
        val service = awaitVpnService() ?: run {
            debugLog("wired VPN service bind failed")
            ncm.close()
            return false
        }
        debugLog("wired VPN service bound; attaching NCM transport")
        val result = try {
            service.attach(
                ncm = ncm,
                linkLocal = config.linkLocal,
                hostMac = hostMac,
                config = airPlayConfig,
                identity = identity,
                pairings = pairings,
                mfi = mfiSession?.client,
                listener = sessionListener,
                media = media,
            )
        } catch (error: Throwable) {
            ncm.close()
            onStatus(CarPlayStatus.Failed(error.message ?: error.javaClass.simpleName))
            return false
        }
        return when (result) {
            CarPlayVpnService.AttachResult.Started -> {
                debugLog("wired VPN/NCM transport attach result=started")
                true
            }
            CarPlayVpnService.AttachResult.AlreadyStarted -> {
                debugLog("wired VPN/NCM transport attach result=already-started")
                ncm.close()
                false
            }
            is CarPlayVpnService.AttachResult.Failed -> {
                debugLog("wired VPN/NCM transport attach result=failed ${result.message}")
                ncm.close()
                onStatus(CarPlayStatus.Failed(result.message))
                false
            }
        }
    }

    private fun ByteArray.macString(): String =
        joinToString(":") { byte -> "%02x".format(byte.toInt() and 0xff) }

    private fun awaitVpnService(): CarPlayVpnService? {
        // This binds the shared AirPlay listener host. In the wireless path the service is only
        // used for its listener and attachWireless() deliberately never establishes a VPN/TUN.
        vpnService?.let { return it }
        bindVpn()
        return try {
            if (vpnLatch.await(VPN_CONNECT_TIMEOUT_MILLIS, TimeUnit.MILLISECONDS)) vpnService else null
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            null
        }
    }

    private fun bindVpn() {
        if (vpnBound) return
        vpnBound = true
        try {
            val intent = Intent(appContext, CarPlayVpnService::class.java)
            if (!appContext.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)) {
                vpnBound = false
                vpnLatch.countDown()
            }
        } catch (_: Throwable) {
            vpnBound = false
            vpnLatch.countDown()
        }
    }

    private fun unbindVpn() {
        if (!vpnBound) return
        vpnBound = false
        try {
            appContext.unbindService(serviceConnection)
        } catch (_: Exception) {
            // The service may have already been unbound.
        }
        vpnService = null
    }

    private fun closeReceivers() {
        listOfNotNull(permissionCloseable, attachCloseable, ch341PermissionCloseable).forEach {
            try {
                it.close()
            } catch (_: Exception) {
                // Receiver is already unregistered.
            }
        }
        permissionCloseable = null
        attachCloseable = null
        ch341PermissionCloseable = null
    }

    private fun closeMfiSession() {
        val session = mfiSession
        mfiSession = null
        if (session != null) {
            executor.execute {
                try {
                    session.close()
                } catch (_: Exception) {
                    // Best effort.
                }
            }
        }
    }

    private fun fail(error: Throwable) {
        if (closed) return
        onStatus(CarPlayStatus.Failed(error.message ?: error.javaClass.simpleName))
    }

    private fun debugLog(message: String) {
        Log.i(IphoneCarPlayConfiguration.TAG, message)
        try {
            uiListener?.onDebugLog(message)
        } catch (error: Exception) {
            Log.w(IphoneCarPlayConfiguration.TAG, "debug log callback failed", error)
        }
    }

    private fun debugLog(message: String, error: Throwable) {
        Log.w(IphoneCarPlayConfiguration.TAG, message, error)
        try {
            uiListener?.onDebugLog(
                "$message: ${error.message ?: error.javaClass.simpleName}",
            )
        } catch (callbackError: Exception) {
            Log.w(IphoneCarPlayConfiguration.TAG, "debug log callback failed", callbackError)
        }
    }

    private fun onStatus(status: CarPlayStatus) {
        if (closed) return
        mainHandler.post {
            if (!closed && status != lastReportedStatus) {
                lastReportedStatus = status
                uiListener?.onDebugLog(status.debugLogMessage())
                uiStatusReporter?.invoke(status)
            }
        }
    }

    private fun CarPlayStatus.debugLogMessage(): String = when (this) {
        CarPlayStatus.DiscoveringMfi ->
            "STEP mfi/start: preparing the configured MFi authentication provider"
        CarPlayStatus.WaitingForMfi ->
            "STEP mfi/wait: MFi coprocessor not present; polling"
        CarPlayStatus.RequestingMfiPermission ->
            "STEP mfi/permission: requesting CH341 USB access"
        CarPlayStatus.MfiReady ->
            "STEP mfi/ready: MFi authentication provider is ready"
        CarPlayStatus.StartingHotspot ->
            "STEP wifi/ap: starting the wireless CarPlay access point"
        is CarPlayStatus.HotspotReady ->
            "STEP wifi/ap-ready: backend=$backend ssid=$ssid band=$band " +
                "channel=$channel bssid=$bssid address=$address"
        CarPlayStatus.WaitingForPairedIphone ->
            "STEP bt/select: waiting for a paired or connected iPhone"
        CarPlayStatus.ConnectingBluetooth ->
            "STEP bt/rfcomm: connecting to the iPhone iAP2 RFCOMM service"
        CarPlayStatus.RunningWireless ->
            "STEP iap2/wireless: Bluetooth control loop running"
        CarPlayStatus.WirelessActive ->
            "STEP handoff/complete: tunnel iAP2 ready; Bluetooth bootstrap released"
        is CarPlayStatus.WirelessConnecting -> "STEP wireless/progress: stage=${stage.name}"
        CarPlayStatus.DiscoveringIphone ->
            "STEP usb/discover: searching for an iPhone USB device"
        CarPlayStatus.WaitingForIphone ->
            "STEP usb/wait: iPhone USB device not present; polling"
        CarPlayStatus.RequestingIphonePermission ->
            "STEP usb/permission: requesting USB access to the iPhone"
        CarPlayStatus.WaitingForReenumeration ->
            "STEP usb/reenum: waiting for the CarPlay USB configuration"
        CarPlayStatus.SelectingConfiguration ->
            "STEP usb/config: selecting the iPhone CarPlay configuration"
        CarPlayStatus.OpeningDataPaths ->
            "STEP usb/data: opening iAP2 and NCM USB data paths"
        CarPlayStatus.Pairing ->
            "STEP lockdown/pair: loading or creating the pairing record"
        CarPlayStatus.ConnectingControl ->
            "STEP lockdown/carkit: opening com.apple.carkit.service"
        CarPlayStatus.AttachingNetwork ->
            "STEP network/attach: attaching the AirPlay network transport"
        CarPlayStatus.RunningControl ->
            "STEP iap2/wired: wired iAP2 control loop running"
        CarPlayStatus.ControlEnded ->
            "STEP control/end: the control window ended"
        is CarPlayStatus.Failed ->
            "ERROR $message"
    }

    companion object {
        private const val NOW_PLAYING_UPDATE = 0x5001
        private const val MEDIA_REMOTE_SEND_TIMEOUT_MILLIS = 2_000L
        private const val HID_REPORT_HOLD_MILLIS = 50L
        private const val IAP2_IPHONE_UUID = "00000000-deca-fade-deca-deafdecacafe"
        private const val WIFI_P2P_START_TIMEOUT_MILLIS = 20_000L
        private const val PAIR_TIMEOUT_MILLIS = 5 * 60_000L
        private const val VPN_CONNECT_TIMEOUT_MILLIS = 10_000L
        private const val CONTROL_BRING_UP_TIMEOUT_MILLIS = 5 * 60_000L
        private const val PERMISSION_POLL_INTERVAL_MILLIS = 500L
        private const val PERMISSION_POLL_TIMEOUT_MILLIS = 120_000L
        private const val DEVICE_AVAILABILITY_POLL_INTERVAL_MILLIS = 2_000L
        private const val WIRELESS_HANDOFF_TIMEOUT_MILLIS = 45_000L
        private const val RFCOMM_CONNECT_TIMEOUT_MILLIS = 8_000L
        private const val BLUETOOTH_EVENT_GRACE_MILLIS = 1_000L
        private const val MAX_BLUETOOTH_DEVICE_ATTEMPTS = 2
        private const val LAST_WIRELESS_PHONE = "last_successful_bluetooth_address"
        private const val WIRELESS_CONTROL_TIMEOUT_MILLIS = 20_000L
        private const val MAXIMUM_REENUMERATION_ATTEMPTS = 2
        private const val EXECUTOR_CLOSE_TIMEOUT_MILLIS = 2_000L
        private const val ADAPTER_ADDRESS_PLACEHOLDER = "02:00:00:00:00:00"
        private val BLUETOOTH_ADDRESS = Regex("^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$")
    }
}
