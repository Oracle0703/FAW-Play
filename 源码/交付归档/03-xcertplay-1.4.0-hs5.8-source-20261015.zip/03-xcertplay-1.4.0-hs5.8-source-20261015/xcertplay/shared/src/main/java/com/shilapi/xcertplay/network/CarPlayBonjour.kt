package com.shilapi.xcertplay.network

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.util.Log
import com.shilapi.xcertplay.airplay.AirPlayConfig
import com.shilapi.xcertplay.airplay.AirPlayIdentity
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.IOException
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

data class CarPlayBonjourEndpoint(
    val serviceName: String,
    val host: String,
    val port: Int,
    val bluetoothId: String?,
)

enum class CarPlayBonjourStartOperation {
    AIRPLAY_REGISTRATION,
    CARPLAY_DISCOVERY,
}

sealed interface CarPlayBonjourEvent {
    data class StartFailed(
        val operation: CarPlayBonjourStartOperation,
        val errorCode: Int,
    ) : CarPlayBonjourEvent

    data class Resolved(val endpoint: CarPlayBonjourEndpoint) : CarPlayBonjourEvent

    data class Probed(
        val endpoint: CarPlayBonjourEndpoint,
        val attempts: Int,
        val statusLine: String?,
        val error: IOException?,
    ) : CarPlayBonjourEvent
}

/** Pure protocol values shared by the Android runtime and JVM tests. */
object CarPlayBonjourProtocol {
    /** Use the listener's family and interface scope; system NSD can also see the STA network. */
    internal fun compatibleAddresses(addresses: List<InetAddress>, local: InetAddress?, prefixLength: Int? = null): List<InetAddress> =
        addresses.asSequence().filter { address ->
            !address.isAnyLocalAddress && !address.isLoopbackAddress && !address.isMulticastAddress &&
                (local == null || (address is Inet4Address) == (local is Inet4Address)) &&
                (local !is Inet4Address || address !is Inet4Address || prefixLength == null ||
                    sameSubnet(address.address, local.address, prefixLength)) &&
                (local !is Inet6Address || address.isLinkLocalAddress) &&
                !(local is Inet6Address && address is Inet6Address &&
                    local.scopeId != 0 && address.scopeId != 0 && local.scopeId != address.scopeId)
        }.map { address ->
            if (local is Inet6Address && address is Inet6Address && address.scopeId == 0 && local.scopeId != 0) {
                Inet6Address.getByAddress(null, address.address, local.scopeId)
            } else address
        }.distinct().take(4).toList()

    private fun sameSubnet(address: ByteArray, local: ByteArray, prefix: Int): Boolean {
        if (prefix !in 0..32) return false
        return address.indices.all { index ->
            val bits = (prefix - index * 8).coerceIn(0, 8)
            val mask = (0xff shl (8 - bits)) and 0xff
            (address[index].toInt() and mask) == (local[index].toInt() and mask)
        }
    }

    fun airPlayTxtRecords(
        config: AirPlayConfig,
        identity: AirPlayIdentity,
    ): Map<String, String> = linkedMapOf(
        "deviceid" to config.deviceId,
        "features" to "0x44540380,0x61",
        "flags" to "0x4",
        "model" to config.model,
        "srcvers" to config.sourceVersion,
        "protovers" to "1.1",
        "pi" to identity.pairingId,
        "pk" to identity.publicKeyHex,
    )

    fun connectProbeRequest(
        host: String,
        port: Int,
        sourceVersion: String,
        deviceId: String,
    ): String {
        val unbracketedHost = host.removeSurrounding("[", "]").substringBefore('%')
        require(unbracketedHost.isNotBlank()) { "host must not be blank" }
        require(port in 1..65535) { "port must be in 1..65535" }
        require(sourceVersion.isNotEmpty()) { "sourceVersion must not be empty" }
        require('\r' !in sourceVersion && '\n' !in sourceVersion) {
            "sourceVersion must not contain a line break"
        }
        require('\r' !in unbracketedHost && '\n' !in unbracketedHost) {
            "host must not contain a line break"
        }
        val receiverDeviceId = deviceId.replace(":", "")
        require(receiverDeviceId.isNotEmpty()) { "deviceId must contain a hexadecimal value" }
        require('\r' !in receiverDeviceId && '\n' !in receiverDeviceId) {
            "deviceId must not contain a line break"
        }
        val hostHeader = if (':' in unbracketedHost) {
            "[$unbracketedHost]:$port"
        } else {
            "$unbracketedHost:$port"
        }
        return "GET /ctrl-int/1/connect HTTP/1.1\r\n" +
            "Host: $hostHeader\r\n" +
            "User-Agent: AirPlay/$sourceVersion\r\n" +
            "AirPlay-Receiver-Device-ID: $receiverDeviceId\r\n" +
            "Connection: close\r\n" +
            "\r\n"
    }
}

/**
 * Publishes the accessory AirPlay service and discovers the iPhone's CarPlay control service.
 *
 * NSD resolution is serial on older Android versions. Probes and event delivery have their own
 * workers so an unreachable endpoint cannot hold discovery or a startup failure notification.
 */
class CarPlayBonjour(
    context: Context,
    private val config: AirPlayConfig,
    private val identity: AirPlayIdentity,
    private val advertisedHost: String? = null,
    private val onEvent: (CarPlayBonjourEvent) -> Unit = {},
    private val socketFactory: () -> Socket = ::Socket,
) : Closeable {
    private val nsdManager = (context.applicationContext ?: context)
        .getSystemService(Context.NSD_SERVICE) as NsdManager
    private class ServiceGeneration {
        @Volatile var active = true
    }
    private sealed interface Work {
        data class ServiceFound(val serviceInfo: NsdServiceInfo, val key: String, val token: ServiceGeneration) : Work
    }
    private data class PendingEvent(val value: CarPlayBonjourEvent, val service: Work.ServiceFound? = null)

    private val workQueue = LinkedBlockingQueue<Work>()
    private val events = LinkedBlockingQueue<PendingEvent>()
    private val seenServices = ConcurrentHashMap<String, ServiceGeneration>()
    private val probeExecutor = Executors.newScheduledThreadPool(2) { task ->
        Thread(task, "carplay-control-probe").apply { isDaemon = true }
    }
    private val activeSockets = ConcurrentHashMap.newKeySet<Socket>()
    private val lifecycleLock = Any()
    private val localAdvertisedAddress = advertisedHostAddress()
    private val localPrefixLength = localAdvertisedAddress?.let { address ->
        runCatching {
            NetworkInterface.getByInetAddress(address)?.interfaceAddresses
                ?.firstOrNull { it.address == address }?.networkPrefixLength?.toInt()
        }.getOrNull()
    }
    private val failedStartOperations = mutableSetOf<CarPlayBonjourStartOperation>()

    private var started = false
    @Volatile
    private var closed = false
    private var registrationRequested = false
    private var discoveryRequested = false
    @Volatile
    private var worker: Thread? = null
    @Volatile
    private var eventWorker: Thread? = null

    private val registrationListener = object : NsdManager.RegistrationListener {
        override fun onServiceRegistered(serviceInfo: NsdServiceInfo) = Unit

        override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
            enqueueStartFailure(CarPlayBonjourStartOperation.AIRPLAY_REGISTRATION, errorCode)
        }

        override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) = Unit

        override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
            Log.w(TAG, "AirPlay NSD unregistration failed code=$errorCode")
        }
    }

    private val discoveryListener = object : NsdManager.DiscoveryListener {
        override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
            enqueueStartFailure(CarPlayBonjourStartOperation.CARPLAY_DISCOVERY, errorCode)
        }

        override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
            Log.w(TAG, "CarPlay control discovery stop failed code=$errorCode")
        }

        override fun onDiscoveryStarted(serviceType: String) = Unit

        override fun onDiscoveryStopped(serviceType: String) = Unit

        override fun onServiceFound(serviceInfo: NsdServiceInfo) {
            if (closed) return
            val name = serviceInfo.serviceName ?: return
            val type = serviceInfo.serviceType ?: CARPLAY_CONTROL_SERVICE_TYPE
            val key = "$type|$name"
            val token = ServiceGeneration()
            if (seenServices.compute(key) { _, previous -> previous?.takeIf { it.active } ?: token } !== token) return
            workQueue.offer(Work.ServiceFound(serviceInfo, key, token))
        }

        override fun onServiceLost(serviceInfo: NsdServiceInfo) {
            val name = serviceInfo.serviceName ?: return
            val type = serviceInfo.serviceType ?: CARPLAY_CONTROL_SERVICE_TYPE
            seenServices.remove("$type|$name")
        }
    }

    /** Starts publication and discovery. Calling this more than once is harmless. */
    fun start() {
        synchronized(lifecycleLock) {
            check(!closed) { "CarPlayBonjour is closed" }
            if (started) return
            started = true
            try {
                registerAirPlay()
                registrationRequested = true
                nsdManager.discoverServices(
                    CARPLAY_CONTROL_SERVICE_TYPE,
                    NsdManager.PROTOCOL_DNS_SD,
                    discoveryListener,
                )
                discoveryRequested = true
                worker = Thread(::runWorker, WORKER_NAME).apply {
                    isDaemon = true
                    start()
                }
                eventWorker = Thread(::runEvents, "carplay-bonjour-events").apply {
                    isDaemon = true
                    start()
                }
            } catch (error: RuntimeException) {
                closed = true
                if (registrationRequested) {
                    registrationRequested = false
                    runCatching { nsdManager.unregisterService(registrationListener) }
                }
                if (discoveryRequested) {
                    discoveryRequested = false
                    runCatching { nsdManager.stopServiceDiscovery(discoveryListener) }
                }
                worker?.interrupt()
                worker = null
                eventWorker?.interrupt()
                eventWorker = null
                probeExecutor.shutdownNow()
                activeSockets.forEach { socket -> runCatching { socket.close() } }
                activeSockets.clear()
                workQueue.clear()
                events.clear()
                throw error
            }
        }
    }

    override fun close() {
        val workerToJoin: Thread?
        val eventsToJoin: Thread?
        synchronized(lifecycleLock) {
            if (closed) return
            closed = true
            if (registrationRequested) {
                registrationRequested = false
                runCatching { nsdManager.unregisterService(registrationListener) }
            }
            if (discoveryRequested) {
                discoveryRequested = false
                runCatching { nsdManager.stopServiceDiscovery(discoveryListener) }
            }
            activeSockets.forEach { socket -> runCatching { socket.close() } }
            activeSockets.clear()
            probeExecutor.shutdownNow()
            workQueue.clear()
            events.clear()
            seenServices.clear()
            workerToJoin = worker
            worker = null
            workerToJoin?.interrupt()
            eventsToJoin = eventWorker
            eventWorker = null
            eventsToJoin?.interrupt()
        }
        workerToJoin?.let(::joinWorker)
        eventsToJoin?.let(::joinWorker)
    }

    @Suppress("DEPRECATION")
    private fun registerAirPlay() {
        val serviceInfo = NsdServiceInfo().apply {
            serviceName = config.deviceName
            serviceType = AIRPLAY_SERVICE_TYPE
            port = config.port
            CarPlayBonjourProtocol.airPlayTxtRecords(config, identity).forEach { (key, value) ->
                setAttribute(key, value)
            }
            localAdvertisedAddress?.let(::setHost)
        }
        nsdManager.registerService(
            serviceInfo,
            NsdManager.PROTOCOL_DNS_SD,
            registrationListener,
        )
    }

    private fun advertisedHostAddress(): InetAddress? {
        val value = advertisedHost?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        val address = try {
            InetAddress.getByName(value.removeSurrounding("[", "]"))
        } catch (error: Exception) {
            throw IllegalArgumentException("Invalid advertised host: $value", error)
        }
        require(!address.isLoopbackAddress) {
            "advertisedHost must not be a loopback address"
        }
        require(address !is Inet6Address || address.isLinkLocalAddress) {
            "advertisedHost must be link-local IPv6 or IPv4"
        }
        return address
    }

    private fun runWorker() {
        while (!closed) {
            val work = try {
                workQueue.poll(WORKER_POLL_MILLIS, TimeUnit.MILLISECONDS)
            } catch (_: InterruptedException) {
                return
            } ?: continue
            if (closed) return
            try {
                when (work) {
                    is Work.ServiceFound -> handleService(work)
                }
            } catch (_: InterruptedException) {
                return
            } catch (error: Exception) {
                if (work is Work.ServiceFound) seenServices.remove(work.key, work.token)
                if (!closed) Log.w(TAG, "CarPlay control service handling failed", error)
            }
        }
    }

    private fun enqueueStartFailure(operation: CarPlayBonjourStartOperation, errorCode: Int) {
        synchronized(lifecycleLock) {
            if (closed || !started || !failedStartOperations.add(operation)) return
            emit(CarPlayBonjourEvent.StartFailed(operation, errorCode))
        }
    }

    private fun handleService(work: Work.ServiceFound) {
        if (!isCurrent(work)) return
        val service = work.serviceInfo
        val resolved = resolveWithRetry(service)
        if (resolved == null) {
            seenServices.remove(work.key, work.token)
            return
        }
        val addresses = compatibleAddresses(resolved)
        val port = resolved.port
        if (addresses.isEmpty() || port !in 1..65535) {
            seenServices.remove(work.key, work.token)
            return
        }
        val serviceName = resolved.serviceName ?: service.serviceName ?: return
        val bluetoothId = resolved.attributes
            ?.get("id")
            ?.let(::decodeTxtValue)
            ?.takeIf { it.isNotBlank() }
        val endpoints = addresses.map { address ->
            CarPlayBonjourEndpoint(serviceName, address.hostAddress ?: return@map null, port, bluetoothId)
                .let { it to address }
        }.filterNotNull()
        if (endpoints.isNotEmpty() && isCurrent(work)) {
            scheduleProbe(Probe(work, endpoints), 0)
        }
    }

    private fun isCurrent(work: Work.ServiceFound): Boolean =
        !closed && work.token.active && seenServices[work.key] === work.token

    private class Probe(val work: Work.ServiceFound, val endpoints: List<Pair<CarPlayBonjourEndpoint, InetAddress>>) {
        val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(PROBE_BUDGET_MILLIS)
        var attempts = 0
        var lastError: IOException? = null
    }

    private fun scheduleProbe(probe: Probe, delayMillis: Long) {
        if (!isCurrent(probe.work)) return
        try {
            probeExecutor.schedule({ runProbe(probe) }, delayMillis, TimeUnit.MILLISECONDS)
        } catch (_: RejectedExecutionException) {
            // close() owns cancellation; no task may revive a closed discovery instance.
        }
    }

    @Suppress("DEPRECATION")
    private fun resolveWithRetry(service: NsdServiceInfo): NsdServiceInfo? {
        repeat(RESOLVE_ATTEMPTS) { attempt ->
            if (closed) return null
            val latch = CountDownLatch(1)
            val resolved = AtomicReference<NsdServiceInfo?>()
            val failure = AtomicInteger(FAILURE_NONE)
            val listener = object : NsdManager.ResolveListener {
                override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                    resolved.set(serviceInfo)
                    latch.countDown()
                }

                override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                    failure.set(errorCode)
                    latch.countDown()
                }
            }
            val submitted = try {
                synchronized(lifecycleLock) {
                    if (closed) {
                        false
                    } else {
                        nsdManager.resolveService(service, listener)
                        true
                    }
                }
            } catch (error: RuntimeException) {
                Log.w(TAG, "CarPlay control service resolution failed", error)
                false
            }
            if (!submitted) return null
            val completed = try {
                latch.await(RESOLVE_TIMEOUT_MILLIS, TimeUnit.MILLISECONDS)
            } catch (error: InterruptedException) {
                throw error
            }
            if (!completed) {
                Log.w(TAG, "CarPlay control service resolution timed out")
                return null
            }
            resolved.get()?.let { return it }
            if (failure.get() != NsdManager.FAILURE_ALREADY_ACTIVE) {
                Log.w(TAG, "CarPlay control service resolution failed code=${failure.get()}")
                return null
            }
            if (!closed && attempt + 1 < RESOLVE_ATTEMPTS) {
                Thread.sleep(RESOLVE_RETRY_DELAY_MILLIS)
            }
        }
        return null
    }

    @Suppress("DEPRECATION")
    private fun compatibleAddresses(serviceInfo: NsdServiceInfo): List<InetAddress> {
        val addresses = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            serviceInfo.hostAddresses.orEmpty()
        } else {
            listOfNotNull(serviceInfo.host)
        }
        return CarPlayBonjourProtocol.compatibleAddresses(addresses, localAdvertisedAddress, localPrefixLength)
    }

    private fun runProbe(probe: Probe) {
        if (!isCurrent(probe.work)) return
        val (endpoint, address) = probe.endpoints[probe.attempts % probe.endpoints.size]
        var remaining = TimeUnit.NANOSECONDS.toMillis(probe.deadline - System.nanoTime())
        if (remaining > 0) {
            probe.attempts++
            emit(CarPlayBonjourEvent.Resolved(endpoint), probe.work)
            try {
                val statusLine = probeOnce(address, endpoint.port, minOf(remaining, CONNECT_TIMEOUT_MILLIS.toLong()).toInt())
                if (!Regex("^HTTP/\\d(?:\\.\\d)? 2\\d\\d(?: |$)").containsMatchIn(statusLine)) {
                    throw IOException("CarPlay control endpoint did not accept the connect request")
                }
                if (isCurrent(probe.work)) emit(CarPlayBonjourEvent.Probed(endpoint, probe.attempts, statusLine, null), probe.work)
                return
            } catch (error: IOException) {
                probe.lastError = error
            } catch (error: RuntimeException) {
                probe.lastError = IOException("AirPlay control probe failed", error)
            }
        }
        if (!isCurrent(probe.work)) return
        remaining = TimeUnit.NANOSECONDS.toMillis(probe.deadline - System.nanoTime())
        val delay = if (probe.attempts % probe.endpoints.size == 0) PROBE_RETRY_DELAY_MILLIS else 0L
        if (probe.attempts < probe.endpoints.size * MAX_PROBE_ROUNDS && remaining > delay) {
            // Try the next compatible address before retrying a failed address. Scheduling leaves
            // both discovery and probes for other services free to make progress during backoff.
            scheduleProbe(probe, delay)
        } else {
            // Keep this generation long enough to validate its queued terminal event. The next
            // discovery may replace an inactive generation immediately, without onServiceLost.
            probe.work.token.active = false
            emit(CarPlayBonjourEvent.Probed(endpoint, probe.attempts, null,
                probe.lastError ?: IOException("CarPlay control probe budget expired")), probe.work)
        }
    }

    private fun probeOnce(address: InetAddress, port: Int, timeoutMillis: Int): String {
        val socket = socketFactory()
        try {
            synchronized(lifecycleLock) {
                if (closed) throw IOException("CarPlayBonjour is closed")
                activeSockets.add(socket)
            }
            val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMillis.toLong())
            localAdvertisedAddress?.let { socket.bind(InetSocketAddress(it, 0)) }
            socket.connect(InetSocketAddress(address, port), timeoutMillis)
            val remaining = TimeUnit.NANOSECONDS.toMillis(deadline - System.nanoTime()).coerceAtLeast(1)
            socket.soTimeout = minOf(remaining, READ_TIMEOUT_MILLIS.toLong()).toInt()
            val host = address.hostAddress
                ?: throw IOException("AirPlay control service has no host address")
            val request = CarPlayBonjourProtocol.connectProbeRequest(
                host = host,
                port = port,
                sourceVersion = config.sourceVersion,
                deviceId = config.deviceId,
            )
            val output = socket.getOutputStream()
            output.write(request.toByteArray(StandardCharsets.US_ASCII))
            output.flush()
            val input = socket.getInputStream()
            val line = ByteArrayOutputStream()
            while (line.size() < MAX_STATUS_LINE_BYTES) {
                val left = TimeUnit.NANOSECONDS.toMillis(deadline - System.nanoTime())
                if (left <= 0) throw IOException("CarPlay control status line timed out")
                socket.soTimeout = minOf(left, READ_TIMEOUT_MILLIS.toLong()).toInt().coerceAtLeast(1)
                val next = input.read()
                if (next < 0) throw IOException("AirPlay control probe returned no complete status line")
                if (next == '\n'.code) return line.toString(StandardCharsets.US_ASCII.name()).trimEnd('\r')
                line.write(next)
            }
            throw IOException("CarPlay control status line is too long")
        } finally {
            activeSockets.remove(socket)
            runCatching { socket.close() }
        }
    }

    private fun emit(event: CarPlayBonjourEvent, service: Work.ServiceFound? = null) {
        if (!closed) events.offer(PendingEvent(event, service))
    }

    private fun runEvents() {
        while (!closed) {
            val event = try {
                events.poll(WORKER_POLL_MILLIS, TimeUnit.MILLISECONDS)
            } catch (_: InterruptedException) { return } ?: continue
            try { deliver(event) } catch (_: InterruptedException) { Thread.currentThread().interrupt(); return }
        }
    }

    private fun deliver(event: PendingEvent) {
        if (closed || event.service?.let { seenServices[it.key] !== it.token } == true) return
        try {
            onEvent(event.value)
        } catch (error: RuntimeException) {
            Log.w(TAG, "CarPlay Bonjour event callback failed", error)
        }
    }

    private fun decodeTxtValue(value: ByteArray): String =
        String(value, StandardCharsets.UTF_8).trimEnd('\u0000')

    private fun joinWorker(worker: Thread) {
        if (worker === Thread.currentThread()) return
        try {
            worker.join(JOIN_TIMEOUT_MILLIS)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    private companion object {
        const val TAG = "xcertplay-bonjour"
        const val WORKER_NAME = "carplay-bonjour"
        const val AIRPLAY_SERVICE_TYPE = "_airplay._tcp"
        const val CARPLAY_CONTROL_SERVICE_TYPE = "_carplay-ctrl._tcp"
        const val WORKER_POLL_MILLIS = 500L
        const val RESOLVE_ATTEMPTS = 3
        const val RESOLVE_TIMEOUT_MILLIS = 10_000L
        const val RESOLVE_RETRY_DELAY_MILLIS = 250L
        const val MAX_PROBE_ROUNDS = 2
        const val PROBE_BUDGET_MILLIS = 12_000L
        const val PROBE_RETRY_DELAY_MILLIS = 1_500L
        const val CONNECT_TIMEOUT_MILLIS = 3_000
        const val READ_TIMEOUT_MILLIS = 3_000
        const val MAX_STATUS_LINE_BYTES = 512
        const val JOIN_TIMEOUT_MILLIS = 2_000L
        const val FAILURE_NONE = -1
    }
}
