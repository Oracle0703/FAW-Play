package com.shilapi.xcertplay.media

import android.view.MotionEvent
import com.shilapi.xcertplay.airplay.AirPlayContact

/** One host owns stable Android pointer identities for the complete HID gesture. */
class CarPlayTouchMapper {
    private val pointers = arrayOfNulls<Int>(MAX_CONTACTS)
    private var outsideContent = false
    private var active = false

    fun clear() { pointers.fill(null); outsideContent = false; active = false }

    fun contacts(
        event: MotionEvent,
        viewWidth: Int,
        viewHeight: Int,
        streamWidth: Int = viewWidth,
        streamHeight: Int = viewHeight,
    ): List<AirPlayContact> {
        val width = viewWidth.coerceAtLeast(1)
        val height = viewHeight.coerceAtLeast(1)
        val action = event.actionMasked
        if (action == MotionEvent.ACTION_DOWN) { clear(); active = true }
        if (!active) return emptyList()
        val liftedId = if (action == MotionEvent.ACTION_POINTER_UP) event.getPointerId(event.actionIndex) else null
        val allUp = action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL
        val rect = contentRect(width, height, streamWidth.coerceAtLeast(1), streamHeight.coerceAtLeast(1))
        if (action == MotionEvent.ACTION_DOWN) outsideContent =
            (event.x < rect[0] || event.x > rect[0] + rect[2] || event.y < rect[1] || event.y > rect[1] + rect[3])
        if (outsideContent) {
            if (allUp) clear()
            return emptyList()
        }
        for (index in 0 until event.pointerCount) {
            val id = event.getPointerId(index)
            if (id !in pointers) pointers.indexOfFirst { it == null }.takeIf { it >= 0 }?.let { pointers[it] = id }
        }
        val contacts = ArrayList<AirPlayContact>(MAX_CONTACTS)
        pointers.forEachIndexed { slot, id ->
            val index = id?.let(event::findPointerIndex) ?: -1
            if (index >= 0) contacts.add(
                AirPlayContact(
                    id = slot,
                    x = ((event.getX(index) - rect[0]) / rect[2]).coerceIn(0.0, 1.0),
                    y = ((event.getY(index) - rect[1]) / rect[3]).coerceIn(0.0, 1.0),
                    down = !allUp && id != liftedId,
                ),
            )
        }
        if (allUp) clear() else pointers.indices.forEach { if (pointers[it] == liftedId) pointers[it] = null }
        return contacts
    }

    companion object {
        private const val MAX_CONTACTS = 2

        fun contentRect(viewWidth: Int, viewHeight: Int, streamWidth: Int, streamHeight: Int): DoubleArray {
            require(viewWidth > 0 && viewHeight > 0 && streamWidth > 0 && streamHeight > 0)
            val scale = minOf(viewWidth.toDouble() / streamWidth, viewHeight.toDouble() / streamHeight)
            val width = streamWidth * scale
            val height = streamHeight * scale
            return doubleArrayOf((viewWidth - width) / 2, (viewHeight - height) / 2, width, height)
        }
    }
}
