package com.shilapi.xcertplay.network

import java.io.IOException

/** A request for a new, unconnected group. The returned group remains the source of actual radio data. */
sealed class WirelessRadioSelection {
    object System5Ghz : WirelessRadioSelection()

    data class Frequency(
        val frequencyMHz: Int,
        val source: Source = Source.LEGACY_REQUEST,
    ) : WirelessRadioSelection() {
        init {
            require(isCompatibleNonDfs5GhzFrequency(frequencyMHz)) {
                "Only compatible non-DFS 5 GHz frequencies may be requested"
            }
        }
    }

    enum class Source { SYSTEM_USABLE_CHANNELS, LEGACY_REQUEST }
}

/** Keeps the Android result code available for retry decisions without parsing error messages. */
class WifiP2pGroupCreationException(
    val reason: Int,
    message: String,
) : IOException(message)

// A compatibility subset; OS regulatory and concurrency checks still decide whether GO may start.
internal fun isCompatibleNonDfs5GhzFrequency(frequencyMHz: Int): Boolean =
    frequencyMHz in 5180..5240 && (frequencyMHz - 5180) % 20 == 0 ||
        frequencyMHz in 5745..5825 && (frequencyMHz - 5745) % 20 == 0
