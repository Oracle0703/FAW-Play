package com.shilapi.xcertplay.licensing

import android.os.SystemClock
import com.shilapi.xcertplay.api.ApiUrls
import com.shilapi.xcertplay.api.HttpTransport
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean

class LicenseApiException(val status: Int, val code: String, message: String) : Exception(message)
/** expectedChallengeId comes from this live request, never from parsing the returned ticket. */
data class IssuedLicense(val token: String, val expectedChallengeId: String)
data class DeviceActivation(
    val sessionId: String,
    val pollToken: String,
    val activationUrl: String,
    val deviceFingerprint: String,
    val intervalSeconds: Int,
    val expiresInSeconds: Int,
    val receivedAtElapsed: Long
)

object LicenseApi {
    fun beginActivation(appId: String, key: ByteArray, deviceName: String, sign: (ByteArray) -> String): DeviceActivation {
        val name = deviceName.take(80)
        val challenge = challenge("pair", appId, key)
        val json = post("/v1/activation/sessions", JSONObject()
            .put("challengeId", challenge.getString("challengeId"))
            .put("signature", sign(LicenseProof.bytes("pair", challenge.getString("nonce"), appId, key, name)))
            .put("deviceName", name))
        val path = json.getString("activationPath")
        // Accept only the locally configured backend and the fixed activation route.
        require(path.matches(Regex("/activate/#token=[A-Za-z0-9_-]{43}")))
        val fingerprint = LicenseVerifier.sha256Hex(key).take(16).uppercase(java.util.Locale.ROOT)
        require(json.getString("deviceFingerprint") == fingerprint)
        val interval = json.getInt("interval")
        val expires = json.getInt("expiresIn")
        require(interval in 5..60 && expires in 1..600)
        val id = json.getString("sessionId")
        java.util.UUID.fromString(id)
        val poll = json.getString("pollToken")
        require(poll.matches(Regex("[A-Za-z0-9_-]{43}")))
        return DeviceActivation(id, poll, ApiUrls.backend("/activate/") + path.removePrefix("/activate/"), fingerprint, interval, expires, SystemClock.elapsedRealtime())
    }

    fun awaitActivation(grant: DeviceActivation, appId: String, key: ByteArray, cancelled: AtomicBoolean, sign: (ByteArray) -> String): IssuedLicense {
        val deadline = grant.receivedAtElapsed + grant.expiresInSeconds * 1000L
        while (!cancelled.get()) {
            val pollAt = SystemClock.elapsedRealtime() + grant.intervalSeconds * 1000L
            while (!cancelled.get() && SystemClock.elapsedRealtime() < minOf(pollAt, deadline)) {
                Thread.sleep(minOf(250L, pollAt - SystemClock.elapsedRealtime()).coerceAtLeast(1))
            }
            if (cancelled.get()) break
            if (SystemClock.elapsedRealtime() >= deadline) throw LicenseApiException(410, "ACTIVATION_EXPIRED", "激活二维码已过期，请重新生成。")
            val status = post("/v1/activation/status", JSONObject()
                .put("sessionId", grant.sessionId).put("pollToken", grant.pollToken)).getString("status")
            if (cancelled.get()) break
            when (status) {
                "pending" -> Unit
                "ready" -> {
                    val challenge = challenge("activate", appId, key)
                    val reply = post("/v1/activation/claim", deviceRequest(grant, challenge, "activate", appId, key, sign))
                    return IssuedLicense(reply.getString("license"), challenge.getString("challengeId"))
                }
                else -> throw LicenseApiException(0, "INVALID_RESPONSE", "激活状态无效，请重新扫码。")
            }
        }
        throw LicenseApiException(0, "CANCELLED", "已停止等待激活结果。")
    }

    fun cancelActivation(grant: DeviceActivation, appId: String, key: ByteArray, sign: (ByteArray) -> String) {
        val challenge = challenge("cancel", appId, key)
        post("/v1/activation/cancel", deviceRequest(grant, challenge, "cancel", appId, key, sign))
    }

    private fun deviceRequest(grant: DeviceActivation, challenge: JSONObject, purpose: String, appId: String, key: ByteArray, sign: (ByteArray) -> String) =
        JSONObject().put("sessionId", grant.sessionId).put("challengeId", challenge.getString("challengeId"))
            .put("signature", sign(LicenseProof.bytes(purpose, challenge.getString("nonce"), appId, key, grant.sessionId)))

    fun renew(appId: String, publicKeySpki: ByteArray, license: String, sign: (ByteArray) -> String): IssuedLicense {
        val challenge = challenge("renew", appId, publicKeySpki)
        val proof = LicenseProof.bytes("renew", challenge.getString("nonce"), appId, publicKeySpki, license)
        return IssuedLicense(post("/v1/licenses/renew", JSONObject().put("challengeId", challenge.getString("challengeId"))
            .put("signature", sign(proof)).put("license", license)).getString("license"), challenge.getString("challengeId"))
    }

    private fun challenge(purpose: String, appId: String, key: ByteArray): JSONObject =
        post("/v1/challenges", JSONObject().put("purpose", purpose).put("appId", appId)
            .put("publicKeySpki", LicenseVerifier.encodeUrl(key))
            .put("offlineDays", LicenseVerifier.MAX_OFFLINE_DAYS)).also {
            require(it.getInt("expiresIn") in 1..300)
            require(it.getString("nonce").length in 16..512 && it.getString("challengeId").length in 1..128)
        }

    private fun post(path: String, body: JSONObject): JSONObject {
        val response = HttpTransport.request("POST", ApiUrls.backend(path), body.toString())
        val status = response.status
        val json = try { JSONObject(response.body) } catch (_: Exception) { JSONObject() }
        if (status !in 200..299) {
            val code = json.optString("error", "HTTP_$status")
            // Server response text may contain HTML, tokens or internal details.
            val message = when (code) {
                "DEVICE_LIMIT", "DEVICE_LIMIT_REACHED" -> "兑换码的设备额度已用完，请联系提供方解绑旧车机。"
                "LICENSE_REVOKED", "DEVICE_REVOKED" -> "此设备授权已被撤销，请联系提供方。"
                "ACTIVATION_EXPIRED", "ACTIVATION_CANCELLED" -> "二维码已失效，请重新生成并扫码。"
                "NO_LICENSE" -> "暂无可用授权，请重新扫码激活或联系提供方。"
                "LICENSE_EXPIRED" -> "购买授权已到期，请联系提供方续费。"
                "INVALID_ACTIVATION_CODE", "ACTIVATION_CODE_INVALID", "ACTIVATION_CODE_USED" -> "兑换码无效或已过期，请检查后重试。"
                else -> if (status == 429) "请求过于频繁，请稍后重试。" else "授权服务器暂未完成请求（$status），请稍后重试。"
            }
            throw LicenseApiException(status, code, message)
        }
        require(response.body.isNotBlank() && json.length() > 0) { "Empty JSON response" }
        return json
    }
}
