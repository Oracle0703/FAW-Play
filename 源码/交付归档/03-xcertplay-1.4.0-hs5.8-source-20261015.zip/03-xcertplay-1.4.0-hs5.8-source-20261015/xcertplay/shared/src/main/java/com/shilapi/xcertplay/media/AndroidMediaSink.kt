package com.shilapi.xcertplay.media

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.AudioFormat as AndroidAudioFormat
import android.media.AudioTimestamp
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaCodecList
import android.media.MediaFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Surface
import com.shilapi.xcertplay.airplay.AudioCodecKind
import com.shilapi.xcertplay.airplay.AudioStreamId
import com.shilapi.xcertplay.airplay.AudioFormat
import com.shilapi.xcertplay.airplay.MediaSink
import com.shilapi.xcertplay.airplay.MicrophoneConfig
import com.shilapi.xcertplay.airplay.VideoCodec
import com.shilapi.xcertplay.airplay.toHexString
import java.io.Closeable
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue

/**
 * Android rendering backend for the CarPlay media engine. Video frames are
 * decoded with MediaCodec onto a Surface; audio streams are decoded to PCM and
 * played through AudioTrack. Call [close] when the session tears down.
 */
class AndroidMediaSink(
    private val context: Context,
    surface: Surface? = null,
    private val videoWidth: Int = 1280,
    private val videoHeight: Int = 720,
    private val preferSoftwareHevcDecoder: Boolean = false,
    private val advancedAudioChannelMapping: Boolean = false,
    private val mainMediaAudioBufferDurationMs: Int = MainMediaAudioBuffer.DEFAULT_DURATION_MS,
    private val microphoneGainPercent: Int = MicrophoneGain.DEFAULT_PERCENT,
    mediaMetricsMonitor: MediaMetricsMonitor? = null,
    onScreenStreamActiveChanged: ((Int, Boolean) -> Unit)? = null,
    private val videoSizes: Map<Int, Pair<Int, Int>> = emptyMap(),
    private val mediaTap: MediaTap? = null,
    private val onClosed: () -> Unit = {},
    private val audioFocus: AudioFocusSession? = null,
    private val hs5: Boolean = com.shilapi.xcertplay.hud.HongqiNavigation.supported(),
    private val hs5MediaPrebufferMillis: Int = 500,
    private val hs5NavigationStream: Int = 14,
) : MediaSink {
    private val closed = java.util.concurrent.atomic.AtomicBoolean(false)
    private val defaultSurface = surface
    @Volatile private var screenStreamActiveChanged = onScreenStreamActiveChanged
    private val surfaces = ConcurrentHashMap<Int, Surface>()
    private val videoDecoders = ConcurrentHashMap<Int, VideoDecoder>()
    private val audioRenderers = ConcurrentHashMap<AudioStreamId, AudioRenderer>()
    private val microphoneUplinks = ConcurrentHashMap<AudioStreamId, MicrophoneUplink>()
    private val videoRecoveryHandlers = ConcurrentHashMap<Int, () -> Boolean>()
    private val videoRecoveryDispatcher = VideoRecoveryDispatcher()
    private val pendingVideoCodec = ConcurrentHashMap<Int, VideoCodec>()
    private val videoConfigs = ConcurrentHashMap<Int, Pair<VideoCodec, ByteArray>>()
    private val previewLock = Any()
    private val speechRouting = SpeechAudioRoutingState()
    private var contextSession: Any? = null
    @Volatile private var mediaMetricsMonitor = mediaMetricsMonitor

    init {
        audioFocus?.retain(this)
    }

    @Synchronized
    fun setSurface(type: Int, surface: Surface) {
        if (closed.get()) return
        surfaces[type] = surface
        if (!forwarded(type)) {
            videoDecoders[type]?.setSurface(surface)
            return
        }
        // A forwarded stream has no local decoder until a preview appears; start at the last config.
        synchronized(previewLock) {
            val decoder = videoDecoders[type]
            if (decoder != null) decoder.setSurface(surface)
            else videoConfigs[type]?.let { (codec, data) -> videoDecoder(type).configure(codec, data) }
        }
    }

    @Synchronized
    fun clearSurface(type: Int, surface: Surface) {
        if (!forwarded(type)) {
            if (surfaces.remove(type, surface)) videoDecoders[type]?.setSurface(null)
            return
        }
        // Holding frames for a future Surface would apply backpressure to the forwarded stream.
        synchronized(previewLock) {
            if (surfaces.remove(type, surface)) videoDecoders.remove(type)?.close()
        }
    }

    /** Queue a random-access request without writing the event socket on the calling thread. */
    fun requestKeyFrame(type: Int): Boolean {
        val handler = videoRecoveryHandlers[type] ?: return false
        return requestVideoRecovery(type, handler)
    }

    private fun requestVideoRecovery(type: Int, handler: () -> Boolean): Boolean =
        videoRecoveryDispatcher.request(
            isCurrent = { !closed.get() && videoRecoveryHandlers[type] === handler },
            send = handler,
            completed = { sent -> Log.i(TAG, "video recovery key frame completed type=$type sent=$sent") },
        )

    fun setScreenStreamActiveChangedListener(listener: ((Int, Boolean) -> Unit)?) {
        screenStreamActiveChanged = listener
    }

    fun setMediaMetricsMonitor(monitor: MediaMetricsMonitor?) {
        mediaMetricsMonitor = monitor
        videoDecoders.values.forEach { it.setMediaMetricsMonitor(monitor) }
        audioRenderers.values.forEach { it.setMediaMetricsMonitor(monitor) }
    }

    @Synchronized
    override fun onVideoRecoveryHandler(type: Int, requestKeyFrame: (() -> Boolean)?) {
        if (closed.get()) return
        val previous = if (requestKeyFrame == null) videoRecoveryHandlers.remove(type)
            else videoRecoveryHandlers.put(type, requestKeyFrame)
        if (previous !== requestKeyFrame) {
            // Each decoder captures its screen's recovery binding. Retire it on replacement;
            // an old accepted tail must never look up the new stream's handler by type alone.
            videoDecoders.remove(type)?.close()
            pendingVideoCodec.remove(type)
            videoConfigs.remove(type)
        }
    }

    override fun onVideoInteraction(type: Int) {
        videoDecoders[type]?.beginInteraction()
    }

    @Synchronized
    override fun onVideoCodec(type: Int, codec: VideoCodec) {
        if (!closed.get()) pendingVideoCodec[type] = codec
    }

    @Synchronized
    override fun onVideoConfig(type: Int, codecData: ByteArray) {
        if (closed.get()) return
        val codec = pendingVideoCodec[type] ?: VideoCodec.H264
        videoConfigs[type] = codec to codecData.copyOf()
        if (!forwarded(type)) {
            videoDecoder(type).configure(codec, codecData)
            return
        }
        mediaTap?.onVideoConfig(type, codec, codecData.copyOf())
        synchronized(previewLock) {
            if (surfaces[type] != null) videoDecoder(type).configure(codec, codecData)
        }
    }

    override fun onVideoFrame(type: Int, naluBytes: ByteArray) { prepareVideoFrame(type)?.invoke(naluBytes) }

    @Synchronized
    override fun prepareVideoFrame(type: Int): ((ByteArray) -> Unit)? {
        if (closed.get()) return null
        val remote = forwarded(type)
        val decoder = if (remote && surfaces[type] == null) videoDecoders[type] else videoDecoder(type)
        return { bytes ->
            if (!closed.get()) {
                val arrivalUs = System.nanoTime() / 1_000L
                if (remote) {
                    val accessUnit = MediaCodecSupport.toLengthPrefixed(bytes)
                    if (accessUnit.isNotEmpty()) mediaTap?.onVideoFrame(type, accessUnit, arrivalUs)
                }
                decoder?.submit(bytes, arrivalUs)
            }
        }
    }

    @Synchronized
    override fun onScreenStreamActive(type: Int, active: Boolean) {
        if (!active) {
            videoDecoders.remove(type)?.close()
            pendingVideoCodec.remove(type)
            videoConfigs.remove(type)
            videoRecoveryHandlers.remove(type)
        }
        mediaTap?.onVideoActive(type, active)
        screenStreamActiveChanged?.invoke(type, active)
    }

    private fun forwarded(type: Int) = mediaTap?.forwardsVideo(type) == true

    @Synchronized override fun onCarPlaySessionActive(session: Any) {
        contextSession = session
        speechRouting.reset()
    }
    @Synchronized override fun onCarPlaySessionEnded(session: Any) {
        if (contextSession === session) { contextSession = null; speechRouting.reset() }
    }
    @Synchronized override fun onPlaybackContext(session: Any, playback: CarPlayNowPlaying, phone: Boolean?, speech: Boolean?) {
        if (hs5 && contextSession === session) speechRouting.update(playback, phone, speech)
    }
    @Synchronized override fun onSiriRequested(session: Any) {
        if (hs5 && contextSession === session) speechRouting.siriRequested()
    }
    override fun onAudioStarted(type: Int, format: AudioFormat, firstSample: Int) = onAudioStarted(AudioStreamId(type, format.audioType), format, firstSample)
    @Synchronized override fun onAudioStarted(id: AudioStreamId, format: AudioFormat, firstSample: Int) {
        if (!closed.get()) audioRenderer(id, format).start()
    }
    override fun onAudioRtp(type: Int, format: AudioFormat, rtp: ByteArray, sample: Int) = onAudioRtp(AudioStreamId(type, format.audioType), format, rtp, sample)
    @Synchronized override fun onAudioRtp(id: AudioStreamId, format: AudioFormat, rtp: ByteArray, sample: Int) {
        if (!closed.get()) audioRenderer(id, format).submit(rtp, sample)
    }
    override fun onAudioStopped(type: Int) { audioRenderers.keys.filter { it.type == type }.forEach(::onAudioStopped) }
    @Synchronized override fun onAudioStopped(id: AudioStreamId) {
        audioRenderers.remove(id)?.close()
        mediaTap?.onAudioStopped(id.type)
    }
    override fun onMicrophoneStarted(type: Int, config: MicrophoneConfig) = onMicrophoneStarted(AudioStreamId(type, config.audioType), config)
    @Synchronized override fun onMicrophoneStarted(id: AudioStreamId, config: MicrophoneConfig) {
        if (closed.get()) return
        val uplink = microphoneUplinks.computeIfAbsent(id) { MicrophoneUplink(context, config, microphoneGainPercent) }
        if (!uplink.start()) microphoneUplinks.remove(id, uplink)
    }
    override fun onMicrophoneStopped(type: Int) { microphoneUplinks.keys.filter { it.type == type }.forEach(::onMicrophoneStopped) }
    @Synchronized override fun onMicrophoneStopped(id: AudioStreamId) { microphoneUplinks.remove(id)?.close() }

    @Synchronized
    fun close() {
        if (!closed.compareAndSet(false, true)) return
        videoDecoders.values.forEach(VideoDecoder::close)
        videoDecoders.clear()
        videoRecoveryHandlers.clear()
        videoRecoveryDispatcher.close()
        pendingVideoCodec.clear()
        videoConfigs.clear()
        audioRenderers.values.forEach(AudioRenderer::close)
        audioRenderers.clear()
        microphoneUplinks.values.forEach(MicrophoneUplink::close)
        microphoneUplinks.clear()
        audioFocus?.release(this)
        onClosed()
    }

    private fun videoDecoder(type: Int): VideoDecoder {
        val existing = videoDecoders[type]
        if (existing?.isRunning == true) return existing
        val recoveryHandler = videoRecoveryHandlers[type]
        return VideoDecoder(
            surfaces[type] ?: defaultSurface,
            videoSizes[type]?.first ?: videoWidth,
            videoSizes[type]?.second ?: videoHeight,
            preferSoftwareHevcDecoder, mediaMetricsMonitor,
            requestKeyFrame = { recoveryHandler != null && requestVideoRecovery(type, recoveryHandler) },
            probeOutput = type == 110 && !forwarded(type),
        ).also { next ->
            videoDecoders[type] = next
            videoConfigs[type]?.let { (codec, data) -> next.configure(codec, data) }
        }
    }

    @Synchronized
    private fun audioRenderer(id: AudioStreamId, format: AudioFormat): AudioRenderer {
        val existing = audioRenderers[id]
        if (existing?.format == format && existing.isRunning) return existing
        existing?.close()
        val focusOwner = Any()
        if (hs5) audioFocus?.streamCreated(this, focusOwner)
        return AudioRenderer(id.type, format, advancedAudioChannelMapping, mainMediaAudioBufferDurationMs,
            mediaMetricsMonitor, mediaTap, hs5, hs5MediaPrebufferMillis, hs5NavigationStream, speechRouting,
            onAudioChannelChanged = { channel -> if (hs5) audioFocus?.updateChannel(focusOwner, channel) },
            onClosed = { if (hs5) audioFocus?.streamEnded(focusOwner) },
        ).also { audioRenderers[id] = it }
    }

    companion object {
        private const val TAG = "xcertplay-usb"
        fun createAudioFocus(context: Context): AudioFocusSession = AudioFocusSession(
            context.applicationContext.getSystemService(AudioManager::class.java),
        )
    }

    /** Shared by the visible host and the background media pipeline. */
    class AudioFocusSession internal constructor(private val manager: AudioManager) {
        private val hs5Focus = if (com.shilapi.xcertplay.hud.HongqiNavigation.supported()) {
            Hs5AudioFocusCoordinator(manager)
        } else null
        private val owners = mutableSetOf<Any>()
        private var requested = false
        private var hasFocus = false
        private val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build(),
            )
            .setAcceptsDelayedFocusGain(true)
            .setWillPauseWhenDucked(true)
            .setOnAudioFocusChangeListener(::onFocusChanged, Handler(Looper.getMainLooper()))
            .build()

        @Synchronized
        fun retain(owner: Any) {
            hs5Focus?.let { it.retain(owner); return }
            owners.add(owner)
        }

        /** Called only when the user enters the host, never by arriving audio packets. */
        @Synchronized
        fun requestFromHost() {
            hs5Focus?.let { it.requestFromHost(); return }
            if (owners.isEmpty() || hasFocus) return
            val result = manager.requestAudioFocus(request)
            requested = result != AudioManager.AUDIOFOCUS_REQUEST_FAILED
            hasFocus = result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            Log.i(TAG, "audio focus request result=$result")
        }

        @Synchronized
        fun release(owner: Any) {
            hs5Focus?.let { it.release(owner); return }
            owners.remove(owner)
            if (owners.isNotEmpty()) return
            manager.abandonAudioFocusRequest(request)
            requested = false
            hasFocus = false
            Log.i(TAG, "audio focus released")
        }

        internal fun streamCreated(owner: Any, stream: Any) { hs5Focus?.streamCreated(owner, stream) }
        internal fun updateChannel(stream: Any, channel: AudioChannel) { hs5Focus?.updateChannel(stream, channel) }
        internal fun streamEnded(stream: Any) { hs5Focus?.streamEnded(stream) }

        @Synchronized
        private fun onFocusChanged(change: Int) {
            if (owners.isEmpty() || !requested) return
            when (change) {
                AudioManager.AUDIOFOCUS_GAIN -> hasFocus = true
                AudioManager.AUDIOFOCUS_LOSS -> {
                    requested = false
                    hasFocus = false
                }
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT,
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK,
                -> hasFocus = false
            }
            // Focus tracks ownership only; the phone's audio keeps flowing at its normal volume.
            Log.i(TAG, "audio focus change=$change hasFocus=$hasFocus")
        }

        private companion object {
            const val TAG = "xcertplay-usb"
        }
    }
}

private sealed interface VideoJob {
    data class Config(val codec: VideoCodec, val codecData: ByteArray) : VideoJob
    data class Frame(val nalus: ByteArray, val receivedUs: Long) : VideoJob
}

/** Serial MediaCodec video decoder: one worker owns configure and frame feeding. */
private class VideoDecoder(
    surface: Surface?,
    private val width: Int,
    private val height: Int,
    private val preferSoftwareHevcDecoder: Boolean,
    mediaMetricsMonitor: MediaMetricsMonitor?,
    private val requestKeyFrame: () -> Boolean,
    private val probeOutput: Boolean,
) : Closeable, VideoSurfaceHandoff.Owner {
    private val queue = VideoWorkQueue<VideoJob>(8)
    @Volatile private var running = true
    @Volatile private var decoder: MediaCodec? = null
    private var pump: VideoDecodePump? = null
    private var syncGate: VideoSyncGate? = null
    private var pendingSinceNs = 0L
    private var lastPtsUs = 0L
    private var statsStartNs = System.nanoTime()
    private var inputCount = 0
    private var outputCount = 0
    private var inputRetries = 0
    private var syncSkips = 0
    private var maxOutputAgeUs = 0L
    private var needsKeyFrame = false
    private var lastKeyFrameRequestNs = 0L
    private val outputProgress = VideoOutputProgress()
    private val interactionPending = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var requestedSurface: Surface? = surface
    @Volatile private var outputSurface: Surface? = surface
    private var heldFrame: VideoJob.Frame? = null
    private var lastConfig: VideoJob.Config? = null
    private var renderedFrameLogged = false
    private var submittedFrameLogged = false
    private var duplicateConfigLogged = false
    private var awaitingConfigLogged = false
    @Volatile private var mediaMetricsMonitor = mediaMetricsMonitor
    private val exited = java.util.concurrent.CountDownLatch(1)
    val isRunning get() = running
    private val thread = Thread(::run, "carplay-video").apply { isDaemon = true }
    init { VideoSurfaceHandoff.register(this); thread.start() }
    override fun beginRelease(surface: Surface): Boolean {
        if (requestedSurface !== surface && outputSurface !== surface) return false
        close()
        return true
    }
    override fun awaitRelease(deadlineNs: Long): Boolean =
        exited.await((deadlineNs - System.nanoTime()).coerceAtLeast(0), java.util.concurrent.TimeUnit.NANOSECONDS)

    fun configure(codec: VideoCodec, codecData: ByteArray) {
        queue.control(VideoJob.Config(codec, codecData.copyOf()))
    }

    fun submit(nalus: ByteArray, arrivalUs: Long) {
        queue.frame(VideoJob.Frame(nalus, arrivalUs))
    }

    fun setSurface(surface: Surface?) {
        requestedSurface = surface
    }

    fun setMediaMetricsMonitor(monitor: MediaMetricsMonitor?) {
        mediaMetricsMonitor = monitor
    }

    fun beginInteraction() { interactionPending.set(true) }

    override fun close() {
        running = false
        queue.close()
        thread.interrupt()
    }

    private fun run() {
        try {
            while (running) {
                try {
                    if (outputSurface !== requestedSurface) changeSurface(requestedSurface)
                    if (interactionPending.getAndSet(false)) outputProgress.beginEpisode(System.nanoTime())
                    if (needsKeyFrame && outputSurface != null &&
                        System.nanoTime() - lastKeyFrameRequestNs >= KEY_FRAME_REQUEST_INTERVAL_NS
                    ) {
                        lastKeyFrameRequestNs = System.nanoTime()
                        Log.i(TAG, "video recovery key frame queued=${requestKeyFrame()}")
                    }
                    // Poll output independently of input arrival, including the final/static frame.
                    pump?.tick()
                    val now = System.nanoTime()
                    if (probeOutput && !needsKeyFrame && outputSurface != null && outputProgress.shouldProbe(now) &&
                        (lastKeyFrameRequestNs == 0L || now - lastKeyFrameRequestNs >= KEY_FRAME_REQUEST_INTERVAL_NS) &&
                        requestKeyFrame()) {
                        lastKeyFrameRequestNs = now
                        outputProgress.probeScheduled()
                        Log.i(TAG, "video output pending without progress; keyframe probe queued ageMs=${outputProgress.ageNanos(now) / 1_000_000}")
                    }
                    logVideoStats()
                    if (pump?.hasPending == true) {
                        check(System.nanoTime() - pendingSinceNs < INPUT_STALL_NS) {
                            "Video decoder input stalled; waiting for a new random access frame"
                        }
                        Thread.sleep(2)
                        continue
                    }
                    if (heldFrame != null && outputSurface == null) {
                        Thread.sleep(5)
                        continue
                    }
                    when (val job = heldFrame ?: queue.poll(5)) {
                        is VideoJob.Config -> configureDecoder(job)
                        is VideoJob.Frame -> {
                            // Preserve the initial random access picture until a Surface exists.
                            heldFrame = if (outputSurface == null) job else null
                            if (outputSurface != null) feed(job)
                        }
                        null -> Unit
                    }
                } catch (error: InterruptedException) {
                    throw error
                } catch (error: Exception) {
                    if (running) Log.e(TAG, "video decoder failed; restarting at random access", error)
                    releaseDecoder()
                    needsKeyFrame = true
                }
            }
        } catch (_: InterruptedException) {
            // Worker shut down.
        } finally {
            heldFrame = null
            try { releaseDecoder() } finally { VideoSurfaceHandoff.unregister(this); exited.countDown() }
        }
    }

    private fun configureDecoder(config: VideoJob.Config) {
        val previous = lastConfig
        if (
            decoder != null &&
            previous?.codec == config.codec &&
            previous.codecData.contentEquals(config.codecData)
        ) {
            if (!duplicateConfigLogged) {
                duplicateConfigLogged = true
                Log.i(TAG, "video decoder config unchanged; keeping existing decoder")
            }
            return
        }
        lastConfig = config
        duplicateConfigLogged = false
        awaitingConfigLogged = false
        releaseDecoder()
        val surface = outputSurface ?: return
        val codec = config.codec
        val codecData = config.codecData
        val mime = if (codec == VideoCodec.H265) MediaFormat.MIMETYPE_VIDEO_HEVC
        else MediaFormat.MIMETYPE_VIDEO_AVC
        val csd: ByteArray
        val pps: ByteArray?
        if (codec == VideoCodec.H265) {
            csd = MediaCodecSupport.hevcCodecSpecificData(codecData)
            pps = null
        } else {
            val sets = MediaCodecSupport.avcParameterSets(codecData)
            require(sets.first.isNotEmpty() && sets.second.isNotEmpty()) { "Missing AVC parameter sets" }
            csd = START_CODE + sets.first
            pps = START_CODE + sets.second
        }
        require(csd.isNotEmpty()) { "Missing or invalid video parameter sets" }
        val parameters = VideoParameters.parse(codec, csd)
        val format = MediaFormat.createVideoFormat(mime, parameters.width, parameters.height).apply {
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, MAX_INPUT_SIZE)
            setByteBuffer("csd-0", ByteBuffer.wrap(csd))
            if (pps != null) setByteBuffer("csd-1", ByteBuffer.wrap(pps))
            // Unspecified VUI fields remain unspecified; do not force full range or BT.709.
            if (parameters.colorStandard != -1) setInteger(MediaFormat.KEY_COLOR_STANDARD, parameters.colorStandard)
            if (parameters.colorRange != -1) setInteger(MediaFormat.KEY_COLOR_RANGE, parameters.colorRange)
            if (parameters.colorTransfer != -1) setInteger(MediaFormat.KEY_COLOR_TRANSFER, parameters.colorTransfer)
            setInteger(MediaFormat.KEY_PRIORITY, 0)
        }
        val next = VideoDecoderStartup.start(
            mime, format, surface, preferSoftwareHevcDecoder, createDefault = { createDecoder(mime) },
        )
        decoder = next
        syncGate = VideoSyncGate(codec)
        pump = VideoDecodePump(object : VideoDecodePump.Port {
            override fun drain() = drainOutput(next)
            override fun queue(bytes: ByteArray, presentationTimeUs: Long): Boolean {
                val index = next.dequeueInputBuffer(0)
                if (index < 0) {
                    inputRetries++
                    return false
                }
                val input = checkNotNull(next.getInputBuffer(index)) { "Missing video input buffer" }
                input.clear()
                check(bytes.size <= input.remaining()) { "Video access unit exceeds decoder input capacity" }
                input.put(bytes)
                next.queueInputBuffer(index, 0, bytes.size, presentationTimeUs, 0)
                outputProgress.onInput(presentationTimeUs, System.nanoTime())
                inputCount++
                return true
            }
        })
        Log.i(TAG, "video SPS parameters=$parameters negotiated=${width}x$height inputFormat=$format")
        renderedFrameLogged = false
        submittedFrameLogged = false
        Log.i(TAG, "video decoder configured name=${next.name} mime=$mime; waiting for random access")
    }

    private fun createDecoder(mime: String): MediaCodec {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
            mime == MediaFormat.MIMETYPE_VIDEO_HEVC &&
            preferSoftwareHevcDecoder
        ) {
            val software = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.firstOrNull {
                !it.isEncoder && it.isSoftwareOnly && mime in it.supportedTypes
            }
            if (software != null) {
                try {
                    return MediaCodec.createByCodecName(software.name)
                } catch (error: Exception) {
                    Log.w(TAG, "software HEVC decoder unavailable name=${software.name}", error)
                }
            }
        }
        return MediaCodec.createDecoderByType(mime)
    }

    private fun changeSurface(surface: Surface?) {
        if (outputSurface === surface) return
        outputSurface = surface
        if (surface == null) {
            releaseDecoder()
            Log.i(TAG, "video decoder detached from surface")
            return
        }
        val codec = decoder
        if (codec != null) {
            try {
                codec.setOutputSurface(surface)
                Log.i(TAG, "video decoder output surface updated")
                return
            } catch (error: Exception) {
                Log.w(TAG, "video decoder output surface update failed; reconfiguring", error)
            }
        }
        releaseDecoder()
        lastConfig?.let(::configureDecoder)
    }

    private fun feed(frame: VideoJob.Frame) {
        if (decoder == null) {
            if (outputSurface == null) return
            val config = lastConfig
            if (config == null) {
                // The phone emits its codec config (opcode=1) before the first
                // frame; frames without one mean it skipped that step (seen with
                // HEVC). Nudge it instead of dropping frames forever.
                if (!awaitingConfigLogged) {
                    awaitingConfigLogged = true
                    Log.i(TAG, "video frames without codec config; requesting keyframe")
                }
                needsKeyFrame = true
                return
            }
            configureDecoder(config)
        }
        val activePump = pump ?: return
        val annexB = MediaCodecSupport.toAnnexB(frame.nalus)
        require(annexB.isNotEmpty()) { "Malformed video access unit" }
        if (syncGate?.accept(annexB) != true) {
            // RASL intentionally skipped after CRA does not mean sync was lost.
            if (syncGate?.waitingForRandomAccess == true) {
                needsKeyFrame = true
                syncSkips++
            }
            return
        }
        needsKeyFrame = false
        if (!submittedFrameLogged) {
            submittedFrameLogged = true
            Log.i(TAG, "video decoder first random access input bytes=${annexB.size}")
        }
        lastPtsUs = maxOf(lastPtsUs + 1, frame.receivedUs)
        activePump.submit(annexB, lastPtsUs)
        pendingSinceNs = System.nanoTime()
        activePump.tick()
    }

    private fun drainOutput(codec: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        while (running) {
            val index = codec.dequeueOutputBuffer(info, 0)
            when {
                index == MediaCodec.INFO_TRY_AGAIN_LATER -> return
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> logOutputFormat(codec.outputFormat)
                index >= 0 -> {
                    val render = outputSurface != null &&
                        info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0
                    outputCount++
                    maxOutputAgeUs = maxOf(maxOutputAgeUs, System.nanoTime() / 1000 - info.presentationTimeUs)
                    codec.releaseOutputBuffer(index, render)
                    if (render) {
                        outputProgress.onOutput(info.presentationTimeUs, System.nanoTime())
                        // feed() assigns the System.nanoTime-based arrival as input PTS. This
                        // measurement assumes MediaCodec preserves that PTS in BufferInfo.
                        mediaMetricsMonitor?.recordVideoFrameRendered(
                            arrivalNs = info.presentationTimeUs * 1_000L,
                            renderedNs = System.nanoTime(),
                        )
                    }
                    if (render && !renderedFrameLogged) {
                        renderedFrameLogged = true
                        Log.i(TAG, "video decoder rendered first frame bytes=${info.size}")
                    }
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
                else -> return
            }
        }
    }

    private fun logVideoStats() {
        val now = System.nanoTime()
        if (now - statsStartNs < 5_000_000_000L) return
        if (inputCount + outputCount + inputRetries + syncSkips > 0) {
            val seconds = (now - statsStartNs) / 1e9
            Log.i(TAG, "video stats inputFps=${inputCount / seconds} decodedFps=${outputCount / seconds} " +
                "inputRetries=$inputRetries syncSkips=$syncSkips queued=${queue.size} " +
                "maxOutputAgeMs=${maxOutputAgeUs / 1000} waitingForSync=${syncGate?.waitingForRandomAccess}")
        }
        statsStartNs = now
        inputCount = 0
        outputCount = 0
        inputRetries = 0
        syncSkips = 0
        maxOutputAgeUs = 0
    }

    private fun logOutputFormat(format: MediaFormat) {
        Log.i(
            TAG,
            "video decoder output format " +
                "size=${format.intOrNull(MediaFormat.KEY_WIDTH)}x" +
                "${format.intOrNull(MediaFormat.KEY_HEIGHT)} " +
                "stride=${format.intOrNull(MediaFormat.KEY_STRIDE)} " +
                "slice=${format.intOrNull(MediaFormat.KEY_SLICE_HEIGHT)} " +
                "standard=${format.intOrNull(MediaFormat.KEY_COLOR_STANDARD)} " +
                "range=${format.intOrNull(MediaFormat.KEY_COLOR_RANGE)} " +
                "transfer=${format.intOrNull(MediaFormat.KEY_COLOR_TRANSFER)}",
        )
    }

    @Synchronized
    private fun releaseDecoder() {
        val codec = decoder
        decoder = null
        pump = null
        syncGate = null
        outputProgress.reset()
        if (codec != null) {
            needsKeyFrame = true
            try {
                codec.stop()
            } catch (_: Exception) {
                // Best effort.
            }
            try {
                codec.release()
            } catch (_: Exception) {
                // Best effort.
            }
        }
    }

    private companion object {
        const val TAG = "xcertplay-usb"
        const val MAX_INPUT_SIZE = 8 * 1024 * 1024
        const val INPUT_STALL_NS = 2_000_000_000L
        const val KEY_FRAME_REQUEST_INTERVAL_NS = 2_000_000_000L
        val START_CODE = byteArrayOf(0x00, 0x00, 0x00, 0x01)
    }
}

private fun MediaFormat.intOrNull(key: String): Int? =
    if (!containsKey(key)) {
        null
    } else {
        try {
            getInteger(key)
        } catch (_: Exception) {
            null
        }
    }

/** Decodes AAC-LC/Opus to PCM and plays it, or plays wired LPCM directly. */
private class AudioRenderer(
    private val stream: Int,
    val format: AudioFormat,
    private val advancedAudioChannelMapping: Boolean,
    private val mainMediaAudioBufferDurationMs: Int,
    mediaMetricsMonitor: MediaMetricsMonitor?,
    private val mediaTap: MediaTap?,
    private val hs5: Boolean,
    private val mediaPrebufferMillis: Int,
    private val navigationStream: Int,
    private val speechRouting: SpeechAudioRoutingState,
    private val onAudioChannelChanged: (AudioChannel) -> Unit = {},
    private val onClosed: () -> Unit = {},
) : Closeable {
    private data class AudioPacket(val rtp: ByteArray, val sample: Int)

    private val queue = LinkedBlockingQueue<AudioPacket>(MAX_QUEUED_PACKETS)
    @Volatile private var running = true
    @Volatile private var started = false
    val isRunning get() = running
    private val streamStartedAt = android.os.SystemClock.uptimeMillis()
    private var selectedChannel = AudioChannel.MEDIA
    private var routing: SpeechAudioRoute? = null
    private var bufferProgress = AudioBufferProgress(if (format.channels >= 2) 4 else 2)
    private var underrunsAtStart = 0
    private var lastPcmWriteNs = 0L
    private var codec: MediaCodec? = null
    private var track: AudioTrack? = null
    private var pcm = ByteArray(64 * 1024)
    private var playbackStarted = false
    private var prebufferBytes = 0
    private var startThresholdBytes = 0
    private var fadeApplied = false
    private var droppedPacketsLogged = false
    private var firstAacPayloadLogged = false
    private var firstOpusShortPacketLogged = false
    private var firstInputQueuedLogged = false
    private var inputQueued = 0
    private var inputDropped = 0
    private var outputBuffers = 0
    private var firstPcmLogged = false
    private var trackBytesPerFrame = 0
    private var totalBytesWritten = 0L
    private var playbackHeadWraps = 0L
    private var lastPlaybackHeadRaw = 0L
    private var lastPlaybackHeadFrames = 0L
    private val audioTimestamp = AudioTimestamp()
    private var lastAudioTimestampQueryNs = 0L
    private var timestampHeadWraps = 0L
    private var lastTimestampHeadRaw = 0L
    private var lastTimestampHeadFrames = 0L
    private var latestOutputLatencyMs: Float? = null
    @Volatile private var mediaMetricsMonitor = mediaMetricsMonitor
    private val thread = Thread(::run, "carplay-audio").apply { isDaemon = true }

    fun start() {
        if (started) return
        started = true
        thread.start()
    }

    fun submit(rtp: ByteArray, sample: Int) {
        if (!started || !queue.offer(AudioPacket(rtp, sample))) {
            if (started && !droppedPacketsLogged) {
                droppedPacketsLogged = true
                Log.w(TAG, "audio queue full; dropping newest packets to bound latency")
            }
        }
    }

    fun setMediaMetricsMonitor(monitor: MediaMetricsMonitor?) {
        mediaMetricsMonitor = monitor
    }

    override fun close() {
        running = false
        thread.interrupt()
        onClosed()
    }

    private fun run() {
        try {
            when (format.codec) {
                AudioCodecKind.AAC_LC -> configureCodec(MediaFormat.MIMETYPE_AUDIO_AAC)
                AudioCodecKind.OPUS -> configureCodec(MediaFormat.MIMETYPE_AUDIO_OPUS)
                AudioCodecKind.LPCM -> Unit
            }
            while (running && hs5 && format.audioType == "speechrecognition" && speechRouting.route(streamStartedAt) == SpeechAudioRoute.WAIT) Thread.sleep(10)
            if (!running) return
            createTrack()
            while (running) {
                if (hs5 && format.audioType == "speechrecognition") {
                    val next = speechRouting.route(streamStartedAt)
                    if (next != SpeechAudioRoute.WAIT && next != routing) { track?.release(); track = null; createTrack() }
                }
                queue.poll(20, java.util.concurrent.TimeUnit.MILLISECONDS)?.let(::handle)
                if (hs5) maintainPlaybackBuffer()
            }
        } catch (_: InterruptedException) {
            // Worker shut down.
        } catch (error: Exception) {
            if (running) Log.e(TAG, "audio renderer worker failed", error)
        } finally {
            running = false
            release()
        }
    }

    private fun configureCodec(mime: String) {
        val mediaFormat = MediaFormat().apply {
            setString(MediaFormat.KEY_MIME, mime)
            setInteger(MediaFormat.KEY_SAMPLE_RATE, format.sampleRate)
            setInteger(MediaFormat.KEY_CHANNEL_COUNT, format.channels)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 64 * 1024)
            if (mime == MediaFormat.MIMETYPE_AUDIO_AAC) {
                setInteger(MediaFormat.KEY_IS_ADTS, 1)
                setByteBuffer("csd-0", ByteBuffer.wrap(aacAudioSpecificConfig()))
            } else {
                setByteBuffer("csd-0", ByteBuffer.wrap(opusHead()))
                setByteBuffer("csd-1", ByteBuffer.wrap(opusCodecDelay()))
                setByteBuffer("csd-2", ByteBuffer.wrap(opusSeekPreRoll()))
            }
        }
        if (mime == MediaFormat.MIMETYPE_AUDIO_AAC) {
            Log.i(
                TAG,
                "audio AAC config rate=${format.sampleRate} channels=${format.channels} " +
                    "csd0=${aacAudioSpecificConfig().toHexString()}",
            )
        }
        codec = try {
            MediaCodec.createDecoderByType(mime).also {
                it.configure(mediaFormat, null, null, 0)
                it.start()
                Log.i(TAG, "audio decoder configured mime=$mime name=${it.name}")
            }
        } catch (error: Exception) {
            Log.e(TAG, "audio decoder configuration failed mime=$mime", error)
            null
        }
    }

    private fun createTrack() {
        val encoding = AndroidAudioFormat.ENCODING_PCM_16BIT
        val trackChannelCount = if (format.channels >= 2) 2 else 1
        val channelMask = if (trackChannelCount == 2) AndroidAudioFormat.CHANNEL_OUT_STEREO
        else AndroidAudioFormat.CHANNEL_OUT_MONO
        val minBuffer = AudioTrack.getMinBufferSize(format.sampleRate, channelMask, encoding)
        if (minBuffer <= 0) {
            Log.e(TAG, "AudioTrack buffer size unavailable rate=${format.sampleRate} channels=${format.channels}")
            return
        }
        val configuredMainMediaBuffer = MainMediaAudioBuffer.isMainMedia(
            audioType = format.audioType,
            payloadType = format.payloadType,
        )
        val bufferBytes = if (configuredMainMediaBuffer) {
            MainMediaAudioBuffer.bufferSizeBytes(
                durationMs = mainMediaAudioBufferDurationMs,
                sampleRate = format.sampleRate,
                channelCount = trackChannelCount,
                minBufferBytes = minBuffer,
            )
        } else {
            maxOf(minBuffer * 4, MIN_TRACK_BUFFER_BYTES)
        }
        startThresholdBytes = if (format.audioType == "telephony" || format.audioType == "speechrecognition") {
            maxOf(minBuffer, MIN_START_BUFFER_BYTES)
        } else {
            maxOf(minBuffer, MIN_START_BUFFER_BYTES)
        }
        val attributes = audioAttributes()
        val plan = if (hs5 && selectedChannel == AudioChannel.NAVIGATION) NavigationAudioBuffer.plan(format.sampleRate, trackChannelCount, minBuffer)
            else MediaAudioBuffer.plan(selectedChannel == AudioChannel.MEDIA, format.sampleRate, trackChannelCount, minBuffer, mediaPrebufferMillis)
        if (hs5) startThresholdBytes = plan.startBytes
        val capacityBytes = if (hs5) plan.trackBufferBytes else bufferBytes
        fun usageTrack() = AudioTrack.Builder()
            .setAudioAttributes(attributes)
            .setAudioFormat(
                AndroidAudioFormat.Builder()
                    .setEncoding(encoding)
                    .setSampleRate(format.sampleRate)
                    .setChannelMask(channelMask)
                    .build(),
            )
            .setBufferSizeInBytes(capacityBytes)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = if (hs5 && selectedChannel == AudioChannel.NAVIGATION && navigationStream == 14) {
            LegacyAudioFallback.build(
                createLegacy = { AudioTrack(14, format.sampleRate, channelMask, encoding, capacityBytes, AudioTrack.MODE_STREAM) },
                isInitialized = { it.state == AudioTrack.STATE_INITIALIZED },
                release = { it.release() },
                createFallback = { Log.w(TAG, "HS5 navigation stream 14 rejected; using navigation usage"); usageTrack() },
            )
        } else usageTrack()
        // AudioTrack consumes 16-bit PCM, so frame size follows the channel mask configured above.
        trackBytesPerFrame = trackChannelCount * BYTES_PER_PCM_16_SAMPLE
        if (hs5) startThresholdBytes = MediaAudioBuffer.startBytesFor(startThresholdBytes, requireNotNull(track).bufferSizeInFrames * trackBytesPerFrame, PREBUFFER_WRITE_CHUNK_BYTES)
        playbackStarted = false; prebufferBytes = 0; totalBytesWritten = 0L
        fadeApplied = false; lastPcmWriteNs = 0L; underrunsAtStart = 0
        lastAudioTimestampQueryNs = 0L; timestampHeadWraps = 0L; lastTimestampHeadRaw = 0L; lastTimestampHeadFrames = 0L
        latestOutputLatencyMs = null
        bufferProgress = AudioBufferProgress(trackBytesPerFrame)
        playbackHeadWraps = 0; lastPlaybackHeadRaw = 0; lastPlaybackHeadFrames = 0
        Log.i(
            TAG,
            "audio track prepared type=${format.payloadType} audioType=${format.audioType} " +
                "codec=${format.codec} " +
                "rate=${format.sampleRate} channels=${format.channels} " +
                "bufferBytes=$capacityBytes startBytes=$startThresholdBytes" +
                if (configuredMainMediaBuffer && !hs5) {
                    " configuredDurationMs=${MainMediaAudioBuffer.sanitizeDurationMs(mainMediaAudioBufferDurationMs)}"
                } else {
                    ""
                },
        )
        if (running) onAudioChannelChanged(selectedChannel)
    }

    private fun aacAudioSpecificConfig(): ByteArray {
        val frequencyIndex = MediaCodecSupport.aacFrequencyIndex(format.sampleRate)
        val value = (AAC_OBJECT_TYPE_LC shl 11) or
            (frequencyIndex shl 7) or
            (format.channels.coerceIn(1, 7) shl 3)
        return byteArrayOf((value ushr 8).toByte(), value.toByte())
    }

    private fun audioAttributes(): AudioAttributes {
        val mode = if (advancedAudioChannelMapping) {
            AudioChannelMappingMode.AUTOMOTIVE_BUS
        } else {
            AudioChannelMappingMode.MOBILE_COMPATIBLE
        }
        var selection = AudioChannelMapper.map(
            audioType = format.audioType,
            payloadType = format.payloadType,
            mode = mode,
        )
        if (hs5) {
            selection = Hs5AudioProfile.selection(format.audioType, format.payloadType, mode)
            if (format.audioType == "speechrecognition") {
                routing = speechRouting.route(streamStartedAt)
                if (routing == SpeechAudioRoute.MEDIA) selection = AudioChannelSelection(AudioChannel.MEDIA, AudioContentType.MUSIC)
            }
        }
        selectedChannel = selection.channel
        val usage = usageFor(selection.channel)
        val contentType = contentTypeFor(selection.contentType)
        return AudioAttributes.Builder()
            .setUsage(usage)
            .setContentType(contentType)
            .build()
            .also {
                Log.i(
                    TAG,
                    "audio route type=${format.payloadType} audioType=${format.audioType} " +
                        "mode=$mode channel=${selection.channel} " +
                        "usage=$usage contentType=$contentType",
                )
            }
    }

    private fun usageFor(channel: AudioChannel): Int = when (channel) {
        AudioChannel.MEDIA -> AudioAttributes.USAGE_MEDIA
        AudioChannel.PHONE -> AudioAttributes.USAGE_VOICE_COMMUNICATION
        AudioChannel.ASSISTANT -> AudioAttributes.USAGE_ASSISTANT
        AudioChannel.NAVIGATION -> AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE
    }

    private fun contentTypeFor(contentType: AudioContentType): Int = when (contentType) {
        AudioContentType.MUSIC -> AudioAttributes.CONTENT_TYPE_MUSIC
        AudioContentType.SPEECH -> AudioAttributes.CONTENT_TYPE_SPEECH
    }

    /** Minimal OpusHead CSD for the mono 48 kHz stream CarPlay negotiates. */
    private fun opusHead(): ByteArray {
        val head = ByteArray(19)
        "OpusHead".toByteArray(Charsets.US_ASCII).copyInto(head, 0)
        head[8] = 1
        head[9] = format.channels.toByte()
        head[10] = 0x38
        head[11] = 0x01
        head[12] = format.sampleRate.toByte()
        head[13] = (format.sampleRate ushr 8).toByte()
        head[14] = (format.sampleRate ushr 16).toByte()
        head[15] = (format.sampleRate ushr 24).toByte()
        return head
    }

    private fun opusCodecDelay(): ByteArray =
        java.nio.ByteBuffer.allocate(8)
            .order(java.nio.ByteOrder.LITTLE_ENDIAN)
            .putLong(OPUS_CODEC_DELAY_NANOS)
            .array()

    private fun opusSeekPreRoll(): ByteArray =
        java.nio.ByteBuffer.allocate(8)
            .order(java.nio.ByteOrder.LITTLE_ENDIAN)
            .putLong(OPUS_SEEK_PRE_ROLL_NANOS)
            .array()

    private fun handle(packet: AudioPacket) {
        val rtp = packet.rtp
        val timestampUs = sampleTimestampUs(packet.sample)
        when (format.codec) {
            AudioCodecKind.LPCM -> writePcm(byteSwapS16(rtp.copyOfRange(12, rtp.size)))
            AudioCodecKind.AAC_LC -> {
                val accessUnit = rtp.copyOfRange(12, rtp.size)
                if (accessUnit.isNotEmpty()) {
                    if (!firstAacPayloadLogged) {
                        firstAacPayloadLogged = true
                        Log.i(
                            TAG,
                            "audio AAC access unit bytes=${accessUnit.size} " +
                                "head=${accessUnit.copyOf(minOf(accessUnit.size, 16)).toHexString()}",
                        )
                    }
                    feedCodec(
                        MediaCodecSupport.adtsFrame(accessUnit, format.sampleRate, format.channels),
                        timestampUs,
                    )
                }
            }
            AudioCodecKind.OPUS -> {
                val accessUnit = rtp.copyOfRange(12, rtp.size)
                if (accessUnit.size < MIN_OPUS_PACKET_BYTES) {
                    if (!firstOpusShortPacketLogged) {
                        firstOpusShortPacketLogged = true
                        Log.i(
                            TAG,
                            "audio Opus skipping short packet bytes=${accessUnit.size} " +
                                "head=${accessUnit.toHexString()}",
                        )
                    }
                    return
                }
                feedCodec(accessUnit, timestampUs)
            }
        }
    }

    private fun sampleTimestampUs(sample: Int): Long =
        (sample.toLong() and 0xffff_ffffL) * 1_000_000L / format.sampleRate

    private fun feedCodec(payload: ByteArray, presentationTimeUs: Long) {
        val codec = codec ?: return
        val index = AudioInputPump.acquire(
            running = { running },
            dequeue = { codec.dequeueInputBuffer(INPUT_TIMEOUT_US) },
            drain = { drainCodec(codec); if (hs5) maintainPlaybackBuffer() },
        )
        if (index < 0 || !running) return
        val input = codec.getInputBuffer(index) ?: return
        input.clear()
        if (payload.size <= input.remaining()) {
            input.put(payload)
            codec.queueInputBuffer(index, 0, payload.size, presentationTimeUs, 0)
            inputQueued++
            if (!firstInputQueuedLogged) {
                firstInputQueuedLogged = true
                Log.i(
                    TAG,
                    "audio decoder first input codec=${format.codec} bytes=${payload.size} " +
                        "head=${payload.copyOf(minOf(payload.size, 16)).toHexString()}",
                )
            }
        } else {
            codec.queueInputBuffer(index, 0, 0, 0, 0)
            inputDropped++
        }
        drainCodec(codec)
    }

    private fun drainCodec(codec: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        while (running) {
            val index = codec.dequeueOutputBuffer(info, 0)
            when {
                index == MediaCodec.INFO_TRY_AGAIN_LATER -> return
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> Unit
                index >= 0 -> {
                    val size = info.size
                    if (size > 0) {
                        outputBuffers++
                        if (outputBuffers == 1 || outputBuffers % DECODED_BUFFER_LOG_INTERVAL == 0) {
                            Log.i(
                                TAG,
                                "audio decoder output codec=${format.codec} " +
                                    "buffers=$outputBuffers bytes=$size " +
                                    "queued=$inputQueued dropped=$inputDropped",
                            )
                        }
                    }
                    if (size > 0) {
                        val output = codec.getOutputBuffer(index)
                        if (output != null) {
                            if (size > pcm.size) pcm = ByteArray(size)
                            output.position(info.offset)
                            output.limit(info.offset + size)
                            output.get(pcm, 0, size)
                            writePcm(pcm, 0, size)
                        }
                    }
                    codec.releaseOutputBuffer(index, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
                else -> return
            }
        }
    }

    private fun writePcm(data: ByteArray, offset: Int = 0, length: Int = data.size) {
        if (mediaTap?.takesAudio() == true) {
            forwardPcm(data, offset, length)
            return
        }
        val track = track ?: return
        if (!firstPcmLogged && length > 0) {
            firstPcmLogged = true
            val end = minOf(data.size, offset + minOf(length, 16))
            Log.i(
                TAG,
                "audio first PCM type=${format.payloadType} bytes=$length " +
                    "head=${data.copyOfRange(offset, end).toHexString()}",
            )
        }
        if (!fadeApplied) {
            applyFadeIn(data, offset, length)
            fadeApplied = true
        }
        var written = 0
        while (written < length && running) {
            val writeLength = if (playbackStarted) {
                length - written
            } else {
                minOf(length - written, PREBUFFER_WRITE_CHUNK_BYTES)
            }
            val count = track.write(data, offset + written, writeLength, AudioTrack.WRITE_BLOCKING)
            if (count <= 0) break
            written += count
            totalBytesWritten += count
            bufferProgress.written(count)
            lastPcmWriteNs = System.nanoTime()
            val monitor = mediaMetricsMonitor
            if (monitor != null) {
                val nowNs = System.nanoTime()
                val totalFramesWritten = totalBytesWritten / trackBytesPerFrame
                monitor.recordAudioBuffer(
                    totalFramesWritten = totalFramesWritten,
                    playbackHeadFrames = playbackHeadFrames(track),
                    sampleRate = format.sampleRate,
                    nowNs = nowNs,
                    outputLatencyMs = outputLatencyMs(track, totalFramesWritten, nowNs),
                )
            }
            if (!playbackStarted) {
                prebufferBytes += count
                if (prebufferBytes >= startThresholdBytes) {
                    underrunsAtStart = track.underrunCount
                    track.play()
                    playbackStarted = true
                    Log.i(TAG, "audio playback started type=${format.payloadType}")
                }
            }
        }
    }

    private fun maintainPlaybackBuffer() {
        if (mediaTap?.takesAudio() == true) return
        val track = track ?: return
        val buffered = bufferProgress.queuedBytes(track.playbackHeadPosition)
        if (bufferProgress.shouldRebuffer(selectedChannel in setOf(AudioChannel.MEDIA, AudioChannel.NAVIGATION), playbackStarted,
                track.underrunCount > underrunsAtStart, queue.isEmpty(), track.playbackHeadPosition, trackBytesPerFrame.toLong())) {
            track.pause()
            playbackStarted = false
            prebufferBytes = buffered.toInt()
        }
        if (!playbackStarted && queue.isEmpty() && buffered > 0 && lastPcmWriteNs > 0 && System.nanoTime() - lastPcmWriteNs >= 500_000_000L) {
            underrunsAtStart = track.underrunCount
            track.play(); playbackStarted = true
        }
    }

    /** Remote playback silences the local track; returning to it starts over with prebuffering. */
    private fun forwardPcm(data: ByteArray, offset: Int, length: Int) {
        val tap = mediaTap ?: return
        val track = track
        if (track != null && (playbackStarted || prebufferBytes > 0)) {
            try {
                track.pause()
                track.flush()
            } catch (_: Exception) {
                // Best effort.
            }
            playbackStarted = false
            prebufferBytes = 0
            fadeApplied = false
            bufferProgress = AudioBufferProgress(trackBytesPerFrame)
            totalBytesWritten = 0L; playbackHeadWraps = 0L; lastPlaybackHeadRaw = 0L; lastPlaybackHeadFrames = 0L
            lastPcmWriteNs = 0L
            Log.i(TAG, "audio forwarded remotely type=${format.payloadType}")
        }
        tap.onAudioPcm(stream, format.sampleRate, if (format.channels >= 2) 2 else 1, data, offset, length)
    }

    private fun playbackHeadFrames(track: AudioTrack): Long {
        val raw = track.playbackHeadPosition.toLong() and UINT32_MASK
        if (raw < lastPlaybackHeadRaw && lastPlaybackHeadRaw - raw > UINT32_HALF_RANGE) {
            playbackHeadWraps++
        }
        lastPlaybackHeadRaw = raw
        val unwrapped = playbackHeadWraps * UINT32_MODULUS + raw
        lastPlaybackHeadFrames = maxOf(lastPlaybackHeadFrames, unwrapped)
        return lastPlaybackHeadFrames
    }

    private fun outputLatencyMs(
        track: AudioTrack,
        totalFramesWritten: Long,
        nowNs: Long,
    ): Float? {
        if (!playbackStarted) return null
        if (nowNs - lastAudioTimestampQueryNs < AUDIO_TIMESTAMP_INTERVAL_NS) {
            return latestOutputLatencyMs
        }
        lastAudioTimestampQueryNs = nowNs
        if (!track.getTimestamp(audioTimestamp)) {
            latestOutputLatencyMs = null
            return null
        }
        val raw = audioTimestamp.framePosition and UINT32_MASK
        if (raw < lastTimestampHeadRaw && lastTimestampHeadRaw - raw > UINT32_HALF_RANGE) {
            timestampHeadWraps++
        }
        lastTimestampHeadRaw = raw
        val unwrapped = timestampHeadWraps * UINT32_MODULUS + raw
        lastTimestampHeadFrames = maxOf(lastTimestampHeadFrames, unwrapped)
        val elapsedNs = (nowNs - audioTimestamp.nanoTime).coerceAtLeast(0L)
        val elapsedFrames = (elapsedNs.toDouble() * format.sampleRate / NANOS_PER_SECOND).toLong()
        val presentedFrames = minOf(totalFramesWritten, lastTimestampHeadFrames + elapsedFrames)
        return MediaMetricsMonitor.audioLatencyMs(
            totalFramesWritten,
            presentedFrames,
            format.sampleRate,
        ).also { latestOutputLatencyMs = it }
    }

    private fun applyFadeIn(data: ByteArray, offset: Int, length: Int) {
        val samples = (length - length % 2) / 2
        val fadeSamples = minOf(samples, maxOf(1, format.sampleRate / 100))
        for (index in 0 until fadeSamples) {
            val position = offset + index * 2
            val sample = (data[position].toInt() and 0xff) or (data[position + 1].toInt() shl 8)
            val scaled = (sample.toLong() * (index + 1) / fadeSamples).toInt()
            data[position] = scaled.toByte()
            data[position + 1] = (scaled shr 8).toByte()
        }
    }

    private fun byteSwapS16(source: ByteArray): ByteArray {
        for (index in 0 until source.size - 1 step 2) {
            val tmp = source[index]
            source[index] = source[index + 1]
            source[index + 1] = tmp
        }
        return source
    }

    @Synchronized
    private fun release() {
        onClosed()
        val codec = codec
        this.codec = null
        if (codec != null) {
            try {
                codec.stop()
            } catch (_: Exception) {
                // Best effort.
            }
            try {
                codec.release()
            } catch (_: Exception) {
                // Best effort.
            }
        }
        val track = track
        this.track = null
        if (track != null) {
            try {
                track.pause()
            } catch (_: Exception) {
                // Best effort.
            }
            try {
                track.flush()
            } catch (_: Exception) {
                // Best effort.
            }
            try {
                track.release()
            } catch (_: Exception) {
                // Best effort.
            }
        }
    }

    private companion object {
        const val TAG = "xcertplay-usb"
        const val AAC_OBJECT_TYPE_LC = 2
        const val MIN_OPUS_PACKET_BYTES = 4
        const val OPUS_CODEC_DELAY_NANOS = 6_500_000L
        const val OPUS_SEEK_PRE_ROLL_NANOS = 80_000_000L
        const val INPUT_TIMEOUT_US = 10_000L
        const val MAX_QUEUED_PACKETS = 64
        const val MIN_TRACK_BUFFER_BYTES = 16 * 1024
        const val MIN_START_BUFFER_BYTES = 4 * 1024
        const val PREBUFFER_WRITE_CHUNK_BYTES = 2 * 1024
        const val DECODED_BUFFER_LOG_INTERVAL = 50
        const val AUDIO_TIMESTAMP_INTERVAL_NS = 200_000_000L
        const val NANOS_PER_SECOND = 1_000_000_000L
        const val BYTES_PER_PCM_16_SAMPLE = 2
        const val UINT32_MASK = 0xffff_ffffL
        const val UINT32_HALF_RANGE = 0x8000_0000L
        const val UINT32_MODULUS = 0x1_0000_0000L
    }
}
