package com.shilapi.xcertplay.updates

import com.shilapi.xcertplay.api.ApiUrls
import com.shilapi.xcertplay.api.HttpTransport
import com.shilapi.xcertplay.api.ResponseLimitException
import com.shilapi.xcertplay.api.readBytesLimited
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean

object UpdateTransport {
    fun fetch(app: String, publicKey: String, signer: String): UpdateManifest {
        return HttpTransport.withConnection(ApiUrls.updates("/v1/updates/$app/stable"), readTimeoutMillis = 15_000) { connection ->
            connection.setRequestProperty("Accept-Encoding", "identity")
            val status = connection.responseCode
            requirePublishedResponse(status)
            val bytes = try {
                connection.inputStream.use { it.readBytesLimited(UpdateManifestVerifier.MAX_ENVELOPE_BYTES) }
            } catch (_: ResponseLimitException) {
                throw UpdateException("更新信息超出大小限制。")
            }
            UpdateManifestVerifier.verify(String(bytes, Charsets.UTF_8), publicKey, app, signer)
        }
    }

    internal fun requirePublishedResponse(status: Int) {
        if (status == 404) throw UpdateChannelNotPublishedException()
        if (status != 200) throw UpdateException("更新服务器暂不可用（$status），请稍后重试。")
    }

    fun download(manifest: UpdateManifest, directory: File, cancelled: AtomicBoolean, progress: (Long, Long) -> Unit): File {
        require(directory.isDirectory || directory.mkdirs())
        val ready = File(directory, manifest.sha256 + ".apk")
        if (ready.isFile && matchesFile(ready, manifest)) return ready
        val partial = File(directory, manifest.sha256 + ".apk.part")
        try {
            HttpTransport.withConnection(ApiUrls.updates(manifest.downloadPath), readTimeoutMillis = 15_000) { connection ->
                connection.setRequestProperty("Accept-Encoding", "identity")
                val status = connection.responseCode
                if (status != 200) throw UpdateException("更新包下载未完成（$status），请重试。")
                val encoding = connection.getHeaderField("Content-Encoding")
                if (encoding != null && !encoding.equals("identity", true)) throw UpdateException("更新包传输格式无效。")
                val length = connection.contentLengthLong
                if (length >= 0 && length != manifest.sizeBytes) throw UpdateException("更新包大小不匹配。")
                connection.inputStream.use { input ->
                    FileOutputStream(partial).use { output ->
                        copyVerified(input, output, manifest, cancelled, progress)
                        output.fd.sync()
                    }
                }
            }
            if (cancelled.get()) throw UpdateException("下载已取消。")
            if (ready.exists() && !ready.delete()) throw UpdateException("无法替换本地更新包。")
            if (!partial.renameTo(ready)) throw UpdateException("无法保存更新包。")
            return ready
        } finally {
            partial.delete()
        }
    }

    internal fun copyVerified(input: java.io.InputStream, output: java.io.OutputStream, manifest: UpdateManifest,
        cancelled: AtomicBoolean, progress: (Long, Long) -> Unit) {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(64 * 1024)
        var count = 0L
        while (true) {
            if (cancelled.get()) throw UpdateException("下载已取消。")
            val bytesRead = input.read(buffer)
            if (bytesRead < 0) break
            count += bytesRead
            if (count > manifest.sizeBytes || count > UpdateManifestVerifier.MAX_APK_BYTES) throw UpdateException("更新包超出大小限制。")
            digest.update(buffer, 0, bytesRead)
            output.write(buffer, 0, bytesRead)
            progress(count, manifest.sizeBytes)
        }
        if (count != manifest.sizeBytes || hex(digest.digest()) != manifest.sha256) throw UpdateException("更新包完整性校验失败。")
    }

    fun matchesFile(file: File, manifest: UpdateManifest): Boolean {
        if (!file.isFile || file.length() != manifest.sizeBytes) return false
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return hex(digest.digest()) == manifest.sha256
    }

    private fun hex(bytes: ByteArray) = bytes.joinToString("") { "%02x".format(it.toInt() and 255) }
}
