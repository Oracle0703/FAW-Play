package com.shilapi.xcertplay.media

import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import java.util.Collections
import java.util.IdentityHashMap

/** Focus follows the HS5's actual output channels; it never controls iPhone playback. */
internal class Hs5AudioFocusCoordinator(
    private val manager: AudioManager,
    private val handler: Handler = Handler(Looper.getMainLooper()),
) {
    private data class Stream(val owner: Any, var channel: AudioChannel? = null)
    private class FocusState {
        var channel: AudioChannel? = null
        var request: AudioFocusRequest? = null
        var result = AudioManager.AUDIOFOCUS_REQUEST_FAILED
        var hasFocus = false
        var lost = false
        var failures = 0
        var retryAt = 0L
        var generation = 0L
    }

    private val owners = Collections.newSetFromMap(IdentityHashMap<Any, Boolean>())
    private val streams = IdentityHashMap<Any, Stream>()
    private val media = FocusState()
    private val transient = FocusState()
    private var hostSelected = false
    private val retry = Runnable {
        synchronized(this) {
            var mediaRetried = false
            for (state in listOf(media, transient)) {
                if (state.request != null && state.result == AudioManager.AUDIOFOCUS_REQUEST_FAILED &&
                    !state.lost && SystemClock.uptimeMillis() >= state.retryAt
                ) {
                    request(state)
                    if (state === media) mediaRetried = true
                }
            }
            // A newly granted media request must remain underneath an active call/guide.
            if (mediaRetried && media.result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED && transient.request != null)
                request(transient)
            scheduleRetry()
        }
    }

    @Synchronized fun retain(owner: Any) { owners.add(owner) }

    @Synchronized fun requestFromHost() {
        if (owners.isEmpty()) return
        hostSelected = true
        reconcile(forceMedia = true)
    }

    /** Register before the renderer starts, so a late shutdown callback cannot own a new stream. */
    @Synchronized fun streamCreated(owner: Any, stream: Any) {
        if (owners.contains(owner)) streams.putIfAbsent(stream, Stream(owner))
    }

    @Synchronized fun updateChannel(stream: Any, channel: AudioChannel) {
        val entry = streams[stream] ?: return
        if (entry.channel == channel) return
        entry.channel = channel
        reconcile()
    }

    @Synchronized fun streamEnded(stream: Any) {
        if (streams.remove(stream) != null) reconcile()
    }

    @Synchronized fun release(owner: Any) {
        owners.remove(owner)
        streams.entries.removeAll { it.value.owner === owner }
        if (owners.isEmpty()) hostSelected = false
        reconcile()
    }

    private fun reconcile(forceMedia: Boolean = false) {
        val channels = streams.values.mapNotNull { it.channel }
        // Keep media underneath temporary call/navigation focus, so Android can return it.
        val mediaChannel = AudioChannel.MEDIA.takeIf {
            owners.isNotEmpty() && (hostSelected || AudioChannel.MEDIA in channels)
        }
        val transientChannel = channels.filter { it != AudioChannel.MEDIA }.maxByOrNull {
            when (it) {
                AudioChannel.PHONE -> 3
                AudioChannel.ASSISTANT -> 2
                AudioChannel.NAVIGATION -> 1
                AudioChannel.MEDIA -> 0
            }
        }
        val mediaRequested = refresh(media, mediaChannel, forceMedia && transientChannel == null && !media.hasFocus)
        refresh(transient, transientChannel, force = mediaRequested && transientChannel != null)
        scheduleRetry()
    }

    private fun refresh(state: FocusState, channel: AudioChannel?, force: Boolean = false): Boolean {
        if (channel == null) { abandon(state); return false }
        if (state.channel == channel && state.request != null) {
            if (force) request(state)
            return force
        }
        abandon(state)
        state.channel = channel
        val generation = state.generation
        val gain = when (channel) {
            AudioChannel.MEDIA -> AudioManager.AUDIOFOCUS_GAIN
            AudioChannel.PHONE -> AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
            AudioChannel.ASSISTANT, AudioChannel.NAVIGATION -> AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
        }
        val usage = when (channel) {
            AudioChannel.MEDIA -> AudioAttributes.USAGE_MEDIA
            AudioChannel.PHONE -> AudioAttributes.USAGE_VOICE_COMMUNICATION
            AudioChannel.ASSISTANT -> AudioAttributes.USAGE_ASSISTANT
            AudioChannel.NAVIGATION -> AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE
        }
        state.request = AudioFocusRequest.Builder(gain)
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(usage)
                .setContentType(if (channel == AudioChannel.MEDIA) AudioAttributes.CONTENT_TYPE_MUSIC else AudioAttributes.CONTENT_TYPE_SPEECH)
                .build())
            .setAcceptsDelayedFocusGain(channel == AudioChannel.MEDIA)
            // Let Android/OEM apply ducking. A second application gain curve would double it.
            .setWillPauseWhenDucked(false)
            .setOnAudioFocusChangeListener({ change ->
                synchronized(this) {
                    if (generation != state.generation || state.request == null) return@synchronized
                    state.hasFocus = change == AudioManager.AUDIOFOCUS_GAIN
                    when (change) {
                        AudioManager.AUDIOFOCUS_GAIN -> {
                            state.result = AudioManager.AUDIOFOCUS_REQUEST_GRANTED
                            state.lost = false
                        }
                        AudioManager.AUDIOFOCUS_LOSS,
                        AudioManager.AUDIOFOCUS_LOSS_TRANSIENT,
                        AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> state.lost = true
                    }
                    // Only initial failures retry. A granted request losing focus must
                    // wait for the platform or an explicit host action, never fight it.
                    scheduleRetry()
                    Log.i(TAG, "audio focus change=$change channel=$channel")
                }
            }, handler)
            .build()
        request(state)
        return true
    }

    private fun request(state: FocusState) {
        val request = state.request ?: return
        state.result = try {
            manager.requestAudioFocus(request)
        } catch (error: RuntimeException) {
            Log.w(TAG, "audio focus unavailable ${error.javaClass.simpleName}")
            AudioManager.AUDIOFOCUS_REQUEST_FAILED
        }
        state.hasFocus = state.result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        state.lost = false
        if (state.result == AudioManager.AUDIOFOCUS_REQUEST_FAILED) {
            state.retryAt = SystemClock.uptimeMillis() + RETRY_DELAYS[state.failures.coerceAtMost(RETRY_DELAYS.lastIndex)]
            state.failures++
        } else {
            state.failures = 0
            state.retryAt = 0
        }
        Log.i(TAG, "audio focus requested channel=${state.channel} result=${state.result}")
    }

    private fun scheduleRetry() {
        handler.removeCallbacks(retry)
        listOf(media, transient).filter {
            it.request != null && it.result == AudioManager.AUDIOFOCUS_REQUEST_FAILED && !it.lost
        }.minOfOrNull { it.retryAt }?.let { deadline ->
            handler.postDelayed(retry, (deadline - SystemClock.uptimeMillis()).coerceAtLeast(1))
        }
    }

    private fun abandon(state: FocusState) {
        state.generation++
        state.request?.let { request ->
            try { manager.abandonAudioFocusRequest(request) }
            catch (error: RuntimeException) { Log.w(TAG, "audio focus release unavailable ${error.javaClass.simpleName}") }
        }
        state.request = null
        state.channel = null
        state.result = AudioManager.AUDIOFOCUS_REQUEST_FAILED
        state.hasFocus = false
        state.lost = false
        state.failures = 0
        state.retryAt = 0
    }

    private companion object {
        const val TAG = "FAW-AudioFocus"
        val RETRY_DELAYS = longArrayOf(1_000, 2_000, 5_000, 15_000, 30_000)
    }
}
