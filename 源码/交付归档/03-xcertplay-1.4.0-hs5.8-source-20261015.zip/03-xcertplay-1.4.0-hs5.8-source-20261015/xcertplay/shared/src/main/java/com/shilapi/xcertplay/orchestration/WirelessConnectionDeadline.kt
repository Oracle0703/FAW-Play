package com.shilapi.xcertplay.orchestration

/** Application recovery budgets, not timings mandated by Apple's private accessory spec. */
enum class WirelessConnectionStage(val label: String, val timeoutMillis: Long, val radioRecovery: Boolean = false) {
    WAITING_FOR_PAIR("等待手机蓝牙配对", 120_000),
    HOTSPOT("建立无线网络", 20_000, true),
    BLUETOOTH("连接手机蓝牙", 20_000),
    IDENTIFICATION("识别手机", 20_000),
    AUTHENTICATION("验证附件身份", 20_000),
    PHONE_WIFI("等待手机加入 Wi-Fi", 25_000, true),
    PAIRING("建立安全配对", 30_000),
    SESSION("启动 CarPlay 音视频", 20_000),
    CONNECTED("CarPlay 已连接", 0),
}

/** Monotonic, generation-bound deadlines. Repeated messages never renew the current budget. */
internal class WirelessConnectionDeadline(private val totalTimeoutMillis: Long = 90_000) {
    data class Expired(val stage: WirelessConnectionStage, val elapsedMillis: Long, val totalBudget: Boolean)
    private var generation = -1
    private var startedAt = 0L
    private var stageStartedAt = 0L
    private var stage = WirelessConnectionStage.WAITING_FOR_PAIR
    private var finished = true

    @Synchronized fun start(owner: Int, now: Long) {
        generation = owner
        startedAt = now
        stageStartedAt = now
        stage = WirelessConnectionStage.WAITING_FOR_PAIR
        finished = false
    }

    @Synchronized fun advance(owner: Int, next: WirelessConnectionStage, now: Long): Boolean {
        if (owner != generation || finished || next.ordinal <= stage.ordinal) return false
        if (remainingMillis(owner, now) <= 0) return false
        // User preparation has its own budget; the 90-second protocol budget begins with Wi-Fi.
        if (stage == WirelessConnectionStage.WAITING_FOR_PAIR) startedAt = now
        stage = next
        stageStartedAt = now
        if (next == WirelessConnectionStage.CONNECTED) finished = true
        return true
    }

    @Synchronized fun current(owner: Int): WirelessConnectionStage? =
        if (generation == owner && !finished) stage else null

    @Synchronized fun remainingMillis(owner: Int, now: Long): Long {
        if (generation != owner || finished) return 0
        val stageRemaining = stage.timeoutMillis - (now - stageStartedAt)
        return if (stage == WirelessConnectionStage.WAITING_FOR_PAIR) stageRemaining.coerceAtLeast(0)
        else minOf(stageRemaining, totalTimeoutMillis - (now - startedAt)).coerceAtLeast(0)
    }

    @Synchronized fun expire(owner: Int, now: Long): Expired? {
        if (owner != generation || finished) return null
        val total = now - startedAt
        val stageElapsed = now - stageStartedAt
        val totalExpired = stage != WirelessConnectionStage.WAITING_FOR_PAIR && total >= totalTimeoutMillis
        if (!totalExpired && stageElapsed < stage.timeoutMillis) return null
        finished = true
        return Expired(stage, stageElapsed.coerceAtLeast(0), totalExpired)
    }

    @Synchronized fun stop() { finished = true }
}
