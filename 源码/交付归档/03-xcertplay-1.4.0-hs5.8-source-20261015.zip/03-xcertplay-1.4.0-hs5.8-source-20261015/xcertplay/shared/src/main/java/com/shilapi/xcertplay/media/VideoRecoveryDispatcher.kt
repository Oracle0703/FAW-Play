package com.shilapi.xcertplay.media

import java.io.Closeable
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** At most one refresh write is pending or active; the decoder never waits for its socket. */
internal class VideoRecoveryDispatcher : Closeable {
    private val closed = AtomicBoolean(false)
    private val pending = AtomicBoolean(false)
    private val executor = ThreadPoolExecutor(1, 1, 0, TimeUnit.MILLISECONDS,
        ArrayBlockingQueue(1), { task ->
            Thread(task, "carplay-video-recovery").apply { isDaemon = true }
        })

    fun request(isCurrent: () -> Boolean, send: () -> Boolean, completed: (Boolean) -> Unit = {}): Boolean {
        if (closed.get() || !isCurrent() || !pending.compareAndSet(false, true)) return false
        try {
            executor.execute {
                try {
                    val sent = runCatching { !closed.get() && isCurrent() && send() }.getOrDefault(false)
                    runCatching { completed(sent) }
                } finally { pending.set(false) }
            }
        } catch (_: RejectedExecutionException) {
            pending.set(false)
            return false
        }
        return true
    }

    override fun close() {
        if (closed.compareAndSet(false, true)) executor.shutdownNow()
    }
}
