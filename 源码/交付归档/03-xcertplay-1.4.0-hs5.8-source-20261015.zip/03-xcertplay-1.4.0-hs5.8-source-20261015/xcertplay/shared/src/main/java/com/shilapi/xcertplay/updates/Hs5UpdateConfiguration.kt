package com.shilapi.xcertplay.updates

import com.shilapi.xcertplay.api.ApiUrls
import com.shilapi.xcertplay.licensing.LicenseVerifier
import com.shilapi.xcertplay.shared.BuildConfig

/** Update trust and availability do not depend on purchasing an enhancement entitlement. */
object Hs5UpdateConfiguration {
    fun problem(): String? = validate(BuildConfig.HS5_UPDATE_SERVER_URL,
        BuildConfig.HS5_UPDATE_PUBLIC_KEY_SPKI, BuildConfig.HS5_UPDATE_SIGNING_CERT_SHA256)

    internal fun validate(server: String, publicKey: String, signer: String): String? {
        if (server.isBlank() || publicKey.isBlank() || !signer.matches(Regex("[0-9a-f]{64}"))) {
            return "此安装包尚未配置 HS5 专用更新渠道，请联系提供方。"
        }
        return try {
            ApiUrls.validateConfiguredUrl(server)
            LicenseVerifier.trustedPublicKey(publicKey)
            null
        } catch (_: Exception) {
            "HS5 更新渠道配置无效，请联系提供方。"
        }
    }
}
