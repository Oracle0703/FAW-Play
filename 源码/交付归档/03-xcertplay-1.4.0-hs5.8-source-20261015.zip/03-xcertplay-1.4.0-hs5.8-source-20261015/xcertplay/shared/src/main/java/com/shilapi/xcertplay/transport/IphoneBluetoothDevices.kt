package com.shilapi.xcertplay.transport

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import java.util.UUID

/** iAP2's phone service identifies renamed iPhones without a Bluetooth vendor-address list. */
object IphoneBluetoothDevices {
    const val IAP2_SERVICE_UUID = "00000000-deca-fade-deca-deafdecacafe"
    private val service = UUID.fromString(IAP2_SERVICE_UUID)

    @JvmStatic
    fun bonded(adapter: BluetoothAdapter): List<BluetoothDevice> =
        try { adapter.bondedDevices.orEmpty().filter(::isIphone) } catch (_: SecurityException) { emptyList() }

    @JvmStatic
    fun isIphone(device: BluetoothDevice): Boolean = try {
        matches(device.name, device.bluetoothClass?.majorDeviceClass,
            device.uuids?.mapTo(mutableSetOf()) { it.uuid })
    } catch (_: SecurityException) { false } catch (_: RuntimeException) { false }

    internal fun matches(name: String?, majorClass: Int?, services: Set<UUID>?): Boolean {
        if (!phoneClass(majorClass)) return false
        return services?.contains(service) == true
    }

    @JvmStatic
    fun isConnectionCandidate(device: BluetoothDevice): Boolean = try {
        connectionCandidate(device.name, device.bluetoothClass?.majorDeviceClass,
            device.uuids?.mapTo(mutableSetOf()) { it.uuid })
    } catch (_: SecurityException) { false } catch (_: RuntimeException) { false }

    // getUuids() is only a cache. A missing UUID (or a renamed phone) must not prevent
    // connecting to the iAP2 UUID: BluetoothSocket.connect() performs its own SDP lookup.
    // Candidates are probes, not confirmed iPhones; unrelated phones simply fail that lookup.
    internal fun connectionCandidate(name: String?, majorClass: Int?, services: Set<UUID>?): Boolean =
        services?.contains(service) == true || phoneClass(majorClass) ||
            (majorClass == BluetoothClass.Device.Major.COMPUTER &&
                (services.isNullOrEmpty() && !looksLikeAccessoryName(name) || looksLikeApplePhoneName(name)))

    @JvmStatic
    fun needsIdentification(device: BluetoothDevice): Boolean = try {
        phoneClass(device.bluetoothClass?.majorDeviceClass) &&
            device.uuids?.any { it.uuid == service } != true
    } catch (_: SecurityException) { false } catch (_: RuntimeException) { false }

    private fun phoneClass(value: Int?): Boolean =
        value == null || value == 0 || value == BluetoothClass.Device.Major.UNCATEGORIZED ||
            value == BluetoothClass.Device.Major.PHONE

    /**
     * Some Android Bluetooth stacks classify an iPhone as COMPUTER and expose no cached UUIDs.
     * This only adds a bounded RFCOMM probe; SDP/iAP2 still decides whether the device is usable.
     * Keep accessory names such as "iPhone speaker" out of this fallback.
     */
    private fun looksLikeApplePhoneName(name: String?): Boolean {
        val normalized = name?.trim()?.lowercase() ?: return false
        if (normalized.isEmpty() || looksLikeAccessoryName(normalized)) return false
        return normalized.contains("iphone") || normalized.contains("ipad") ||
            normalized.contains("苹果")
    }

    private fun looksLikeAccessoryName(name: String?): Boolean {
        val normalized = name?.trim()?.lowercase() ?: return false
        return normalized.contains("speaker") || normalized.contains("耳机") ||
            normalized.contains("headset")
    }
}
