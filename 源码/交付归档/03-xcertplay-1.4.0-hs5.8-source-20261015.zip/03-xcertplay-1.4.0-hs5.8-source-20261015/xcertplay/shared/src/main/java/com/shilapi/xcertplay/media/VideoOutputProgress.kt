package com.shilapi.xcertplay.media

/** One refresh probe per playback episode for accepted input that has not reached output. */
internal class VideoOutputProgress {
    private var queuedPtsUs = Long.MIN_VALUE
    private var outputPtsUs = Long.MIN_VALUE
    private var lastProgressNs = 0L
    private var probed = false
    private var resumedInputStartNs = Long.MIN_VALUE
    private var previousInputNs = Long.MIN_VALUE

    fun reset() {
        queuedPtsUs = Long.MIN_VALUE
        outputPtsUs = Long.MIN_VALUE
        lastProgressNs = 0L
        probed = false
        clearInputRun()
    }

    /**
     * Start a new user interaction or independently identified playback episode.
     * A short multi-frame refresh reply must not be mistaken for a new playback episode.
     * Keep the pending pictures and codec reference frames intact.
     */
    fun beginEpisode(nowNs: Long) {
        probed = false
        lastProgressNs = nowNs
        clearInputRun()
    }

    fun onInput(ptsUs: Long, nowNs: Long) {
        if (probed) {
            // Autonomous animation can resume without a touch. Require sustained traffic,
            // rather than the few closely spaced pictures returned by our refresh request.
            if (resumedInputStartNs == Long.MIN_VALUE ||
                nowNs - previousInputNs !in 0..MAX_INPUT_GAP_NS
            ) {
                resumedInputStartNs = nowNs
            } else if (nowNs - resumedInputStartNs >= REARM_INPUT_DURATION_NS) {
                beginEpisode(nowNs)
            }
            previousInputNs = nowNs
        }
        queuedPtsUs = maxOf(queuedPtsUs, ptsUs)
        lastProgressNs = nowNs
    }

    fun onOutput(ptsUs: Long, nowNs: Long) {
        outputPtsUs = maxOf(outputPtsUs, ptsUs)
        lastProgressNs = nowNs
    }

    fun ageNanos(nowNs: Long): Long = (nowNs - lastProgressNs).coerceAtLeast(0L)

    fun shouldProbe(nowNs: Long): Boolean =
        queuedPtsUs > outputPtsUs && !probed && ageNanos(nowNs) >= STALL_DURATION_NS

    /** Consume the episode's probe once it has been accepted for scheduling. */
    fun probeScheduled() {
        probed = true
        clearInputRun()
    }

    private fun clearInputRun() {
        resumedInputStartNs = Long.MIN_VALUE
        previousInputNs = Long.MIN_VALUE
    }

    private companion object {
        const val STALL_DURATION_NS = 500_000_000L
        const val REARM_INPUT_DURATION_NS = 500_000_000L
        const val MAX_INPUT_GAP_NS = 120_000_000L
    }
}
