package com.shilapi.xcertplay.network

import android.os.Build
import android.os.ParcelFileDescriptor
import android.system.Os
import android.system.OsConstants
import java.io.FileDescriptor
import java.net.Socket

/** Probe the TCP peer instead of interpreting an idle CarPlay screen as a disconnect. */
internal object TcpLiveness {
    // Linux UAPI <linux/tcp.h>; these options are omitted from Android's public OsConstants.
    private const val TCP_KEEPIDLE = 4
    private const val TCP_KEEPINTVL = 5
    private const val TCP_KEEPCNT = 6

    fun configure(socket: Socket, diagnostic: (String) -> Unit) {
        try {
            socket.keepAlive = true
            if (Build.VERSION.SDK_INT >= 29) {
                // Android 10+ duplicates the socket descriptor; this wrapper owns only its copy.
                ParcelFileDescriptor.fromSocket(socket).use { duplicate ->
                    configureOptions(
                        set = { option, value ->
                            Os.setsockoptInt(duplicate.fileDescriptor, OsConstants.IPPROTO_TCP, option, value)
                        },
                        diagnostic = diagnostic,
                    )
                }
            } else {
                // Android 9's fromSocket shares the live descriptor. Borrow it and duplicate
                // explicitly, so closing our copy cannot close or invalidate the session socket.
                val borrowed = Socket::class.java.getMethod("getFileDescriptor$").invoke(socket) as FileDescriptor
                val duplicate = Os.dup(borrowed)
                try {
                    configureOptions(
                        set = { option, value ->
                            Os.setsockoptInt(duplicate, OsConstants.IPPROTO_TCP, option, value)
                        },
                        diagnostic = diagnostic,
                    )
                } finally {
                    Os.close(duplicate)
                }
            }
        } catch (failure: Exception) {
            // Firmware may restrict descriptor access or individual options. Keep default TCP
            // keepalive as a fallback; never turn a tuning failure into a session failure.
            diagnostic("TCP peer detection tuning unavailable: ${failure.javaClass.simpleName}")
        }
    }

    /** Each unsupported option falls back independently to the kernel default. */
    internal fun configureOptions(set: (Int, Int) -> Unit, diagnostic: (String) -> Unit) {
        val options = listOf(
            Triple("idleSeconds", TCP_KEEPIDLE, 2),
            Triple("intervalSeconds", TCP_KEEPINTVL, 1),
            Triple("probeCount", TCP_KEEPCNT, 3),
            Triple("userTimeoutMillis", OsConstants.TCP_USER_TIMEOUT, 5_000),
        )
        var applied = 0
        for ((name, option, value) in options) {
            try {
                set(option, value)
                applied++
            } catch (failure: Exception) {
                diagnostic("TCP peer detection $name unavailable: ${failure.javaClass.simpleName}")
            }
        }
        diagnostic("TCP peer detection appliedOptions=$applied/${options.size} (setsockopt accepted; no readback)")
    }
}
