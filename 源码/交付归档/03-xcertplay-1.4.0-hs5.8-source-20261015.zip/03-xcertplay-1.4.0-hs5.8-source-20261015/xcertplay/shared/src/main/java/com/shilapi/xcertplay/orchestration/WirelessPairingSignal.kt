package com.shilapi.xcertplay.orchestration

import java.io.Closeable
import java.util.concurrent.TimeUnit

/** A broadcast wakes the worker; a revision prevents an event during device reads being lost. */
internal class WirelessPairingSignal : Closeable {
    private val monitor = Object()
    private var revision = 0L
    private val deviceRevisions = mutableMapOf<String, Long>()
    private var closed = false

    fun revision(): Long = synchronized(monitor) { revision }
    fun signal(deviceAddress: String? = null) = synchronized(monitor) {
        revision++
        if (!deviceAddress.isNullOrBlank()) deviceRevisions[deviceAddress] = revision
        monitor.notifyAll()
    }
    fun deviceRevision(address: String): Long = synchronized(monitor) { deviceRevisions[address] ?: 0 }
    fun awaitChange(observedRevision: Long, timeoutMillis: Long): Boolean = synchronized(monitor) {
        val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMillis.coerceAtLeast(0))
        while (!closed && revision == observedRevision) {
            val remaining = deadline - System.nanoTime()
            if (remaining <= 0) return@synchronized false
            TimeUnit.NANOSECONDS.timedWait(monitor, remaining)
        }
        !closed && revision != observedRevision
    }
    override fun close() = synchronized(monitor) { closed = true; monitor.notifyAll() }
}
