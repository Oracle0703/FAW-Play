package com.shilapi.xcertplay.network

import android.content.Context
import android.net.wifi.p2p.WifiP2pGroup
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Handler
import android.provider.Settings
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import com.shilapi.xcertplay.transport.Iap2WirelessSecurity
import java.io.IOException
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.SocketException
import java.net.UnknownHostException
import java.util.Collections
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * API 28 HS5 adapter: creates a system-configured Wi-Fi Direct owner for legacy AP clients.
 *
 * The group is deliberately not persistent. [close] removes it and releases the callback thread.
 */
class HongqiWifiP2pGroupManager(
    context: Context,
    private val diagnostic: (String) -> Unit = {},
    private val radioSelection: WirelessRadioSelection = WirelessRadioSelection.System5Ghz,
) : WirelessHotspotManager {
    private val appContext = context.applicationContext
    private val p2pManager = appContext.getSystemService(WifiP2pManager::class.java)
        ?: throw IllegalStateException("WifiP2pManager is unavailable")
    private val stateLock = Object()

    private val ownership = appContext.getSharedPreferences("hs5_p2p_ownership", Context.MODE_PRIVATE)
    private val ownerToken = java.util.UUID.randomUUID().toString()
    private val scopedId = Settings.Secure.getString(appContext.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
    private val ssidPrefix = P2pOwnership.prefix(appContext.packageName, scopedId)
    @Volatile private var observedName: String? = null
    private var channel: WifiP2pManager.Channel? = null
    private var callbackThread: HandlerThread? = null
    private var created = false
    private var closed = false
    private var startAttempt: StartAttempt? = null
    private var groupLossMonitor: P2pGroupLossMonitor? = null
    @Volatile private var onUnexpectedStopped: (() -> Unit)? = null
    @Volatile private var onPeerDisconnected: ((String) -> Unit)? = null
    private var activePeerMac: String? = null

    override fun setOnUnexpectedStopped(listener: (() -> Unit)?) {
        onUnexpectedStopped = listener
    }

    override fun setOnPeerDisconnected(listener: ((String) -> Unit)?) {
        onPeerDisconnected = listener
    }

    override fun setActivePeer(wifiMac: String?) {
        val monitor = synchronized(stateLock) {
            if (closed) return
            activePeerMac = wifiMac
            groupLossMonitor
        }
        monitor?.setActivePeer(wifiMac)
    }

    override fun queryHasAssociatedClients(callback: (Boolean?) -> Unit) {
        val activeChannel = synchronized(stateLock) {
            if (closed || !created || startAttempt != null) null else channel
        }
        if (activeChannel == null) {
            callback(null)
            return
        }
        val completed = AtomicBoolean(false)
        fun complete(value: Boolean?) {
            if (completed.compareAndSet(false, true)) callback(value)
        }
        try {
            p2pManager.requestGroupInfo(activeChannel) { group ->
                val associated = try {
                    synchronized(stateLock) {
                        synchronized(OWNERSHIP_LOCK) {
                            when {
                                closed || !created || startAttempt != null || channel !== activeChannel -> null
                                ownership.getString("owner_token", null) != ownerToken -> null
                                group == null -> false
                                !group.isGroupOwner || observedName == null || group.networkName != observedName -> null
                                else -> group.clientList.isNotEmpty()
                            }
                        }
                    }
                } catch (_: Exception) {
                    null
                }
                complete(associated)
            }
        } catch (_: SecurityException) {
            complete(null)
        } catch (_: Exception) {
            complete(null)
        }
    }

    override fun start(timeoutMillis: Long): WirelessHotspotInfo {
        check(Build.VERSION.SDK_INT == Build.VERSION_CODES.P) { "HS5 legacy P2P adapter requires API 28" }
        check(Looper.myLooper() != Looper.getMainLooper()) {
            "WifiP2pGroupManager.start must not run on the main thread"
        }
        require(timeoutMillis > 0) { "timeoutMillis must be positive" }

        val attempt = StartAttempt()
        synchronized(stateLock) {
            check(!closed) { "WifiP2pGroupManager is closed" }
            check(startAttempt == null && !created) {
                "A Wi-Fi P2P group is already starting or active"
            }
            startAttempt = attempt
        }

        val thread = HandlerThread("xcertplay-wifi-p2p").apply { start() }
        attempt.thread = thread
        val deadlineNanos = deadlineAfter(timeoutMillis)

        try {
            val p2pChannel = p2pManager.initialize(
                appContext,
                thread.looper,
                createChannelListener(attempt),
            )
            attempt.channel = p2pChannel
            synchronized(stateLock) {
                ensureStartActiveLocked(attempt)
                channel = p2pChannel
                callbackThread = thread
            }

            val existing = requestGroupInfo(attempt, p2pChannel, minOf(remainingNanos(deadlineNanos), REQUEST_POLL_NANOS))
            if (existing != null) {
                if (!P2pOwnership.canReclaim(existing.isGroupOwner, existing.networkName,
                        ownership.getString("owned_ssid", null), ssidPrefix)) throw P2pResetRequiredException()
                observedName = existing.networkName
                claimOwnership()
                removeGroupBlocking(p2pChannel)
                while (requestGroupInfo(attempt, p2pChannel, minOf(remainingNanos(deadlineNanos), REQUEST_POLL_NANOS)) != null) {
                    if (remainingNanos(deadlineNanos) == 0L) throw IOException("Owned P2P group could not be removed")
                    synchronized(stateLock) { waitNanos(100_000_000L) }
                }
            }
            claimOwnership()
            setDeviceName(attempt, p2pChannel, deadlineNanos)
            // API 28 has no public band/frequency createGroup API. Never report a request as applied.
            diagnostic("HS5 P2P radio selection: no_public_frequency_control")
            if (radioSelection is WirelessRadioSelection.Frequency) {
                diagnostic("HS5 P2P explicit frequency request ignored; system selection retained")
            }
            ensureStartActive(attempt)
            attempt.createIssued = true
            p2pManager.createGroup(p2pChannel, createActionListener(attempt))
            awaitGroupCreated(attempt, deadlineNanos, timeoutMillis)

            val group = awaitUsableGroup(
                attempt = attempt,
                channel = p2pChannel,
                deadlineNanos = deadlineNanos,
                timeoutMillis = timeoutMillis,
            )
            synchronized(stateLock) {
                ensureStartActiveLocked(attempt)
                created = true
                startAttempt = null
                groupLossMonitor = P2pGroupLossMonitor(appContext, p2pManager, p2pChannel,
                    onGroupLost = {
                        val listener = synchronized(stateLock) {
                            if (!closed && created) onUnexpectedStopped else null
                        }
                        listener?.invoke()
                    },
                    onPeerDisconnected = { mac ->
                        val listener = synchronized(stateLock) {
                            if (!closed && created) onPeerDisconnected else null
                        }
                        listener?.invoke(mac)
                    },
                ).also { it.setActivePeer(activePeerMac); it.start() }
            }
            return group
        } catch (failure: SecurityException) {
            cleanupFailedStart(attempt)
            throw IOException("Wi-Fi startup permission unavailable", failure)
        } catch (failure: Exception) {
            cleanupFailedStart(attempt)
            throw failure
        }
    }

    override fun close() {
        val attempt: StartAttempt?
        val activeChannel: WifiP2pManager.Channel?
        val activeThread: HandlerThread?
        val removeGroup: Boolean
        synchronized(stateLock) {
            if (closed) return
            closed = true
            onUnexpectedStopped = null
            onPeerDisconnected = null
            activePeerMac = null
            groupLossMonitor?.close()
            groupLossMonitor = null
            attempt = startAttempt
            attempt?.stopped = true
            stateLock.notifyAll()
            activeChannel = channel ?: attempt?.channel
            activeThread = callbackThread ?: attempt?.thread
            removeGroup = created || attempt?.createSucceeded == true
            channel = null
            callbackThread = null
            startAttempt = null
        }

        if (removeGroup && activeChannel != null) {
            removeGroupBlocking(activeChannel)
        }
        releaseCallbackThread(attempt, activeThread)
    }

    private fun createChannelListener(
        attempt: StartAttempt,
    ): WifiP2pManager.ChannelListener = object : WifiP2pManager.ChannelListener {
        override fun onChannelDisconnected() {
            failAttempt(attempt, IOException("Wi-Fi P2P channel disconnected"))
        }
    }

    private fun createActionListener(
        attempt: StartAttempt,
    ): WifiP2pManager.ActionListener = object : WifiP2pManager.ActionListener {
        override fun onSuccess() {
            val activeChannel = attempt.channel
            val removeDetachedGroup = synchronized(stateLock) {
                attempt.createSucceeded = true
                attempt.createFinished = true
                if (!closed && startAttempt === attempt) created = true
                if (startAttempt === attempt && !attempt.stopped && !closed) {
                    stateLock.notifyAll()
                    false
                } else {
                    true
                }
            }
            if (removeDetachedGroup && activeChannel != null) {
                removeGroup(activeChannel, waitForCallback = false)
                attempt.thread?.let { thread -> Handler(thread.looper).postDelayed({ thread.quitSafely() }, REMOVE_GROUP_TIMEOUT_MILLIS) }
            }
        }

        override fun onFailure(reason: Int) {
            attempt.createFinished = true
            failAttempt(
                attempt,
                WifiP2pGroupCreationException(reason, "Wi-Fi P2P createGroup failed: ${failureReason(reason)}"),
            )
            if (attempt.stopped || closed) attempt.thread?.quitSafely()
        }
    }

    private fun failAttempt(attempt: StartAttempt, failure: IOException) {
        synchronized(stateLock) {
            if (startAttempt === attempt && !attempt.stopped && !closed) {
                if (attempt.failure == null) attempt.failure = failure
                stateLock.notifyAll()
            }
        }
    }

    private fun awaitGroupCreated(
        attempt: StartAttempt,
        deadlineNanos: Long,
        timeoutMillis: Long,
    ) {
        synchronized(stateLock) {
            while (true) {
                ensureStartActiveLocked(attempt)
                attempt.failure?.let { throw it }
                if (attempt.createSucceeded) return

                val remainingNanos = remainingNanos(deadlineNanos)
                if (remainingNanos <= 0) {
                    throw IOException(
                        "Timed out after ${timeoutMillis}ms waiting for Wi-Fi P2P group creation",
                    )
                }
                waitNanos(remainingNanos)
            }
        }
    }

    private fun awaitUsableGroup(
        attempt: StartAttempt,
        channel: WifiP2pManager.Channel,
        deadlineNanos: Long,
        timeoutMillis: Long,
    ): WirelessHotspotInfo {
        var lastReason = "group information was not available"
        while (true) {
            ensureStartActive(attempt)
            val remainingNanos = remainingNanos(deadlineNanos)
            if (remainingNanos <= 0) {
                throw IOException(
                    "Timed out after ${timeoutMillis}ms waiting for a usable Wi-Fi P2P group: " +
                        lastReason,
                )
            }

            val group = requestGroupInfo(
                attempt = attempt,
                channel = channel,
                timeoutNanos = minOf(remainingNanos, REQUEST_POLL_NANOS),
            )
            if (group == null) continue
            if (!group.isGroupOwner) {
                throw IOException("Wi-Fi P2P device became a group client instead of owner")
            }

            val networkName = group.networkName?.takeIf { it.isNotBlank() }
            val passphrase = group.passphrase?.takeIf { it.isNotBlank() }
            val interfaceName = group.getInterface()?.takeIf { it.isNotBlank() }
            // API 28 vendor frameworks often omit getFrequency. Do not wait for it or invent a channel.
            val frequencyMHz = runCatching {
                (group.javaClass.getMethod("getFrequency").invoke(group) as? Number)?.toInt()?.takeIf { it > 0 }
            }.getOrNull()
            val channelNumber = frequencyMHz?.let(::wifiFrequencyMhzToChannel) ?: 0
            if (
                networkName == null ||
                interfaceName == null || passphrase == null
            ) {
                lastReason = "networkName=$networkName interface=$interfaceName " +
                    "frequencyMHz=$frequencyMHz"
                continue
            }
            val hostAddress = interfaceAddress(interfaceName)
                ?: requestConnectionAddress(
                    attempt = attempt,
                    channel = channel,
                    timeoutNanos = minOf(remainingNanos(deadlineNanos), REQUEST_POLL_NANOS),
                )
            if (hostAddress == null) {
                lastReason = "interface $interfaceName has no usable IPv6 or IPv4 address"
                continue
            }

            observedName = networkName
            check(ownership.edit().putString("owned_ssid", networkName).commit()) { "P2P ownership journal unavailable" }
            diagnostic("HS5 P2P ready interface=$interfaceName channel=$channelNumber")
            return WirelessHotspotInfo(
                ssid = networkName,
                passphrase = passphrase,
                security = Iap2WirelessSecurity.WPA_WPA2,
                channel = channelNumber,
                frequencyMHz = frequencyMHz,
                bssid = interfaceHardwareAddress(interfaceName)
                    ?: group.owner?.deviceAddress?.takeIf { it.isNotBlank() },
                interfaceName = interfaceName,
                hostAddress = hostAddress,
                bandLabel = if (frequencyMHz == null) "System selected" else if (frequencyMHz >= 5000) "5 GHz" else "2.4 GHz",
                backend = WirelessHotspotBackend.WIFI_P2P,
            )
        }
    }

    private fun requestGroupInfo(
        attempt: StartAttempt,
        channel: WifiP2pManager.Channel,
        timeoutNanos: Long,
    ): WifiP2pGroup? {
        val result = AtomicReference<WifiP2pGroup?>()
        val latch = CountDownLatch(1)
        try {
            p2pManager.requestGroupInfo(channel) { result.set(it); latch.countDown() }
        } catch (error: SecurityException) {
            throw IOException("Wi-Fi group query permission unavailable", error)
        }
        if (!await(latch, timeoutNanos)) throw IOException("Wi-Fi P2P group query timed out")
        ensureStartActive(attempt)
        return result.get()
    }

    private fun requestConnectionAddress(
        attempt: StartAttempt,
        channel: WifiP2pManager.Channel,
        timeoutNanos: Long,
    ): InetAddress? {
        val result = AtomicReference<WifiP2pInfo?>()
        val latch = CountDownLatch(1)
        p2pManager.requestConnectionInfo(channel) {
            result.set(it)
            latch.countDown()
        }
        if (!await(latch, timeoutNanos)) return null
        ensureStartActive(attempt)
        val info = result.get() ?: return null
        if (!info.groupFormed || !info.isGroupOwner) return null
        return info.groupOwnerAddress?.takeUnless { it.isAnyLocalAddress || it.isLoopbackAddress }
    }

    private fun await(latch: CountDownLatch, timeoutNanos: Long): Boolean = try {
        val waitNanos = timeoutNanos.coerceAtLeast(1L)
        latch.await(waitNanos, TimeUnit.NANOSECONDS)
    } catch (interrupted: InterruptedException) {
        Thread.currentThread().interrupt()
        throw IOException("Interrupted while waiting for Wi-Fi P2P", interrupted)
    }

    private fun interfaceAddress(interfaceName: String): InetAddress? {
        val networkInterface = networkInterface(interfaceName) ?: return null
        var ipv4: InetAddress? = null
        for (address in Collections.list(networkInterface.inetAddresses)) {
            if (address is Inet6Address && address.isLinkLocalAddress) {
                if (address.scopeId == networkInterface.index) return address
                try {
                    return Inet6Address.getByAddress(null, address.address, networkInterface)
                } catch (_: UnknownHostException) {
                    continue
                }
            }
            if (address is Inet4Address && !address.isLoopbackAddress && ipv4 == null) {
                ipv4 = address
            }
        }
        return ipv4
    }

    private fun interfaceHardwareAddress(interfaceName: String): String? =
        networkInterface(interfaceName)
            ?.hardwareAddress
            ?.takeIf { it.isNotEmpty() }
            ?.joinToString(":") { byte -> "%02x".format(byte.toInt() and 0xff) }

    private fun networkInterface(interfaceName: String): NetworkInterface? = try {
        NetworkInterface.getByName(interfaceName)
    } catch (_: SocketException) {
        null
    }

    private fun claimOwnership() = synchronized(OWNERSHIP_LOCK) {
        check(ownership.edit().putString("owner_token", ownerToken).commit()) { "P2P ownership journal unavailable" }
    }

    private fun setDeviceName(attempt: StartAttempt, channel: WifiP2pManager.Channel, deadline: Long) {
        val latch = CountDownLatch(1)
        val listener = object : WifiP2pManager.ActionListener {
            override fun onSuccess() { latch.countDown() }
            override fun onFailure(reason: Int) { latch.countDown() }
        }
        // Optional vendor API. Real SSID/passphrase still come from the created group.
        runCatching {
            p2pManager.javaClass.getMethod("setDeviceName", WifiP2pManager.Channel::class.java,
                String::class.java, WifiP2pManager.ActionListener::class.java)
                .invoke(p2pManager, channel, P2pOwnership.deviceName(ssidPrefix), listener)
            await(latch, minOf(remainingNanos(deadline), REQUEST_POLL_NANOS))
        }
        ensureStartActive(attempt)
    }

    private fun ensureStartActive(attempt: StartAttempt) {
        synchronized(stateLock) {
            ensureStartActiveLocked(attempt)
        }
    }

    private fun ensureStartActiveLocked(attempt: StartAttempt) {
        if (closed) throw IOException("WifiP2pGroupManager closed while starting")
        if (startAttempt !== attempt) throw IOException("Wi-Fi P2P startup was cancelled")
        if (attempt.stopped) throw IOException("Wi-Fi P2P group stopped before startup completed")
    }

    private fun cleanupFailedStart(attempt: StartAttempt) {
        val failedChannel: WifiP2pManager.Channel?
        val failedThread: HandlerThread?
        val removeGroup: Boolean
        synchronized(stateLock) {
            if (startAttempt === attempt) startAttempt = null
            attempt.stopped = true
            stateLock.notifyAll()
            failedChannel = attempt.channel
            failedThread = attempt.thread
            removeGroup = attempt.createSucceeded
            if (channel === failedChannel) channel = null
            if (callbackThread === failedThread) callbackThread = null
        }
        if (removeGroup && failedChannel != null) {
            removeGroupBlocking(failedChannel)
        }
        releaseCallbackThread(attempt, failedThread)
    }

    private fun removeGroupBlocking(channel: WifiP2pManager.Channel) {
        removeGroup(channel, waitForCallback = true)
    }

    private fun removeGroup(channel: WifiP2pManager.Channel, waitForCallback: Boolean) {
        if (ownership.getString("owner_token", null) != ownerToken) return
        val done = CountDownLatch(1)
        try {
            p2pManager.requestGroupInfo(channel) { group ->
                synchronized(OWNERSHIP_LOCK) {
                    val recorded = observedName ?: ownership.getString("owned_ssid", null)
                    val ours = ownership.getString("owner_token", null) == ownerToken &&
                        group != null && P2pOwnership.canReclaim(group.isGroupOwner, group.networkName, recorded, ssidPrefix)
                    if (!ours) { done.countDown(); return@requestGroupInfo }
                    p2pManager.removeGroup(channel, object : WifiP2pManager.ActionListener {
                        override fun onSuccess() {
                            synchronized(OWNERSHIP_LOCK) {
                                if (ownership.getString("owner_token", null) == ownerToken)
                                    ownership.edit().remove("owned_ssid").remove("owner_token").commit()
                            }
                            done.countDown()
                        }
                        override fun onFailure(reason: Int) { Log.w(TAG, "Owned P2P cleanup failed: $reason"); done.countDown() }
                    })
                }
            }
            if (waitForCallback) done.await(REMOVE_GROUP_TIMEOUT_MILLIS, TimeUnit.MILLISECONDS)
        } catch (failure: SecurityException) {
            Log.w(TAG, "P2P cleanup permission unavailable")
        } catch (failure: Exception) {
            if (failure is InterruptedException) Thread.currentThread().interrupt()
            Log.w(TAG, "Owned P2P cleanup could not complete", failure)
        }
    }

    private fun releaseCallbackThread(attempt: StartAttempt?, thread: HandlerThread?) {
        if (thread == null) return
        if (attempt?.createIssued != true || attempt.createFinished) { thread.quitSafely(); return }
        // Retain the callback looper for a late successful create after cancellation.
        Handler(thread.looper).postDelayed({
            attempt.channel?.let { removeGroup(it, waitForCallback = false) }
            Handler(thread.looper).postDelayed({ thread.quitSafely() }, REMOVE_GROUP_TIMEOUT_MILLIS)
        }, 30_000L)
    }

    private fun waitNanos(nanos: Long) {
        val millis = nanos / NANOS_PER_MILLISECOND
        val remainder = (nanos % NANOS_PER_MILLISECOND).toInt()
        try {
            stateLock.wait(millis, remainder)
        } catch (interrupted: InterruptedException) {
            Thread.currentThread().interrupt()
            throw IOException("Interrupted while waiting for Wi-Fi P2P", interrupted)
        }
    }

    private fun deadlineAfter(timeoutMillis: Long): Long {
        val now = System.nanoTime()
        val delta = timeoutMillis * NANOS_PER_MILLISECOND
        return if (Long.MAX_VALUE - now < delta) Long.MAX_VALUE else now + delta
    }

    private fun remainingNanos(deadlineNanos: Long): Long =
        (deadlineNanos - System.nanoTime()).coerceAtLeast(0L)

    private fun failureReason(reason: Int): String = when (reason) {
        WifiP2pManager.P2P_UNSUPPORTED -> "Wi-Fi P2P is unsupported"
        WifiP2pManager.BUSY -> "Wi-Fi P2P is busy"
        WifiP2pManager.ERROR -> "generic error"
        WifiP2pManager.NO_PERMISSION -> "permission denied"
        else -> "reason $reason"
    }

    private class StartAttempt {
        var channel: WifiP2pManager.Channel? = null
        var thread: HandlerThread? = null
        @Volatile var createIssued = false
        @Volatile var createFinished = false
        var createSucceeded = false
        var failure: IOException? = null
        var stopped = false
    }

    private companion object {
        val OWNERSHIP_LOCK = Any()
        const val TAG = "xcertplay-usb"
        const val NANOS_PER_MILLISECOND = 1_000_000L
        const val REMOVE_GROUP_TIMEOUT_MILLIS = 2_000L
        val REQUEST_POLL_NANOS: Long = TimeUnit.MILLISECONDS.toNanos(500)
    }
}

