package com.shilapi.xcertplay.media

/** Differences measured on the API 28 HS5; the generic AAOS mapper stays upstream. */
internal object Hs5AudioProfile {
    fun selection(audioType: String, payloadType: Int, mode: AudioChannelMappingMode): AudioChannelSelection =
        if (audioType.equals("default", ignoreCase = true))
            AudioChannelSelection(AudioChannel.NAVIGATION, AudioContentType.SPEECH)
        else AudioChannelMapper.map(audioType, payloadType, mode)
}
