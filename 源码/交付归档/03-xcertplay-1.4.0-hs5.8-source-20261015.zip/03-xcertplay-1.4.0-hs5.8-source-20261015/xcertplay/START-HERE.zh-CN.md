# xcertplay HS5 1.4.0-hs5.8

> 本版对照本地 DiPlay / FAW-Play 0.2.49 当前工作树优化无线连接、低延迟硬解、触摸与日志链路，并修复首页未点击即显示连接中、定位消息洪泛及定位交接问题。输出停滞恢复采用同一参考实现的有界关键帧探测。Apple 官方 CarPlay Ultra 仍未完成。

当前测试版包名 `com.shilapi.xcertplay.hs5`、版本 code 1408。采用开发调试签名，尚未作为正式更新发布。验证记录位于 `artifacts/hs5.8/verification.json`：shared 578 项、common 117 项单元测试通过，无失败或跳过；四模块 Lint 无 Error/Fatal，仍有警告。mobile 和 automotive 调试包均完成构建、签名验证和 Intel x86_64 库检查。实车验收状态单独记录，不以构建成功代替。性能对照和适用边界见 [DiPlay 性能承接记录](docs/DIPLAY-PERFORMANCE-ALIGNMENT.zh-CN.md)。

## 首次使用

1. 安装 mobile APK，打开 App，进入中文首次引导。普通东软 Android 9 车机使用 mobile 包；automotive 包用于 AAOS 验证。
2. 检查蓝牙、Wi-Fi、P2P 接口和内置认证准备状态。车机无线总开关由原厂管理，App 不切换总开关。
3. 在 App 内点击麦克风、精确定位授权，确认 Android 系统弹窗。拒绝这两项仍可继续基础 CarPlay；没有麦克风时不声明车机拾音，没有定位时不回传车机 GPS，继续使用 iPhone 定位。匹配 HS5 Android 9 的 P2P 建组不请求扫描定位权限；测试手机按 Android 版本请求无线权限。
4. 检查更新，网络失败或发布配置未完成会如实显示，可稍后处理。
5. 基础 CarPlay 免费。HUD、原厂仪表地图和方向盘增强功能分别按签名授权票据启用；绑定使用手机扫码、在手机网页输入兑换码。新 App 不继承旧 App 的票据和设备身份。
6. 点击连接，在 iPhone 蓝牙设置中搜索车机名称，确认配对和 CarPlay。App 自动建立专用 Wi-Fi Direct/P2P 组并继续 xcertplay 的 iAP2/AirPlay 链路。首次引导仅在真实主屏视频流成功启动后完成；中断后继续未完成步骤。

日常设置替换为管理页：权限、软件授权、更新、手机配对、诊断和Apple CarPlay Ultra 开关。管理页保持当前 CarPlay 会话；期间断链会清理状态并保存恢复请求，关闭管理后执行恢复。新增拾音/GPS/仪表授权可能需下次连接生效，用户可以选择“断开并重新连接”。

普通权限尽量由 App 内的系统弹窗完成。仪表导航窗口的悬浮窗权限和更新包安装权限是 Android 特殊权限，不能伪装成普通弹窗；仅在实际需要时说明限制并由用户选择系统确认。没有强行拉回 App 或设置页自动返回逻辑。

## 固定 HS5 参数

- 主屏 H.264、硬件优先的既有 MediaCodec 路径，关闭 HEVC/软件 HEVC；30 fps、100% 显示比例、物理宽度 300 mm、左舵、隐藏系统栏。历史试验设置不覆盖固定配置；车辆示宽灯优先驱动日夜。
- 媒体预缓冲 500 ms，媒体/导航使用原新装默认 usage 路由，advanced mapping 关闭。历史 stream 14 不作为全局默认。电话、Siri、导航按实际输出频道分别请求焦点；播放恢复继续由现有单一状态机处理。
- 无线 HS5 Opus 拾音为 48 kHz 单声道 PCM16、20 ms、增益 100%；通话与 Siri 使用各自实车录音源。RTP 时钟独立于采集时钟，按协商 16/24/48 kHz 分别递增 320/480/960；4 帧预缓冲、6 帧容量。通用设备与 PCM 路径保留，不把 HS5 特例当作通用 Opus 标准。
- 原厂仪表副屏为 1920×720 面板、1600×600 流、30 fps；使用手机原生 INSTRUMENTS/ETA 内容和 HS5 固定安全区。HUD 和方向盘参数使用原适配默认，不对用户开放调参。

上述固定配置已由代码和历史证据核对；新 APK 的解码性能、混音压音、拾音回声与仪表显示仍需实车验收。当前音量降低由系统/OEM负责，未叠加未验证的 DSP 开关或软件音量曲线。

## 内置认证与预留接口

按照本次用户授权，从旧 DiPlay 项目恢复的两个附件身份文件随 APK 内置，首次启动自动准备到应用私有、不参与备份的目录，通过不可导出的 LocalAuthDocumentsProvider 交给原 LOCAL_FILES 认证器。上游认证算法不改、不引入 DiPlay 运行库。打包脚本仅允许这两个精确 assets，禁止额外私钥、服务器签名密钥或 Android keystore 混入。

xcertplay CH341 USB→I²C 硬件认证实现保留；已显式配置的外部认证后端不被启动流程覆盖。没有面向普通用户的认证技术调参页。此预留接口不表示任意 CarPlay 盒子可充当认证芯片。源码材料验证也不证明 Apple MFi 官方授权或 iPhone 已接受当前身份。

## HS5 车辆接口

匹配的 HS5 平台打开 App 后，由界面和 CarPlay 控制器共享原厂 Qisi 服务连接；离开管理页不会释放仍在使用的连接。状态通过原厂回调和每秒读取更新，断线清空，超过 5 秒的读数按未获取处理。普通测试手机明确显示不支持。

已接入 32 个字段：空调状态、左右温度、风量/模式、环境温度，前排座椅加热/通风，以及车速、挡位、燃油、续航、总里程、车门、尾门、位置灯、胎压等。管理页先展示常用只读状态；完整字段供应用内部使用。Qisi 车速及尚未核实物理单位的数值保留原厂编码，不映射为 Apple 数据。

空调和座椅的控制入口已接到原厂服务，但没有新增用户控制按钮，也不会在启动或订阅时自动下发指令。调用前校验车型、座椅能力、参数范围和状态时效；服务应答不视为车辆已执行，实际结果仍从读取和回调确认。普通 APK 是否获准访问原厂服务，以及本车具体编码和反馈，待实车验证。详细接口和证据见 [车辆接口接入记录](docs/HS5-VEHICLE-DATA-AND-CONTROLS.zh-CN.md)。

## 当前未完成的接入

授权/更新客户端已实现，旧服务地址和公钥仅保存在忽略的本地配置中。新包名允许项、正式 APK 签名 pin、独立 HS5 更新清单和旧用户设备额度迁移尚未接入，当前测试包明确显示未配置；不阻止免费基础连接。见 [产品服务接入说明](docs/HS5-PRODUCT-SERVICES.zh-CN.md)。

用户要求真正的 Apple CarPlay Ultra。此前提出的“Ultra 风格 Kanzi 主题”路线已经撤回；Kanzi 原厂换肤不作为 Ultra 接入方案。管理页保留 Apple CarPlay Ultra 开关，但实际功能未实现，保持禁用。后续依据 Apple 公开架构及可取得的正式车端规范核对通信、车辆数据、本地渲染、资源真实性、多屏合成和 UI 同步。官方资料、上游和 HS5 的核对见 [官方 Ultra 接入核查](docs/APPLE-CARPLAY-ULTRA-INTEGRATION.zh-CN.md)。[原厂主题接口调查](docs/HS5-ULTRA-THEME-AUDIT.zh-CN.md)仅为历史平台证据，不能当作官方 Ultra 的实现路线。3092 无线/权限证据与 3222 IPC 主题证据不等同于当前实车版本。

最终打包版本已通过 ADB 更新到 OPPO PJZ110，读取设备端 APK 后计算的 SHA-256 与打包结果一致。两次无线 bring-up 至 CONNECTED 分别为 7.164 秒、8.952 秒，不含 Android 蓝牙可发现弹窗等待；实际启动 `c2.qti.avc.decoder.low_latency` 硬件组件，主屏 SurfaceView 层存在。第一次持续观察 5 分 42 秒、第二次 4 分 20 秒，均未出现断链；分别发送 341、260 次定位，每秒最多一次，首个快照遇背压后下一秒正常继续。做过连续六次主页滑动和静置后再次操作，输出探测成功发送，静置尾帧较大的输出年龄仍可出现，不能宣称流畅度已完全追平 DiPlay。详见 [本轮 OPPO 记录](docs/evidence/diplay-performance-oppo-20261015.json)。

没有连接 HS5；首装引导、真实绑定/更新、全部手机兼容性、音频恢复、Intel 解码、HUD/仪表/方向盘及车辆读写仍保留对应实机验收项。

## 开发与历史记录

基线为 xcertplay 1.4.0 固定提交 `551895a121f5fb22312331f3cd0d7b2857bb478f`，旧 FAW-Play 项目保持原状。

- [无线连接与协议对照](WIRELESS-CONNECTION.zh-CN.md)
- [系统包接入与权限](docs/HS5-SYSTEM-INTEGRATION.zh-CN.md)
- [交互与架构](INTERACTION-FLOW.zh-CN.md)
- [实现记录](HS5-IMPLEMENTATION.zh-CN.md)
- [原始源码审查](HS5-SOURCE-REVIEW.zh-CN.md)

历史 hs5.1–hs5.7 的手机验证、连接/断开和构建记录不作为 hs5.8 实测证明。撤除了未交付 hs5.5 的权限设置页自动返回草稿。

构建使用本机 JDK、Android SDK 37、NDK 28.2.13676358，最低 Android 9，包含 Intel x86_64 原生库：

```sh
./gradlew :shared:testDebugUnitTest :common:testDebugUnitTest \
  :shared:lintDebug :common:lintDebug :mobile:lintDebug :automotive:lintDebug \
  :mobile:assembleDebug :automotive:assembleDebug
python3 scripts/package-hs5-build.py --build-log /path/to/current-successful-build.log
```

完整 Apple 车机接收端文档尚未取得，当前协议判断来自公开官方资料、上游实现与已有设备证据。
