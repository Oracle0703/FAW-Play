#!/usr/bin/env python3
"""Check deployment inputs using the compiled upstream authenticator; print no secrets."""

import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


ROOT = Path(__file__).resolve().parents[1]
SOURCE = r"""
import com.shilapi.xcertplay.mfi.LocalMfiAuthenticationClient;
import com.shilapi.xcertplay.mfi.MfiInvalidDataException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.math.BigInteger;
import java.util.Arrays;
import org.bouncycastle.asn1.ASN1Integer;
import org.bouncycastle.asn1.DERSequence;

public class VerifyLocalAuth {
    public static void main(String[] args) throws Exception {
        Path certificatePath = Path.of(args[0]);
        Path keyPath = Path.of(args[1]);
        LocalMfiAuthenticationClient client;
        try (InputStream certificate = Files.newInputStream(certificatePath);
             InputStream key = Files.newInputStream(keyPath)) {
            client = LocalMfiAuthenticationClient.Companion.load(certificate, key);
        }
        if (client.protocolMajor() != 3) throw new IllegalStateException("Expected AuthV3");
        if (!Arrays.equals(Files.readAllBytes(certificatePath), client.readCertificate(16384))) {
            throw new IllegalStateException("Certificate bytes changed");
        }
        byte[] challenge = new byte[32];
        new SecureRandom().nextBytes(challenge);
        byte[] raw = client.signChallenge(challenge);
        if (raw.length != 64) throw new IllegalStateException("Expected 64-byte signature");
        byte[] der = new DERSequence(new ASN1Integer[] {
            new ASN1Integer(new BigInteger(1, Arrays.copyOfRange(raw, 0, 32))),
            new ASN1Integer(new BigInteger(1, Arrays.copyOfRange(raw, 32, 64)))
        }).getEncoded();
        Signature verifier = Signature.getInstance("NONEwithECDSA");
        try (InputStream certificate = Files.newInputStream(certificatePath)) {
            verifier.initVerify(CertificateFactory.getInstance("X.509")
                .generateCertificates(certificate).iterator().next().getPublicKey());
        }
        verifier.update(challenge);
        if (!verifier.verify(der)) throw new IllegalStateException("Signature verification failed");
        challenge[0] ^= 1;
        verifier.update(challenge);
        if (verifier.verify(der)) throw new IllegalStateException("Altered challenge accepted");
        boolean rejected = false;
        try { client.signChallenge(new byte[31]); }
        catch (Exception expected) {
            if (!(expected instanceof MfiInvalidDataException)) throw expected;
            rejected = true;
        }
        if (!rejected) throw new IllegalStateException("Invalid challenge length accepted");
        System.out.println("{\"upstream_loader\":\"passed\",\"certificate_bytes\":\"passed\","
            + "\"protocol_major\":3,\"signature_bytes\":64,\"signature_verification\":\"passed\","
            + "\"altered_challenge_rejected\":true,\"invalid_challenge_length_rejected\":true}");
    }
}
"""


def main():
    classes = ROOT / "shared/build/intermediates/built_in_kotlinc/debug/compileDebugKotlin/classes"
    if not (classes / "com/shilapi/xcertplay/mfi/LocalMfiAuthenticationClient.class").is_file():
        raise SystemExit("Build shared debug classes first.")
    gradle_home = Path(os.environ.get("GRADLE_USER_HOME", str(Path.home() / ".gradle")))
    modules = gradle_home / "caches/modules-2/files-2.1"
    jars = []
    for group, artifact in [("org.bouncycastle", "bcprov-jdk18on"),
                            ("org.jetbrains.kotlin", "kotlin-stdlib")]:
        matches = [p for p in (modules / group / artifact).glob("*/*/*.jar")
                   if not p.name.endswith(("-sources.jar", "-javadoc.jar"))]
        if not matches:
            raise SystemExit("Missing Gradle dependency: " + artifact)
        jars.extend(matches)
    java_home = os.environ.get("JAVA_HOME")
    if not java_home:
        cached = list((gradle_home / "jdks").glob("*/jdk-*/Contents/Home/bin/javac"))
        if cached:
            java_home = str(sorted(cached)[-1].parents[1])
    javac = str(Path(java_home) / "bin/javac") if java_home else shutil.which("javac")
    java = str(Path(java_home) / "bin/java") if java_home else shutil.which("java")
    if not java or not javac:
        raise SystemExit("Set JAVA_HOME to a JDK with javac.")
    classpath = os.pathsep.join(str(p) for p in [classes, *jars])
    auth = ROOT / ".private/local-auth"
    for name in ("certificate.p7b", "identity.pk8"):
        if not (auth / name).is_file():
            raise SystemExit("Missing ignored local authentication file: " + name)
    with tempfile.TemporaryDirectory(prefix="xcertplay-auth-check-") as temporary:
        source = Path(temporary) / "VerifyLocalAuth.java"
        source.write_text(SOURCE)
        compile_result = subprocess.run(
            [javac, "-cp", classpath, "-d", temporary, str(source)],
            capture_output=True, text=True,
        )
        if compile_result.returncode:
            raise SystemExit("Could not compile the deployment verifier: " + compile_result.stderr)
        result = subprocess.run(
            [java, "-cp", temporary + os.pathsep + classpath, "VerifyLocalAuth",
             str(auth / "certificate.p7b"), str(auth / "identity.pk8")],
            capture_output=True, text=True,
        )
        if result.returncode:
            raise SystemExit("Upstream authentication validation failed; material was not printed.")
        verification = json.loads(result.stdout)
        print(json.dumps(verification, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
