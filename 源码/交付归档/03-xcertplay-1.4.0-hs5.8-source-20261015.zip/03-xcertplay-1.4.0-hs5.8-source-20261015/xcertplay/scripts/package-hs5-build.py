#!/usr/bin/env python3
"""Package the verified HS5 build and record evidence without emitting identity material."""
import argparse
import collections
from datetime import date
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BASE = '551895a121f5fb22312331f3cd0d7b2857bb478f'
build_config = (ROOT / 'mobile/build.gradle.kts').read_text()
VERSION = re.search(r'versionName\s*=\s*"([^"]+)"', build_config).group(1)
VERSION_CODE = int(re.search(r'versionCode\s*=\s*(\d+)', build_config).group(1))
OUT = ROOT / 'artifacts' / VERSION.split('-', 1)[-1]
parser = argparse.ArgumentParser()
parser.add_argument('--build-log', type=Path, required=True, help='Successful complete Gradle verification log')
LOG = parser.parse_args().build_log.resolve()
sdk = os.environ.get('ANDROID_SDK_ROOT') or os.environ.get('ANDROID_HOME')
if not sdk:
    sdk = next(line.split('=', 1)[1] for line in (ROOT / 'local.properties').read_text().splitlines() if line.startswith('sdk.dir='))
BUILD_TOOLS = sorted((Path(sdk) / 'build-tools').glob('*'), key=lambda p: tuple(int(n) for n in re.findall(r'\d+', p.name)))[-1]


def run(args):
    return subprocess.run(args, cwd=ROOT, capture_output=True, text=True, check=True).stdout


def digest(content):
    return hashlib.sha256(content).hexdigest()


def original(path):
    result = subprocess.run(['git', 'show', BASE + ':' + path], cwd=ROOT, capture_output=True)
    return result.stdout if result.returncode == 0 else None


def unit_results(module):
    reports = list((ROOT / module / 'build/test-results/testDebugUnitTest').glob('TEST-*.xml'))
    if not reports:
        raise SystemExit('Missing current unit test reports: ' + module)
    counts = dict.fromkeys(['tests', 'failures', 'errors', 'skipped'], 0)
    for report in reports:
        root = ET.parse(report).getroot()
        for key in counts:
            counts[key] += int(root.attrib.get(key, 0))
    if counts['failures'] or counts['errors'] or counts['skipped']:
        raise SystemExit('Unit tests have not passed: ' + module)
    return counts


def lint_results(module):
    root = ET.parse(ROOT / module / 'build/reports/lint-results-debug.xml').getroot()
    result = dict(collections.Counter(issue.attrib.get('severity') for issue in root))
    if result.get('Error', 0) or result.get('Fatal', 0):
        raise SystemExit('Lint has not passed: ' + module)
    return {'errors': 0, 'warnings': result.get('Warning', 0)}


def apk_contract(source, module):
    lines = run([str(BUILD_TOOLS / 'aapt2'), 'dump', 'xmltree', '--file',
                 'AndroidManifest.xml', str(source)]).splitlines()
    nodes = []
    for i, line in enumerate(lines):
        node = re.match(r'(\s*)E: ([\w-]+) ', line)
        if not node:
            continue
        indent = len(node.group(1))
        attrs = {}
        descendants = []
        for child in lines[i + 1:]:
            if len(child) - len(child.lstrip()) <= indent:
                break
            descendants.append(child)
            if len(child) - len(child.lstrip()) != indent + 2:
                continue
            attr = re.search(r':(\w+)\(0x[0-9a-f]+\)=("[^"]*"|true|false)', child)
            if attr:
                attrs[attr.group(1)] = attr.group(2).strip('"')
        if node.group(2) == 'activity-alias':
            attrs['main_launcher'] = all(value in '\n'.join(descendants) for value in
                                         ['android.intent.action.MAIN', 'android.intent.category.LAUNCHER'])
        nodes.append((node.group(2), attrs))
    provider = next((attrs for kind, attrs in nodes if kind == 'provider' and
                     attrs.get('name') == 'com.shilapi.xcertplay.LocalAuthDocumentsProvider'), None)
    if not provider or provider.get('exported') != 'false' or provider.get('grantUriPermissions') != 'false':
        raise SystemExit('Private authentication provider is exposed: ' + module)
    result = {'local_auth_provider_exported': False, 'local_auth_uri_grants_allowed': False}
    if module == 'mobile':
        expected = {'Group': 'GROUP CARPLAY', 'Domain': 'DOMAIN CARPLAY',
                    'Ability': 'com.shilapi.xcertplay.DiPlayActivity', 'MoreApp': 'true'}
        metadata = {attrs.get('name'): attrs.get('value') for kind, attrs in nodes if kind == 'meta-data'}
        if any(metadata.get(key) != value for key, value in expected.items()):
            raise SystemExit('HS5 launcher metadata is incomplete')
        alias = next((attrs for kind, attrs in nodes if kind == 'activity-alias' and
                      attrs.get('name') == expected['Ability']), None)
        if not alias or alias.get('exported') != 'true' or alias.get('targetActivity') != 'com.shilapi.xcertplay.CarPlayHostActivity':
            raise SystemExit('HS5 launcher alias is not connected to the host')
        if not alias.get('main_launcher'):
            raise SystemExit('HS5 launcher alias is not launchable')
        result.update({'hs5_launcher_metadata': expected, 'launcher_alias_target': alias['targetActivity'],
                       'launcher_alias_declares_main_launcher': True, 'vehicle_launcher_visibility': 'pending'})
    return result


def manifest():
    changed = set(run(['git', 'diff', '--name-only', '-z', 'HEAD']).split('\0'))
    changed.update(run(['git', 'ls-files', '--others', '--exclude-standard', '-z']).split('\0'))
    files = []
    for name in sorted(changed):
        path = ROOT / name
        if not name or not path.is_file() or path.suffix not in {'.kt', '.java', '.xml', '.gradle', '.kts'}:
            continue
        content = path.read_bytes()
        upstream = original(name)
        prior = ROOT.parent / 'FAW-Play' / name
        hs5 = prior.read_bytes() if prior.is_file() else None
        if upstream is not None:
            kind = 'upstream_unchanged' if content == upstream else 'adapted_upstream'
        elif hs5 is not None:
            kind = 'reused_hs5_boundary_or_helper' if content == hs5 else 'adapted_hs5_boundary_or_helper'
        else:
            kind = 'new_integration_or_regression'
        files.append({'target': name, 'kind': kind, 'target_sha256': digest(content),
                      'upstream_sha256': digest(upstream) if upstream is not None else None,
                      'old_app_sha256': digest(hs5) if hs5 is not None else None})
    old = json.loads((ROOT / 'HS5_MIGRATION.json').read_text())
    retired = set(old.get('retired_draft_files', []))
    retired.update(item['target'] for item in old.get('files', []) if not (ROOT / item['target']).exists())
    result = {'upstream_commit': BASE, 'source_project': 'FAW-Play current source (left unchanged)',
              'version': VERSION, 'approach': 'One upstream pipeline with HS5 adapters and narrow fixes',
              'files': files, 'retired_draft_files': sorted(retired)}
    (ROOT / 'HS5_MIGRATION.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
    return result


if 'BUILD SUCCESSFUL' not in LOG.read_text():
    raise SystemExit('The complete current Gradle verification has not passed')
checks = {'unit_tests': {m: unit_results(m) for m in ['shared', 'common']},
          'lint': {m: lint_results(m) for m in ['shared', 'common', 'mobile', 'automotive']}}
checks['authentication'] = json.loads(run(['python3', 'scripts/verify-local-auth.py']))
unchanged = []
for path in (ROOT / 'shared/src/main/java/com/shilapi/xcertplay/mfi').glob('*.kt'):
    name = path.relative_to(ROOT).as_posix()
    if path.read_bytes() != original(name):
        raise SystemExit('Authentication code changed: ' + path.name)
    unchanged.append(name)
for name in ['media/OpusEncoder.kt', 'media/AudioChannelMapping.kt']:
    path = ROOT / 'shared/src/main/java/com/shilapi/xcertplay' / name
    if path.read_bytes() != original(path.relative_to(ROOT).as_posix()):
        raise SystemExit('Protected upstream baseline changed: ' + name)
    unchanged.append(path.relative_to(ROOT).as_posix())
checks['unchanged_upstream_components'] = unchanged
secrets = [(ROOT / '.private/local-auth' / name).read_bytes() for name in ['certificate.p7b', 'identity.pk8']]
if any((ROOT / '.private/local-auth' / name).stat().st_mode & 0o077 for name in ['certificate.p7b', 'identity.pk8']):
    raise SystemExit('Authentication file access is too broad')
if (ROOT / '.private/local-auth').stat().st_mode & 0o077:
    raise SystemExit('Authentication directory access is too broad')
OUT.mkdir(parents=True, exist_ok=True)
apks = []
checks['apk_contracts'] = {}
for module in ['mobile', 'automotive']:
    source = ROOT / module / f'build/outputs/apk/debug/{module}-debug.apk'
    target = OUT / f'xcertplay-{VERSION}-{module}-debug.apk'
    run([str(BUILD_TOOLS / 'apksigner'), 'verify', str(source)])
    badging = run([str(BUILD_TOOLS / 'aapt2'), 'dump', 'badging', str(source)])
    package = re.search(r"package: name='([^']+)' versionCode='([^']+)' versionName='([^']+)'", badging)
    if not package or package.groups() != ('com.shilapi.xcertplay.hs5', str(VERSION_CODE), VERSION):
        raise SystemExit('Unexpected APK identity: ' + module)
    checks['apk_contracts'][module] = apk_contract(source, module)
    with zipfile.ZipFile(source) as archive:
        abis = sorted({name.split('/')[1] for name in archive.namelist() if name.startswith('lib/')})
        if 'x86_64' not in abis:
            raise SystemExit('Missing Intel x86_64 libraries: ' + module)
        allowed_identity = dict(zip(['assets/hs5-auth/certificate.p7b', 'assets/hs5-auth/identity.pk8'], secrets))
        if any(archive.read(name) != content for name, content in allowed_identity.items()):
            raise SystemExit('Bundled accessory identity does not match approved inputs')
        for name in archive.namelist():
            if name in allowed_identity:
                continue
            if name.endswith(('.pk8', '.p7b', '.keystore', '.jks')):
                raise SystemExit('Unapproved private file included in APK')
            content = archive.read(name)
            if any(secret in content for secret in secrets):
                raise SystemExit('Identity bytes included outside approved assets')
    shutil.copy2(source, target)
    apks.append({'file': target.relative_to(ROOT).as_posix(), 'sha256': digest(target.read_bytes()),
                 'bytes': target.stat().st_size, 'package': package.group(1), 'version_code': VERSION_CODE,
                 'version_name': package.group(3), 'signature_verified': True, 'abis': abis,
                 'identity_material_included': True, 'identity_assets_allowlist_verified': True})
changes = manifest()
checks.update({'date': date.today().isoformat(), 'upstream_commit': BASE, 'version': VERSION,
               'build_log': str(LOG), 'apks': apks,
               'source_manifest_sha256': digest((ROOT / 'HS5_MIGRATION.json').read_bytes()),
               'vehicle_installed': False, 'vehicle_validation': 'pending',
               'source_file_kinds': dict(collections.Counter(item['kind'] for item in changes['files']))})
(OUT / 'verification.json').write_text(json.dumps(checks, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'unit_tests': checks['unit_tests'], 'lint': checks['lint'], 'apks': apks,
                  'vehicle_validation': 'pending'}, indent=2, ensure_ascii=False))
