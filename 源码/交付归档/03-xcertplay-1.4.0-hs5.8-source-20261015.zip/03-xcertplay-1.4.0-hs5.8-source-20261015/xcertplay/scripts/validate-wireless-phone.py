#!/usr/bin/env python3
"""Restart the authorized test app and save only allowlisted connection evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = 'com.shilapi.xcertplay.hs5'
parser = argparse.ArgumentParser()
parser.add_argument('--adb', required=True)
parser.add_argument('--serial', required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--seconds', type=int, default=180)
args = parser.parse_args()
A = [args.adb, '-s', args.serial]
OUT = args.output.resolve()
verified = json.loads((OUT / 'verification.json').read_text())

def adb(*parts):
    return subprocess.check_output(A + list(parts), stderr=subprocess.PIPE)

def log():
    try:
        return adb('exec-out', 'cat', '/sdcard/Android/data/' + PACKAGE + '/files/logs/xcertplay.log').decode(errors='replace')
    except subprocess.CalledProcessError:
        return ''

apk_path = adb('shell', 'pm', 'path', PACKAGE).decode().strip().splitlines()[0].removeprefix('package:')
installed_hash = hashlib.sha256(adb('exec-out', 'cat', apk_path)).hexdigest()
assert installed_hash == next(item['sha256'] for item in verified['apks'] if '-mobile-' in item['file'])
baseline = log()
adb('shell', 'am', 'force-stop', PACKAGE)
adb('shell', 'am', 'start', '-n', PACKAGE + '/com.shilapi.xcertplay.DiPlayActivity')

rules = [
    ('attempt_start', r'wireless bring-up generation=\d+ starting'),
    ('identity_loaded', r'mfi local documents ready'),
    ('stage', r'wireless connection stage=(WAITING_FOR_PAIR|HOTSPOT|BLUETOOTH|IDENTIFICATION|AUTHENTICATION|PHONE_WIFI|PAIRING|SESSION|CONNECTED)'),
    ('bluetooth_discoverability', r'(Bluetooth already discoverable|HS5 Bluetooth discoverability (?:enabled for \d+s|confirmed by system state)|Bluetooth discoverability consent granted)'),
    ('stage_timeout', r'wireless connection timed out stage=(\w+) elapsedMs=(\d+)'),
    ('retry', r'wireless recovery attempt=(\d+)/3 radioAttempt=(\d+)'),
    ('retry_stopped', r'wireless recovery stopped attempts=(\d+)'),
    ('association_retry_classification', r'wireless retry association=(true|false|unknown) radioRecovery=(true|false)'),
    ('radio_request', r'P2P radio selection: requestedFrequencyMHz=(\d+) source=(\w+) retry=(\d+)'),
    ('system_radio', r'P2P radio selection: system_5ghz retry=(\d+)'),
    ('radio_query_fallback', r'P2P radio selection: (channel_query_\w+|no_alternative_non_dfs_go_channel|no_public_frequency_control)'),
    ('hotspot_ready', r'wireless hotspot backend=.*?band=([^ ]+) channel=(\d+) frequency=(\d+|unknown)MHz'),
    ('rfcomm_connected', r'wireless RFCOMM connected'),
    ('iap2_ready', r'wireless iAP2 CSM channel opened'),
    ('pairing_rejected', r'airplay pairing rejected operation=([\w-]+) code=(\d+)'),
    ('session_active', r'AirPlay session active'),
    ('home', r'showing connection home'),
]
started = time.monotonic()
last_change = started
events = []
seen = set()
record = {
    'date': '2026-10-14', 'version': verified['version'], 'device': {'model': 'OPPO PJZ110', 'android_api': 37},
    'package': PACKAGE, 'installed_apk_sha256': installed_hash,
    'source_manifest_sha256': verified['source_manifest_sha256'], 'matches_verified_deliverable': True,
    'trigger': 'Fresh app start; the iPhone Wi-Fi switch is not remotely observable',
    'vehicle_validation': 'pending', 'multiple_iphone_validation': 'pending',
    'raw_logs_names_addresses_or_identity_saved': False,
}

def persist():
    record['events'] = events
    record['observed_seconds'] = round(time.monotonic() - started, 2)
    temporary = OUT / 'phone-wireless-validation.json.tmp'
    temporary.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(OUT / 'phone-wireless-validation.json')

print(json.dumps({'watch_started': True, 'installed_apk_matches': True}), flush=True)
while time.monotonic() - started < args.seconds:
    current = log()
    delta = current[len(baseline):] if current.startswith(baseline) else current.rsplit('xcertplay log started', 1)[-1]
    for line in delta.splitlines():
        stamp = re.search(r'\b\d{2}:\d{2}:\d{2}\.\d{3}\b', line)
        if not stamp:
            continue
        for kind, expression in rules:
            match = re.search(expression, line)
            if match:
                key = (stamp.group(), kind, match.groups())
                if key not in seen:
                    seen.add(key)
                    event = {'time': stamp.group(), 'kind': kind, 'values': list(match.groups())}
                    events.append(event)
                    last_change = time.monotonic()
                    print(json.dumps(event), flush=True)
                break
    kinds = [event['kind'] for event in events]
    if 'retry_stopped' in kinds and time.monotonic() - last_change > 8:
        record['runtime_acceptance'] = 'bounded_retry_stop_observed_ui_pending'
        break
    if 'session_active' in kinds and time.monotonic() - last_change > 5:
        record['runtime_acceptance'] = 'active_session_observed'
        break
    persist()
    time.sleep(.5)
else:
    record['runtime_acceptance'] = 'observation_window_ended'

record['attempt_count'] = sum(event['kind'] == 'attempt_start' for event in events)
record['identity_loaded'] = any(event['kind'] == 'identity_loaded' for event in events)
record['automatic_retry_stopped'] = any(event['kind'] == 'retry_stopped' for event in events)
record['airplay_active'] = any(event['kind'] == 'session_active' for event in events)
record['timeout_stages'] = [event['values'][0] for event in events if event['kind'] == 'stage_timeout']
record['timeout_elapsed_ms'] = [int(event['values'][1]) for event in events if event['kind'] == 'stage_timeout']
pid = adb('shell', 'pidof', PACKAGE).decode().strip()
if pid:
    crash = adb('logcat', '-b', 'crash', '-d', '--pid=' + pid).decode(errors='replace')
    record['current_process_java_or_native_crash'] = any(marker in crash for marker in ['FATAL EXCEPTION:', 'Fatal signal'])
persist()
verified.update({'phone_installed': True, 'phone_validation': 'phone-wireless-validation.json',
                 'vehicle_installed': False, 'vehicle_validation': 'pending'})
(OUT / 'verification.json').write_text(json.dumps(verified, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key != 'events'}, ensure_ascii=False), flush=True)
