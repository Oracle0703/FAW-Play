> hs5.6 更新：首次中文引导、固定参数、内置身份、产品授权和更新管理已接入；旧调参页面不再向用户开放。最新行为与未完成项以 [START-HERE](START-HERE.zh-CN.md) 为准，本文保留此前架构和历史证据。

# xcertplay HS5 当前交互与音频链路

本文件对应 `1.4.0-hs5.4`，以 xcertplay 提交 `551895a121f5fb22312331f3cd0d7b2857bb478f` 为基础。它描述当前源码实现；完整 Apple 车机接收端规范未取得，以下不是官方认证结论。

mobile 启动通过旧版桌面元数据及 DiPlayActivity 别名进入新的 CarPlayHostActivity。旧风格首页与八类中文设置操作原宿主状态，首页在主屏视频活动时隐藏。切页和主题切换不替换视频视图或媒体后端；保存继续执行原重连流程，取消恢复原设置。当前解码策略保持 hs5.1 的实现。

```mermaid
flowchart LR
    iPhone["iPhone"] --> BT["蓝牙 RFCOMM：无线引导 iAP2"]
    BT --> Auth["上游 LOCAL_FILES：AuthV3"]
    Auth --> Wifi["HS5 API 28 Wi-Fi Direct"]
    Wifi --> AirPlay["Bonjour / AirPlay 会话"]
    AirPlay --> Tunnel["type 130：运行期 iAP2"]
    AirPlay --> Engine["上游 CarPlayMediaEngine + 隔离修复"]
    Engine --> Video["AndroidMediaSink：MediaCodec"]
    Video --> Main["type 110：中控 SurfaceView"]
    Video --> Cluster["type 111：仪表 Presentation"]
    Engine --> Audio["AndroidMediaSink：AudioTrack"]
    Audio --> Policy["东软 / Android 原厂音频策略"]
    Mic["车辆麦克风"] --> Capture["上游 AudioRecord / 编码 / RTP"]
    Capture --> iPhone
    Tunnel --> Hud["路线解析 → Qisi HUD / 仪表提示"]
    Keys["Qisi 按键 / Android 媒体键"] --> Control["既有控制队列：iAP2 HID / AirPlay event"]
    Control --> iPhone
    Vehicle["车辆 GNSS / 只读车速 HAL"] --> Location["iAP2 LocationInformation"]
    Location --> Tunnel
```

## 连接与身份

1. 用户选择 `LOCAL_FILES`，通过系统文件选择器提供证书和对应私钥；认证文件不打入 APK。保留上游其他认证后端。
   已授权的设备部署也可将身份配置到应用的 `no_backup/local-auth/`，由不可导出的只读文档 Provider 提供 `content://` 地址；仍使用同一个上游加载器。OPPO 的当前配置采用此方式，APK 本身不带身份。
2. 首次打开首页不启动链路，点击“打开 CarPlay”后准备必要授权，并请求蓝牙可发现。HS5 API 28 优先使用已核对的系统接口；接受请求后等待实际 scanMode，2 秒内未确认则使用系统可发现授权入口。App 不切换已有 Wi-Fi、蓝牙总开关。
3. 控制器读取认证后端，等待已配对候选或首次配对完成广播；首次配对准备预算为 120 秒，取消/关闭及时结束等待。确定候选后才建立 Wi-Fi Direct 组主，启动 AirPlay listener 和 Bonjour，再通过 RFCOMM 发起无线 iAP2 身份识别及认证。旧候选失败时读取新配对或已连接手机，固定 20 秒蓝牙阶段预算内每个地址只探测一次。
4. 仅系统包匹配平台 `API 28 / MODEL=HONG QI / DEVICE=t1c_acrn` 使用 HS5 后端，读取系统实际生成的 SSID、密码、网络接口和可用地址。频率读取不到时，信道为 0（未知），不等待一个必然缺失的频率接口，也不填入猜测值。该 GO-only 路径不扫描 P2P peers，不额外要求扫描定位；可选 GPS 回传独立授权。系统依据见 [系统接入与权限](docs/HS5-SYSTEM-INTEGRATION.zh-CN.md)，本轮仍待实车验证。
5. 只回收本应用有明确记录或命名空间的网络组。陌生组会返回需要处理现有连接的错误。取消后的晚到创建回调仍检查归属令牌，避免旧控制器删除新控制器的组。
6. iPhone 通过 Wi-Fi 建立 AirPlay；运行期 iAP2 使用原 type 130 通道。沿用上游“隧道就绪后再关闭蓝牙引导”的交接和超时逻辑。
7. HS5 的同一手机 A2DP 媒体交接与恢复有独立归属记录；不接管其他蓝牙设备。

## 音频输出

`iPhone → 加密媒体流 → 原 AudioStream → CarPlayMediaEngine → 原 AudioRenderer → AudioTrack → 车辆音频策略 → 扬声器`。

引擎和输出端以 `session + type + audioType` 区分流，避免 type 100 的音乐、提示或电话互相替换。接收、解码和播放只有一套上游实现。

| 手机音频类型 | HS5 输出策略 |
|---|---|
| media | Android 媒体输出，音乐预缓冲 |
| default / alert | 导航提示；可选择原厂 stream 14，失败则回退导航 usage |
| compatibility | 沿用上游移动/AAOS 模式的映射；映射为媒体时采用音乐预缓冲 |
| telephony | 语音通信 usage，短缓冲 |
| speechRecognition | 默认助手 usage；结合 NowPlaying、电话及 Siri 状态，处理相机期间仍在播放的音乐 |

HS5 音乐设置为预缓冲 300 / 500 / 1000 ms，默认 500 ms；请求容量为预缓冲加 200 ms，仍受系统最小缓冲限制。实际开始阈值会根据车机授予的 AudioTrack 容量收缩，避免暂停状态下写满而阻塞。电话、助手和提示采用各自的短缓冲。

解码输入暂忙时先排出已完成输出，再重试同一包；超过期限报错，而不是无声丢掉该包。音乐缓冲实际耗尽时才重新预缓冲；短尾音在没有新包时仍可播放。失败的渲染线程可在后续媒体包到来时重建。

保留上游唯一的 AudioFocusSession，不增加旧版逐音轨焦点协调器。电话/Siri 恢复只在原先正在播放、来源一致、干预已结束且当前会话仍有效时发出 PLAY；用户暂停、新通话、来源变化或会话结束会撤销恢复。连接后不强制自动播放。其他 App 抢占后的恢复仍需逐场景实车验证。

## 麦克风输入

`车辆麦克风 → 上游 AudioRecord（16 kHz 单声道）→ 增益 → 上游重采样 → PCM/Opus → 加密 RTP → iPhone`。

手机 SETUP 给出有效输入端口和支持的音频格式后，在 SETUP 响应发送完毕时启动录音，不等待手机先发下行声音。沿用上游 16 / 24 / 48 kHz 协商及 Opus 的 48 kHz RTP 时钟。新旧会话交替时，麦克风输出的归属单独登记，旧会话不能停止替代它的新麦克风。

车辆真实拾音器、AEC、功放和原厂电话策略仍由系统决定，编译与模拟测试不能确认这些效果。

## 视频、仪表与 HUD

- 中控使用原 VideoWorkQueue / VideoDecodePump / VideoSyncGate / MediaCodec，接到 HS5 SurfaceView。
- 仪表使用原 type 111 解码器，输出到实际 `Cluster-Display` 的 Presentation；默认物理尺寸 1920×720、流尺寸 1600×600、HS5 安全区和 `instruments?showETA=yes` 请求。
- HS5 仅协商其兼容路径所需的 altScreen，不要求上游通用接收端的 uiContext 配套语义；通用设备保持原协商方式。
- 高速路口图来自手机发送的仪表视频，不由 HUD 箭头或车道元数据拼出。当前代码保留旧 MAP3 的已观测兼容配置；新架构下仍需实际手机复验。
- 副屏 EOF/解密错误只结束副屏；主屏结束仍结束当前 CarPlay。替换后的屏流不受旧流晚到回调影响。
- SurfaceHolder 拥有 Surface；销毁视图前撤销并等待所有相关解码器释放，不由 App 释放 holder 的 Surface。
- 原厂仪表启用时，网页副屏输出不抢占它。Activity 管窗口和显示监听；控制器保留 HUD/路线状态与过期清理，Activity 消失后不会留下过期 HUD 指引。

路线与车道是独立路径：原 iAP2 订阅收到 0x5201/0x5202 后解析成 HUD/仪表提示；0x5204 提供独立车道元数据。HS5 运行期身份声明路线组件及车道字段，引导身份不声明这些输出。此前车道实车检查未收到 0x5204，当前解析与能力声明通过测试不等于已收到或已显示车道。

## 输入与车辆数据

Qisi 负责原厂键码、短长按和原厂页面优先级，沿用倒车影像/E-CALL 让位逻辑。音乐键走上游 iAP2 Consumer Control 的按下、保持和释放；电话/Siri/旋钮走既有 AirPlay event 通道。电话按下、释放和可选电话页面请求由同一个 event 锁保护。

三指左/右手势分别显示/隐藏仪表地图，设置页面不触发地图手势。车灯状态通过只读 Qisi 接口更新上游 setNightMode，接口不可用时回到 Android 主题。

HS5 定位仅采用新鲜车辆 GNSS，使用单调时钟判断过期。未知卫星数、精度指标或海拔不伪造。实际具备 CAR_SPEED 权限时才声明车速能力；手机请求 selector 4 后，组合只读 HAL 车速为 PASCD。实际 OEM 权限和数据可用性仍需车机确认。

## 会话结束

原控制器负责协议、热点、iAP2、媒体键队列和后台会话；HS5 模块只负责本车服务接入。结束会话撤销延迟恢复、清理路线与车道状态、归还自己交接的 A2DP、释放麦克风和各媒体流。Activity 销毁释放显示窗口、车灯监听和前台按键归属，保留允许继续工作的会话资源。
