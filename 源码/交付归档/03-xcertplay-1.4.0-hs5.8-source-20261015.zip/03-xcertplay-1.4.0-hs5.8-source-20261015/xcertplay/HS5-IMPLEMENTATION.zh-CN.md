> hs5.6 更新：首次中文引导、固定参数、内置身份、产品授权和更新管理已接入；旧调参页面不再向用户开放。最新行为与未完成项以 [START-HERE](START-HERE.zh-CN.md) 为准，本文保留此前架构和历史证据。

# HS5 整合实现与验收记录

版本：`1.4.0-hs5.3` / code 1403 / `com.shilapi.xcertplay.hs5`。基线：xcertplay 1.4.0，提交 `551895a121f5fb22312331f3cd0d7b2857bb478f`。依照改造前源码审查，在上游已有接入点实现 HS5 扩展。

## 架构与代码取舍

系统保留一条 `CarPlayController → AirPlaySession → CarPlayMediaEngine → AndroidMediaSink` 媒体链。身份使用上游 LOCAL_FILES；无线引导、Bonjour、运行期 type 130 iAP2、Media3 媒体会话和 HID 按下/保持/释放都由原链路承担。

| 边界 | 本轮处理 | 验证范围 |
|---|---|---|
| 本地身份 | 全部 mfi 源码保持固定上游版本；认证文件只作为运行期输入 | 编译出的上游加载器验证 AuthV3、公钥验签、无效挑战拒绝 |
| 无线 | API 28 HS5 后端使用系统实际凭据；API 29+ 后端回收残留的匹配组，保留原控制器交接逻辑 | 陌生组保护、取消后晚到成功、旧令牌保护、未知频率；新增匹配旧组、陌生组、缺失凭据、组客户端四项回归 |
| 音频流 | 原引擎/渲染器按会话、type、audioType 隔离；新 SETUP 主动撤销旧输出 | 并行媒体/提示、替换、类型拆除、旧会话清理和旧 SETUP 拒绝 |
| 音频路由 | 保留通用 mapper；HS5 default 导航、原厂 stream 14 可回退、上下文 speech 路由 | 通用/HS5 差异、失败回退、相机与 Siri/电话状态逻辑 |
| 缓冲 | 在原 AudioRenderer 中接入音乐预缓冲、真实容量钳制、耗尽重缓冲和短尾音 | 容量过小、播放头回绕、实际耗尽判断、短延迟流不重缓冲 |
| 音频解码 | 原 codec 输入忙时排出输出并重试同一包，有取消和截止期限 | 暂忙、停机、永久阻塞三个回归场景 |
| 麦克风 | 原 MicrophoneUplink、MicrophonePacketizer、OpusEncoder 不替换；补输出归属 | SETUP 响应后启动且不重复、无需下行首包、旧会话不能停掉新麦克风 |
| 中控/仪表 | 原 VideoDecoder 连接 SurfaceView / 原厂 Display 的 Presentation | SurfaceHolder 不被主动 release；等待包括退役解码器；副屏断流隔离 |
| 仪表协商 | 仅 HS5 保留 MAP3 对 instruments、ETA、altScreen 的兼容路径 | 无 uiContext 时可协商；没有新的 URL 列表时保留首选 URL；1600×600 |
| HUD/车道 | 复用纯路线/车道解析器和 Qisi Binder 边界，控制器维护指引过期 | 严格 TLV、陈旧指引、索引切换、能力字段门控；不代表手机已发送车道 |
| 按键/电话 | 复用 Qisi 按键分类和原控制队列；电话请求由既有 event 锁保护 | Android 媒体键、短长按/多指手势、电话状态纯逻辑 |
| 日夜/定位/车速 | 只读 PositionLight、HS5 新鲜 GNSS；手机请求 selector 4 后组合 PASCD | Binder 读写格式、NMEA 校验、车速声明门控；车速声明需实际 CAR_SPEED 权限 |
| 会话恢复 | 限 HS5 的条件式电话/Siri恢复，暂停和结束可撤销；同手机 A2DP 交接 | 来源变化、用户暂停、重复/晚到恢复、蓝牙归属与恢复 |
| 宿主生命周期 | Activity 管窗口和前台监听；控制器留存协议/HUD；重新接管补回副屏状态 | Surface 测试和源码接线；实车切回、后台与系统回收待验证 |
| 桌面与界面 | 旧版 Group/Domain/Ability/MoreApp、启动别名；旧首页/分类设置/主题/图标接入新宿主 | 启动入口、中文校验、切页与主题保留未保存值；车机桌面实测待补 |
| 连接过程 | 首页进度条读取既有 HandshakeTimeline；详情复用握手面板，取消撤销当前连接及自动重试 | 真实阶段推进、耗时不模拟完成、失败入口、1920×720 操作区域；手机实测进度、取消、详情及再次连接 |
| 断线退出 | 先通知 UI，再清理媒体；本机组丢失及已确认 iPhone 客户端离开直接结束展示，TCP 失联探测兜底 | 慢清理、旧会话/旧控制器、后台重新附加、初始空列表、其他客户端、乱序查询、两个 P2P 后端接线；实机状态见本次断线记录 |

撤下草稿中重复的 HongqiMediaSink、HongqiAudioStream、HongqiScreenStream、HongqiMicrophoneUplink、额外媒体/麦克风管线、未接入的采样与诊断类，以及 API 29+ P2P 重试/信道限制/配置记忆逻辑。也没有并行引入旧版逐音轨焦点协调器、全局导航混音状态改写或旧授权 UI。

旧版中已经验证的纯状态机与 OEM 服务边界可以复用；它们与上游机制重叠时，以上游为主，必要行为合并到原类。`HS5_MIGRATION.json` 逐项区分上游改写、HS5 边界复用/改写和新回归检查，并记录当前及来源源码哈希。旧 FAW-Play 工作区未改动，草稿源码备份保留在 workspace 的 work 目录。

单独检查 shared 模块额外发现上游 Media3 缺少 opt-in，以及部分权限撤销路径缺少显式处理；本轮补齐 scoped 注解和 SecurityException 错误处理，没有禁用整个模块的 Lint 检查。AndroidX 将标准 Activity 键盘回调的内部 bridge 标注为 RestrictedApi，该公开回调覆写保留一处有说明的局部 Lint 标注。

## hs5.2 的桌面与界面接入

mobile 的 `Group=GROUP CARPLAY`、`Domain=DOMAIN CARPLAY`、`MoreApp=true` 沿用旧版识别值；`Ability=com.shilapi.xcertplay.DiPlayActivity` 指向同名启动别名，由别名进入新的 CarPlayHostActivity。保留原 USB 入口，AAOS 构建单独保留宿主 launcher。没有复制旧 DiPlayActivity 的认证与媒体业务。

复用旧版 FawUiTheme、主题监听、首页连接插画和分类图标，新增 Hs5HomeView/Hs5SettingsView。设置分为连接、画面、声音、导航、权限、诊断、认证与外观、关于八类。中文资源覆盖设置、状态和保存校验；技术名词及协议标识保留原名称。

首页覆盖在既有视频视图上，主屏视频活动时隐藏。切页不重启控制器，主题刷新只重建界面，并保留选中分类、未保存值和原视频 View。保存/取消仍调用原宿主流程。宿主以横屏呈现；此次没有改变 MediaCodec 的选择、硬解判定或音视频链路。手机测试只能验证 UI，不能确认 Intel 核显解码。

设备卡片在 Android 12+ 查询配对设备前检查 BLUETOOTH_CONNECT，保留权限被撤销时的 SecurityException 处理；仅该读取 helper 对 Lint 无法追踪的 lambda 权限路径作局部说明标注。

按用户授权，现有实验身份配置到 OPPO 的 `no_backup/local-auth/`，不内置 APK。上游 CarPlayRuntimeConfig 要求 `content://` 文档地址，因此新增只读 LocalAuthDocumentsProvider；它只允许两个固定文档路径，拒绝写入、未知路径和其他 authority，manifest 设置 exported=false、grantUriPermissions=false。原 LOCAL_FILES 加载器及 mfi 算法保持固定上游。手机已观察到 `mfi local documents ready protocolMajor=3`；这说明设备能够加载身份并完成本地匹配校验，不能视作 iPhone 已接受身份。

手机早期测试曾因个人热点资源占用使用 MANUAL 后端；该结果保留为历史记录。实际配对后又发现 targetSdk 37 缺少 ACCESS_LOCAL_NETWORK，已在 shared manifest 声明，并在宿主的 API 37 无线权限请求中加入。重启复现了系统残留旧 P2P 组、新建组持续 busy 的问题；API 29+ 的 WifiP2pGroupManager 现在先查询旧组，仅在组主身份、网络名和凭据均匹配时移除，并等待组消失再创建新组。查询超时或组归属无法确认时不尝试删除，回收等待受原启动截止时间及取消状态约束。API 28 HS5 后端的原有归属检查保持不变。

此前连接界面构建已确认本地网络权限授予，当时配置为 WIFI_P2P。取消后重新连接只启动一次尝试，日志确认建组、Bonjour、RFCOMM、iAP2 CSM、无线 iAP2 隧道、蓝牙引导交接及 AirPlay 会话活动，没有 busy 或上述权限错误。完整音频播放、拾音及车辆功能验收仍开放，网络凭据未写入交付材料。

按用户明确选择，视频参考只用于连接过程显示。新增 Hs5ConnectionProgressView，显示真实阶段、经过秒数、完成标记、详情和取消；没有套用参考实现的固定 37 步。连接中的首页按钮禁用并显示“连接中…”。取消增加回调 generation、撤销自动重试、将旧详情标记为用户取消、清除连接归属并通过既有 teardown executor 关闭旧控制器和媒体 sink；再次打开后恢复既有启动流程。实机发现首页长状态文字被截断，已缩小标题字号并启用单行自适应；进度操作按钮扩大到 48 dp，保持原卡片高度。没有改变主屏切入条件、Surface 或解码器选择。

## 当前验证

hs5.2 历史 Gradle 检查：shared 313 项、common 78 项，共 **391 项测试，0 失败、0 错误、0 跳过**。包含 Robolectric、协议/状态纯测试及 loopback 媒体流测试。断线新增 49 项回归，覆盖通知先于慢清理、监听器异常、旧控制器失效、后台重新附加、TCP 参数独立降级、P2P/热点生命周期，以及确认当前 iPhone 曾关联之后的客户端离开；空列表、其他客户端、换会话、乱序查询和主动关闭均不会误报。保留此前中文设置、私有文档、连接进度及旧 P2P 组回收测试。这不是车机运行测试。

| 模块 | Lint 错误 | Lint 警告 |
|---|---:|---:|
| shared | 0 | 29 |
| common | 0 | 97 |
| mobile | 0 | 3 |
| automotive | 0 | 3 |

警告仍包括既有 API 弃用、国际化和视图可访问性等项目；新增一项 ViewConstructor 警告来自仅程序创建的连接进度 View，没有 XML inflation 用途。没有把“零错误”写成“没有警告”。

hs5.2 断线修复包曾更新到 OPPO PJZ110（API 37）。用户确认在 iPhone 设置中关闭 Wi-Fi 总开关后，记录到控制连接关闭及返回首页通知，两者间隔 11 毫秒；接收端 Wi-Fi 仍开启。随后将应用置前台，通过不等待画面静止的可访问性抓取与脱敏截图确认连接首页。此截图不用于计算退出时延，物理开关到可见首页的总时延、精确客户端离开兜底路径的运行时延及 HS5 实车验收仍未测。当前状态及绑定的 APK 哈希见 `phone-disconnect-validation.json`。退出通知与媒体清理分开，客户端离开通过系统广播后查询当前组确认，MAC 只在内存使用、不写入本次验证产物。主屏静止不作为断线依据。TCP 设置请求是空闲 2 秒、间隔 1 秒、3 次探测和 5000ms 用户超时，但内核、无线驱动及探针发送条件会影响实际时限，不能据参数承诺固定退出时间。

此前连接界面构建在同一 OPPO 上验证了真实连接进度、状态文字及操作区域，取消后显示“已取消连接”并恢复连接按钮；连续观察 8.08 秒，没有新的启动或重试。详情页明确显示用户取消，经过详情→设置→首页后仍保持暂停；再次点击“打开 CarPlay”恢复无线链路，建立 iAP2 隧道、完成蓝牙引导交接并进入活动 AirPlay 会话。该恢复只启动一次尝试，14.38 秒为历史构建的观测窗口，不作为普遍连接耗时保证；证据与该记录中的 APK 哈希绑定。

此前构建已实机检查八个中文设置页、浅色/深色/跟随车机、保存/取消及退出重开；其 phone-validation.json 含此前 APK 哈希，作为历史证据保留，不冒充本次构建对全部旧功能的重复验收。当前连接过程截图已遮盖输入值、配对名称和私人网络地址。

此前设备数据检查确认 LOCAL_FILES / AuthV3 加载成功，两个私有文件与本机输入一致，目录权限 0700、文件权限 0600，外部 UID 访问文档 Provider 被拒绝。当前配对 iPhone 已建立实际 AirPlay 会话；这不代表官方 MFi 资格，也不等于通话、拾音或 HS5 音视频已完整验收。当前记录未确认 Intel 解码器名称或硬解出帧。

两个 debug APK 均构建并通过 apksigner 验证，包含 x86 与 x86_64 等原生库。打包检查逐项扫描 APK 的文件名及解压内容，未包含本机认证文件或其完整字节。已有身份通过编译后的上游 AuthV3 实现验证，且对篡改挑战和错误长度进行了拒绝检查。

- [普通 Android 车机 APK](artifacts/hs5.3/xcertplay-1.4.0-hs5.3-mobile-debug.apk)
- [AAOS 入口 APK](artifacts/hs5.3/xcertplay-1.4.0-hs5.3-automotive-debug.apk)
- [机器可读验证记录](artifacts/hs5.3/verification.json)：测试、Lint、签名、ABI、APK SHA-256、认证检查及实车状态。
- [hs5.2 历史断线验证](artifacts/hs5.2/phone-disconnect-validation.json)：该构建 APK 的精确客户端匹配、已观测断开事件及其计时范围；物理开关到退出的总时延未测。
- [历史连接界面验证](artifacts/hs5.2/phone-connection-ui-validation.json) 与 [连接过程截图](artifacts/hs5.2/phone-connection-ui/)：此前构建的进度、取消、详情、恢复及无线链路。
- [历史手机运行验证记录](artifacts/hs5.2/phone-validation.json)：此前构建的八类页面、主题、操作、认证加载及当时网络状态，以记录内 APK 哈希为准。
- [手机私有身份配置记录](artifacts/hs5.2/phone-auth-configuration.json) 与 [脱敏界面截图](artifacts/hs5.2/phone-ui/)。
- [当前完整交互流程](INTERACTION-FLOW.zh-CN.md)
- [用户提供的无线 Surface 源码 ZIP 对照](SURFACE-ARCHIVE-REVIEW.zh-CN.md)：只读检查，未将其身份资产、热点回退或解码器实现并入当前工程。

`artifacts/` 根目录中原 1.4.0 构建属于历史上游基线，`artifacts/hs5.1/` 是上次适配及车机安装记录；本轮连接修复结果位于 `artifacts/hs5.3/`，hs5.2 记录保留为历史证据。两个新包是同一应用的不同入口构建，选择适合平台的一种即可。

## 实车验收仍开放

历史记录：2026-10-14 已通过 ADB 将 hs5.1 mobile APK 安装并启动到 HONG QI / t1c_acrn（Android 9、x86_64）车机，证据见 artifacts/hs5.1/vehicle-installation.json。hs5.2 与本轮 hs5.3 按用户要求先使用 OPPO 手机验证；尚未安装到车机。桌面识别值已接入，但车机 launcher 是否实际展示新版入口仍需 HS5 实测。实车握手、音频、拾音及显示验收仍待测试，旧版通过的现象不能记为新版通过。

| 验收项 | 已有证据与剩余步骤 |
|---|---|
| 冷/热连接与重连速度 | 生命周期和未知频率路径已验证；需记录车机冷启动、熄火再启动和连接耗时 |
| 连接后播放行为 | 当前不强制自动播放；需观察 iPhone 原播放器状态与系统媒体资源交接 |
| 音乐/提示/电话/Siri 路由 | 逻辑与缓冲测试通过；需确认东软功放路径、同时导航提示、音量、AEC 和通话输入输出 |
| 相机/其他 App 打断后恢复 | 保留已知 QQ/Siri 状态逻辑；微信相机退出、首次无声和任意第三方 App 释放资源仍需实车复验 |
| 高速路口图/ETA | 旧 MAP3 同源 COMPAT1 有恢复证据；当前保留其配置，但需新项目导航驶入路口复验 |
| HUD/原厂按键/车灯 | Binder 接线已整合；需确认权限、倒车/E-CALL 让位、前后台切回和日夜更新 |
| 车道元数据 | 旧 LANE1 实车未收到 0x5204、PresentLaneGuidance=false；当前声明/解析测试通过，仍不能认定车道功能完成 |
| 车辆定位/车速 | 实际 CAR_SPEED 权限存在才声明车速能力；需验证 GNSS 新鲜度、selector 4 请求和隧道内 PASCD 数据 |
| 身份接受 | 本地证书/私钥匹配已验证；iPhone 是否接受现有实验身份仍属于实车验收，不代表 MFi 认证 |

完整 Apple 车机接收端规范仍未取得。当前实现依据公开上游源码与已有车辆恢复证据，不能声称已经符合完整官方认证规范。

## 无线连接超时、失败反馈与信道恢复（2026-10-14）

本次针对“部分 iPhone 秒连、部分机型长时间等待”的差异补上了边界。Android 官方 BluetoothSocket 文档说明 `connect()` 会阻塞，`close()` 可立即中止；官方连接示例还要求在连接前调用 `BluetoothAdapter.cancelDiscovery()`。当前无线流程已在 RFCOMM 前停止系统蓝牙扫描，并将单个连接尝试限制为 8 秒、整组候选手机限制为 20 秒。

部分 Android 蓝牙栈会把 iPhone 报成 `COMPUTER`，并且 `getUuids()` 没有缓存 iAP2 UUID。此时对无 UUID 缓存且不属于扬声器/耳机的 COMPUTER 候选加入有限 RFCOMM 探测，同时优先接受明确的 iPhone/iPad/苹果名称；是否可用仍由 SDP 和 iAP2 CSM 握手决定。AirPlay TCP 监听器同时绑定当前热点实际地址，避免 P2P、STA 或 VPN 多网卡环境下接收错误接口的连接。

无线启动现在有单调阶段预算：建立 Wi-Fi 20 秒、蓝牙 20 秒、iAP2 识别 20 秒、MFi 验证 20 秒、等待 iPhone 加入 CarPlay Wi-Fi 25 秒、安全配对 30 秒、会话启动 20 秒，总预算 90 秒；底层无线 iAP2 初始引导另有 20 秒整体限制。预算是本项目的故障恢复策略，不是 Apple 私有 CarPlay 接收端规范中的官方数值。超时会显示中文失败原因并停止无界等待；配对 TLV 返回认证错误也会立即报告，避免界面长期停在“配对中”。AirPlay/Bonjour 注册或发现启动失败现在进入同一失败链路。

自动恢复只在无线网络建立或等待入网失败时请求重选 5 GHz 信道；身份认证、配对拒绝和已建立会话断开不会盲目换信道。API 29–33 在重试时请求兼容的非 DFS 5 GHz 频率；API 34+ 查询系统允许的 Wi-Fi Direct GO 频率后再选择候选；API 28 东软 HS5 没有公开的频率控制 API，保持系统选频并记录能力限制。首次尝试使用系统 5 GHz，失败后最多自动重试两次，频率候选按失败频率排除。热点成功后立即进入蓝牙阶段，蓝牙故障不误触发选频；等待入网超时先用 250 毫秒后台查询真实关联状态，已有客户端或未知时不主动请求改频。Android `WifiP2pConfig.Builder` 的频段/频率接口和 `WifiManager.getUsableChannels` 仅表达请求与可用性，最终仍由系统监管域、芯片和厂商驱动决定，不能保证某个信道一定成功。

公开依据：

- [BluetoothSocket](https://developer.android.com/reference/android/bluetooth/BluetoothSocket)
- [Android Bluetooth 连接示例](https://developer.android.com/develop/connectivity/bluetooth/connect-bluetooth-devices)
- [WifiP2pConfig.Builder.setGroupOperatingBand](https://developer.android.com/reference/android/net/wifi/p2p/WifiP2pConfig.Builder#setGroupOperatingBand(int))
- [WifiP2pConfig.Builder.setGroupOperatingFrequency](https://developer.android.com/reference/android/net/wifi/p2p/WifiP2pConfig.Builder#setGroupOperatingFrequency(int))
- [WifiManager.getUsableChannels](https://developer.android.com/reference/android/net/wifi/WifiManager#getUsableChannels(int,%20int))
- [NsdManager.discoverServices](https://developer.android.com/reference/android/net/nsd/NsdManager#discoverServices(java.lang.String,%20int,%20android.net.nsd.NsdManager.DiscoveryListener))
- [Apple CarPlay](https://developer.apple.com/carplay/)

Apple 公共页面能确认无线 CarPlay 使用 iPhone、蓝牙和 Wi-Fi，并指向 MFi 计划；完整接收端认证、iAP2 无线报文和官方超时阈值仍属于 MFi 受限资料，不能从公开页面推导。本实现的阶段和重试值因此只作为明确的工程策略。

本轮更完整的阶段、兼容性处理、官方来源和验收边界见 [无线连接修复对照](WIRELESS-CONNECTION.zh-CN.md)。hs5.2 的 391 项检查和断线运行记录是历史结果，本轮验证以 hs5.3 目录的记录为准。
