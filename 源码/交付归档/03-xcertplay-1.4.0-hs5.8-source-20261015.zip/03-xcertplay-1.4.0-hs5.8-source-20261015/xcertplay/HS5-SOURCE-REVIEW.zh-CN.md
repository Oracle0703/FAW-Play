# xcertplay 源码与 HS5 接入审查

> 这是改造前的源码审查记录。改造后的当前结构与验证结果见 [实现记录](HS5-IMPLEMENTATION.zh-CN.md) 和 [交互流程](INTERACTION-FLOW.zh-CN.md)。

2026-10-14。结论：应保留 xcertplay 的会话、媒体、输入和认证主干，将旧 App 中有依据的 HS5 差异接到对应边界。不能把旧 App 的问题修复集合当作必须整套迁移的新架构。

本次审查在用户指出“不要直接照搬”后进行。审查阶段未继续修改运行源码。此前生成的整套移植草稿仍在新项目工作区，尚未通过编译，不能作为迁移完成的版本使用。

审查基准是 https://github.com/shilapi/xcertplay 的固定提交 `551895a121f5fb22312331f3cd0d7b2857bb478f`，不是已经被迁移改动过的工作区。原始代码只读参考副本保存在 upstream（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream`，未随包交付）。旧 App 使用 FAW-Play 当前工作树；其 Git HEAD 不能代表现有修复。这里的“上游”指 xcertplay 源码，不指 Apple 官方接收端规范。没有获得完整受限 MFi/CarPlay 接收端规范，不能把源码行为写成 Apple 认证要求。

## 上游的实际接入链

宿主 Activity/设置创建 RuntimeConfig、AirPlayConfig 和 AndroidMediaSink，再交给 CarPlayController。控制器选择认证器和无线后端，附着 AirPlay 服务并发布 Bonjour，建立蓝牙 iAP2 bootstrap，发送无线配置与 CarPlay endpoint；手机进入 Wi-Fi AirPlay 后，按 SETUP 建立媒体流和 type130 iAP2 隧道。bootstrap 和隧道的交接由既有 ready/代次判断处理。

输出音频走 `AirPlaySession SETUP → CarPlayMediaEngine → AudioStream → AndroidMediaSink.AudioRenderer → MediaCodec/PCM → AudioTrack`。输入音频走 `SETUP 输入端口 → 响应发出 → MicrophoneUplink → AudioRecord/重采样/增益 → Opus或PCM → RTP加密 → 手机`。上游已经负责这两条链，HS5 适配不需要另起一套媒体引擎。

触摸、旋钮、电话/Siri 命令可以走已有 AirPlay HID/event 通道；Android MediaSession 的播放/暂停/切歌由控制器经当前 iAP2 会话发送。实体车机按键适配需要把 Qisi 事件接入这些出口，并保持通话状态与按下/释放语义。

主屏与副屏分别为110、111。仪表有两种不同数据来源：111视频承载地图/路口图；路线元数据用于 HUD/TBT。两者不能互相替代。

## 逐项处理结论

| 功能 | xcertplay 已有实现或源码事实 | HS5 合入方式 | 源码依据 |
| --- | --- | --- | --- |
| 认证 | 已有 `LOCAL_FILES`、证书/私钥匹配验证及 AuthV3 签名。 | 直接使用上游认证入口；旧 App 的认证代理、授权检查和认证代码不迁移。 | LocalMfiAuthenticationClient.kt（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream/shared/src/main/java/com/shilapi/xcertplay/mfi/LocalMfiAuthenticationClient.kt`，未随包交付） |
| 无线建立与蓝牙交接 | 已有 AirPlay 服务、Bonjour、RFCOMM bootstrap、type-130 运行隧道，以及等待隧道 ready 后关闭 bootstrap 的状态控制。 | 保留控制器主干；HS5 仅补网络后端/设备识别/原厂 A2DP 交接。把 RFCOMM 控制交接和原厂 A2DP 媒体交接分开管理。 | CarPlayController.kt（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream/shared/src/main/java/com/shilapi/xcertplay/orchestration/CarPlayController.kt`，未随包交付） |
| Android 9 无线网络 | API28 的 P2P 组主接口是 HS5 当前可验证的无线接入边界。 | HS5 只保留专用 P2P 组主后端、实际凭据读取、所有权和退出清理；不再包含 LocalOnlyHotspot 或手动热点回退。 | [CarPlayController.kt](shared/src/main/java/com/shilapi/xcertplay/orchestration/CarPlayController.kt) |
| 音乐/导航/电话/Siri 输出 | 已有 LPCM/AAC/Opus 解码、音频类型到 Android usage 的映射、AudioTrack 和媒体缓冲设置。 | 保留 AndroidMediaSink；只在 HS5 profile 中补经验证的路由选择。尤其不能把通用 AAOS 的 default/compatibility 映射全局改成旧版 HS5 映射。 | AudioChannelMapping.kt（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream/shared/src/main/java/com/shilapi/xcertplay/media/AudioChannelMapping.kt`，未随包交付） |
| 音频流隔离 | 引擎 StreamKey 为 session+type，但音频元数据和渲染器仍主要按 type 保存；同一 type 的不同 audioType 会替换。 | 在原引擎和原渲染器中补一致的流身份及会话归属，保留原 SETUP/TEARDOWN 行为和工具回调；不替换整套引擎。 | CarPlayMediaEngine.kt（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream/shared/src/main/java/com/shilapi/xcertplay/airplay/CarPlayMediaEngine.kt`，未随包交付） |
| 音频焦点与原厂播放器 | 已有 Activity 进入时申请媒体焦点、共享 AudioFocusSession、Media3 MediaSession 控制/歌曲信息。 | 先复用上游焦点机制；确有 HS5 usage/总线缺口时扩展同一管理器。旧版每轨 focus coordinator 不能与上游同时运行。A2DP 专用交接仅作用于本轮选中的 iPhone，并记录恢复责任。 | AndroidMediaSink.kt（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream/shared/src/main/java/com/shilapi/xcertplay/media/AndroidMediaSink.kt`，未随包交付） |
| 音乐抗抖与解码重试 | 已有可调 AudioTrack 容量、起播预缓冲和淡入；dequeueInputBuffer 无可用输入时会丢弃当前包。 | 旧版 AudioInputPump、耗尽后重缓冲和短尾段播放有可保留行为，但要嵌入原 renderer。容量、起播阈值、协议 audioLatencyMs 分开；旧版 500ms 起播/700ms 容量不是上游滑条同一个含义。 | AndroidMediaSink.kt（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream/shared/src/main/java/com/shilapi/xcertplay/media/AndroidMediaSink.kt`，未随包交付） |
| 其他 App 占用语音通道 | 上游按 audioType 静态映射 speechrecognition；旧版根据 NowPlaying、phone/speech 状态判断拍摄场景。 | 保留旧版状态判断的语义，接到上游 NowPlaying 和 AirPlay 命令回调，再由同一个 renderer 选路。状态不明确时保守处理；不迁移第二套播放流水线。 | SpeechAudioRoutingState.kt（外部历史资料：`FAW-Play/shared/src/main/java/com/shilapi/xcertplay/media/SpeechAudioRoutingState.kt`，未随包交付） |
| 中断后续播 | 上游具备媒体命令发送通道，但没有旧版 Call/Siri 条件恢复状态机。 | 同会话、同播放器、此前确在播放、无主动暂停、通话/语音已空闲时才补发 PLAY；复用上游媒体控制通道并保持按钮 release 时序。禁止连接成功后无条件 PLAY 或占用结束后定时强播。 | CarPlayController.kt（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream/shared/src/main/java/com/shilapi/xcertplay/orchestration/CarPlayController.kt`，未随包交付） |
| 麦克风回传 | SETUP 响应完成后启动；按协商位选 16/24/48k 编码输入，固定 16k 采集后重采样；Opus RTP 使用 48k 时间基准；已有增益、共享通信模式 lease。 | 保留 MicrophoneUplink、OpusEncoder、MicrophonePacketizer 和启动时序。HS5 的 VOICE_COMMUNICATION/VOICE_RECOGNITION、AEC/NS 或 pacing 只作为有证据的采集兼容选项；不能搬入旧版固定 960 样本模型。 | CarPlayMediaEngine.kt（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream/shared/src/main/java/com/shilapi/xcertplay/airplay/CarPlayMediaEngine.kt`，未随包交付） |
| 中控视频与 Surface | 已有 VideoWorkQueue、VideoDecodePump、VideoSyncGate、Surface 切换、等待初始帧、主屏关键帧恢复及显示统计。 | 保留原解码器。HS5 的 SurfaceView 仅作为宿主输出视图接到 setSurface/clearSurface；需要的阻塞隔离/Surface 生命周期保护修改原边界，不增加 HongqiVideoDecoder。 | AndroidMediaSink.kt（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream/shared/src/main/java/com/shilapi/xcertplay/media/AndroidMediaSink.kt`，未随包交付） |
| 仪表原生地图/路口图 | 已有 cluster 配置、110/111 解码和 altScreen/uiContext/showUI 状态；宿主现成仪表输出是网页/预览。 | 新增 HS5 物理 Display 的 Presentation 接上原 type111 Surface。保留旧版 instruments+ETA、安全区及 MAP3 兼容语义；协商开关只作用于 HS5 cluster 会话。路口图来自手机副屏视频，不用 HUD 元数据拼造。 | AirPlayInfoPlist.kt（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream/shared/src/main/java/com/shilapi/xcertplay/airplay/AirPlayInfoPlist.kt`，未随包交付） |
| 副屏故障隔离 | 原引擎 ScreenStream.onClosed 在任何屏流关闭后都调用 session.close()。 | 应在原 onClosed 中区分主屏110和副屏111；旧流回调不能关闭替换后的流。只断副屏不结束音乐/电话/主屏，是可独立保留的修复。 | CarPlayMediaEngine.kt（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream/shared/src/main/java/com/shilapi/xcertplay/airplay/CarPlayMediaEngine.kt`，未随包交付） |
| HUD 与仪表 TBT | 上游列出了路线消息/通信消息，但控制器收到帧主要只处理 NowPlaying；没有 Qisi HUD/仪表服务实现。 | 复用 iAP2 onIncoming，将路线解码后交给独立 HS5 车辆输出模块。普通 HUD/TBT、原生111地图、独立车道数据是三条输出链，分别维护状态和结束清理。 | CarPlayController.kt（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream/shared/src/main/java/com/shilapi/xcertplay/orchestration/CarPlayController.kt`，未随包交付） |
| 方向盘与旋钮/电话键 | AirPlaySession 已有 sendKnob/sendMedia/sendTelephony/invokeSiri；控制器已有 iAP2 媒体命令队列。 | Qisi 负责接收实体事件并判断短按/长按/页面归属，再调用既有通道。复用已有事件锁和队列；媒体命令必须选一个统一出口，电话键的接听/挂断/打开页面要参考真实通话状态。 | AirPlaySession.kt（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream/shared/src/main/java/com/shilapi/xcertplay/airplay/AirPlaySession.kt`，未随包交付） |
| 车灯与日夜 | 已有 setNightMode 的协议发送和待发送状态。 | 只新增 HS5 PositionLight 状态源，调用现有 setNightMode；保留 listener 注销、晚到回调和不可用时回退。 | AirPlaySession.kt（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream/shared/src/main/java/com/shilapi/xcertplay/airplay/AirPlaySession.kt`，未随包交付） |
| 车辆定位/车速 | 已有 AndroidCarPlayLocationProvider 和 iAP2 LocationInformation，通用定位可用 GPS/fused/network。 | HS5 配置下只采用新鲜 WGS84 车辆 GNSS；车速单独由只读 HAL source 提供。在 Location provider seam 组合，且真正传递手机请求的 selector4；仅加类和权限不算接通。 | AndroidCarPlayLocationProvider.kt（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream/shared/src/main/java/com/shilapi/xcertplay/location/AndroidCarPlayLocationProvider.kt`，未随包交付） |
| 网页显示/性能统计/后台会话 | 已有 MediaTap、媒体统计及 retained background session。 | 任何车辆扩展都必须保留这些上游用途；不能让旧版 backend 接收参数却不完整实现。Activity 管窗口，controller 管会话/OEM 输出，不能重复争用副屏。 | CarPlayHostActivity.kt（外部历史资料：`work/xcertplay-hs5-source-audit-20261014/upstream/common/src/main/java/com/shilapi/xcertplay/CarPlayHostActivity.kt`，未随包交付） |

## 已有草稿的具体问题

此前的草稿添加了 HongqiMediaSink、HongqiAudioStream、HongqiScreenStream、HongqiMicrophoneUplink，并大幅改写 CarPlayMediaEngine。这种方式扩大了维护面，也让原来的兼容假设与上游契约混在一起。应先回到原类做最小行为修正，只有平台专用服务和设备后端另设 HS5 实现。

存在三个已确认的边界差异：

1. 麦克风：旧版在首个下行包后启动，而上游测试明确要求 SETUP 响应后启动且不等待下行。上游同时支持16/24/48k协商、16k采集重采样以及48k Opus RTP时钟，旧版固定960输入样本模型不能直接替换。
2. 焦点：宿主仍保留上游 AudioFocusSession，HS5 backend 又引入旧版 AudioFocusCoordinator，形成两套策略。应明确同一会话的唯一焦点管理责任。
3. 设置：旧版500ms起播/700ms容量模型不能用硬编码覆盖上游媒体容量滑条。必须定义容量、预缓冲、重缓冲三个各自的参数和限制，避免界面保存值与实际运行值不一致。

最新草稿验证停在 `CarPlayMediaEngine.kt` 的 `requestedMicrophonePort` 引用缺失导致的编译失败。此次没有把这个错误单独补掉并继续批量移植，因为先需要纠正整合方式。尚无本轮可交付的新 HS5 APK；现有 artifacts 中的 APK 属于先前原始基线验证。

## 建议实现顺序与验收

先整理回上游主干并保留本地认证接入，然后按以下边界合入。每一步用上游测试与针对该行为的旧版回归检查，避免把旧版测试对旧结构的假设也原样照搬。

| 顺序 | 修改边界 | 必须确认的结果 |
| --- | --- | --- |
| 1 | 会话/媒体流身份与清理 | 旧会话回调不影响新会话；同type不同音频类别互不覆盖；副屏结束保留主屏、音乐和电话；SETUP启动麦克风及teardown正确 |
| 2 | HS5平台服务模块 | Qisi连接、注销与服务重连完整；原厂倒车/E-CALL优先级保留；方向盘与日夜调用上游输入/状态出口 |
| 3 | 原生仪表/HUD | Presentation接原type111 Surface；路线元数据走HUD/TBT；MAP3兼容开关和URL匹配局限在HS5；退出时清理原厂导航状态 |
| 4 | 原 renderer 音频兼容 | 解码输入重试、buffer进度、短音频尾段、必要路由选择分别验证；焦点唯一；用户暂停/换播放器不被恢复逻辑覆盖 |
| 5 | HS5网络/定位 | API28 legacy P2P创建和实际凭据正确；蓝牙bootstrap与运行隧道边界清楚；车辆GNSS新鲜/坐标系有效；手机请求车速后才发送 |
| 6 | 构建与实车 | 编译、测试、lint、APK验签后再做新包实车验收；首次配对、已配对重连、音频中断和高速路口各自记录 |

连接慢需要分阶段记录蓝牙候选识别、热点准备、bootstrap认证、手机关联、AirPlay SETUP、首个视频与音频输出时间。不能仅因切换后端便宣称连接加快。

## 历史验证不能替代新集成验收

旧 App 的 MAP3 对照包曾获得用户反馈：高速路口图以及 ETA、剩余时间/距离、转向箭头恢复。这是保留该兼容语义的重要依据，但原因尚未定位到某一条具体协议消息。新项目合入后仍需复测。

LANE1 是能力声明和解析链已补齐、实车显示验收失败：现场未收到0x5204，PresentLaneGuidance为false。不能把独立车道提示列为“已经可用”。原生111视频能否画车道又是另一个出口。

旧 App 的音频改善有不同证据范围：Siri恢复和原厂媒体交接有HS5历史确认；QQ拍摄路由修复缺少独立实车验收，微信拍摄退出偶发续播、无线音频和首次配对仍有未闭环样本。新架构应保留已验证行为，不能把所有补丁统称为已解决。

旧 App、认证文件与先前基线构建没有在此次审查中被修改；当前移植工作区仍待按上述结论重新整理。
