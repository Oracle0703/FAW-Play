package com.shilapi.xcertplay

import android.graphics.SurfaceTexture
import android.view.Surface
import android.view.SurfaceHolder
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito.*
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowBuild

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28, 33], manifest = Config.NONE)
class CarPlayMainDisplayTest {
    @Test fun oppoNativeMainDisplayUsesDirectSurfaceAndRetainsGestureLayerDuringWebToggles() {
        ShadowBuild.setModel("PJZ110")
        ShadowBuild.setDevice("OPPO")
        val activity = Robolectric.buildActivity(CarPlayHostActivity::class.java).get()
        activity.javaClass.getDeclaredMethod("buildContentView").apply { isAccessible = true }.invoke(activity)
        val original = field(activity, "videoView").get(activity) as VideoSurfaceView
        val overlay = field(activity, "gestureOverlay").get(activity) as View
        val parent = original.parent as ViewGroup
        val children = parent.childCount
        val index = parent.indexOfChild(original)
        val callback = shadowOf(original).fakeSurfaceHolder.callbacks.single()
        val surface = mock(Surface::class.java)
        val holder = mock(SurfaceHolder::class.java)
        `when`(holder.surface).thenReturn(surface)
        callback.surfaceCreated(holder)
        assertSame(surface, field(activity, "currentSurface").get(activity))

        configureWeb(activity, CarPlayWebDisplayConfig(enabled = true))
        val web = field(activity, "videoView").get(activity) as TextureView
        assertSame(web, parent.getChildAt(index))
        assertSame(parent, overlay.parent)
        assertEquals(children, parent.childCount)
        assertNull(field(activity, "currentSurface").get(activity))
        verify(surface, never()).release()
        callback.surfaceCreated(holder)
        assertNull("Retired holder cannot take ownership again", field(activity, "currentSurface").get(activity))

        // The app owns the TextureView's wrapper Surface, but never the holder's Surface.
        val wrapper = mock(Surface::class.java)
        field(activity, "currentSurface").set(activity, wrapper)
        field(activity, "currentSurfaceTexture").set(activity, mock(SurfaceTexture::class.java))
        configureWeb(activity, CarPlayWebDisplayConfig(enabled = true, preview = false))
        assertSame(web, field(activity, "videoView").get(activity))
        assertEquals(View.INVISIBLE, web.visibility)
        configureWeb(activity, CarPlayWebDisplayConfig())
        assertTrue(field(activity, "videoView").get(activity) is VideoSurfaceView)
        assertSame(parent, overlay.parent)
        assertEquals(children, parent.childCount)
        assertNull(web.surfaceTextureListener)
        assertNull(field(activity, "currentSurface").get(activity))
        verify(wrapper).release()
        verify(surface, never()).release()
        assertNull(field(activity, "controller").get(activity))
    }

    private fun configureWeb(activity: CarPlayHostActivity, config: CarPlayWebDisplayConfig) {
        activity.javaClass.getDeclaredMethod("setWebDisplayConfig", Int::class.javaPrimitiveType,
            CarPlayWebDisplayConfig::class.java).apply { isAccessible = true }.invoke(activity, 110, config)
    }
    private fun field(activity: CarPlayHostActivity, name: String) =
        activity.javaClass.getDeclaredField(name).apply { isAccessible = true }
}
