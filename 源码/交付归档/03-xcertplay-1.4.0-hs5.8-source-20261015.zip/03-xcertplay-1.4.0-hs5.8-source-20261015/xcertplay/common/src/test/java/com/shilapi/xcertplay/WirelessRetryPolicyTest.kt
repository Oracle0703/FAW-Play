package com.shilapi.xcertplay

import org.junit.Assert.*
import org.junit.Test

class WirelessRetryPolicyTest {
    @Test fun atMostTwoAutomaticRetriesAreScheduled() {
        val policy = WirelessRetryPolicy()
        assertEquals(2_000L, policy.next(true, null)!!.delayMillis)
        assertEquals(4_000L, policy.next(true, 5180)!!.delayMillis)
        assertNull(policy.next(true, 5745))
        assertTrue(policy.exhausted)
    }

    @Test fun radioRecoveryRecordsFailedFrequencyButPairingFailureDoesNotRetry() {
        val policy = WirelessRetryPolicy()
        assertNotNull(policy.next(true, 5180))
        assertEquals(5180, policy.failedFrequencyMHz)
        policy.reset()
        assertNull(policy.next(false, null, retryable = false))
        assertTrue(policy.exhausted)
    }

    @Test fun nonRadioFailureKeepsSelectionAndExhaustionCannotRestartUntilReset() {
        val policy = WirelessRetryPolicy()
        assertEquals(1, policy.next(true, 5180)!!.radioAttempt)
        assertEquals(1, policy.next(false, 5745)!!.radioAttempt)
        assertEquals(5180, policy.failedFrequencyMHz)
        assertNull(policy.next(false, null))
        assertNull(policy.next(true, 5745))
        assertEquals(3, policy.failures)
        policy.reset()
        assertEquals(0, policy.failures)
        assertEquals(0, policy.radioAttempt)
        assertNull(policy.failedFrequencyMHz)
        assertEquals(2, policy.next(false, null)!!.attempt)
    }
}
