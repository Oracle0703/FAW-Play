package com.shilapi.xcertplay

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.RadioButton
import android.widget.TextView
import com.shilapi.xcertplay.orchestration.MfiTarget
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowBuild
import java.util.concurrent.atomic.AtomicBoolean

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "zh-rCN-w1920dp-h720dp-land-mdpi", manifest = Config.NONE)
class Hs5SettingsUiTest {
    private lateinit var activity: CarPlayHostActivity

    @Before fun setup() {
        ShadowBuild.setModel("HONG QI")
        ShadowBuild.setDevice("t1c_acrn")
        val context = RuntimeEnvironment.getApplication()
        listOf("xcertplay_airplay", "xcertplay_hs5", "faw_ui").forEach {
            context.getSharedPreferences(it, Context.MODE_PRIVATE).edit().clear().commit()
        }
        activity = Robolectric.buildActivity(CarPlayHostActivity::class.java).get()
        invoke("loadPersistedSettings")
    }

    private fun invoke(name: String): Any? = activity.javaClass.getDeclaredMethod(name).apply { isAccessible = true }.invoke(activity)
    private fun field(name: String) = activity.javaClass.getDeclaredField(name).apply { isAccessible = true }
    private fun settings(): Hs5ManagementView = (invoke("buildSettingsMenu") as Hs5ManagementView).also {
        field("settingsMenu").set(activity, it)
        activity.setContentView(FrameLayout(activity).apply { addView(it, ViewGroup.LayoutParams(-1, -1)) })
    }
    private fun views(root: View): List<View> = listOf(root) + if (root is ViewGroup) (0 until root.childCount).flatMap { views(root.getChildAt(it)) } else emptyList()
    private fun button(root: View, text: String) = views(root).filterIsInstance<Button>().single { it.text.toString() == text }
    private fun prefs() = activity.getSharedPreferences("xcertplay_airplay", Context.MODE_PRIVATE).all.toMap()

    @Test fun managementDoesNotExposeTechnicalTuningOrStartTheController() {
        val root = settings()
        assertFalse(views(root).any { it is android.widget.SeekBar || it is RadioButton || it is EditText })
        assertNull(field("controller").get(activity))
        assertTrue(views(root).filterIsInstance<TextView>().any { it.text.toString().contains("Ultra") })
    }

    @Test fun historicalExperimentalParametersCannotOverrideFixedHs5Defaults() {
        activity.getSharedPreferences("xcertplay_airplay", Context.MODE_PRIVATE).edit()
            .putBoolean("hevc_enabled", true).putInt("display_fps", 60)
            .putInt("display_scale_tenths", 3).putInt("display_width_physical_mm", 100)
            .putInt("main_media_audio_buffer_duration_ms", 100).putInt("microphone_gain_percent", 250).commit()
        invoke("loadPersistedSettings")
        assertFalse(field("hevcEnabled").getBoolean(activity))
        assertFalse(field("hevcSoftwareDecoderEnabled").getBoolean(activity))
        assertEquals(30, field("fps").getInt(activity))
        assertEquals(10, field("displayScaleTenths").getInt(activity))
        assertEquals(300, field("widthPhysicalMm").getInt(activity))
        assertEquals(500, field("mainMediaAudioBufferDurationMs").getInt(activity))
        assertEquals(100, field("microphoneGainPercent").getInt(activity))
        assertNull(field("controller").get(activity))
    }

    @Test fun openingManagementKeepsAnActiveConnectionGeneration() {
        settings()
        field("connectionRequested").setBoolean(activity, true)
        field("activeScreenStreamTypes").set(activity, mutableSetOf(110))
        val generation = field("restartGeneration").getInt(activity)
        invoke("openSettingsMenu")
        assertTrue(field("menuOpen").getBoolean(activity))
        assertEquals(generation, field("restartGeneration").getInt(activity))
        assertTrue((field("activeScreenStreamTypes").get(activity) as Set<*>).contains(110))
        field("connectionRequested").setBoolean(activity, false)
        invoke("closeManagement")
        assertFalse(field("menuOpen").getBoolean(activity))
        assertEquals(generation, field("restartGeneration").getInt(activity))
    }

    @Test fun homeAndThemeRedrawOnlyDispatchTheActionTheUserChooses() {
        var connects = 0
        var selected = -1
        val home = Hs5HomeView(activity, { selected = it }, { connects++ }, {}, {}, {}, {})
        home.setStatus("等待已配对的 iPhone")
        repeat(3) { home.redraw() }
        assertEquals(0, connects)
        button(home, "导航与 HUD").performClick()
        assertEquals(3, selected)
        assertEquals(0, connects)
        button(home, "打开 CarPlay").performClick()
        assertEquals(1, connects)
        assertTrue(views(home).filterIsInstance<TextView>().any { it.text.toString() == "等待已配对的 iPhone" })
    }

    @Test fun homeKeepsTimeoutReasonAndRetryCountVisibleAfterThemeRedraw() {
        val home = Hs5HomeView(activity, {}, {}, {}, {}, {}, {})
        val failure = "连接失败：等待手机加入 Wi-Fi 超时；2 秒后第 2/3 次尝试，重新选择无线信道"
        home.setStatus(failure)
        home.redraw()
        val status = views(home).filterIsInstance<TextView>().single { it.tag == "hs5_connection_status" }
        assertEquals(failure, status.text.toString())
        assertEquals(3, status.maxLines)
        assertTrue(button(home, "打开 CarPlay").isEnabled)
    }

    @Test fun connectionProgressAdvancesOnlyWhenTheRealHandshakeAdvances() {
        val timeline = HandshakeTimeline(true, System.currentTimeMillis() - 90_000)
        val progress = Hs5ConnectionProgressView(activity, {}, {}, {})
        timeline.accept("STEP mfi/start: preparing", System.currentTimeMillis())
        progress.bind(timeline, "准备认证")
        assertTrue(views(progress).filterIsInstance<TextView>().any { it.text.toString() == "无线连接 · 第 1 / 9 阶段" })
        assertTrue(views(progress).any { it.contentDescription == "准备认证：进行中" })
        assertFalse(views(progress).any { it.contentDescription == "准备认证：完成" })
        timeline.accept("STEP mfi/ready: local files", System.currentTimeMillis())
        timeline.accept("STEP wifi/ap: starting", System.currentTimeMillis())
        progress.bind(timeline, "建立连接")
        assertTrue(views(progress).filterIsInstance<TextView>().any { it.text.toString() == "无线连接 · 第 3 / 9 阶段" })
        assertTrue(views(progress).any { it.contentDescription == "准备认证：完成" })
        assertTrue(views(progress).any { it.contentDescription == "建立 Wi-Fi 连接：进行中" })
    }

    @Test fun failedHandshakeKeepsCancellationAvailableAndAllowsRetry() {
        val timeline = HandshakeTimeline(true, System.currentTimeMillis())
        timeline.accept("STEP wifi/ap: starting", System.currentTimeMillis())
        timeline.fail("Connection failed", "Wi-Fi unavailable", System.currentTimeMillis())
        var connecting = true
        val progress = Hs5ConnectionProgressView(activity, {}, {}, { connecting = it })
        progress.bind(timeline, "Wi-Fi Direct 暂不可用")
        assertFalse(connecting)
        assertTrue(views(progress).filterIsInstance<TextView>().any { it.text.toString() == "连接未完成" })
        assertEquals(View.VISIBLE, button(progress, "取消").visibility)
        progress.bind(null, "已取消连接")
        assertEquals(View.GONE, button(progress, "取消").visibility)
        assertTrue(views(progress).filterIsInstance<TextView>().any { it.text.toString() == "已取消连接" })
    }

    @Test fun progressActionsFitTheHs5HomeCardWhileConnecting() {
        val timeline = HandshakeTimeline(true, System.currentTimeMillis())
        timeline.accept("STEP mfi/start: preparing", System.currentTimeMillis())
        val home = Hs5HomeView(activity, {}, {}, {}, {}, {}, {})
        home.bind(timeline)
        home.measure(View.MeasureSpec.makeMeasureSpec(1920, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(720, View.MeasureSpec.EXACTLY))
        home.layout(0, 0, 1920, 720)
        assertFalse(button(home, "连接中…").isEnabled)
        listOf("查看全部步骤", "取消").forEach { title ->
            val control = button(home, title)
            val bounds = android.graphics.Rect()
            control.getDrawingRect(bounds)
            home.offsetDescendantRectToMyCoords(control, bounds)
            assertTrue(android.graphics.Rect(0, 0, 1920, 720).contains(bounds))
            assertTrue(control.width > 0 && control.height >= 40)
        }
    }

}
