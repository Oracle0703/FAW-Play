package com.shilapi.xcertplay

import android.view.View
import com.shilapi.xcertplay.airplay.*
import com.shilapi.xcertplay.orchestration.CarPlayStatus
import java.net.Socket
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import android.os.Looper

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class Hs5DisconnectUiTest {
    private lateinit var activity: CarPlayHostActivity
    private lateinit var home: Hs5HomeView
    @Before fun setup() {
        activity = Robolectric.buildActivity(CarPlayHostActivity::class.java).get()
        Hs5OnboardingProgress(activity).complete()
        home = Hs5HomeView(activity, {}, {}, {}, {}, {}, {})
        field("homeView").set(activity, home)
        field("connectionRequested").setBoolean(activity, true)
        field("activeScreenStreamTypes").set(activity, mutableSetOf(110, 111))
        home.visibility = View.GONE
    }
    private fun field(name: String) = activity.javaClass.getDeclaredField(name).apply { isAccessible = true }
    private fun listener(generation: Int = 0) = activity.javaClass.getDeclaredMethod("createSessionListener", Int::class.javaPrimitiveType)
        .apply { isAccessible = true }.invoke(activity, generation) as AirPlaySessionListener
    private fun session() = AirPlaySession(Socket(), AirPlayConfig("test", "test", "", "1", AirPlayDisplayConfig(800, 480)),
        AirPlayIdentity.generate(), PairingStore(), null, object : AirPlaySessionListener {}, object : AirPlayMediaHandler {})
    private fun idle() = shadowOf(Looper.getMainLooper()).idle()

    @Test fun disconnectShowsHomeBeforeCleanupCompletesAndLateStreamCannotHideIt() {
        val session = session()
        field("activeAirPlaySession").set(activity, session)
        listener().onSessionDisconnected(session)
        idle()
        assertEquals(View.VISIBLE, home.visibility)
        assertNull(field("activeAirPlaySession").get(activity))
        assertTrue((field("activeScreenStreamTypes").get(activity) as Set<*>).isEmpty())
        assertTrue(field("reconnectScheduled").getBoolean(activity))
        assertEquals(1, field("restartGeneration").getInt(activity))
        activity.javaClass.getDeclaredMethod("onScreenStreamStateChanged", Int::class.javaPrimitiveType,
            Int::class.javaPrimitiveType, Boolean::class.javaPrimitiveType).apply { isAccessible = true }
            .invoke(activity, 0, 110, true)
        idle()
        assertEquals(View.VISIBLE, home.visibility)
        // A new session from the retired controller must wait for the scheduled fresh stack.
        val replacement = session()
        try {
            listener(0).onSessionActive(replacement)
            idle()
            assertNull(field("activeAirPlaySession").get(activity))
            assertEquals(View.VISIBLE, home.visibility)
        } finally { replacement.close() }
        session.close()
    }

    @Test fun disconnectDuringManagementStillRetiresTheSessionAndSchedulesRecovery() {
        val current = session()
        try {
            field("menuOpen").setBoolean(activity, true)
            field("activeAirPlaySession").set(activity, current)
            listener().onSessionDisconnected(current)
            idle()
            assertNull(field("activeAirPlaySession").get(activity))
            assertTrue((field("activeScreenStreamTypes").get(activity) as Set<*>).isEmpty())
            assertFalse(field("reconnectScheduled").getBoolean(activity))
            assertNotNull(field("pendingManagementRecovery").get(activity))
            assertTrue(field("menuOpen").getBoolean(activity))
            assertEquals(View.GONE, home.visibility)
            activity.javaClass.getDeclaredMethod("closeManagement").apply { isAccessible = true }.invoke(activity)
            assertFalse(field("menuOpen").getBoolean(activity))
            assertNull(field("pendingManagementRecovery").get(activity))
            assertTrue(field("reconnectScheduled").getBoolean(activity))
        } finally { current.close() }
    }

    @Test fun oldSessionAndOldControllerCannotExitTheCurrentSession() {
        val old = session(); val current = session()
        try {
            field("activeAirPlaySession").set(activity, current)
            listener().onSessionDisconnected(old)
            listener(-1).onSessionDisconnected(current)
            listener().onSessionEnded(old)
            idle()
            assertSame(current, field("activeAirPlaySession").get(activity))
            assertEquals(View.GONE, home.visibility)
            assertFalse(field("reconnectScheduled").getBoolean(activity))
        } finally { old.close(); current.close() }
    }

    @Test fun confirmedStackFailureShowsHomeWithoutWaitingForRestartDelay() {
        @Suppress("UNCHECKED_CAST")
        val reporter = activity.javaClass.getDeclaredMethod("createStatusReporter", Int::class.javaPrimitiveType)
            .apply { isAccessible = true }.invoke(activity, 0) as (CarPlayStatus) -> Unit
        val worker = Thread { reporter(CarPlayStatus.Failed("Wireless hotspot stopped")) }.apply { start() }
        worker.join(3_000)
        idle()
        assertEquals(View.VISIBLE, home.visibility)
        assertTrue((field("activeScreenStreamTypes").get(activity) as Set<*>).isEmpty())
        assertTrue(field("reconnectScheduled").getBoolean(activity))
    }
}
