package com.shilapi.xcertplay

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "zh-rCN-w1920dp-h720dp-land-mdpi", manifest = Config.NONE)
class Hs5OnboardingUiTest {
    private lateinit var context: Context
    private var actions = 0
    private var selectedStep: Hs5OnboardingStep? = null
    private val ready = Hs5SetupCheck(Hs5CheckState.READY, "已检查")

    @Before fun setup() {
        context = RuntimeEnvironment.getApplication()
        context.getSharedPreferences("hs5_first_use", Context.MODE_PRIVATE).edit().clear().commit()
        actions = 0
        selectedStep = null
    }

    private fun callbacks() = Hs5OnboardingCallbacks(
        onMoveTo = { selectedStep = it }, onRefreshEnvironment = { actions++ },
        onRequestMicrophone = { actions++ }, onRequestLocation = { actions++ },
        onRequestWirelessPermissions = { actions++ }, onCheckUpdates = { actions++ },
        onInstallUpdate = { actions++ }, onStartBinding = { actions++ }, onRedeemCode = { actions++ },
        onCancelBinding = { actions++ }, onConnect = { actions++ }, onCancelConnection = { actions++ },
        onConnectionDetails = { actions++ }, onFinish = { actions++ },
    )

    private fun snapshot(step: Hs5OnboardingStep) = Hs5OnboardingSnapshot(
        step, ready, ready, ready, ready, Hs5PermissionStatus.NOT_REQUESTED, Hs5PermissionStatus.NOT_REQUESTED,
    )

    private fun views(root: View): List<View> = listOf(root) + if (root is ViewGroup)
        (0 until root.childCount).flatMap { views(root.getChildAt(it)) } else emptyList()

    @Test fun recreatingTheFlowRestoresNavigationWithoutGrantingPermissionsOrCompletingSetup() {
        Hs5OnboardingProgress(context).moveTo(Hs5OnboardingStep.CONNECTION)
        val restored = Hs5OnboardingProgress(context)
        assertEquals(Hs5OnboardingStep.CONNECTION, restored.step)
        assertFalse(restored.completed)
        val denied = snapshot(restored.step).copy(wirelessPermission = Hs5PermissionStatus.DENIED)
        assertFalse(denied.canConnect)
        val view = Hs5OnboardingView(context, callbacks()).apply { bind(denied) }
        assertFalse(view.findViewWithTag<Button>("hs5_setup_continue").isEnabled)
        assertEquals(0, actions)
    }

    @Test fun deniedMicrophoneAndLocationRemainOptionalAndPermanentDenialDoesNotOpenSettings() {
        val state = snapshot(Hs5OnboardingStep.PERMISSIONS).copy(
            microphone = Hs5PermissionStatus.PERMANENTLY_DENIED, location = Hs5PermissionStatus.DENIED,
        )
        val view = Hs5OnboardingView(context, callbacks()).apply { bind(state) }
        assertNull(view.findViewWithTag<Button>("hs5_setup_microphone"))
        assertTrue(view.findViewWithTag<Button>("hs5_setup_continue").isEnabled)
        view.findViewWithTag<Button>("hs5_setup_continue").performClick()
        assertEquals(Hs5OnboardingStep.UPDATE, selectedStep)
        assertEquals(0, actions)
        assertTrue(state.copy(step = Hs5OnboardingStep.CONNECTION).canConnect)
    }

    @Test fun networkFailureIsDisplayedAndCanBeSkippedWithoutClaimingAnUpToDateVersion() {
        val state = snapshot(Hs5OnboardingStep.UPDATE).copy(
            update = Hs5UpdateStatus(Hs5UpdateState.FAILED, "无法连接更新服务，请稍后重试"),
        )
        val view = Hs5OnboardingView(context, callbacks()).apply { bind(state) }
        assertEquals(state.update.detail, view.findViewWithTag<TextView>("hs5_update_status").text.toString())
        assertNull(view.findViewWithTag<Button>("hs5_install_update"))
        view.findViewWithTag<Button>("hs5_setup_continue").performClick()
        assertEquals(Hs5OnboardingStep.LICENSE, selectedStep)
        assertEquals(0, actions)
    }

    @Test fun freeUsersCanSkipBindingButFailedMfiReadinessStillBlocksConnection() {
        val view = Hs5OnboardingView(context, callbacks())
        view.bind(snapshot(Hs5OnboardingStep.LICENSE))
        view.findViewWithTag<Button>("hs5_setup_continue").performClick()
        assertEquals(Hs5OnboardingStep.CONNECTION, selectedStep)
        view.bind(snapshot(Hs5OnboardingStep.CONNECTION).copy(
            authentication = Hs5SetupCheck(Hs5CheckState.FAILED, "内置认证材料不可用"),
        ))
        assertFalse(view.findViewWithTag<Button>("hs5_setup_continue").isEnabled)
        assertEquals(0, actions)
    }

    @Test fun enteringOrRefreshingAViewNeverRequestsPermissionsBindsOrStartsConnecting() {
        val view = Hs5OnboardingView(context, callbacks())
        Hs5OnboardingStep.entries.forEach { step -> repeat(2) { view.bind(snapshot(step)) } }
        assertEquals(0, actions)
        assertNull(selectedStep)
    }

    private fun managementCallbacks() = Hs5ManagementCallbacks(
        onBack = { actions++ }, onRequestMicrophone = { actions++ }, onRequestLocation = { actions++ },
        onRequestWirelessPermissions = { actions++ }, onCheckUpdates = { actions++ }, onInstallUpdate = { actions++ },
        onStartBinding = { actions++ }, onRedeemCode = { actions++ }, onCancelBinding = { actions++ },
        onInstrumentPermission = { actions++ }, onToggleUltra = { actions++ },
        onManagePhones = { actions++ }, onDiagnostics = { actions++ },
        onReconnect = { actions++ },
    )

    private fun managementState() = Hs5ManagementSnapshot(
        Hs5PermissionStatus.GRANTED, Hs5PermissionStatus.GRANTED, ready,
        Hs5LicenseStatus(Hs5LicenseState.ACTIVE, "授权有效"), Hs5UpdateStatus(),
        Hs5InstrumentPermission.NEEDED, "当前仪表地图需要系统悬浮窗特殊授权", false, false,
        "当前版本尚未接入 Apple CarPlay Ultra，暂不可开启。",
    )

    @Test fun anAuthorizedUserStillCannotEnableUnimplementedAppleCarPlayUltra() {
        val state = managementState()
        val view = Hs5ManagementView(context, managementCallbacks()).apply { bind(state) }
        val control = view.findViewWithTag<Switch>("hs5_ultra_switch")
        assertFalse(control.isEnabled)
        assertFalse(control.isChecked)
        assertEquals(state.ultraUnavailableReason, view.findViewWithTag<TextView>("hs5_ultra_status").text.toString())
        control.isChecked = true
        assertEquals(0, actions)
        assertTrue(view.findViewWithTag<Button>("hs5_instrument_permission").isEnabled)
        assertFalse(views(view).filterIsInstance<Button>().any { it.text.contains("保存并重连") })
    }

    @Test fun instrumentPermissionPromptIsOnlyOfferedToAnAuthorizedEnhancedUser() {
        val view = Hs5ManagementView(context, managementCallbacks()).apply {
            bind(managementState().copy(license = Hs5LicenseStatus()))
        }
        assertNull(view.findViewWithTag<Button>("hs5_instrument_permission"))
        assertFalse(view.findViewWithTag<Switch>("hs5_ultra_switch").isEnabled)
        assertEquals(0, actions)
    }

    @Test fun reconnectIsOnlyOfferedDuringAnActiveSessionAndRequiresAnExplicitClick() {
        val view = Hs5ManagementView(context, managementCallbacks())
        view.bind(managementState())
        assertNull(view.findViewWithTag<Button>("hs5_reconnect"))
        view.bind(managementState().copy(sessionActive = true))
        assertEquals(0, actions)
        assertTrue(views(view).filterIsInstance<TextView>().any {
            it.text.toString() == "连接期间更改权限或绑定授权，部分功能在下次连接时生效。"
        })
        val reconnect = view.findViewWithTag<Button>("hs5_reconnect")
        assertEquals("断开并重新连接", reconnect.text.toString())
        assertTrue(reconnect.isEnabled)
        assertTrue(reconnect.isFocusable)
        reconnect.performClick()
        assertEquals(1, actions)
        view.bind(managementState().copy(sessionActive = false))
        assertNull(view.findViewWithTag<Button>("hs5_reconnect"))
        assertEquals(1, actions)
    }

    @Test fun firstUsePrimaryActionsFitTheHs5ScreenForEveryStep() {
        val view = Hs5OnboardingView(context, callbacks())
        Hs5OnboardingStep.entries.forEach { step ->
            view.bind(snapshot(step))
            view.measure(View.MeasureSpec.makeMeasureSpec(1920, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(720, View.MeasureSpec.EXACTLY))
            view.layout(0, 0, 1920, 720)
            val button = view.findViewWithTag<Button>("hs5_setup_continue")
            val bounds = android.graphics.Rect()
            button.getDrawingRect(bounds)
            view.offsetDescendantRectToMyCoords(button, bounds)
            assertTrue(android.graphics.Rect(0, 0, 1920, 720).contains(bounds))
            assertTrue(button.width > 0 && button.height >= 48)
        }
    }
}
