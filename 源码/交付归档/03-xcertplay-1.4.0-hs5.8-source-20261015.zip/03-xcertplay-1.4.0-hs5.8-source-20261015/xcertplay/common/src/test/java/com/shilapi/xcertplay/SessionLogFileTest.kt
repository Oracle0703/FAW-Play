package com.shilapi.xcertplay

import com.shilapi.xcertplay.airplay.VideoCodec
import org.junit.Assert.*
import org.junit.Test
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.nio.file.Files
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

class SessionLogFileTest {
    @Test fun rotationKeepsHandshakeAndWholeRecentRecords() {
        val file = Files.createTempFile("xcert-log", ".txt").toFile()
        try {
            val records = (0..100).map { "record-$it\n${"x".repeat(300)}\nend-$it" }
            SessionLogFile(file, maxBytes = 8192, headLimitBytes = 2048).use { log ->
                log.reset("handshake-header")
                // Exercise retention rather than queue overload; overload has separate coverage.
                records.chunked(16).forEach { batch ->
                    batch.forEach(log::append)
                    log.flush()
                }
            }
            val retained = file.readText()
            assertTrue(retained.startsWith("handshake-header\n${records.first()}\n"))
            assertTrue(retained.endsWith("${records.last()}\n"))
            assertTrue(retained.contains("LOG RETENTION"))
            assertTrue(file.length() <= 8192)
            for (i in records.indices) {
                assertEquals(retained.contains("record-$i\n"), retained.contains("\nend-$i\n"))
            }
        } finally { file.delete() }
    }

    @Test fun oversizedTextRemainsValidUtf8AndReportsTruncation() {
        val file = Files.createTempFile("xcert-log", ".txt").toFile()
        try {
            SessionLogFile(file, maxBytes = 8192, headLimitBytes = 2048).use { log ->
                log.reset("header")
                log.append("原始数据".repeat(4000))
            }
            val retained = file.readText()
            assertTrue(retained.startsWith("header\nLOG TRUNCATED"))
            assertFalse(retained.contains('\uFFFD'))
            assertTrue(file.length() <= 8192)
        } finally { file.delete() }
    }

    @Test fun rawVideoIsOptInAndCopiesExactWireAndPlainBytes() {
        val file = Files.createTempFile("xcert-log", ".txt").toFile()
        try {
            SessionLog().use { log ->
                log.start(file, "header")
                val header = byteArrayOf(0, 1, 2, 3, 0)
                val wire = byteArrayOf(0x10, 0x20, 0xff.toByte())
                val plain = byteArrayOf(0, 0, 1, 0x65)
                log.appendVideoPacket(110, VideoCodec.H264, 1, header, wire, plain)
                log.videoFramesEnabled = true
                log.appendVideoPacket(111, VideoCodec.H265, 2, header, wire, plain)
                wire.fill(0)
                plain.fill(0)
                log.videoFramesEnabled = false
                log.appendVideoPacket(110, VideoCodec.H264, 3, header, wire, plain)
            }
            val retained = file.readText()
            assertFalse(retained.contains("type=110"))
            assertTrue(retained.contains("type=111 codec=H265 sequence=2"))
            assertTrue(retained.contains("headerHex=0001020300"))
            assertTrue(retained.contains("wireHex=1020ff"))
            assertTrue(retained.contains("plainHex=00000165"))
        } finally { file.delete() }
    }

    @Test fun oversizedRawPacketIsDroppedWithMarkerAndProgressSurvives() {
        val file = Files.createTempFile("xcert-log", ".txt").toFile()
        try {
            SessionLogFile(file, maxBytes = 2048, headLimitBytes = 512).use { log ->
                log.reset("handshake-header")
                log.appendVideoPacket(110, "H264", 1, ByteArray(128), ByteArray(2048), null)
                log.append("connection-ready")
            }
            val retained = file.readText()
            assertTrue(retained.startsWith("handshake-header\n"))
            assertTrue(retained.contains("LOG VIDEO LOSS droppedPackets=1"))
            assertFalse(retained.contains("wireHex="))
            assertTrue(retained.endsWith("connection-ready\n"))
        } finally { file.delete() }
    }

    @Test fun activityReattachmentKeepsOneCaptureAndDoesNotTruncate() {
        val file = Files.createTempFile("xcert-log", ".txt").toFile()
        try {
            SessionLog().use { log ->
                log.start(file, "first-activity")
                log.append("connected")
                log.start(file, "second-activity")
                log.append("reattached")
            }
            assertEquals("first-activity\nconnected\nreattached\n", file.readText())
        } finally { file.delete() }
    }

    @Test(timeout = 10_000) fun slowDiskCannotBlockAppendAndOnlyRecentPendingRecordsSurvive() {
        val file = Files.createTempFile("xcert-log", ".txt").toFile()
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val blockWrite = AtomicBoolean(false)
        val diskWrites = AtomicInteger()
        val log = SessionLogFile(file, outputFactory = { destination, append ->
            val delegate = FileOutputStream(destination, append)
            object : OutputStream() {
                override fun write(value: Int) = write(byteArrayOf(value.toByte()), 0, 1)
                override fun write(bytes: ByteArray, offset: Int, length: Int) {
                    diskWrites.incrementAndGet()
                    if (blockWrite.compareAndSet(true, false)) {
                        entered.countDown()
                        check(release.await(5, TimeUnit.SECONDS))
                    }
                    delegate.write(bytes, offset, length)
                }
                override fun close() = delegate.close()
            }
        })
        try {
            log.reset("handshake-header")
            blockWrite.set(true)
            log.append("active-record")
            assertTrue(entered.await(2, TimeUnit.SECONDS))
            val enqueued = CountDownLatch(1)
            thread(isDaemon = true) {
                repeat(200) { log.append("pending-$it") }
                enqueued.countDown()
            }
            assertTrue("append must finish while disk is blocked", enqueued.await(2, TimeUnit.SECONDS))
            val closed = CountDownLatch(1)
            thread(isDaemon = true) { log.close(); closed.countDown() }
            assertFalse("close must remain an ordered drain", closed.await(20, TimeUnit.MILLISECONDS))
            release.countDown()
            assertTrue(closed.await(2, TimeUnit.SECONDS))
            val retained = file.readText()
            assertTrue(retained.startsWith("handshake-header\nactive-record\n"))
            assertTrue(retained.contains("LOG LOSS droppedRecords=136 reason=queue-capacity\n"))
            assertEquals((136 until 200).map { "pending-$it" },
                retained.lineSequence().filter { it.startsWith("pending-") }.toList())
            assertTrue("queued records should share buffered disk writes", diskWrites.get() < 16)
            log.append("after-close")
            assertEquals(retained, file.readText())
        } finally {
            release.countDown()
            log.close()
            file.delete()
        }
    }

    @Test(timeout = 10_000) fun resetBarrierSurvivesLaterOverflowAndFlushMakesSnapshotReadable() {
        val file = Files.createTempFile("xcert-log", ".txt").toFile()
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val blockWrite = AtomicBoolean(false)
        val log = SessionLogFile(file, outputFactory = { destination, append ->
            val delegate = FileOutputStream(destination, append)
            object : OutputStream() {
                override fun write(value: Int) = write(byteArrayOf(value.toByte()), 0, 1)
                override fun write(bytes: ByteArray, offset: Int, length: Int) {
                    if (blockWrite.compareAndSet(true, false)) {
                        entered.countDown()
                        check(release.await(5, TimeUnit.SECONDS))
                    }
                    delegate.write(bytes, offset, length)
                }
                override fun close() = delegate.close()
            }
        })
        try {
            log.reset("old-session")
            blockWrite.set(true)
            log.append("old-record")
            assertTrue(entered.await(2, TimeUnit.SECONDS))
            val reset = CountDownLatch(1)
            val resetting = thread(isDaemon = true) { log.reset("new-session"); reset.countDown() }
            val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(2)
            while (resetting.state != Thread.State.WAITING && System.nanoTime() < deadline) Thread.yield()
            assertEquals("reset should be waiting on its queued barrier", Thread.State.WAITING, resetting.state)
            repeat(200) { log.append("new-record-$it") }
            release.countDown()
            assertTrue(reset.await(2, TimeUnit.SECONDS))
            log.flush()
            val snapshot = file.readText()
            assertTrue(snapshot.startsWith("new-session\n"))
            assertFalse(snapshot.contains("old-session"))
            assertFalse(snapshot.contains("old-record"))
            assertTrue(snapshot.endsWith("new-record-199\n"))
        } finally {
            release.countDown()
            log.close()
            file.delete()
        }
    }

    @Test(timeout = 10_000) fun failedBufferedWriteRollsBackOffsetsAndCallbackFailureDoesNotStopWriter() {
        val file = Files.createTempFile("xcert-log", ".txt").toFile()
        val failNextWrite = AtomicBoolean(false)
        val failed = CountDownLatch(1)
        val log = SessionLogFile(file, onError = {
            failed.countDown()
            throw IllegalStateException("diagnostic callback failed")
        }, outputFactory = { destination, append ->
            val delegate = FileOutputStream(destination, append)
            object : OutputStream() {
                override fun write(value: Int) = write(byteArrayOf(value.toByte()), 0, 1)
                override fun write(bytes: ByteArray, offset: Int, length: Int) {
                    if (failNextWrite.compareAndSet(true, false)) {
                        delegate.write(bytes, offset, minOf(5, length))
                        throw IOException("injected partial disk write")
                    }
                    delegate.write(bytes, offset, length)
                }
                override fun close() = delegate.close()
            }
        })
        try {
            log.reset("handshake-header")
            failNextWrite.set(true)
            log.append("discard-this-partial-record")
            assertTrue(failed.await(2, TimeUnit.SECONDS))
            log.append("connection-recovered")
            log.flush()
            assertEquals("handshake-header\n\nLOG LOSS priorFailedRecords=1\nconnection-recovered\n", file.readText())
        } finally {
            log.close()
            file.delete()
        }
    }
}
