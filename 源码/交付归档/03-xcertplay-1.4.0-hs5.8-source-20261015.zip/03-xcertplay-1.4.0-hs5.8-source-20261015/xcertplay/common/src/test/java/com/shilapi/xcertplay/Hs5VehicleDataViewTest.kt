package com.shilapi.xcertplay

import android.app.Activity
import android.os.Looper
import android.widget.FrameLayout
import android.widget.TextView
import com.shilapi.xcertplay.vehicle.Hs5VehicleCapabilities
import com.shilapi.xcertplay.vehicle.Hs5VehicleConnectionStatus
import com.shilapi.xcertplay.vehicle.Hs5VehicleField
import com.shilapi.xcertplay.vehicle.Hs5VehicleSnapshot
import com.shilapi.xcertplay.vehicle.Hs5VehicleValue
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.Closeable
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], qualifiers = "zh-rCN-w1920dp-h720dp-land-mdpi", manifest = Config.NONE)
class Hs5VehicleDataViewTest {
    private var now = 10_000L

    private fun connected(vararg values: Pair<Hs5VehicleField, Double>) = Hs5VehicleSnapshot(
        status = Hs5VehicleConnectionStatus.CONNECTED,
        capabilities = Hs5VehicleCapabilities(hs5Model = true, frontSeatHeat = true, frontSeatVent = true),
        values = values.associate { it.first to Hs5VehicleValue(it.second, now) },
    )

    private fun view(snapshot: Hs5VehicleSnapshot) = Hs5VehicleDataView(
        RuntimeEnvironment.getApplication(), { snapshot }, { listener -> listener(snapshot); Closeable {} }, { now },
    )

    private fun text(view: Hs5VehicleDataView, key: String) =
        view.findViewWithTag<TextView>("hs5_vehicle_$key").text.toString()

    @Test fun missingValuesRemainUnknownWhileARealZeroIsShown() {
        val view = view(connected(Hs5VehicleField.SPEED_RAW to 0.0))
        assertEquals("车速原始值：0（单位待核验）　挡位：未获取", text(view, "driving"))
        assertEquals("风量档位：未获取", text(view, "fan"))
        assertEquals("设定温度：主驾 未获取　副驾 未获取", text(view, "temperature"))
    }

    @Test fun seatAndGearCodesAreNotInventedAsLevelsOrPositions() {
        val view = view(connected(Hs5VehicleField.DRIVER_SEAT_HEAT to 1.0,
            Hs5VehicleField.PASSENGER_SEAT_VENT to 4.0, Hs5VehicleField.GEAR_RAW to 2.0))
        assertEquals("座椅加热：主驾 编码 1（待实车核验）　副驾 未获取", text(view, "seat_heat"))
        assertEquals("座椅通风：主驾 未获取　副驾 编码 4（待实车核验）", text(view, "seat_vent"))
        assertEquals("车速原始值：未获取（单位待核验）　挡位：编码 2（待实车核验）", text(view, "driving"))
    }

    @Test fun unverifiedClimateFlagsAreNotAssumedToBeBoolean() {
        val view = view(connected(Hs5VehicleField.HVAC_POWER to 1.0, Hs5VehicleField.HVAC_AUTO to 0.0))
        assertEquals("空调状态：编码 1（待实车核验）", text(view, "hvac"))
        assertEquals("AUTO：编码 0（待实车核验）　A/C：未获取　前除霜：未获取", text(view, "hvac_modes"))
    }

    @Test fun ordinaryDevicesGetACompactUnsupportedMessage() {
        val view = view(Hs5VehicleSnapshot(status = Hs5VehicleConnectionStatus.UNSUPPORTED_DEVICE))
        assertEquals(2, view.childCount)
        assertEquals("当前设备不支持 HS5 车辆接口", text(view, "status"))
        assertNull(view.findViewWithTag<TextView>("hs5_vehicle_seat_heat"))
    }

    @Test fun deniedServiceDoesNotRetainOldReadingsOrClaimConnection() {
        val view = view(connected(Hs5VehicleField.SPEED_RAW to 80.0).copy(
            status = Hs5VehicleConnectionStatus.PERMISSION_DENIED,
            failure = "SecurityException",
        ))
        assertEquals("车辆服务访问被系统拒绝", text(view, "status"))
        assertEquals("车速原始值：未获取（单位待核验）　挡位：未获取", text(view, "driving"))
        assertTrue(text(view, "notice").contains("未取得车辆服务访问权限"))
    }

    @Test fun expiredValuesAreClearedWithoutAnIncomingCallbackAndObserversCloseOnDetach() {
        val activity = Robolectric.buildActivity(Activity::class.java).setup().visible().get()
        val holder = FrameLayout(activity)
        activity.setContentView(holder)
        var observed = 0
        var closed = 0
        var listener: ((Hs5VehicleSnapshot) -> Unit)? = null
        val initial = connected(Hs5VehicleField.SPEED_RAW to 25.0)
        val view = Hs5VehicleDataView(activity, { initial }, { callback ->
            observed++
            listener = callback
            callback(initial)
            Closeable { closed++ }
        }, { now })
        assertEquals(0, observed)
        holder.addView(view)
        assertEquals(1, observed)
        assertEquals("车速原始值：25（单位待核验）　挡位：未获取", text(view, "driving"))
        now += 6_000
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(1))
        assertEquals("车速原始值：未获取（单位待核验）　挡位：未获取", text(view, "driving"))
        holder.removeView(view)
        assertEquals(1, closed)
        // A queued listener after close must not update the detached view.
        val oldListener = listener!!
        oldListener(connected(Hs5VehicleField.SPEED_RAW to 35.0))
        assertEquals("车速原始值：未获取（单位待核验）　挡位：未获取", text(view, "driving"))
        holder.addView(view)
        assertEquals(2, observed)
        oldListener(connected(Hs5VehicleField.SPEED_RAW to 35.0))
        assertEquals("车速原始值：未获取（单位待核验）　挡位：未获取", text(view, "driving"))
        holder.removeView(view)
        assertEquals(2, closed)
    }
}
