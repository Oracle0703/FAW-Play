package com.shilapi.xcertplay

import android.content.Context
import com.shilapi.xcertplay.orchestration.MfiTarget
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class Hs5AuthenticationBootstrapTest {
    private val context: Context get() = RuntimeEnvironment.getApplication()
    @Before fun clear() {
        context.getSharedPreferences("xcertplay_airplay", 0).edit().clear().commit()
        File(context.noBackupFilesDir, "local-auth").deleteRecursively()
    }

    @Test fun freshInstallPreparesBundledIdentityInPrivateNonBackupStorage() {
        assertEquals(MfiTarget.LOCAL_FILES, AirPlayPersistence.loadMfiTarget(context))
        assertTrue(Hs5AuthenticationBootstrap.prepare(context).ready)
        assertTrue(File(context.noBackupFilesDir, "local-auth/certificate.p7b").length() > 0)
        assertTrue(File(context.noBackupFilesDir, "local-auth/identity.pk8").length() > 0)
        assertEquals("content://${context.packageName}.localauth/certificate.p7b", AirPlayPersistence.loadLocalMfiCertificateUri(context))
        assertEquals("content://${context.packageName}.localauth/identity.pk8", AirPlayPersistence.loadLocalMfiPrivateKeyUri(context))
    }

    @Test fun explicitlySelectedUsbAuthenticationIsPreserved() {
        AirPlayPersistence.saveMfiTarget(context, MfiTarget.USB_CH341)
        assertTrue(Hs5AuthenticationBootstrap.prepare(context).ready)
        assertEquals(MfiTarget.USB_CH341, AirPlayPersistence.loadMfiTarget(context))
        assertFalse(File(context.noBackupFilesDir, "local-auth/identity.pk8").exists())
    }

    @Test fun corruptPrivateDocumentsAreRepairedFromTheApprovedBundle() {
        val directory = File(context.noBackupFilesDir, "local-auth").apply { mkdirs() }
        File(directory, "certificate.p7b").writeText("invalid")
        File(directory, "identity.pk8").writeText("invalid")
        assertTrue(Hs5AuthenticationBootstrap.prepare(context).ready)
        assertTrue(File(directory, "identity.pk8").length() > 7)
    }
}
