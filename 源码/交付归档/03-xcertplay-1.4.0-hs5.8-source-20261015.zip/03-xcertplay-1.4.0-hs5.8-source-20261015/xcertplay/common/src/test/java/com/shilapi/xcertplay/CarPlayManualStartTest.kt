package com.shilapi.xcertplay

import android.content.Context
import android.os.Looper
import android.view.View
import android.widget.Button
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.RobolectricTestRunner
import org.robolectric.shadows.ShadowBuild
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class CarPlayManualStartTest {
    private fun field(activity: CarPlayHostActivity, name: String) =
        activity.javaClass.getDeclaredField(name).apply { isAccessible = true }
    private fun invoke(activity: CarPlayHostActivity, name: String) =
        activity.javaClass.getDeclaredMethod(name).apply { isAccessible = true }.invoke(activity)

    @Test @Config(sdk = [28, 33])
    fun resumedHomeStaysIdleAndClickableUntilTheUserActuallyStartsConnecting() {
        ShadowBuild.setModel("PJZ110")
        ShadowBuild.setDevice("OPPO")
        val context = RuntimeEnvironment.getApplication()
        listOf("xcertplay_airplay", "xcertplay_hs5", "hs5_first_use").forEach {
            context.getSharedPreferences(it, Context.MODE_PRIVATE).edit().clear().commit()
        }
        Hs5OnboardingProgress(context).complete()
        shadowOf(context).denyPermissions(android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION, android.Manifest.permission.BLUETOOTH_CONNECT,
            android.Manifest.permission.BLUETOOTH_SCAN, android.Manifest.permission.BLUETOOTH_ADVERTISE)
        val lifecycle = Robolectric.buildActivity(CarPlayHostActivity::class.java).setup().visible()
        val activity = lifecycle.get()
        try {
            shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(90))
            val home = field(activity, "homeView").get(activity) as Hs5HomeView
            val connect = home.findViewWithTag<Button>("faw_open_carplay")
            assertEquals(View.VISIBLE, home.visibility)
            assertEquals(View.VISIBLE, (field(activity, "videoView").get(activity) as View).visibility)
            assertTrue(connect.isEnabled)
            assertEquals("打开 CarPlay", connect.text.toString())
            assertFalse(field(activity, "connectionRequested").getBoolean(activity))
            assertNull(field(activity, "handshakeTimeline").get(activity))
            assertNull(field(activity, "controller").get(activity))
            assertFalse(field(activity, "awaitingWirelessPermissions").getBoolean(activity))

            // Isolate local identity preparation from the UI lifecycle regression. A denied
            // permission keeps this click at the real startup boundary without starting radios.
            val setup = invoke(activity, "getSetup") as Hs5SetupCoordinator
            setup.javaClass.getDeclaredField("authentication").apply { isAccessible = true }
                .set(setup, Hs5SetupCheck(Hs5CheckState.READY, "测试认证已准备"))
            val clickedAt = System.currentTimeMillis()
            assertTrue(connect.performClick())
            assertTrue(field(activity, "connectionRequested").getBoolean(activity))
            assertTrue(field(activity, "awaitingWirelessPermissions").getBoolean(activity))
            val timeline = field(activity, "handshakeTimeline").get(activity) as HandshakeTimeline
            assertTrue(timeline.startedAtMillis >= clickedAt)
            assertFalse(connect.isEnabled)
            assertEquals("连接中…", connect.text.toString())
            assertNull(field(activity, "controller").get(activity))
        } finally { lifecycle.pause().stop().destroy() }
    }

    @Test fun freshLaunchWithPreviouslyGrantedPermissionsStillWaitsForConnect() {
        val context = RuntimeEnvironment.getApplication()
        context.getSharedPreferences("xcertplay_airplay", Context.MODE_PRIVATE).edit().clear().commit()
        val activity = Robolectric.buildActivity(CarPlayHostActivity::class.java).get()
        field(activity, "microphoneAvailable").setBoolean(activity, true)
        field(activity, "microphonePermissionResolved").setBoolean(activity, true)
        field(activity, "wirelessPermissionsReady").setBoolean(activity, true)
        field(activity, "vpnReady").setBoolean(activity, true)
        invoke(activity, "requestStartupPrerequisites")
        invoke(activity, "maybeStartCarPlay")
        assertFalse(field(activity, "connectionRequested").getBoolean(activity))
        assertFalse(field(activity, "awaitingWirelessPermissions").getBoolean(activity))
        assertFalse(field(activity, "awaitingVpnConsent").getBoolean(activity))
        assertNull(field(activity, "controller").get(activity))
    }

    @Test fun cancelDisarmsPermissionCallbacksAndAutomaticRecovery() {
        val activity = Robolectric.buildActivity(CarPlayHostActivity::class.java).get()
        field(activity, "connectionRequested").setBoolean(activity, true)
        field(activity, "bluetoothDiscoverabilityReady").setBoolean(activity, true)
        invoke(activity, "cancelConnectionAttempt")
        invoke(activity, "requestStartupPrerequisites")
        invoke(activity, "maybeStartCarPlay")
        assertFalse(field(activity, "connectionRequested").getBoolean(activity))
        assertFalse(field(activity, "bluetoothDiscoverabilityReady").getBoolean(activity))
        assertNull(field(activity, "controller").get(activity))
    }

    @Test fun measuredHs5P2pPathDoesNotRequestScanLocationPermission() {
        ShadowBuild.setModel("HONG QI")
        ShadowBuild.setDevice("t1c_acrn")
        val activity = Robolectric.buildActivity(CarPlayHostActivity::class.java).get()
        assertEquals(emptyList<String>(), invoke(activity, "requiredWirelessPermissions"))
        ShadowBuild.setModel("phone")
        ShadowBuild.setDevice("phone")
        assertEquals(listOf(android.Manifest.permission.ACCESS_COARSE_LOCATION,
            android.Manifest.permission.ACCESS_FINE_LOCATION), invoke(activity, "requiredWirelessPermissions"))
    }
}
