package com.shilapi.xcertplay

import com.shilapi.xcertplay.licensing.LicenseFeatures
import com.shilapi.xcertplay.updates.Hs5UpdateConfiguration
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import android.content.Context

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class Hs5ProductServicesTest {
    private val context: Context = RuntimeEnvironment.getApplication()

    @Test fun unboundEntitlementNeverBlocksBasicProjection() {
        assertTrue(Hs5ProductServices.basicCarPlayAllowed())
        assertFalse(Hs5ProductServices.licenseStatus(context).allowed)
        for (feature in LicenseFeatures.ALL) assertFalse(Hs5ProductServices.featureAllowed(context, feature))
        assertFalse(Hs5ProductServices.featureAllowed(context, "carplay"))
    }

    @Test fun unconfiguredUpdateIsDistinctFromLatestVersion() {
        // A configured release build must never reach its real backend from a unit test.
        assumeTrue(Hs5UpdateConfiguration.problem() != null)
        val result = Hs5ProductServices.checkUpdate(context)
        assertEquals(Hs5UpdateCheckStatus.NOT_CONFIGURED, result.status)
        assertNull(result.manifest)
        assertNotEquals(Hs5UpdateCheckStatus.UP_TO_DATE, result.status)
    }
}
