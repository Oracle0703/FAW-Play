package com.shilapi.xcertplay

import android.net.Uri
import android.provider.OpenableColumns
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileNotFoundException

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class LocalAuthDocumentsProviderTest {
    private lateinit var provider: LocalAuthDocumentsProvider
    private lateinit var authority: String
    private lateinit var directory: File

    @Before fun setup() {
        val app = RuntimeEnvironment.getApplication()
        authority = app.packageName + ".localauth"
        directory = File(app.noBackupFilesDir, "local-auth").apply { mkdirs() }
        provider = Robolectric.buildContentProvider(LocalAuthDocumentsProvider::class.java).create(authority).get()
    }

    @Test fun contentResolverReadsProvisionedDocumentsAndDisplaysTheirNames() {
        val sample = byteArrayOf(1, 5, 9, 13)
        val resolver = RuntimeEnvironment.getApplication().contentResolver
        listOf("certificate.p7b", "identity.pk8").forEach { name ->
            File(directory, name).writeBytes(sample)
            val uri = Uri.parse("content://$authority/$name")
            assertArrayEquals(sample, resolver.openInputStream(uri)!!.use { it.readBytes() })
            resolver.query(uri, null, null, null, null)!!.use { cursor ->
                assertTrue(cursor.moveToFirst())
                assertEquals(name, cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)))
                assertEquals(sample.size.toLong(), cursor.getLong(cursor.getColumnIndexOrThrow(OpenableColumns.SIZE)))
            }
        }
    }

    @Test fun readOnlyBoundaryRejectsUnknownPathsOtherAuthoritiesAndWriteModes() {
        File(directory, "identity.pk8").writeBytes(byteArrayOf(1))
        val uri = Uri.parse("content://$authority/identity.pk8")
        listOf("w", "rw", "rwt", "wa").forEach { mode ->
            assertThrows(FileNotFoundException::class.java) { provider.openFile(uri, mode) }
        }
        listOf("../shared_prefs/settings.xml", "certificate.p7b/extra", "other.pk8", "identity.pk8?export=1", "identity.pk8#extra").forEach { path ->
            assertThrows(FileNotFoundException::class.java) { provider.openFile(Uri.parse("content://$authority/$path"), "r") }
        }
        assertThrows(FileNotFoundException::class.java) { provider.openFile(Uri.parse("content://other.localauth/identity.pk8"), "r") }
        assertThrows(FileNotFoundException::class.java) { provider.openFile(Uri.parse("file:///identity.pk8"), "r") }
        assertThrows(UnsupportedOperationException::class.java) { provider.delete(uri, null, null) }
        assertArrayEquals(byteArrayOf(1), File(directory, "identity.pk8").readBytes())
    }

    @Test fun missingDocumentsFailWithoutCreatingOrReplacingAnIdentity() {
        File(directory, "certificate.p7b").delete()
        val uri = Uri.parse("content://$authority/certificate.p7b")
        assertThrows(FileNotFoundException::class.java) { provider.openFile(uri, "r") }
        assertThrows(FileNotFoundException::class.java) { provider.query(uri, null, null, null, null) }
        assertFalse(File(directory, "certificate.p7b").exists())
    }
}
