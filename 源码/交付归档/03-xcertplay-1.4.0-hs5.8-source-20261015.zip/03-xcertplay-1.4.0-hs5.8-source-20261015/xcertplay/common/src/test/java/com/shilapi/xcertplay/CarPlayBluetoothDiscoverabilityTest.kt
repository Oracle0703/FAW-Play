package com.shilapi.xcertplay

import android.bluetooth.BluetoothAdapter
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito.*
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import android.content.Intent
import android.os.Looper
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class CarPlayBluetoothDiscoverabilityTest {
    @Test fun discoverableVehicleNeedsNoSystemActivity() {
        val adapter = mock(BluetoothAdapter::class.java)
        `when`(adapter.isEnabled).thenReturn(true)
        `when`(adapter.scanMode).thenReturn(BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE)
        assertEquals(CarPlayBluetoothDiscoverability.Result.READY,
            CarPlayBluetoothDiscoverability.prepare(adapter) {})
        verify(adapter, never()).enable()
    }

    @Test fun legacySystemApiMustConfirmDiscoverability() {
        var mode = BluetoothAdapter.SCAN_MODE_CONNECTABLE
        val adapter = mock(BluetoothAdapter::class.java) { call ->
            when (call.method.name) {
                "isEnabled" -> true
                "getScanMode" -> mode
                "setScanMode" -> { mode = call.getArgument(0); true }
                else -> RETURNS_DEFAULTS.answer(call)
            }
        }
        assertEquals(CarPlayBluetoothDiscoverability.Result.READY,
            CarPlayBluetoothDiscoverability.prepare(adapter) {})
        assertEquals(BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE, mode)
        verify(adapter, never()).enable()
    }

    @Test fun rejectedSystemApiRetainsAndroidConsentAndBoundedDuration() {
        val adapter = mock(BluetoothAdapter::class.java)
        `when`(adapter.isEnabled).thenReturn(true)
        `when`(adapter.scanMode).thenReturn(BluetoothAdapter.SCAN_MODE_CONNECTABLE)
        assertEquals(CarPlayBluetoothDiscoverability.Result.CONSENT_REQUIRED,
            CarPlayBluetoothDiscoverability.prepare(adapter) {})
        val intent = CarPlayBluetoothDiscoverability.consentIntent()
        assertEquals(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE, intent.action)
        assertEquals(120, intent.getIntExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, -1))
        verify(adapter, never()).enable()
    }

    @Test fun acceptedAsynchronousRequestWaitsForRealModeAndCanBeCancelled() {
        var mode = BluetoothAdapter.SCAN_MODE_CONNECTABLE
        val adapter = mock(BluetoothAdapter::class.java) { call ->
            when (call.method.name) {
                "isEnabled" -> true
                "getScanMode" -> mode
                "setScanMode" -> true
                else -> RETURNS_DEFAULTS.answer(call)
            }
        }
        assertEquals(CarPlayBluetoothDiscoverability.Result.WAITING_FOR_MODE,
            CarPlayBluetoothDiscoverability.prepare(adapter) {})
        val context = RuntimeEnvironment.getApplication()
        val results = mutableListOf<Boolean>()
        CarPlayBluetoothDiscoverability.awaitDiscoverable(context, adapter, results::add)
        context.sendBroadcast(Intent(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED))
        shadowOf(Looper.getMainLooper()).idle()
        assertTrue(results.isEmpty())
        mode = BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE
        context.sendBroadcast(Intent(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED))
        shadowOf(Looper.getMainLooper()).idle()
        assertEquals(listOf(true), results)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(3))
        assertEquals(listOf(true), results)
        mode = BluetoothAdapter.SCAN_MODE_CONNECTABLE
        val pending = CarPlayBluetoothDiscoverability.awaitDiscoverable(context, adapter, results::add)
        pending.close()
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(3))
        assertEquals(listOf(true), results)
    }

    @Test fun asynchronousModeConfirmationHasAFiniteTimeout() {
        val adapter = mock(BluetoothAdapter::class.java)
        val results = mutableListOf<Boolean>()
        CarPlayBluetoothDiscoverability.awaitDiscoverable(RuntimeEnvironment.getApplication(), adapter, results::add)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(2))
        assertEquals(listOf(false), results)
    }

    @Test fun missingOrDisabledRadioIsReportedWithoutChangingTheSwitch() {
        assertEquals(CarPlayBluetoothDiscoverability.Result.UNAVAILABLE,
            CarPlayBluetoothDiscoverability.prepare(null) {})
        val adapter = mock(BluetoothAdapter::class.java)
        assertEquals(CarPlayBluetoothDiscoverability.Result.BLUETOOTH_OFF,
            CarPlayBluetoothDiscoverability.prepare(adapter) {})
        verify(adapter, never()).enable()
    }
}
