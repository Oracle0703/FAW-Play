// SPDX-License-Identifier: AGPL-3.0-only
package com.shilapi.xcertplay

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/** Compact connection progress, driven by the existing handshake timeline. */
internal class Hs5ConnectionProgressView(
    context: Context,
    onDetails: () -> Unit,
    onCancel: () -> Unit,
    private val onConnectingChanged: (Boolean) -> Unit,
) : LinearLayout(context) {
    private val accent = Color.rgb(240, 24, 48)
    private val muted = Color.rgb(166, 170, 174)
    private val handler = Handler(Looper.getMainLooper())
    private var timeline: HandshakeTimeline? = null
    private var status = "尚未连接"
    private val heading = Hs5Ui.label(context, status, 12f, accent, true).apply { maxLines = 1 }
    private val detail = Hs5Ui.label(context, "", 10f, muted).apply { maxLines = 1 }
    private val dots = Hs5Ui.row(context)
    private val spinner = ProgressBar(context).apply {
        indeterminateTintList = ColorStateList.valueOf(accent)
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
    }
    private val cancel = actionButton("取消", onCancel)
    private var initialized = false
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            scheduleTick()
        }
    }

    init {
        tag = "hs5_connection_progress"
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(Hs5Ui.dp(context, 8), Hs5Ui.dp(context, 5), Hs5Ui.dp(context, 8), Hs5Ui.dp(context, 5))
        background = Hs5Ui.shape(context, Color.rgb(29, 32, 34), Color.rgb(98, 101, 104), 12)
        addView(spinner, LayoutParams(Hs5Ui.dp(context, 24), Hs5Ui.dp(context, 24)))
        addView(Hs5Ui.column(context).apply {
            addView(heading, LayoutParams(-1, 0, 1f))
            addView(detail, LayoutParams(-1, 0, 1f))
            addView(dots, LayoutParams(-1, Hs5Ui.dp(context, 4)))
        }, LayoutParams(0, -1, 1f).apply { leftMargin = Hs5Ui.dp(context, 8) })
        addView(actionButton("查看全部步骤", onDetails), LayoutParams(Hs5Ui.dp(context, 108), Hs5Ui.dp(context, 48)).apply {
            leftMargin = Hs5Ui.dp(context, 8)
        })
        addView(cancel, LayoutParams(Hs5Ui.dp(context, 48), Hs5Ui.dp(context, 48)).apply {
            leftMargin = Hs5Ui.dp(context, 5)
        })
        initialized = true
        refresh()
    }

    fun bind(value: HandshakeTimeline?, message: String) {
        timeline = value
        status = message
        refresh()
        scheduleTick()
    }

    private fun refresh() {
        val current = timeline
        val phases = current?.phases.orEmpty()
        val connecting = current != null && current.failure == null
        spinner.visibility = if (connecting) View.VISIBLE else View.INVISIBLE
        cancel.visibility = if (current != null) View.VISIBLE else View.GONE
        onConnectingChanged(connecting)
        dots.removeAllViews()
        val failed = phases.indexOfFirst { it.state == HandshakeTimeline.State.FAILED }
        val active = phases.indexOfFirst { it.state == HandshakeTimeline.State.ACTIVE }
        val waiting = phases.indexOfFirst { it.state == HandshakeTimeline.State.IDLE }
        val index = when {
            failed >= 0 -> failed
            active >= 0 -> active
            waiting >= 0 -> waiting
            else -> phases.lastIndex
        }
        val elapsed = current?.let { ((System.currentTimeMillis() - it.startedAtMillis).coerceAtLeast(0) / 1000) } ?: 0
        heading.text = when {
            current?.failure != null -> "连接未完成"
            connecting && index >= 0 -> "${if (current!!.wireless) "无线" else "USB"}连接 · 第 ${index + 1} / ${phases.size} 阶段"
            else -> status
        }
        detail.text = when {
            connecting && index >= 0 -> "${phaseName(phases[index].kind)} · 已用 ${elapsed} 秒"
            current?.failure != null -> status
            else -> "准备就绪后，点击打开 CarPlay"
        }
        phases.forEachIndexed { position, phase ->
            val fill = when (phase.state) {
                HandshakeTimeline.State.DONE -> Color.rgb(42, 201, 115)
                HandshakeTimeline.State.ACTIVE, HandshakeTimeline.State.FAILED -> accent
                else -> Color.rgb(77, 81, 85)
            }
            dots.addView(View(context).apply {
                background = Hs5Ui.shape(context, fill, radius = 2)
                contentDescription = "${phaseName(phase.kind)}：${stateName(phase.state)}"
            }, LayoutParams(0, -1, 1f).apply { if (position > 0) leftMargin = Hs5Ui.dp(context, 3) })
        }
    }

    private fun actionButton(text: String, action: () -> Unit): Button = Hs5Ui.button(context, text, action = action).apply {
        setTextColor(Color.WHITE)
        textSize = Hs5Ui.sp(context, 11f)
        background = android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(Color.DKGRAY),
            Hs5Ui.shape(context, Color.rgb(46, 49, 53), Color.rgb(102, 105, 110), 10), null)
    }

    private fun scheduleTick() {
        handler.removeCallbacks(tick)
        if (initialized && isShown && timeline != null && timeline?.failure == null) handler.postDelayed(tick, 1000)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); scheduleTick() }
    override fun onDetachedFromWindow() { handler.removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (initialized) scheduleTick()
    }

    private fun phaseName(kind: HandshakeTimeline.PhaseKind): String = when (kind) {
        HandshakeTimeline.PhaseKind.MFI -> "准备认证"
        HandshakeTimeline.PhaseKind.BOND -> "等待 iPhone 蓝牙配对"
        HandshakeTimeline.PhaseKind.HOTSPOT -> "建立 Wi-Fi 连接"
        HandshakeTimeline.PhaseKind.ADVERTISE -> "发布连接服务"
        HandshakeTimeline.PhaseKind.BLUETOOTH -> "连接 iPhone 蓝牙"
        HandshakeTimeline.PhaseKind.USB -> "发现 USB 设备"
        HandshakeTimeline.PhaseKind.USB_DATA -> "打开 USB 数据通道"
        HandshakeTimeline.PhaseKind.LOCKDOWN -> "验证 USB 配对"
        HandshakeTimeline.PhaseKind.NETWORK -> "建立网络通道"
        HandshakeTimeline.PhaseKind.IAP2 -> "验证设备连接"
        HandshakeTimeline.PhaseKind.PAIR -> "建立安全配对"
        HandshakeTimeline.PhaseKind.SESSION -> "启动 CarPlay 会话"
        HandshakeTimeline.PhaseKind.STREAMS -> "准备音视频通道"
        HandshakeTimeline.PhaseKind.HANDOFF -> "切换到无线数据通道"
    }

    private fun stateName(state: HandshakeTimeline.State): String = when (state) {
        HandshakeTimeline.State.IDLE -> "等待"
        HandshakeTimeline.State.ACTIVE -> "进行中"
        HandshakeTimeline.State.DONE -> "完成"
        HandshakeTimeline.State.FAILED -> "未完成"
        HandshakeTimeline.State.SKIPPED -> "无需执行"
    }
}
