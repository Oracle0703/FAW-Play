// SPDX-License-Identifier: AGPL-3.0-only
package com.shilapi.xcertplay

import android.content.Context

internal enum class Hs5OnboardingStep(val title: String) {
    WELCOME("欢迎与检查"), PERMISSIONS("权限准备"), UPDATE("检查更新"),
    LICENSE("绑定增强授权"), CONNECTION("连接 iPhone");

    fun next(): Hs5OnboardingStep = entries[(ordinal + 1).coerceAtMost(entries.lastIndex)]
    fun previous(): Hs5OnboardingStep = entries[(ordinal - 1).coerceAtLeast(0)]
}

/** This stores navigation only. Permission, license and MFi readiness must be checked afresh. */
internal class Hs5OnboardingProgress(context: Context) {
    private val preferences = context.getSharedPreferences("hs5_first_use", Context.MODE_PRIVATE)
    val completed: Boolean get() = preferences.getBoolean("completed", false)
    val step: Hs5OnboardingStep get() = Hs5OnboardingStep.entries.firstOrNull {
        it.name == preferences.getString("step", null)
    } ?: Hs5OnboardingStep.WELCOME

    fun moveTo(step: Hs5OnboardingStep) {
        preferences.edit().putString("step", step.name).apply()
    }

    /** Call after a real CarPlay connection succeeds, never after merely starting a request. */
    fun complete() {
        preferences.edit().putBoolean("completed", true)
            .putString("step", Hs5OnboardingStep.CONNECTION.name).apply()
    }
}

internal enum class Hs5CheckState { CHECKING, READY, UNAVAILABLE, FAILED }
internal data class Hs5SetupCheck(val state: Hs5CheckState, val detail: String) {
    val ready: Boolean get() = state == Hs5CheckState.READY
}

internal enum class Hs5PermissionStatus {
    NOT_REQUESTED, REQUESTING, GRANTED, DENIED, PERMANENTLY_DENIED, UNAVAILABLE;

    val canRequest: Boolean get() = this == NOT_REQUESTED || this == DENIED
    val label: String get() = when (this) {
        NOT_REQUESTED -> "等待确认"
        REQUESTING -> "等待系统确认"
        GRANTED -> "已允许"
        DENIED -> "未允许，可稍后设置"
        PERMANENTLY_DENIED -> "系统已禁止再次弹窗，可稍后在应用权限中开启"
        UNAVAILABLE -> "当前设备不可用"
    }
}

internal enum class Hs5UpdateState {
    NOT_CHECKED, CHECKING, UP_TO_DATE, AVAILABLE, DOWNLOADING, FAILED, UNCONFIGURED
}
internal data class Hs5UpdateStatus(
    val state: Hs5UpdateState = Hs5UpdateState.NOT_CHECKED,
    val detail: String = "尚未检查更新",
) {
    val busy: Boolean get() = state == Hs5UpdateState.CHECKING || state == Hs5UpdateState.DOWNLOADING
}

internal enum class Hs5LicenseState { FREE, BINDING, ACTIVE, FAILED, UNCONFIGURED }
internal data class Hs5LicenseStatus(
    val state: Hs5LicenseState = Hs5LicenseState.FREE,
    val detail: String = "基础 CarPlay 免费；增强功能需绑定授权",
) {
    val active: Boolean get() = state == Hs5LicenseState.ACTIVE
    val canBind: Boolean get() = state == Hs5LicenseState.FREE || state == Hs5LicenseState.FAILED
}

internal data class Hs5OnboardingSnapshot(
    val step: Hs5OnboardingStep,
    val environment: Hs5SetupCheck,
    val bluetooth: Hs5SetupCheck,
    val wifi: Hs5SetupCheck,
    val authentication: Hs5SetupCheck,
    val microphone: Hs5PermissionStatus,
    val location: Hs5PermissionStatus,
    val wirelessPermission: Hs5PermissionStatus? = null,
    val update: Hs5UpdateStatus = Hs5UpdateStatus(),
    val license: Hs5LicenseStatus = Hs5LicenseStatus(),
    val bluetoothName: String? = null,
    val connectionMessage: String = "点击开始连接，准备手机配对",
    val connecting: Boolean = false,
    val connected: Boolean = false,
) {
    val canConnect: Boolean get() = environment.ready && bluetooth.ready && wifi.ready &&
        authentication.ready && (wirelessPermission == null || wirelessPermission == Hs5PermissionStatus.GRANTED)
}

internal data class Hs5OnboardingCallbacks(
    val onMoveTo: (Hs5OnboardingStep) -> Unit,
    val onRefreshEnvironment: () -> Unit,
    val onRequestMicrophone: () -> Unit,
    val onRequestLocation: () -> Unit,
    val onRequestWirelessPermissions: () -> Unit,
    val onCheckUpdates: () -> Unit,
    val onInstallUpdate: () -> Unit,
    val onStartBinding: () -> Unit,
    val onRedeemCode: () -> Unit,
    val onCancelBinding: () -> Unit,
    val onConnect: () -> Unit,
    val onCancelConnection: () -> Unit,
    val onConnectionDetails: () -> Unit,
    val onFinish: () -> Unit,
)

internal enum class Hs5InstrumentPermission { NOT_REQUIRED, GRANTED, NEEDED, UNAVAILABLE }
internal data class Hs5ManagementSnapshot(
    val microphone: Hs5PermissionStatus,
    val location: Hs5PermissionStatus,
    val authentication: Hs5SetupCheck,
    val license: Hs5LicenseStatus,
    val update: Hs5UpdateStatus,
    val instrumentPermission: Hs5InstrumentPermission,
    val instrumentPermissionDetail: String,
    val ultraSupported: Boolean,
    val ultraEnabled: Boolean,
    val ultraUnavailableReason: String,
    val wirelessPermission: Hs5PermissionStatus? = null,
    val sessionActive: Boolean = false,
) {
    val canToggleUltra: Boolean get() = ultraSupported && license.active
}

internal data class Hs5ManagementCallbacks(
    val onBack: () -> Unit,
    val onRequestMicrophone: () -> Unit,
    val onRequestLocation: () -> Unit,
    val onRequestWirelessPermissions: () -> Unit,
    val onCheckUpdates: () -> Unit,
    val onInstallUpdate: () -> Unit,
    val onStartBinding: () -> Unit,
    val onRedeemCode: () -> Unit,
    val onCancelBinding: () -> Unit,
    val onInstrumentPermission: () -> Unit,
    val onToggleUltra: (Boolean) -> Unit,
    val onManagePhones: () -> Unit,
    val onDiagnostics: () -> Unit,
    val onReconnect: () -> Unit,
)
