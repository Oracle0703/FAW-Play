package com.shilapi.xcertplay

/** One initial attempt and at most two automatic retries; only Wi-Fi failures change radio. */
internal class WirelessRetryPolicy {
    data class Retry(val delayMillis: Long, val attempt: Int, val radioAttempt: Int)
    var failures = 0
        private set
    var radioAttempt = 0
        private set
    var failedFrequencyMHz: Int? = null
        private set
    var exhausted = false
        private set

    fun reset() {
        failures = 0
        radioAttempt = 0
        failedFrequencyMHz = null
        exhausted = false
    }

    fun next(radioRecovery: Boolean, frequencyMHz: Int?, retryable: Boolean = true): Retry? {
        if (exhausted) return null
        failures++
        if (!retryable || failures >= 3) {
            exhausted = true
            return null
        }
        if (radioRecovery) {
            radioAttempt++
            failedFrequencyMHz = frequencyMHz
        }
        return Retry(if (failures == 1) 2_000 else 4_000, failures + 1, radioAttempt)
    }
}
