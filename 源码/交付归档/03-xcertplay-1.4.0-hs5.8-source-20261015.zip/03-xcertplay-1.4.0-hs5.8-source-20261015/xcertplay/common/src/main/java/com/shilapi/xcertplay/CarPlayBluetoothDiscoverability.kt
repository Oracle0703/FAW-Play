package com.shilapi.xcertplay

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.lang.reflect.InvocationTargetException
import java.util.concurrent.atomic.AtomicBoolean

/** Bounded discoverability; does not turn radios on or change the vehicle's Bluetooth name. */
internal object CarPlayBluetoothDiscoverability {
    const val DURATION_SECONDS = 120

    enum class Result { READY, WAITING_FOR_MODE, CONSENT_REQUIRED, BLUETOOTH_OFF, UNAVAILABLE }

    @SuppressLint("MissingPermission")
    fun prepare(adapter: BluetoothAdapter?, diagnostic: (String) -> Unit): Result {
        if (adapter == null) return Result.UNAVAILABLE
        try {
            if (!adapter.isEnabled) return Result.BLUETOOTH_OFF
            if (adapter.scanMode == BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
                diagnostic("Bluetooth already discoverable")
                return Result.READY
            }
            // The measured Android 9 framework exposes this system API. Reflection may be
            // denied for a sideloaded APK; retain Android's consent flow in that case.
            if (Build.VERSION.SDK_INT == Build.VERSION_CODES.P) {
                try {
                    val accepted = adapter.javaClass.getMethod(
                        "setScanMode", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType,
                    ).invoke(adapter, BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE,
                        DURATION_SECONDS) == true
                    if (accepted && adapter.scanMode == BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
                        diagnostic("HS5 Bluetooth discoverability enabled for ${DURATION_SECONDS}s")
                        return Result.READY
                    }
                    if (accepted) return Result.WAITING_FOR_MODE
                    diagnostic("HS5 Bluetooth discoverability request not confirmed")
                } catch (error: ReflectiveOperationException) {
                    val cause = (error as? InvocationTargetException)?.targetException ?: error
                    diagnostic("HS5 Bluetooth discoverability system API unavailable: ${cause.javaClass.simpleName}")
                } catch (error: SecurityException) {
                    diagnostic("HS5 Bluetooth discoverability system API denied")
                }
            }
            return Result.CONSENT_REQUIRED
        } catch (error: SecurityException) {
            diagnostic("Bluetooth discoverability permission unavailable")
            return Result.CONSENT_REQUIRED
        }
    }

    /** Wait for the system's asynchronous mode update without blocking the Activity thread. */
    @SuppressLint("MissingPermission", "UnspecifiedRegisterReceiverFlag")
    fun awaitDiscoverable(context: Context, adapter: BluetoothAdapter, completed: (Boolean) -> Unit): AutoCloseable {
        val handler = Handler(Looper.getMainLooper())
        val ended = AtomicBoolean(false)
        var registered = false
        lateinit var receiver: BroadcastReceiver
        lateinit var timeout: Runnable
        fun finish(result: Boolean?) {
            if (!ended.compareAndSet(false, true)) return
            handler.removeCallbacks(timeout)
            if (registered) runCatching { context.unregisterReceiver(receiver) }
            if (result != null) completed(result)
        }
        fun observed(): Boolean = runCatching {
            adapter.scanMode == BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE
        }.getOrDefault(false)
        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (observed()) finish(true)
            }
        }
        timeout = Runnable { finish(observed()) }
        try {
            context.registerReceiver(receiver, IntentFilter(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED))
            registered = true
            handler.postDelayed(timeout, 2_000)
            if (observed()) finish(true)
        } catch (_: SecurityException) { finish(false) }
        return AutoCloseable { finish(null) }
    }

    fun consentIntent(): Intent = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
        .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, DURATION_SECONDS)
}
