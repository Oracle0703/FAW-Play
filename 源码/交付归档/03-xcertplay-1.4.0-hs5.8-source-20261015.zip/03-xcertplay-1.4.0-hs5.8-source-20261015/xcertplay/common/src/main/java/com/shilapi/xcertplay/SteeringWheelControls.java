package com.shilapi.xcertplay;

import android.content.Context;
import com.shilapi.xcertplay.orchestration.CarPlayController;

/** Native Qisi keys retain their press classification; Android media commands use iAP2. */
public final class SteeringWheelControls {
    public static final int PREVIOUS=0, NEXT=1, PHONE=2, SIRI=3;
    static boolean enabled(Context context) {
        return HongqiWheelControls.supported(context) && com.shilapi.xcertplay.licensing.ProductLicense.featureAllowed(context, com.shilapi.xcertplay.licensing.LicenseFeatures.STEERING_WHEEL);
    }
    static boolean connectionReady(Object owner) {
        return owner instanceof CarPlayController && !((CarPlayController)owner).isClosed() && ((CarPlayController)owner).hasActiveAirPlayAttachment();
    }
    static boolean ready(Object owner) { return connectionReady(owner); }
    static boolean send(Object owner, int role) {
        if (!ready(owner)) return false;
        CarPlayController controller=(CarPlayController)owner;
        switch(role) {
            case PREVIOUS: return controller.sendMediaButton(5);
            case NEXT: return controller.sendMediaButton(4);
            case PHONE: return controller.requestPhoneUi();
            case SIRI: return controller.requestSiri();
            default: return false;
        }
    }
    static boolean sendTelephony(Object owner, int index) {
        return ready(owner) && ((CarPlayController)owner).sendTelephonyButton(index);
    }
}
