// SPDX-License-Identifier: AGPL-3.0-only
package com.shilapi.xcertplay

import android.annotation.SuppressLint
import android.content.Context
import android.os.SystemClock
import android.widget.LinearLayout
import android.widget.TextView
import com.shilapi.xcertplay.vehicle.Hs5VehicleConnectionStatus
import com.shilapi.xcertplay.vehicle.Hs5VehicleData
import com.shilapi.xcertplay.vehicle.Hs5VehicleField
import com.shilapi.xcertplay.vehicle.Hs5VehicleSnapshot
import java.io.Closeable
import java.util.Locale

/** Observes vehicle-side data only; it neither starts a service nor sends vehicle commands. */
@SuppressLint("ViewConstructor")
internal class Hs5VehicleDataView(
    context: Context,
    snapshot: () -> Hs5VehicleSnapshot = { Hs5VehicleData.snapshot() },
    private val observe: ((Hs5VehicleSnapshot) -> Unit) -> Closeable = { Hs5VehicleData.observe(it) },
    private val nowMillis: () -> Long = { SystemClock.elapsedRealtime() },
) : LinearLayout(context) {
    private var current = snapshot()
    private var subscription: Closeable? = null
    private var observerGeneration = 0
    private var showingUnsupported: Boolean? = null
    private val rows = mutableMapOf<String, TextView>()
    private val refresh = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow) return
            render()
            postDelayed(this, 1_000)
        }
    }

    init {
        orientation = VERTICAL
        tag = "hs5_vehicle_data"
        render()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        subscription?.close()
        val generation = ++observerGeneration
        subscription = observe { value ->
            if (isAttachedToWindow && observerGeneration == generation) {
                current = value
                render()
            }
        }
        removeCallbacks(refresh)
        postDelayed(refresh, 1_000)
    }

    override fun onDetachedFromWindow() {
        observerGeneration++
        removeCallbacks(refresh)
        subscription?.close()
        subscription = null
        super.onDetachedFromWindow()
    }

    private fun render() {
        val unsupported = current.status == Hs5VehicleConnectionStatus.UNSUPPORTED_DEVICE
        // Keep the same views during normal updates so TalkBack and scroll position remain stable.
        if (showingUnsupported != unsupported) {
            removeAllViews()
            rows.clear()
            showingUnsupported = unsupported
            addRow("status", true)
            if (unsupported) {
                addRow("notice")
            } else {
                listOf("notice", "hvac", "temperature", "fan", "hvac_modes", "seat_heat",
                    "seat_vent", "driving", "range", "ambient").forEach { addRow(it) }
            }
        }
        text("status", when (current.status) {
            Hs5VehicleConnectionStatus.STOPPED -> "车辆服务尚未启动"
            Hs5VehicleConnectionStatus.UNSUPPORTED_DEVICE -> "当前设备不支持 HS5 车辆接口"
            Hs5VehicleConnectionStatus.CONNECTING -> "正在连接车辆服务…"
            Hs5VehicleConnectionStatus.CONNECTED -> "已连接车辆服务"
            Hs5VehicleConnectionStatus.UNAVAILABLE -> "车辆服务暂不可用"
            Hs5VehicleConnectionStatus.PERMISSION_DENIED -> "车辆服务访问被系统拒绝"
        })
        if (unsupported) {
            text("notice", "车辆状态需在支持的红旗 HS5 车机上读取。")
            return
        }
        text("notice", when (current.status) {
            Hs5VehicleConnectionStatus.PERMISSION_DENIED -> "当前安装方式未取得车辆服务访问权限，暂时无法读取。"
            Hs5VehicleConnectionStatus.UNAVAILABLE -> "暂时无法读取原厂车辆接口；未获取的数值不会用默认值代替。"
            else -> "以下为原厂接口的只读状态；未获取或已过期的数据不会作为当前状态显示。"
        })
        val now = nowMillis()
        fun number(field: Hs5VehicleField, suffix: String = ""): String =
            current.value(field, now)?.takeIf { it.isFinite() }?.let { "${format(it)}$suffix" } ?: UNKNOWN
        fun code(field: Hs5VehicleField): String = current.value(field, now)?.takeIf { it.isFinite() }
            ?.let { "编码 ${format(it)}（待实车核验）" } ?: UNKNOWN
        text("hvac", "空调状态：${code(Hs5VehicleField.HVAC_POWER)}")
        text("temperature", "设定温度：主驾 ${number(Hs5VehicleField.HVAC_LEFT_TEMPERATURE, " °C")}　副驾 ${number(Hs5VehicleField.HVAC_RIGHT_TEMPERATURE, " °C")}")
        text("fan", "风量档位：${number(Hs5VehicleField.HVAC_FAN)}")
        text("hvac_modes", "AUTO：${code(Hs5VehicleField.HVAC_AUTO)}　A/C：${code(Hs5VehicleField.HVAC_COMPRESSOR)}　前除霜：${code(Hs5VehicleField.HVAC_FRONT_DEFROST)}")
        text("seat_heat", if (current.capabilities.frontSeatHeat) {
            "座椅加热：主驾 ${code(Hs5VehicleField.DRIVER_SEAT_HEAT)}　副驾 ${code(Hs5VehicleField.PASSENGER_SEAT_HEAT)}"
        } else "座椅加热：尚未确认本车支持")
        text("seat_vent", if (current.capabilities.frontSeatVent) {
            "座椅通风：主驾 ${code(Hs5VehicleField.DRIVER_SEAT_VENT)}　副驾 ${code(Hs5VehicleField.PASSENGER_SEAT_VENT)}"
        } else "座椅通风：尚未确认本车支持")
        text("driving", "车速原始值：${number(Hs5VehicleField.SPEED_RAW)}（单位待核验）　挡位：${code(Hs5VehicleField.GEAR_RAW)}")
        text("range", "续航：${number(Hs5VehicleField.RANGE_KM, " km")}　总里程：${number(Hs5VehicleField.ODOMETER_KM, " km")}")
        text("ambient", "环境温度：${number(Hs5VehicleField.AMBIENT_TEMPERATURE, " °C")}")
    }

    private fun addRow(key: String, important: Boolean = false) {
        val colors = FawUiTheme.palette(context)
        val row = Hs5Ui.label(context, "", if (important) 16f else 14f,
            if (important) colors.text else colors.muted, important).apply {
            tag = "hs5_vehicle_$key"
            setPadding(0, Hs5Ui.dp(context, 5), 0, Hs5Ui.dp(context, 5))
        }
        rows[key] = row
        addView(row, LayoutParams(-1, -2))
    }

    private fun text(key: String, value: String) {
        rows.getValue(key).let { if (it.text.toString() != value) it.text = value }
    }

    private fun format(value: Double): String = String.format(Locale.CHINA, "%.1f", value).removeSuffix(".0")

    private companion object {
        const val UNKNOWN = "未获取"
    }
}
