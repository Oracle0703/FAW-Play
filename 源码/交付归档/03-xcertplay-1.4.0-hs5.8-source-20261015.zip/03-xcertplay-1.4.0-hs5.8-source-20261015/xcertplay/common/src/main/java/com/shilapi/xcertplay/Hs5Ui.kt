// SPDX-License-Identifier: AGPL-3.0-only
package com.shilapi.xcertplay

import android.app.Activity
import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.wifi.WifiManager
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.shilapi.xcertplay.host.R
import com.shilapi.xcertplay.transport.IphoneBluetoothDevices

/** The old FAW Play layout and artwork, connected to the current host through callbacks. */
internal object Hs5Ui {
    fun scale(context: Context): Float = with(context.resources.displayMetrics) {
        maxOf(1f, minOf(widthPixels, heightPixels) / density / 360f)
    }
    fun dp(context: Context, value: Int) = (value * context.resources.displayMetrics.density * scale(context)).toInt()
    fun sp(context: Context, value: Float) = value * scale(context)
    fun column(context: Context) = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
    fun row(context: Context) = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }
    fun shape(context: Context, fill: Int, stroke: Int = Color.TRANSPARENT, radius: Int = 18) =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(context, radius).toFloat()
            setStroke(maxOf(1, dp(context, 1)), stroke)
        }
    fun label(context: Context, value: String, size: Float, color: Int, bold: Boolean = false) = TextView(context).apply {
        text = value
        textSize = sp(context, size)
        setTextColor(color)
        gravity = Gravity.CENTER_VERTICAL
        if (bold) setTypeface(null, Typeface.BOLD)
    }
    fun button(context: Context, value: String, primary: Boolean = false, action: () -> Unit) = Button(context).apply {
        val colors = FawUiTheme.palette(context)
        text = value
        textSize = sp(context, 14f)
        isAllCaps = false
        setTextColor(if (primary) colors.onAccent else colors.text)
        minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setPadding(dp(context, 6), 0, dp(context, 6), 0)
        stateListAnimator = null
        backgroundTintList = null
        background = RippleDrawable(ColorStateList.valueOf(colors.selected),
            shape(context, if (primary) colors.accent else colors.surface,
                if (primary) colors.accent else colors.border, 24), null)
        setOnClickListener { action() }
    }
    fun header(context: Context, back: String, onBack: () -> Unit, onTheme: () -> Unit): LinearLayout {
        val colors = FawUiTheme.palette(context)
        return row(context).apply {
            setPadding(dp(context, 14), dp(context, 5), dp(context, 10), dp(context, 5))
            background = shape(context, colors.surface)
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_faw_logo)
                imageTintList = ColorStateList.valueOf(colors.accent)
                contentDescription = "应用标志"
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(dp(context, 34), -1))
            addView(label(context, context.getString(R.string.app_name), 20f, colors.text, true).apply {
                setPadding(dp(context, 10), 0, dp(context, 14), 0)
            }, LinearLayout.LayoutParams(-2, -1))
            addView(View(context).apply { setBackgroundColor(colors.border) }, LinearLayout.LayoutParams(dp(context, 1), dp(context, 18)))
            addView(label(context, "无线 CarPlay", 15f, colors.muted).apply {
                setPadding(dp(context, 14), 0, 0, 0)
            }, LinearLayout.LayoutParams(-2, -1))
            addView(View(context), LinearLayout.LayoutParams(0, -1, 1f))
            addView(button(context, back, action = onBack), LinearLayout.LayoutParams(dp(context, 116), -1).apply { leftMargin = dp(context, 8) })
        }
    }
    fun card(context: Context, title: String, icon: Int): LinearLayout {
        val colors = FawUiTheme.palette(context)
        return column(context).apply {
            setPadding(dp(context, 12), dp(context, 12), dp(context, 12), dp(context, 12))
            background = shape(context, colors.surface, colors.border)
            addView(label(context, title, 20f, colors.text, true).apply {
                setCompoundDrawablesWithIntrinsicBounds(FawUiArtwork.Mark(icon, colors.accent, dp(context, 20)), null, null, null)
                compoundDrawablePadding = dp(context, 8)
            }, LinearLayout.LayoutParams(-1, -2))
        }
    }
}

internal class Hs5SettingsView(
    context: Context,
    pages: List<Page>,
    selected: Int,
    onSelected: (Int) -> Unit,
    onBack: () -> Unit,
    onSave: () -> Unit,
    onExit: () -> Unit,
    onTheme: () -> Unit,
) : LinearLayout(context) {
    data class Section(val title: String, val content: View)
    data class Page(val title: String, val hint: String, val icon: Int, val sections: List<Section>)
    var selectedPage = selected.coerceIn(pages.indices)
        private set
    private lateinit var changePage: (Int) -> Unit
    fun selectPage(index: Int) = changePage(index)

    init {
        orientation = VERTICAL
        tag = "faw_settings_root"
        val colors = FawUiTheme.palette(context)
        setBackgroundColor(colors.background)
        setPadding(Hs5Ui.dp(context, 16), Hs5Ui.dp(context, 14), Hs5Ui.dp(context, 16), Hs5Ui.dp(context, 14))
        addView(Hs5Ui.header(context, "返回首页", onBack, onTheme), LayoutParams(-1, Hs5Ui.dp(context, 46)))
        val body = Hs5Ui.row(context)
        val nav = Hs5Ui.column(context).apply {
            setPadding(Hs5Ui.dp(context, 6), Hs5Ui.dp(context, 6), Hs5Ui.dp(context, 6), Hs5Ui.dp(context, 6))
            background = Hs5Ui.shape(context, colors.surface)
        }
        val controls = mutableListOf<Button>()
        val pageViews = mutableListOf<View>()
        val panel = android.widget.FrameLayout(context)
        fun select(index: Int) {
            selectedPage = index
            controls.forEachIndexed { i, control ->
                control.isSelected = i == index
                control.setTextColor(if (i == index) colors.accent else colors.muted)
                control.background = Hs5Ui.shape(context, if (i == index) colors.selected else colors.surface)
            }
            pageViews.forEachIndexed { i, view -> view.visibility = if (i == index) View.VISIBLE else View.GONE }
            onSelected(index)
        }
        pages.forEachIndexed { index, page ->
            controls += Hs5Ui.button(context, page.title) { select(index) }.apply {
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                tag = "hs5_tab_$index"
                setCompoundDrawablesWithIntrinsicBounds(FawUiArtwork.Mark(page.icon, colors.accent, Hs5Ui.dp(context, 20)), null, null, null)
                compoundDrawablePadding = Hs5Ui.dp(context, 8)
            }
            nav.addView(controls.last(), LayoutParams(-1, 0, 1f).apply { if (index > 0) topMargin = Hs5Ui.dp(context, 3) })
            val pageView = Hs5Ui.column(context).apply {
                addView(Hs5Ui.label(context, page.title, 24f, colors.text, true))
                addView(Hs5Ui.label(context, page.hint, 13f, colors.muted))
                val cards = Hs5Ui.row(context)
                page.sections.forEach { section ->
                    val card = Hs5Ui.card(context, section.title, page.icon)
                    val scroll = ScrollView(context).apply {
                        isFillViewport = true
                        addView(section.content, ViewGroup.LayoutParams(-1, -2))
                    }
                    card.addView(scroll, LayoutParams(-1, 0, 1f).apply { topMargin = Hs5Ui.dp(context, 6) })
                    cards.addView(card, LayoutParams(0, -1, 1f).apply { if (cards.childCount > 0) leftMargin = Hs5Ui.dp(context, 10) })
                }
                addView(cards, LayoutParams(-1, 0, 1f).apply { topMargin = Hs5Ui.dp(context, 8) })
            }
            pageViews += pageView
            panel.addView(pageView, ViewGroup.LayoutParams(-1, -1))
        }
        body.addView(nav, LayoutParams(Hs5Ui.dp(context, 190), -1))
        body.addView(panel, LayoutParams(0, -1, 1f).apply { leftMargin = Hs5Ui.dp(context, 18) })
        addView(body, LayoutParams(-1, 0, 1f).apply { topMargin = Hs5Ui.dp(context, 10) })
        val footer = Hs5Ui.row(context).apply {
            addView(Hs5Ui.label(context, "修改后保存，CarPlay 将重新连接", 12f, colors.muted), LayoutParams(0, -1, 1f))
            addView(Hs5Ui.button(context, "退出应用", action = onExit), LayoutParams(Hs5Ui.dp(context, 110), -1))
            addView(Hs5Ui.button(context, "取消更改", action = onBack), LayoutParams(Hs5Ui.dp(context, 110), -1).apply { leftMargin = Hs5Ui.dp(context, 8) })
            addView(Hs5Ui.button(context, "保存并重连", true, onSave), LayoutParams(Hs5Ui.dp(context, 140), -1).apply { leftMargin = Hs5Ui.dp(context, 8) })
        }
        addView(footer, LayoutParams(-1, Hs5Ui.dp(context, 44)).apply { topMargin = Hs5Ui.dp(context, 10) })
        changePage = ::select
        select(selectedPage)
    }
}

internal class Hs5HomeView(
    private val activity: Activity,
    private val onSettings: (Int) -> Unit,
    private val onConnect: () -> Unit,
    private val onBluetooth: () -> Unit,
    private val onDetails: () -> Unit,
    private val onHome: () -> Unit,
    private val onTheme: () -> Unit,
    private val onCancel: () -> Unit = {},
) : LinearLayout(activity) {
    private var stage = "准备连接 iPhone"
    private var status: TextView? = null
    private var timeline: HandshakeTimeline? = null
    private var connectionProgress: Hs5ConnectionProgressView? = null
    private var connectButton: Button? = null

    init { redraw() }
    fun setStatus(message: String) {
        // Keep the actionable failure and retry count visible on the home card.
        stage = when {
            message.startsWith("Hotspot ready:") -> "无线热点已就绪"
            message.contains("Could not establish WIFI_P2P hotspot") -> "Wi-Fi Direct 暂不可用"
            message.contains("No bonded PHONE_SMART devices found") -> "请先配对 iPhone"
            else -> message
        }
        status?.text = stage
        connectionProgress?.bind(timeline, stage)
    }
    fun bind(value: HandshakeTimeline?) {
        timeline = value
        connectionProgress?.bind(value, stage)
    }
    fun redraw() {
        removeAllViews()
        orientation = VERTICAL
        tag = "faw_home_root"
        val colors = FawUiTheme.palette(context)
        setBackgroundColor(colors.background)
        setPadding(Hs5Ui.dp(context, 16), Hs5Ui.dp(context, 14), Hs5Ui.dp(context, 16), Hs5Ui.dp(context, 14))
        addView(Hs5Ui.header(context, "返回车机", onHome, onTheme), LayoutParams(-1, Hs5Ui.dp(context, 46)))
        val body = Hs5Ui.row(context)
        val hero = Hs5Ui.column(context).apply {
            setPadding(Hs5Ui.dp(context, 18), Hs5Ui.dp(context, 16), Hs5Ui.dp(context, 18), Hs5Ui.dp(context, 14))
            background = Hs5Ui.shape(context, colors.surface)
        }
        val main = Hs5Ui.row(context)
        val message = Hs5Ui.column(context)
        message.addView(Hs5Ui.label(context, "无线 CarPlay", 14f, colors.muted))
        status = Hs5Ui.label(context, stage, 20f, colors.text, true).apply {
            tag = "hs5_connection_status"
            maxLines = 3
            ellipsize = android.text.TextUtils.TruncateAt.END
            setAutoSizeTextTypeUniformWithConfiguration(
                Hs5Ui.sp(context, 12f).toInt(), Hs5Ui.sp(context, 20f).toInt(), 1,
                android.util.TypedValue.COMPLEX_UNIT_SP)
        }
        message.addView(status, LayoutParams(-1, 0, 1f))
        message.addView(Hs5Ui.label(context, "配对你的 iPhone，继续你的旅程。", 13f, colors.muted))
        connectButton = Hs5Ui.button(context, "打开 CarPlay", true, onConnect).apply { tag = "faw_open_carplay" }
        message.addView(connectButton,
            LayoutParams(-1, Hs5Ui.dp(context, 48)).apply { topMargin = Hs5Ui.dp(context, 12) })
        main.addView(message, LayoutParams(0, -1, 1.25f))
        main.addView(ImageView(context).apply {
            setImageDrawable(FawUiArtwork.ConnectionArt(context, colors, Hs5Ui.dp(context, 240)))
            scaleType = ImageView.ScaleType.FIT_CENTER
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }, LayoutParams(0, -1, 1f).apply { leftMargin = Hs5Ui.dp(context, 20) })
        hero.addView(main, LayoutParams(-1, 0, 1f))
        val shortcuts = Hs5Ui.row(context)
        listOf("连接设置" to 0, "画面显示" to 1, "导航与 HUD" to 3).forEach { (title, page) ->
            shortcuts.addView(Hs5Ui.button(context, title) { onSettings(page) }, LayoutParams(0, Hs5Ui.dp(context, 44), 1f).apply {
                if (shortcuts.childCount > 0) leftMargin = Hs5Ui.dp(context, 6)
            })
        }
        hero.addView(shortcuts, LayoutParams(-1, -2).apply { topMargin = Hs5Ui.dp(context, 12) })
        connectionProgress = Hs5ConnectionProgressView(context, onDetails, onCancel) { connecting ->
            connectButton?.apply {
                isEnabled = !connecting
                text = if (connecting) "连接中…" else "打开 CarPlay"
                alpha = if (connecting) 0.55f else 1f
            }
        }.also {
            hero.addView(it, LayoutParams(-1, Hs5Ui.dp(context, 58)).apply { topMargin = Hs5Ui.dp(context, 8) })
            it.bind(timeline, stage)
        }
        body.addView(hero, LayoutParams(0, -1, 1.65f))
        val devices = Hs5Ui.card(context, "我的设备", 10)
        devices.addView(Hs5Ui.label(context, "已配对的手机", 12f, colors.muted))
        val names = pairedIphoneNames()
        devices.addView(Hs5Ui.label(context, if (names.isEmpty()) "尚未找到已配对的手机" else names.joinToString("\n"), 18f, colors.text, true),
            LayoutParams(-1, 0, 1f))
        val bluetooth = try { context.getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true } catch (_: SecurityException) { false }
        val wifi = context.applicationContext.getSystemService(WifiManager::class.java)?.isWifiEnabled == true
        devices.addView(Hs5Ui.label(context, if (bluetooth) "蓝牙已开启" else "请开启蓝牙", 14f, colors.text, true))
        devices.addView(Hs5Ui.label(context, if (wifi) "Wi-Fi 已开启" else "请开启 Wi-Fi", 12f, colors.muted))
        devices.addView(Hs5Ui.button(context, "配对新手机", action = onBluetooth), LayoutParams(-1, Hs5Ui.dp(context, 44)).apply { topMargin = Hs5Ui.dp(context, 8) })
        devices.addView(Hs5Ui.button(context, "连接详情", action = onDetails), LayoutParams(-1, Hs5Ui.dp(context, 44)).apply { topMargin = Hs5Ui.dp(context, 6) })
        body.addView(devices, LayoutParams(0, -1, 1f).apply { leftMargin = Hs5Ui.dp(context, 10) })
        addView(body, LayoutParams(-1, 0, 1f).apply { topMargin = Hs5Ui.dp(context, 10) })
    }

    @SuppressLint("MissingPermission")
    private fun pairedIphoneNames(): List<String> {
        // API 28 uses the manifest's normal Bluetooth permission. API 31+ requires
        // BLUETOOTH_CONNECT at runtime; lint cannot follow this guard into map's lambda.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                return emptyList()
            }
        }
        return try {
            context.getSystemService(BluetoothManager::class.java)?.adapter?.bondedDevices.orEmpty()
                .filter(IphoneBluetoothDevices::isConnectionCandidate).map { it.name ?: "iPhone" }
        } catch (_: SecurityException) { emptyList() }
    }
}
