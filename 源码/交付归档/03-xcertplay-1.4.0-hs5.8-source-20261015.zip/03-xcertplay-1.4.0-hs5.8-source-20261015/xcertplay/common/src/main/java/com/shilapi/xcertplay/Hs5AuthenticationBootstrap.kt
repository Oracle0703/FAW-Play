package com.shilapi.xcertplay

import android.content.Context
import android.util.AtomicFile
import com.shilapi.xcertplay.mfi.LocalMfiAuthenticationClient
import com.shilapi.xcertplay.orchestration.MfiTarget
import java.io.File

/** Prepares the two approved identity documents without exporting their content or URI grants. */
internal object Hs5AuthenticationBootstrap {
    fun prepare(context: Context): Hs5SetupCheck = try {
        val target = AirPlayPersistence.loadMfiTarget(context)
        if (target != MfiTarget.LOCAL_FILES) {
            Hs5SetupCheck(Hs5CheckState.READY, "已保留外部认证接口；连接时检查认证硬件")
        } else {
            val directory = File(context.noBackupFilesDir, "local-auth").apply { mkdirs() }
            directory.setReadable(false, false); directory.setReadable(true, true)
            directory.setExecutable(false, false); directory.setExecutable(true, true)
            listOf("certificate.p7b", "identity.pk8").forEach { name ->
                val file = File(directory, name)
                val atomic = AtomicFile(file)
                val output = atomic.startWrite()
                try {
                    context.assets.open("hs5-auth/$name").use { it.copyTo(output) }
                    atomic.finishWrite(output)
                } catch (error: Exception) { atomic.failWrite(output); throw error }
                file.setReadable(false, false); file.setReadable(true, true)
                file.setWritable(false, false); file.setWritable(true, true)
            }
            File(directory, "certificate.p7b").inputStream().use { certificate ->
                File(directory, "identity.pk8").inputStream().use { key ->
                    LocalMfiAuthenticationClient.load(certificate, key)
                }
            }
            val base = "content://${context.packageName}.localauth/"
            AirPlayPersistence.saveLocalMfiCertificateUri(context, base + "certificate.p7b")
            AirPlayPersistence.saveLocalMfiPrivateKeyUri(context, base + "identity.pk8")
            Hs5SetupCheck(Hs5CheckState.READY, "内置认证材料已准备；由 iPhone 在连接时验证")
        }
    } catch (_: Exception) {
        Hs5SetupCheck(Hs5CheckState.FAILED, "认证材料未能准备，请重新安装完整版本")
    }
}
