package com.shilapi.xcertplay

import android.Manifest
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.shilapi.xcertplay.licensing.DeviceActivation
import com.shilapi.xcertplay.licensing.LicenseDecision
import com.shilapi.xcertplay.licensing.LicenseFeatures
import com.shilapi.xcertplay.updates.UpdateManifest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Owns first-use product tasks. Connection and media remain owned by the xcertplay host. */
internal class Hs5SetupCoordinator(
    private val host: CarPlayHostActivity,
    private val requestMicrophone: () -> Unit,
    private val requestLocation: () -> Unit,
    private val requestWireless: () -> Unit,
    private val requiredWireless: () -> List<String>,
    private val connect: () -> Unit,
    private val cancelConnection: () -> Unit,
    private val diagnostics: () -> Unit,
    private val managePhones: () -> Unit,
    private val closeManagement: () -> Unit,
    private val sessionBusy: () -> Boolean,
    private val onAuthenticationPrepared: () -> Unit,
    private val onFeaturesChanged: () -> Unit,
) {
    private val progress = Hs5OnboardingProgress(host)
    private val prefs = host.getSharedPreferences("hs5_first_use", 0)
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newFixedThreadPool(2)
    private var closed = false
    private var diagnosticsShown = false
    private var managementOpen = false
    private val pendingPermissions = mutableSetOf<String>()
    private var authentication = Hs5SetupCheck(Hs5CheckState.CHECKING, "正在准备内置认证")
    private var update = Hs5UpdateStatus()
    private var updateManifest: UpdateManifest? = null
    private var license = Hs5LicenseStatus()
    private var connecting = false
    private var connected = false
    private var connectionMessage = "点击开始连接，准备手机配对"
    private var activation: DeviceActivation? = null
    private var bindingCancelled = AtomicBoolean(true)
    private val downloadCancelled = AtomicBoolean(false)
    private var bindingDialog: AlertDialog? = null
    private var management: Hs5ManagementView? = null
    val onboarding = Hs5OnboardingView(host, Hs5OnboardingCallbacks(
        onMoveTo = { progress.moveTo(it); render(); if (it == Hs5OnboardingStep.UPDATE && update.state == Hs5UpdateState.NOT_CHECKED) checkUpdates() },
        onRefreshEnvironment = ::render, onRequestMicrophone = { request("microphone", requestMicrophone) },
        onRequestLocation = { request("location", requestLocation) },
        onRequestWirelessPermissions = { request("wireless", requestWireless) },
        onCheckUpdates = ::checkUpdates, onInstallUpdate = ::installUpdate,
        onStartBinding = ::startBinding, onRedeemCode = ::startBinding, onCancelBinding = ::cancelBinding,
        onConnect = { if (authentication.ready) connect() }, onCancelConnection = cancelConnection,
        onConnectionDetails = { diagnosticsShown = true; render(); diagnostics() },
        onFinish = { if (connected) { progress.complete(); render() } },
    ))

    fun initialize() {
        render()
        worker.execute {
            val auth = Hs5AuthenticationBootstrap.prepare(host.applicationContext)
            val decision = Hs5ProductServices.licenseStatus(host.applicationContext)
            deliver { authentication = auth; onAuthenticationPrepared(); license = licenseUi(decision); render() }
            if (decision.allowed) {
                val refreshed = Hs5ProductServices.refreshLicense(host.applicationContext)
                deliver { license = licenseUi(refreshed); onFeaturesChanged(); render() }
            }
        }
    }

    fun managementView(): View = Hs5ManagementView(host, Hs5ManagementCallbacks(
        onBack = closeManagement, onRequestMicrophone = { request("microphone", requestMicrophone) },
        onRequestLocation = { request("location", requestLocation) },
        onRequestWirelessPermissions = { request("wireless", requestWireless) },
        onCheckUpdates = ::checkUpdates, onInstallUpdate = ::installUpdate,
        onStartBinding = ::startBinding, onRedeemCode = ::startBinding, onCancelBinding = ::cancelBinding,
        onInstrumentPermission = ::instrumentPermission, onToggleUltra = { render() },
        onManagePhones = managePhones, onDiagnostics = { closeManagement(); diagnosticsShown = true; render(); diagnostics() },
        onReconnect = {
            AlertDialog.Builder(host).setTitle("重新连接 CarPlay")
                .setMessage("当前连接将断开，并使用最新权限和授权重新连接 iPhone。")
                .setNegativeButton("取消", null).setPositiveButton("重新连接") { _, _ ->
                    closeManagement(); host.reconnectWithCurrentPermissions()
                }.show()
        },
    )).also { management = it; render() }

    fun permissionResult() { pendingPermissions.clear(); onFeaturesChanged(); render() }
    fun managementOpen(open: Boolean) { managementOpen = open; render() }

    fun connectionState(message: String, attempting: Boolean, running: Boolean) {
        connectionMessage = message; connecting = attempting && !running; connected = running
        if (running) progress.complete()
        render()
    }

    fun back(): Boolean {
        if (diagnosticsShown) { diagnosticsShown = false; render(); return true }
        if (onboarding.visibility != View.VISIBLE) return false
        if (progress.step != Hs5OnboardingStep.WELCOME && !connecting) progress.moveTo(progress.step.previous())
        render(); return true
    }

    fun refresh() = render()
    fun readyToConnect() = authentication.ready

    private fun request(key: String, action: () -> Unit) {
        pendingPermissions.add(key)
        prefs.edit().putBoolean("asked_$key", true).apply()
        action(); render()
    }

    private fun permission(permission: String, key: String): Hs5PermissionStatus {
        if (key in pendingPermissions) return Hs5PermissionStatus.REQUESTING
        if (host.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) return Hs5PermissionStatus.GRANTED
        if (!prefs.getBoolean("asked_$key", false)) return Hs5PermissionStatus.NOT_REQUESTED
        return if (host.shouldShowRequestPermissionRationale(permission)) Hs5PermissionStatus.DENIED
        else Hs5PermissionStatus.PERMANENTLY_DENIED
    }

    private fun wirelessPermission(): Hs5PermissionStatus? {
        if ("wireless" in pendingPermissions) return Hs5PermissionStatus.REQUESTING
        val permissions = requiredWireless()
        if (permissions.isEmpty()) return null
        if (permissions.all { host.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) return Hs5PermissionStatus.GRANTED
        return if (!prefs.getBoolean("asked_wireless", false)) Hs5PermissionStatus.NOT_REQUESTED
        else if (permissions.any { host.shouldShowRequestPermissionRationale(it) }) Hs5PermissionStatus.DENIED
        else Hs5PermissionStatus.PERMANENTLY_DENIED
    }

    private fun render() {
        if (closed || host.isDestroyed) return
        val adapter = host.getSystemService(BluetoothManager::class.java)?.adapter
        val bluetooth = try {
            Hs5SetupCheck(if (adapter?.isEnabled == true) Hs5CheckState.READY else Hs5CheckState.UNAVAILABLE,
                if (adapter?.isEnabled == true) "已开启；连接时自动请求可被搜索" else "蓝牙未开启或当前无法读取，请检查无线权限")
        } catch (_: SecurityException) { Hs5SetupCheck(Hs5CheckState.UNAVAILABLE, "先允许附近设备权限") }
        val wifiOn = host.applicationContext.getSystemService(WifiManager::class.java)?.isWifiEnabled == true
        val p2p = host.packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT) ||
            (com.shilapi.xcertplay.hud.HongqiNavigation.supported() && host.getSystemService(android.net.wifi.p2p.WifiP2pManager::class.java) != null)
        val wifi = Hs5SetupCheck(if (wifiOn && p2p) Hs5CheckState.READY else Hs5CheckState.UNAVAILABLE,
            when { !wifiOn -> "Wi-Fi 当前未开启"; !p2p -> "系统未提供 Wi-Fi Direct"; else -> "已开启；点击连接后自动创建专用 P2P 组" })
        val name = bluetoothName(adapter)
        onboarding.bind(Hs5OnboardingSnapshot(progress.step,
            Hs5SetupCheck(Hs5CheckState.READY, if (com.shilapi.xcertplay.hud.HongqiNavigation.supported()) "已识别红旗 HS5 车机" else "当前为通用设备验证环境；车辆增强功能仅在 HS5 启用"),
            bluetooth, wifi, authentication, permission(Manifest.permission.RECORD_AUDIO, "microphone"),
            permission(Manifest.permission.ACCESS_FINE_LOCATION, "location"), wirelessPermission(), update, license,
            name, connectionMessage, connecting, connected))
        onboarding.visibility = if (!managementOpen && !progress.completed && !diagnosticsShown && !connected) View.VISIBLE else View.GONE
        val clusterAllowed = Hs5ProductServices.featureAllowed(host, LicenseFeatures.INSTRUMENT_MAP)
        val instrument = when {
            !clusterAllowed || !com.shilapi.xcertplay.hud.HongqiNavigation.supported() -> Hs5InstrumentPermission.NOT_REQUIRED
            Settings.canDrawOverlays(host) -> Hs5InstrumentPermission.GRANTED
            else -> Hs5InstrumentPermission.NEEDED
        }
        management?.bind(Hs5ManagementSnapshot(permission(Manifest.permission.RECORD_AUDIO, "microphone"),
            permission(Manifest.permission.ACCESS_FINE_LOCATION, "location"), authentication, license, update,
            instrument, when (instrument) {
                Hs5InstrumentPermission.NEEDED -> "原厂仪表导航窗口需要系统特殊权限；HUD 本身无需此权限。系统不提供普通授权弹窗。"
                Hs5InstrumentPermission.GRANTED -> "原厂仪表导航窗口权限已允许"
                else -> "基础 CarPlay 和 HUD 无需仪表悬浮窗权限"
            }, false, false,
            "当前版本尚未接入 Apple CarPlay Ultra，暂不可开启。", wirelessPermission(), sessionBusy()))
    }

    // Android 9 uses the manifest normal Bluetooth permission; S+ requires the runtime grant.
    @android.annotation.SuppressLint("MissingPermission")
    private fun bluetoothName(adapter: android.bluetooth.BluetoothAdapter?): String? {
        if (Build.VERSION.SDK_INT >= 31 &&
            host.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return null
        return try { adapter?.name } catch (_: SecurityException) { null }
    }

    private fun checkUpdates() {
        if (update.busy || closed) return
        update = Hs5UpdateStatus(Hs5UpdateState.CHECKING, "正在检查更新"); render()
        worker.execute {
            val check = Hs5ProductServices.checkUpdate(host.applicationContext)
            deliver {
                updateManifest = check.manifest
                update = Hs5UpdateStatus(when (check.status) {
                    Hs5UpdateCheckStatus.AVAILABLE -> Hs5UpdateState.AVAILABLE
                    Hs5UpdateCheckStatus.UP_TO_DATE -> Hs5UpdateState.UP_TO_DATE
                    Hs5UpdateCheckStatus.NOT_CONFIGURED, Hs5UpdateCheckStatus.CHANNEL_NOT_PUBLISHED -> Hs5UpdateState.UNCONFIGURED
                    Hs5UpdateCheckStatus.FAILED -> Hs5UpdateState.FAILED
                }, check.message); render()
            }
        }
    }

    private fun installUpdate() {
        val manifest = updateManifest ?: return
        if (update.busy) return
        if (sessionBusy()) { toast("请先断开 CarPlay，再安装更新"); return }
        AlertDialog.Builder(host).setTitle("安装更新").setMessage("下载并校验 ${manifest.versionName}，随后由系统确认安装。")
            .setNegativeButton("取消", null).setPositiveButton("下载", { _, _ ->
                update = Hs5UpdateStatus(Hs5UpdateState.DOWNLOADING, "正在下载并校验更新包"); render()
                worker.execute {
                    try {
                        val file = Hs5ProductServices.downloadUpdate(host.applicationContext, manifest, downloadCancelled) { _, _ -> }
                        deliver {
                            try {
                                val intent = Hs5ProductServices.installUpdate(host, manifest, file, sessionBusy())
                                host.startActivity(intent)
                                update = Hs5UpdateStatus(Hs5UpdateState.AVAILABLE, "更新包已校验，请在系统弹窗确认安装")
                            } catch (error: Exception) { update = Hs5UpdateStatus(Hs5UpdateState.FAILED, error.message ?: "无法启动系统安装器") }
                            render()
                        }
                    } catch (error: Exception) {
                        deliver { update = Hs5UpdateStatus(Hs5UpdateState.FAILED, error.message ?: "下载未完成，请重试"); render() }
                    }
                }
            }).show()
    }

    private fun startBinding() {
        if (!bindingCancelled.get() || closed) return
        val cancellation = AtomicBoolean(false)
        bindingCancelled = cancellation
        license = Hs5LicenseStatus(Hs5LicenseState.BINDING, "正在生成手机绑定二维码"); render()
        worker.execute {
            var createdGrant: DeviceActivation? = null
            var finished = false
            try {
                val grant = Hs5ProductServices.beginBinding(host.applicationContext)
                createdGrant = grant
                val code = MultiFormatWriter().encode(grant.activationUrl, BarcodeFormat.QR_CODE, 480, 480)
                val bitmap = Bitmap.createBitmap(480, 480, Bitmap.Config.ARGB_8888)
                for (y in 0 until 480) for (x in 0 until 480) bitmap.setPixel(x, y, if (code[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
                deliver {
                    if (!cancellation.get()) {
                        activation = grant
                        license = Hs5LicenseStatus(Hs5LicenseState.BINDING, "请用手机扫码，在手机页面输入兑换码并绑定；二维码会自动过期")
                        val content = LinearLayout(host).apply {
                            orientation = LinearLayout.VERTICAL; setPadding(24, 16, 24, 16)
                            addView(ImageView(host).apply { setImageBitmap(bitmap); contentDescription = "手机授权绑定二维码" }, LinearLayout.LayoutParams(480, 480))
                            addView(TextView(host).apply { text = "基础 CarPlay 免费。请用手机扫码，在手机页面输入兑换码。" })
                        }
                        bindingDialog = AlertDialog.Builder(host).setTitle("绑定增强授权").setView(content)
                            .setNegativeButton("取消绑定") { _, _ -> cancelBinding() }.setOnCancelListener { cancelBinding() }.create().also {
                                it.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE); it.show()
                            }
                        render()
                    }
                }
                val decision = if (!cancellation.get()) Hs5ProductServices.awaitBinding(host.applicationContext, grant, cancellation) else null
                finished = decision != null
                deliver {
                    if (bindingCancelled === cancellation && !cancellation.get()) {
                        cancellation.set(true); activation = null; bindingDialog?.dismiss(); bindingDialog = null
                        license = licenseUi(requireNotNull(decision)); onFeaturesChanged(); render()
                    }
                }
            } catch (error: Exception) {
                deliver {
                    if (bindingCancelled === cancellation && !cancellation.get()) {
                        cancellation.set(true); activation = null; bindingDialog?.dismiss(); bindingDialog = null
                        license = Hs5LicenseStatus(Hs5LicenseState.FAILED, error.message ?: "绑定未完成，请联网后重试"); render()
                    }
                }
            } finally {
                if (!finished) createdGrant?.let { grant ->
                    runCatching { Hs5ProductServices.cancelBinding(host.applicationContext, grant) }
                }
            }
        }
    }

    private fun cancelBinding() {
        bindingCancelled.set(true)
        activation = null
        bindingDialog?.dismiss(); bindingDialog = null
        license = licenseUi(Hs5ProductServices.licenseStatus(host)); render()
    }

    private fun instrumentPermission() {
        if (!Hs5ProductServices.featureAllowed(host, LicenseFeatures.INSTRUMENT_MAP)) return
        AlertDialog.Builder(host).setTitle("仪表显示权限")
            .setMessage("此特殊权限无法通过普通系统弹窗授予。继续将打开系统确认页面；不影响基础 CarPlay 和 HUD。")
            .setNegativeButton("稍后", null).setPositiveButton("系统确认") { _, _ ->
                try { host.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${host.packageName}"))) }
                catch (_: Exception) { toast("当前系统没有提供仪表显示权限入口") }
            }.show()
    }

    private fun licenseUi(decision: LicenseDecision) = Hs5LicenseStatus(when {
        decision.allowed -> Hs5LicenseState.ACTIVE
        decision.code == "NOT_CONFIGURED" -> Hs5LicenseState.UNCONFIGURED
        decision.code == "ACTIVATION_REQUIRED" -> Hs5LicenseState.FREE
        else -> Hs5LicenseState.FAILED
    }, decision.message)

    private fun toast(message: String) = Toast.makeText(host, message, Toast.LENGTH_LONG).show()
    private fun deliver(action: () -> Unit) { main.post { if (!closed && !host.isDestroyed) action() } }
    fun close() {
        closed = true; bindingCancelled.set(true); downloadCancelled.set(true)
        bindingDialog?.dismiss(); bindingDialog = null
        main.removeCallbacksAndMessages(null); worker.shutdown()
    }
}
