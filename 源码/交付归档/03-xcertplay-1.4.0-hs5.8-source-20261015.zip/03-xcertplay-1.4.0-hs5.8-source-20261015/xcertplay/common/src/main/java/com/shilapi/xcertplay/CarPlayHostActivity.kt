package com.shilapi.xcertplay

import android.Manifest
import android.bluetooth.BluetoothManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.shilapi.xcertplay.airplay.CarPlayClusterDisplay
import com.shilapi.xcertplay.airplay.AirPlayConfig
import com.shilapi.xcertplay.airplay.AirPlayDisplaySettings
import com.shilapi.xcertplay.airplay.AirPlayPhysicalSizeBasis
import com.shilapi.xcertplay.airplay.AirPlayPhysicalSizeMm
import com.shilapi.xcertplay.airplay.CarPlayDisplayScale
import com.shilapi.xcertplay.airplay.AirPlayDisplayConfig
import com.shilapi.xcertplay.airplay.AirPlayIdentity
import com.shilapi.xcertplay.airplay.AirPlayIcon
import com.shilapi.xcertplay.airplay.AirPlaySafeArea
import com.shilapi.xcertplay.airplay.AirPlaySession
import com.shilapi.xcertplay.airplay.AirPlaySessionListener
import com.shilapi.xcertplay.airplay.CarPlayMediaEngine
import com.shilapi.xcertplay.airplay.SafeAreaRect
import com.shilapi.xcertplay.host.R
import com.shilapi.xcertplay.location.AndroidCarPlayLocationProvider
import com.shilapi.xcertplay.media.AndroidMediaSink
import com.shilapi.xcertplay.media.CarPlayTouchMapper
import com.shilapi.xcertplay.media.MainMediaAudioBuffer
import com.shilapi.xcertplay.media.MediaMetricsMonitor
import com.shilapi.xcertplay.media.MicrophoneGain
import com.shilapi.xcertplay.media.MicrophoneLevelMonitor
import com.shilapi.xcertplay.network.CarPlayVpnService
import com.shilapi.xcertplay.orchestration.CarPlayController
import com.shilapi.xcertplay.orchestration.CarPlayRuntimeConfig
import com.shilapi.xcertplay.orchestration.CarPlayStatus
import com.shilapi.xcertplay.orchestration.CarPlayTransport
import com.shilapi.xcertplay.orchestration.MfiTarget
import com.shilapi.xcertplay.transport.Iap2IdentificationConfig
import com.shilapi.xcertplay.transport.Iap2LocationProvider
import com.shilapi.xcertplay.transport.UsbDeviceId
import java.io.File
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Full-screen CarPlay host. It renders decoded video through a [VideoSurfaceView], forwards touch to
 * the active AirPlay session, and drives the complete wired or wireless bring-up through
 * [CarPlayController].
 *
 * Apple devices are discovered by vendor ID; CH341 uses the configured VID/PID below.
 */
class CarPlayHostActivity : ComponentActivity() {
    private val MENU_RIPPLE get() = FawUiTheme.palette(this).selected
    private val MENU_DANGER_FILL get() = FawUiTheme.palette(this).selected
    private val MENU_DANGER get() = FawUiTheme.palette(this).accent
    private val MENU_BUTTON_PRIMARY get() = FawUiTheme.palette(this).accent
    private val MENU_BUTTON get() = FawUiTheme.palette(this).surface
    private val MENU_SEPARATOR get() = FawUiTheme.palette(this).border
    private val MENU_TRACK_OFF get() = FawUiTheme.palette(this).border
    private val MENU_ACCENT_TRACK get() = FawUiTheme.palette(this).selected
    private val MENU_ACCENT get() = FawUiTheme.palette(this).accent
    private val MENU_SECONDARY get() = FawUiTheme.palette(this).muted
    private val MENU_LABEL get() = FawUiTheme.palette(this).text
    private val MENU_BACKGROUND get() = FawUiTheme.palette(this).surface
    private data class SettingsBaseline(
        val safeAreaSize: DisplaySize?,
        val safeAreaRect: SafeAreaRect?,
        val customIconBytes: ByteArray?,
    )

    private lateinit var airPlayIdentity: AirPlayIdentity

    // CH341 USB\VID_1A86&PID_5512&REV_0304 is the deployment-supplied bridge identity.
    private fun createRuntimeConfig(): CarPlayRuntimeConfig = CarPlayRuntimeConfig(
        mfiTarget = mfiTarget,
        ch341Devices = if (mfiTarget == MfiTarget.USB_CH341) {
            listOf(UsbDeviceId(0x1a86, 0x5512))
        } else {
            emptyList()
        },
        // The CP latches its I2C address from the RST level at its own power-up, so the host must
        // not pulse RST before discovery. Driving D0 re-latches the part onto the alternate
        // address (0x10), where the accessory certificate is not readable. Leave RST at its
        // hardware pull (VCC -> 0x11) and let the scanner find the part with its certificate.
        // Set this back to 0 to restore the D0 pulse.
        ch341MfiResetGpio = null,
        linuxI2cPath = if (mfiTarget == MfiTarget.I2C) mfiI2cPath.trim() else null,
        remoteMfiServer = remoteMfiServer.trim().takeIf { it.isNotEmpty() },
        remoteMfiToken = remoteMfiToken.takeIf { it.isNotEmpty() },
        localMfiCertificateUri = localMfiCertificateUri.takeIf { it.isNotEmpty() },
        localMfiPrivateKeyUri = localMfiPrivateKeyUri.takeIf { it.isNotEmpty() },
        identification = Iap2IdentificationConfig(
            name = "xcertplay",
            modelIdentifier = normalizedModel(),
            manufacturer = normalizedManufacturer(),
            serialNumber = "xcertplay",
            firmwareVersion = "1.0.0",
            hardwareVersion = "1.0",
            carPlayUsbInterfaceNumber = 3,
            locationInformationEnabled = locationReportingEnabled,
        ),
        transport = if (wirelessEnabled) CarPlayTransport.WIRELESS else CarPlayTransport.WIRED,
        wirelessRadioAttempt = wirelessRetryPolicy.radioAttempt,
        wirelessFailedFrequencyMHz = wirelessRetryPolicy.failedFrequencyMHz,
        locationReportingEnabled = locationReportingEnabled,
    )

    private val vpnConsent =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            awaitingVpnConsent = false
            if (result.resultCode == RESULT_OK) {
                vpnReady = true
                maybeStartCarPlay()
            } else {
                setStatus("VPN consent was denied")
            }
        }
    private val wirelessPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            awaitingWirelessPermissions = false
            wirelessPermissionsReady = hasRequiredWirelessPermissions()
            setup.permissionResult()
            if (!connectionRequested || connectionPaused || menuOpen) return@registerForActivityResult
            appendLog(
                if (wirelessPermissionsReady) {
                    "Wireless startup permissions granted"
                } else {
                    "Wireless startup permissions denied"
                },
            )
            updateHotspotStatusBlock()
            if (wirelessPermissionsReady) prepareBluetoothDiscoverability()
            else setConnectionStage("缺少无线连接权限，请点击连接重试授权")
            maybeStartCarPlay()
        }
    private val bluetoothDiscoverabilityConsent =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            awaitingBluetoothDiscoverability = false
            if (!connectionRequested || connectionPaused) return@registerForActivityResult
            // ACTION_REQUEST_DISCOVERABLE returns the accepted duration, rather than RESULT_OK.
            bluetoothDiscoverabilityReady = result.resultCode > 0
            if (bluetoothDiscoverabilityReady) {
                appendLog("Bluetooth discoverability consent granted")
                maybeStartCarPlay()
            } else {
                setConnectionStage("未允许蓝牙被搜索，请点击连接重试")
            }
        }
    private val microphonePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            awaitingMicrophonePermission = false
            microphoneAvailable = granted
            microphonePermissionResolved = true
            appendLog(if (granted) "Microphone permission granted" else "Microphone permission denied")
            updatePermissionControls()
            setup.permissionResult()
            val startGainTest = granted && microphoneGainTestAfterPermission && menuOpen
            microphoneGainTestAfterPermission = false
            requestStartupPrerequisites()
            if (startGainTest) startMicrophoneGainTest()
        }
    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            awaitingLocationPermission = false
            locationPermissionAvailable = hasFineLocationPermission()
            if (locationPermissionAvailable) {
                appendLog("Location permission granted")
                locationReportingEnabled = true
                AirPlayPersistence.saveLocationReportingEnabled(this, true)
            } else if (locationReportingEnabled) {
                locationReportingEnabled = false
                if (!menuOpen) {
                    AirPlayPersistence.saveLocationReportingEnabled(
                        this@CarPlayHostActivity,
                        false,
                    )
                }
                locationReportingSwitch?.isChecked = false
                val approximateOnly =
                    grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true
                appendLog(
                    if (approximateOnly) {
                        "Precise location permission denied; location reporting disabled"
                    } else {
                        "Location permission denied; location reporting disabled"
                    },
                )
            }
            updateResolutionMenu()
            setup.permissionResult()
            if (!menuOpen) requestStartupPrerequisites()
        }

    private val imagePicker =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri == null) {
                externalActivityInProgress = false
                return@registerForActivityResult
            }
            imageCrop.launch(
                Intent(this, ImageCropActivity::class.java)
                    .setData(uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
            )
        }
    private val imageCrop =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            externalActivityInProgress = false
            if (result.resultCode == RESULT_OK) {
                updateAirPlayIconPreview()
                appendLog("Custom AirPlay icon updated")
            }
        }
    private val localMfiCertificatePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            externalActivityInProgress = false
            if (uri != null && retainDocumentReadPermission(uri, "certificate")) {
                localMfiCertificateUri = uri.toString()
                updateLocalMfiDocumentViews()
                mfiErrorView?.visibility = View.GONE
            }
        }
    private val localMfiPrivateKeyPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            externalActivityInProgress = false
            if (uri != null && retainDocumentReadPermission(uri, "private key")) {
                localMfiPrivateKeyUri = uri.toString()
                updateLocalMfiDocumentViews()
                mfiErrorView?.visibility = View.GONE
            }
        }

    private var mainWebDisplay = CarPlayWebDisplayConfig()
    private var clusterWebDisplay = CarPlayWebDisplayConfig(width = 1920)
    private val webDisplays get() = CarPlayWebDisplayFactory.find(sink)
    private var clusterPreview: TextureView? = null
    private var clusterPreviewSurface: Surface? = null
    private val webDisplayInputs = mutableMapOf<Int, Pair<EditText, EditText>>()
    private val webDisplayRefresh = mutableListOf<() -> Unit>()
    private val webDisplayAddressViews = mutableMapOf<Int, TextView>()
    private var videoView: View? = null
    private val touchMapper = CarPlayTouchMapper()
    private var contentRoot: FrameLayout? = null
    private var gestureOverlay: View? = null
    private var disconnectedSettingsButton: View? = null
    private var settingsMenu: View? = null
    private var settingsPage = 0
    private var homeView: Hs5HomeView? = null
    private var connectionRequested = false
    private var connectionPaused = false
    private var showConnectionDetails = false
    private var uiAppearanceWatch: AutoCloseable? = null
    private var mfiTargetGroup: RadioGroup? = null
    private var mfiI2cFields: View? = null
    private var mfiRemoteFields: View? = null
    private var mfiLocalFields: View? = null
    private var mfiErrorView: TextView? = null
    private var mfiI2cPathInput: EditText? = null
    private var remoteMfiServerInput: EditText? = null
    private var remoteMfiTokenInput: EditText? = null
    private var localMfiCertificateDocumentView: TextView? = null
    private var localMfiPrivateKeyDocumentView: TextView? = null
    private var settingsBaseline: SettingsBaseline? = null
    private var locationReportingSwitch: Switch? = null
    private var mainMediaAudioBufferSeekBar: SeekBar? = null
    private var mainMediaAudioBufferValueView: TextView? = null
    private var microphoneGainSeekBar: SeekBar? = null
    private var microphoneGainValueView: TextView? = null
    private var microphoneTestButton: Button? = null
    private var microphoneLevelBar: ProgressBar? = null
    private var microphoneLevelValueView: TextView? = null
    private var microphoneLevelMonitor: MicrophoneLevelMonitor? = null
    private var microphoneGainTestAfterPermission = false
    private var statusView: TextView? = null
    private var statusScrollView: ScrollView? = null
    private var handshakePanel: HandshakePanelView? = null
    private var handshakeTimeline: HandshakeTimeline? = null
    private var lastAttemptFailure: String? = null
    private var resolutionValueView: TextView? = null
    private var resolutionPreviewView: TextView? = null
    private var hotspotStatusView: TextView? = null
    private var iconPreviewView: ImageView? = null
    private var iconStatusView: TextView? = null
    private var safeAreaSummaryView: TextView? = null
    private var safeAreaEditor: View? = null
    private var safeAreaEditorView: SafeAreaEditorView? = null
    private var safeAreaEditSize: DisplaySize? = null
    private var safeAreaEditorActive = false
    private var mediaMetricsOverlay: MediaMetricsOverlayView? = null
    private var mediaMetricsMonitor: MediaMetricsMonitor? = null
    private var externalActivityInProgress = false
    private var sink: AndroidMediaSink? = null
    private var vehicleNight: Boolean? = null
    private val hs5Prefs by lazy { getSharedPreferences("xcertplay_hs5", MODE_PRIVATE) }
    private val hs5 get() = com.shilapi.xcertplay.hud.HongqiNavigation.supported()
    private val hongqi by lazy { HongqiHostIntegration(this) { night ->
        vehicleNight = night
        darkMode = night ?: isDarkMode(resources.configuration.uiMode)
        syncAirPlayDarkMode()
    } }
    private var controller: CarPlayController? = null
    private var currentUiListener: AirPlaySessionListener? = null
    private var currentSurface: Surface? = null
    private var currentSurfaceTexture: SurfaceTexture? = null
    private var activeDisplaySize: DisplaySize? = null
    private var pendingDisplaySize: DisplaySize? = null
    private var displayScaleTenths = CarPlayDisplayScale.DEFAULT_TENTHS
    private var hevcEnabled = true
    private var hevcSoftwareDecoderEnabled = false
    private var advancedAudioChannelMappingSupported = false
    private var advancedAudioChannelMapping = false
    private var mainMediaAudioBufferDurationMs = MainMediaAudioBuffer.DEFAULT_DURATION_MS
    @Volatile private var debugLogsEnabled = false
    private var videoFrameLogsEnabled = false
    private var videoFrameLogSwitch: Switch? = null
    private var mediaMetricsEnabled = false
    private var audioPacketCaptureEnabled = false
    private var moreGesturesToSettings = false
    private var autoStartOnBoot = false
    private var manufacturer = AirPlayPersistence.DEFAULT_MANUFACTURER
    private var model = AirPlayPersistence.DEFAULT_MODEL
    private var oemLabel = AirPlayPersistence.DEFAULT_OEM_LABEL
    private var fps = AirPlayDisplaySettings.DEFAULT_FPS
    private var widthPhysicalMm = AirPlayDisplaySettings.DEFAULT_WIDTH_PHYSICAL_MM
    private var physicalSizeBasis = AirPlayDisplaySettings.DEFAULT_PHYSICAL_SIZE_BASIS
    private var maximumDetectedWidthPixels = 0
    private var maximumDetectedHeightPixels = 0
    private var rightHandDrive = false
    private var hideTopBar = true
    private var hideBottomBar = true
    private var safeAreaDrawOutside = true
    private var locationReportingEnabled = false
    private var locationPermissionAvailable = false
    private var microphoneAvailable = false
    private var microphonePermissionResolved = false
    @Volatile private var microphoneGainPercent = MicrophoneGain.DEFAULT_PERCENT
    private var wirelessEnabled = false
    private var mfiTarget = MfiTarget.USB_CH341
    private var mfiI2cPath = AirPlayPersistence.DEFAULT_MFI_I2C_PATH
    private var remoteMfiServer = ""
    private var remoteMfiToken = ""
    private var localMfiCertificateUri = ""
    private var localMfiPrivateKeyUri = ""
    private var wirelessPermissionsReady = false
    private var awaitingVpnConsent = false
    private var awaitingWirelessPermissions = false
    private var awaitingMicrophonePermission = false
    private var awaitingBluetoothDiscoverability = false
    private var bluetoothDiscoverabilityReady = false
    private var bluetoothModeConfirmation: AutoCloseable? = null
    private var awaitingLocationPermission = false
    private var vpnReady = false
    private var hotspotStatus = HotspotStatus(state = "off")
    private var menuOpen = false
    private var darkMode = false
    private var activeAirPlaySession: AirPlaySession? = null
    private var activeScreenStreamTypes = mutableSetOf<Int>()
    private var handshakeResetInProgress = false
    private var startAfterHandshakeReset = false
    private var restartGeneration = 0
    private var reconnectScheduled = false
    private var pendingManagementRecovery: Pair<String, Long?>? = null
    private val wirelessRetryPolicy = WirelessRetryPolicy()
    private val sessionLog get() = CarPlayBackgroundSession.log
    private var gestureSequenceActive = false
    private var gestureTracking = false
    private var gestureStartX = 0f
    private var gestureStartY = 0f
    private var edgeSettingsGestureCaptured = false
    private var edgeSettingsGestureEligible = false
    private val shuttingDown = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val setup: Hs5SetupCoordinator by lazy {
        Hs5SetupCoordinator(this,
            requestMicrophone = { awaitingMicrophonePermission = true; microphonePermission.launch(Manifest.permission.RECORD_AUDIO) },
            requestLocation = ::requestLocationPermission,
            requestWireless = { awaitingWirelessPermissions = true; wirelessPermissions.launch(requiredWirelessPermissions().toTypedArray()) },
            requiredWireless = ::requiredWirelessPermissions,
            connect = ::connectFromHome, cancelConnection = ::cancelConnectionAttempt,
            diagnostics = { showConnectionDetails = true; updateDebugOverlays() },
            managePhones = ::openSystemBluetoothSettings, closeManagement = ::closeManagement,
            sessionBusy = { activeAirPlaySession != null || (connectionRequested && !connectionPaused) },
            onAuthenticationPrepared = {
                mfiTarget = AirPlayPersistence.loadMfiTarget(this)
                localMfiCertificateUri = AirPlayPersistence.loadLocalMfiCertificateUri(this)
                localMfiPrivateKeyUri = AirPlayPersistence.loadLocalMfiPrivateKeyUri(this)
            },
            onFeaturesChanged = { hongqi.refreshAuthorization(); updateWebDisplayPreviews() },
        )
    }
    private var microphonePermissionButton: Button? = null
    private var instrumentPermissionButton: Button? = null
    private val teardownExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val airPlayCommandExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val logLines = ScreenLogBuffer(MAX_SCREEN_LOG_LINES)
    private val pendingScreenLogs = ArrayDeque<PendingLog>()
    private val pendingScreenLogsLock = Any()
    private var screenDrainPosted = false
    private val drainScreenLogs = Runnable {
        val pending = synchronized(pendingScreenLogsLock) {
            screenDrainPosted = false
            pendingScreenLogs.toList().also { pendingScreenLogs.clear() }
        }
        if (debugLogsEnabled && !menuOpen) {
            pending.forEach { entry ->
                if (entry.generation == restartGeneration) {
                    appendScreenLog(entry.timestampMillis, entry.message)
                }
            }
        }
    }
    private val expireOldLogLines = Runnable { refreshLogView(System.currentTimeMillis()) }
    private var logRenderScheduled = false
    private val renderLogLines = Runnable {
        logRenderScheduled = false
        refreshLogView(System.currentTimeMillis())
    }
    private val applyDisplaySize = Runnable {
        val size = pendingDisplaySize ?: return@Runnable
        pendingDisplaySize = null
        applyDisplaySize(size)
    }

    private val textureListener = object : TextureView.SurfaceTextureListener {
        override fun onSurfaceTextureAvailable(texture: SurfaceTexture, width: Int, height: Int) {
            val existing = currentSurface
            val surface = if (
                existing != null &&
                currentSurfaceTexture === texture &&
                existing.isValid
            ) {
                existing
            } else {
                Surface(texture).also {
                    existing?.release()
                    currentSurface = it
                    currentSurfaceTexture = texture
                }
            }
            appendLog(if (existing === surface) "Texture surface reused" else "Texture surface created")
            attachSurface(surface)
            updateWebDisplayPreviews()
            scheduleDisplaySize(width, height)
        }

        override fun onSurfaceTextureSizeChanged(texture: SurfaceTexture, width: Int, height: Int) {
            updateWebDisplayPreviews()
            scheduleDisplaySize(width, height)
        }

        override fun onSurfaceTextureDestroyed(texture: SurfaceTexture): Boolean {
            if (currentSurfaceTexture !== texture) return true
            currentSurface?.let { surface ->
                detachSurface(SCREEN_TYPE_MAIN, surface)
                surface.release()
            }
            currentSurface = null
            currentSurfaceTexture = null
            appendLog("Texture surface destroyed")
            return true
        }

        override fun onSurfaceTextureUpdated(texture: SurfaceTexture) = Unit
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initializeSessionLog()
        darkMode = isDarkMode(resources.configuration.uiMode)
        advancedAudioChannelMappingSupported =
            resources.getBoolean(R.bool.config_advanced_audio_channel_mapping)
        airPlayIdentity = AirPlayPersistence.loadIdentity(this)
        loadPersistedSettings()
        locationPermissionAvailable = hasFineLocationPermission()
        setContentView(buildContentView())
        applyFullscreenMode()
        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (menuOpen) {
                        closeManagement()
                    } else if (setup.back()) {
                        showConnectionDetails = false
                        updateDebugOverlays()
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            },
        )

        appendLog(
            "Host started; MFI target=${mfiTargetLabel(mfiTarget)}; " +
                "transport=${if (wirelessEnabled) "wireless" else "wired"}",
        )
        val reusedBackgroundSession = adoptBackgroundSession()
        microphoneAvailable =
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        microphonePermissionResolved = true
        if (reusedBackgroundSession) {
            updateDebugOverlays()
        } else {
            setConnectionStage("点击连接以开始 CarPlay")
        }
        setup.initialize()
        setup.connectionState("点击连接以开始 CarPlay", connectionRequested && !connectionPaused, SCREEN_TYPE_MAIN in activeScreenStreamTypes)
    }

    private fun loadPersistedSettings() {
        mainWebDisplay = AirPlayPersistence.loadWebDisplay(this, SCREEN_TYPE_MAIN)
        clusterWebDisplay = AirPlayPersistence.loadWebDisplay(this, SCREEN_TYPE_ALT)
        displayScaleTenths = AirPlayPersistence.loadDisplayScaleTenths(this)
        hevcEnabled = AirPlayPersistence.loadHevcEnabled(this)
        hevcSoftwareDecoderEnabled =
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                AirPlayPersistence.loadHevcSoftwareDecoderEnabled(this)
        advancedAudioChannelMapping =
            advancedAudioChannelMappingSupported &&
                AirPlayPersistence.loadAdvancedAudioChannelMapping(this)
        mainMediaAudioBufferDurationMs =
            AirPlayPersistence.loadMainMediaAudioBufferDurationMs(this)
        microphoneGainPercent = AirPlayPersistence.loadMicrophoneGainPercent(this)
        debugLogsEnabled = AirPlayPersistence.loadDebugLogsEnabled(this)
        videoFrameLogsEnabled = AirPlayPersistence.loadVideoFrameLogsEnabled(this)
        sessionLog.videoFramesEnabled = videoFrameLogsEnabled
        mediaMetricsEnabled = AirPlayPersistence.loadMediaMetricsEnabled(this)
        audioPacketCaptureEnabled = AirPlayPersistence.loadAudioPacketCaptureEnabled(this)
        moreGesturesToSettings = AirPlayPersistence.loadMoreGesturesToSettings(this)
        autoStartOnBoot = AirPlayPersistence.loadAutoStartOnBoot(this)
        manufacturer = AirPlayPersistence.loadManufacturer(this)
        model = AirPlayPersistence.loadModel(this)
        oemLabel = AirPlayPersistence.loadOemLabel(this)
        fps = AirPlayPersistence.loadFps(this)
        widthPhysicalMm = AirPlayPersistence.loadWidthPhysicalMm(this)
        physicalSizeBasis = AirPlayPersistence.loadPhysicalSizeBasis(this)
        AirPlayPersistence.loadMaximumDetectedDisplay(this).let { (width, height) ->
            maximumDetectedWidthPixels = width
            maximumDetectedHeightPixels = height
        }
        rightHandDrive = AirPlayPersistence.loadRightHandDrive(this)
        hideTopBar = AirPlayPersistence.loadHideTopBar(this)
        hideBottomBar = AirPlayPersistence.loadHideBottomBar(this)
        safeAreaDrawOutside = AirPlayPersistence.loadSafeAreaDrawOutside(this)
        locationReportingEnabled = AirPlayPersistence.loadLocationReportingEnabled(this) && hasFineLocationPermission()
        locationPermissionAvailable = hasFineLocationPermission()
        wirelessEnabled = AirPlayPersistence.loadWirelessEnabled(this)
        mfiTarget = AirPlayPersistence.loadMfiTarget(this)
        mfiI2cPath = AirPlayPersistence.loadMfiI2cPath(this)
        remoteMfiServer = AirPlayPersistence.loadRemoteMfiServer(this)
        remoteMfiToken = AirPlayPersistence.loadRemoteMfiToken(this)
        localMfiCertificateUri = AirPlayPersistence.loadLocalMfiCertificateUri(this)
        localMfiPrivateKeyUri = AirPlayPersistence.loadLocalMfiPrivateKeyUri(this)
        wirelessPermissionsReady = !wirelessEnabled || hasRequiredWirelessPermissions()
    }

    private fun requestStartupPrerequisites() {
        if (!connectionRequested || connectionPaused || menuOpen || shuttingDown.get()) return
        // Optional microphone/GPS grants are handled explicitly by the in-app guide.
        microphonePermissionResolved = true
        locationReportingEnabled = hasFineLocationPermission() && AirPlayPersistence.loadLocationReportingEnabled(this)
        if (wirelessEnabled) {
            appendLog("transport=WIRELESS: requesting Bluetooth/Wi-Fi permissions; VPN consent is not used")
            requestWirelessPermissions()
        } else {
            appendLog("transport=WIRED: requesting Android VPN consent for USB NCM")
            requestVpnConsent()
        }
    }

    private fun requestLocationPermission() {
        if (locationPermissionAvailable || awaitingLocationPermission) return
        awaitingLocationPermission = true
        locationPermission.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
            ),
        )
    }

    private fun hasFineLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestVpnConsent() {
        val consent = CarPlayVpnService.prepare(this)
        if (consent == null) {
            vpnReady = true
            maybeStartCarPlay()
        } else {
            awaitingVpnConsent = true
            vpnConsent.launch(consent)
        }
    }

    private fun requestWirelessPermissions() {
        if (awaitingWirelessPermissions) return
        val permissions = requiredWirelessPermissions()
        if (permissions.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) {
            wirelessPermissionsReady = true
            updateHotspotStatusBlock()
            prepareBluetoothDiscoverability()
            maybeStartCarPlay()
            return
        }
        wirelessPermissionsReady = false
        updateHotspotStatusBlock()
        awaitingWirelessPermissions = true
        wirelessPermissions.launch(permissions.toTypedArray())
    }

    private fun hasRequiredWirelessPermissions(): Boolean =
        requiredWirelessPermissions().all {
            checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
        }

    private fun prepareBluetoothDiscoverability() {
        if (!connectionRequested || connectionPaused || menuOpen || awaitingBluetoothDiscoverability ||
            bluetoothDiscoverabilityReady || !wirelessPermissionsReady) return
        val adapter = getSystemService(BluetoothManager::class.java)?.adapter
        when (CarPlayBluetoothDiscoverability.prepare(adapter, ::appendLog)) {
            CarPlayBluetoothDiscoverability.Result.READY -> bluetoothDiscoverabilityReady = true
            CarPlayBluetoothDiscoverability.Result.WAITING_FOR_MODE -> {
                awaitingBluetoothDiscoverability = true
                setConnectionStage("正在让车机蓝牙可被搜索")
                var finished = false
                val confirmation = CarPlayBluetoothDiscoverability.awaitDiscoverable(this, checkNotNull(adapter)) { ready ->
                    finished = true
                    awaitingBluetoothDiscoverability = false
                    bluetoothModeConfirmation = null
                    if (!connectionRequested || connectionPaused || menuOpen || shuttingDown.get()) return@awaitDiscoverable
                    if (ready) {
                        bluetoothDiscoverabilityReady = true
                        appendLog("HS5 Bluetooth discoverability confirmed by system state")
                        maybeStartCarPlay()
                    } else requestBluetoothDiscoverabilityConsent()
                }
                if (!finished) bluetoothModeConfirmation = confirmation else confirmation.close()
            }
            CarPlayBluetoothDiscoverability.Result.CONSENT_REQUIRED -> requestBluetoothDiscoverabilityConsent()
            CarPlayBluetoothDiscoverability.Result.BLUETOOTH_OFF -> setConnectionStage("车机蓝牙当前关闭，无法开始配对")
            CarPlayBluetoothDiscoverability.Result.UNAVAILABLE -> setConnectionStage("车机蓝牙服务不可用")
        }
    }

    private fun requestBluetoothDiscoverabilityConsent() {
        awaitingBluetoothDiscoverability = true
        setConnectionStage("请允许车机蓝牙被搜索，然后在 iPhone 上配对车机")
        try {
            bluetoothDiscoverabilityConsent.launch(CarPlayBluetoothDiscoverability.consentIntent())
        } catch (error: ActivityNotFoundException) {
            awaitingBluetoothDiscoverability = false
            setConnectionStage("系统未提供蓝牙可发现授权入口，需要车机系统接口支持")
            appendLog("Bluetooth discoverability consent activity unavailable")
        } catch (error: SecurityException) {
            awaitingBluetoothDiscoverability = false
            setConnectionStage("系统拒绝蓝牙可发现请求，需要车机系统授权")
            appendLog("Bluetooth discoverability consent activity denied")
        }
    }

    private fun cancelBluetoothModeConfirmation() {
        if (bluetoothModeConfirmation != null) {
            bluetoothModeConfirmation?.close()
            bluetoothModeConfirmation = null
            awaitingBluetoothDiscoverability = false
        }
    }

    private fun requiredWirelessPermissions(): List<String> = when {
        // Android 17 gates local sockets and Bonjour registration behind runtime permission.
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.CINNAMON_BUN -> listOf(
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.NEARBY_WIFI_DEVICES,
            Manifest.permission.ACCESS_LOCAL_NETWORK,
        )
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> listOf(
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.NEARBY_WIFI_DEVICES,
        )
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> listOf(
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
        )
        // HS5 API 28's measured framework permits createGroup/requestGroupInfo with
        // manifest Wi-Fi permissions. We never discover peers or request scan results.
        hs5 -> emptyList()
        else -> listOf(
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
        )
    }

    override fun onResume() {
        super.onResume()
        microphoneAvailable = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (microphoneAvailable) microphonePermissionResolved = true
        updatePermissionControls()
        hongqi.resume()
        CarPlayBackgroundSession.audioFocus(this).apply {
            retain(this@CarPlayHostActivity)
            requestFromHost()
        }
        locationPermissionAvailable = hasFineLocationPermission()
        locationReportingEnabled = locationPermissionAvailable && AirPlayPersistence.loadLocationReportingEnabled(this)
        setup.refresh()
        wirelessPermissionsReady = !wirelessEnabled || hasRequiredWirelessPermissions()
        maybeStartCarPlay()
        applyFullscreenMode()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyFullscreenMode()
    }

    override fun onPause() {
        hongqi.pause()
        super.onPause()
    }

    override fun onStart() {
        super.onStart()
        uiAppearanceWatch = FawUiTheme.watch(this, ::refreshUiAppearance)
        homeView?.redraw()
    }

    private fun refreshUiAppearance() {
        if (isDestroyed || shuttingDown.get()) return
        homeView?.redraw()
        val old = settingsMenu ?: return
        val parent = old.parent as? ViewGroup ?: return
        val index = parent.indexOfChild(old)
        val visibility = old.visibility
        val params = old.layoutParams
        parent.removeView(old)
        settingsMenu = buildSettingsMenu().also { replacement ->
            replacement.visibility = visibility
            parent.addView(replacement, index, params)
        }
    }

    override fun onStop() {
        uiAppearanceWatch?.close()
        uiAppearanceWatch = null
        stopMicrophoneGainTest()
        // The controller, USB/iAP2 link, and VPN attachment intentionally outlive the UI.
        super.onStop()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val nextDarkMode = vehicleNight ?: isDarkMode(newConfig.uiMode)
        if (nextDarkMode != darkMode) {
            darkMode = nextDarkMode
            syncAirPlayDarkMode()
        }
        refreshUiAppearance()
        applyFullscreenMode()
        scrollLogsToBottom()
        videoView?.post {
            val view = videoView ?: return@post
            scheduleDisplaySize(view.width, view.height)
        }
    }

    override fun onDestroy() {
        setup.close()
        cancelBluetoothModeConfirmation()
        hongqi.close()
        currentUiListener?.let { expected ->
            if (controller?.detachUi(expected) == true) {
                val retainedTypes = activeScreenStreamTypes
                val backgroundHandler = Handler(Looper.getMainLooper())
                sink?.setScreenStreamActiveChangedListener { type, active ->
                    backgroundHandler.post { if (active) retainedTypes.add(type) else retainedTypes.remove(type) }
                }
            }
        }
        currentUiListener = null
        CarPlayBackgroundSession.audioFocus(this).release(this)
        stopMicrophoneGainTest()
        mainHandler.removeCallbacks(applyDisplaySize)
        clusterPreviewSurface?.let { detachSurface(SCREEN_TYPE_ALT, it); it.release() }
        clusterPreviewSurface = null
        mainHandler.removeCallbacks(expireOldLogLines)
        mainHandler.removeCallbacks(renderLogLines)
        mainHandler.removeCallbacks(drainScreenLogs)
        videoView?.let(::releaseMainVideoView)
        touchMapper.clear()
        sessionLog.append("Activity destroyed; background session and log remain active")
        super.onDestroy()
    }

    private fun buildContentView(): View {
        val root = FrameLayout(this).apply {
            setBackgroundColor(NO_VIDEO_BACKGROUND)
        }
        contentRoot = root
        val video = createMainVideoView()
        video.layoutParams = FrameLayout.LayoutParams(-1, -1)
        val gestureLayer = View(this).apply {
            isClickable = true
            setOnTouchListener { view, event -> onHostTouch(view, event) }
        }
        val log = TextView(this).apply {
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            textSize = 11f
            typeface = Typeface.MONOSPACE
            text = ""
        }
        val logScroll = object : ScrollView(this) {
            override fun onInterceptTouchEvent(event: MotionEvent): Boolean = false
            override fun onTouchEvent(event: MotionEvent): Boolean = false
        }.apply {
            setBackgroundColor(Color.argb(150, 0, 0, 0))
            isFillViewport = false
            isFocusable = false
            addView(
                log,
                ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ),
            )
            addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> scrollLogsToBottom() }
        }
        val settingsButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_settings)
            imageTintList = ColorStateList.valueOf(MENU_ACCENT)
            background = menuRipple(
                GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(MENU_BACKGROUND)
                    setStroke(maxOf(1, dp(1)), MENU_SEPARATOR)
                },
            )
            setPadding(dp(14), dp(14), dp(14), dp(14))
            contentDescription = getString(R.string.hs5_open_settings)
            setOnClickListener { openSettingsMenu() }
        }
        val statusParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.START,
        )
        statusParams.setMargins(dp(12), 0, dp(12), dp(12))
        val settingsButtonParams = FrameLayout.LayoutParams(
            dp(56),
            dp(56),
            Gravity.BOTTOM or Gravity.END,
        ).apply { setMargins(dp(16), 0, dp(16), dp(16)) }

        val settings = buildSettingsMenu().apply { visibility = View.GONE }
        val editor = buildSafeAreaEditor().apply { visibility = View.GONE }

        val panel = HandshakePanelView(this).apply { visibility = View.GONE }
        val mainFrame = FrameLayout(this).apply { addView(video) }
        mainFrame.addView(
            gestureLayer,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
            ),
        )
        // Keep the connection UI inside the main display, leaving room for settings below.
        mainFrame.addView(
            panel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            ).apply { setMargins(dp(12), dp(12), dp(12), dp(84)) },
        )
        val cluster = TextureView(this).apply {
            isOpaque = false
            visibility = View.GONE
            surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(texture: SurfaceTexture, width: Int, height: Int) {
                    texture.setDefaultBufferSize(clusterWebDisplay.width, clusterWebDisplay.height)
                    clusterPreviewSurface = Surface(texture).also { attachDisplaySurface(SCREEN_TYPE_ALT, it) }
                }
                override fun onSurfaceTextureSizeChanged(texture: SurfaceTexture, width: Int, height: Int) = Unit
                override fun onSurfaceTextureUpdated(texture: SurfaceTexture) = Unit
                override fun onSurfaceTextureDestroyed(texture: SurfaceTexture): Boolean {
                    clusterPreviewSurface?.let { detachSurface(SCREEN_TYPE_ALT, it); it.release() }
                    clusterPreviewSurface = null
                    return true
                }
            }
        }
        clusterPreview = cluster
        val displays = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(cluster, LinearLayout.LayoutParams(1, 1).apply { gravity = Gravity.CENTER_HORIZONTAL })
            addView(mainFrame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        root.addView(displays, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        homeView = Hs5HomeView(this,
            onSettings = { _ -> openSettingsMenu() },
            onConnect = ::connectFromHome,
            onBluetooth = ::openSystemBluetoothSettings,
            onDetails = { showConnectionDetails = true; updateDebugOverlays() },
            onHome = { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)) },
            onTheme = ::refreshUiAppearance,
            onCancel = ::cancelConnectionAttempt,
        ).also { root.addView(it, FrameLayout.LayoutParams(-1, -1)) }
        root.addView(logScroll, statusParams)
        root.addView(settingsButton, settingsButtonParams)
        root.addView(
            settings,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
            ),
        )
        root.addView(
            editor,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
            ),
        )
        root.addView(setup.onboarding, FrameLayout.LayoutParams(-1, -1))
        root.addOnLayoutChangeListener { _, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom ->
            if (right - left != oldRight - oldLeft || bottom - top != oldBottom - oldTop) {
                updateMediaMetricsOverlayLayout(right - left, bottom - top)
                updateWebDisplayPreviews()
            }
        }
        videoView = video
        gestureOverlay = gestureLayer
        disconnectedSettingsButton = settingsButton
        settingsMenu = settings
        safeAreaEditor = editor
        statusView = log
        statusScrollView = logScroll
        // A timeline belongs to an actual connection attempt. Creating one while idle makes
        // the home progress view disable Connect before the user can start the first attempt.
        handshakeTimeline = null
        handshakePanel = panel.also { it.bind(handshakeTimeline) }
        updateWebDisplayPreviews()
        updateDebugOverlays()
        return root
    }

    private fun buildSettingsMenu(): View = setup.managementView()

    // Retained internally for upstream reference; no production UI routes to these tuning pages.
    private fun buildLegacySettingsMenu(): View {
        webDisplayRefresh.clear()
        val sections = linkedMapOf<String, LinearLayout>()
        fun section(key: String) = sections.getOrPut(key) {
            LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        }
        var content = section("connection")
        content.addView(
            settingsCategoryHeader(getString(R.string.hs5_connection)),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(32) },
        )

        content = section("authentication")
        content.addView(
            buildMfiTargetSection(),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(14) },
        )

        content = section("connection")
        val wirelessRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        wirelessRow.addView(
            menuText(getString(R.string.hs5_wireless_carplay), 20f, MENU_SECONDARY),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f),
        )
        val wirelessSwitch = Switch(this).apply {
            isChecked = wirelessEnabled
            contentDescription = getString(R.string.hs5_wireless_carplay_transport)
            showText = false
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(MENU_ACCENT, MENU_SECONDARY),
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(MENU_ACCENT_TRACK, MENU_TRACK_OFF),
            )
            setOnCheckedChangeListener { _, checked ->
                if (wirelessEnabled == checked) return@setOnCheckedChangeListener
                wirelessEnabled = checked
                hotspotStatus = HotspotStatus(state = if (wirelessEnabled) "stopped" else "off")
                updateHotspotStatusBlock()
                appendLog(
                    "Wireless CarPlay ${if (wirelessEnabled) "enabled" else "disabled"}; " +
                        "applies when settings close",
                )
                requestStartupPrerequisites()
            }
        }
        wirelessRow.addView(
            wirelessSwitch,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        content.addView(
            wirelessRow,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(30) },
        )

        content.addView(
            menuText(getString(R.string.hs5_hotspot_status), 20f, MENU_SECONDARY),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(18) },
        )
        val hotspotStatusView = menuText("", 16f, MENU_ACCENT)
        content.addView(
            hotspotStatusView,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(6) },
        )

        content = section("navigation")
        if (hs5) content.addView(buildHs5Settings()) else {
            content.addView(menuText("车辆功能将在红旗 HS5 车机上启用。", 16f, MENU_SECONDARY))
        }
        content = section("location")
        content.addView(
            settingsCategoryHeader(getString(R.string.hs5_location)),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(36) },
        )
        content.addView(
            buildLocationReportingSection(),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(12) },
        )

        content = section("startup")
        content.addView(
            settingsCategoryHeader(getString(R.string.hs5_startup)),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(36) },
        )
        content.addView(
            settingsSwitchRow(
                label = getString(R.string.hs5_auto_start_on_boot),
                checked = autoStartOnBoot,
                description = getString(R.string.hs5_start_carplay_automatically_after_device_boot),
            ) { checked ->
                autoStartOnBoot = checked
                appendLog("Boot auto-start ${if (checked) "enabled" else "disabled"}")
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(12) },
        )

        content = section("audio")
        content.addView(
            settingsCategoryHeader(getString(R.string.hs5_audio)),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(36) },
        )
        content.addView(
            if (hs5) buildHs5AudioSettings() else buildStepSliderSection(
                title = getString(R.string.hs5_main_media_audio_buffer),
                values = (
                    MainMediaAudioBuffer.MIN_DURATION_MS..MainMediaAudioBuffer.MAX_DURATION_MS
                    step MainMediaAudioBuffer.STEP_DURATION_MS
                    ).toList(),
                selectedValue = mainMediaAudioBufferDurationMs,
                label = ::mainMediaAudioBufferLabel,
                onControlsCreated = { valueView, seekBar ->
                    mainMediaAudioBufferValueView = valueView
                    mainMediaAudioBufferSeekBar = seekBar
                },
                onValueChanged = { value ->
                    mainMediaAudioBufferDurationMs = value
                },
            ),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(12) },
        )
        content.addView(
            buildMicrophoneGainSection(),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(20) },
        )
        if (advancedAudioChannelMappingSupported) {
            content.addView(
                settingsSwitchRow(
                    label = getString(R.string.hs5_advanced_audio_channel_mapping),
                    checked = advancedAudioChannelMapping,
                    description = getString(R.string.hs5_route_aaos_audio_buses_by_carplay_audio_type),
                ) { checked ->
                    advancedAudioChannelMapping = checked
                    appendLog(
                        "Advanced audio channel mapping ${if (checked) "enabled" else "disabled"}; " +
                            "applies when settings close",
                    )
                    updateResolutionMenu()
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ).apply { topMargin = dp(20) },
            )
        }

        content = section("appearance")
        content.addView(
            settingsCategoryHeader(getString(R.string.hs5_identity_appearance)),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(36) },
        )
        content.addView(
            buildIdentitySettingsSection(),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(12) },
        )
        content.addView(
            buildAirPlayIconSection(),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(26) },
        )
        content.addView(
            buildDrivingSideSection(),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(26) },
        )
        content = section("display")
        content.addView(
            settingsCategoryHeader(getString(R.string.hs5_display_video)),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(40) },
        )

        val resolutionHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        resolutionHeader.addView(
            menuText(getString(R.string.hs5_resolution), 20f, MENU_SECONDARY),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f),
        )
        val resolutionValue = menuText(
            CarPlayDisplayScale.label(displayScaleTenths),
            28f,
            MENU_ACCENT,
            bold = true,
        )
        resolutionHeader.addView(
            resolutionValue,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        content.addView(
            resolutionHeader,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(14) },
        )

        val seekBar = SeekBar(this).apply {
            max = CarPlayDisplayScale.MAX_TENTHS - CarPlayDisplayScale.MIN_TENTHS
            progress = displayScaleTenths - CarPlayDisplayScale.MIN_TENTHS
            splitTrack = false
            progressTintList = ColorStateList.valueOf(MENU_ACCENT)
            thumbTintList = ColorStateList.valueOf(MENU_ACCENT)
            setOnSeekBarChangeListener(
                object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                        displayScaleTenths = CarPlayDisplayScale.sanitize(
                            CarPlayDisplayScale.MIN_TENTHS + progress,
                        )
                        updateResolutionMenu()
                    }

                    override fun onStartTrackingTouch(seekBar: SeekBar) = Unit
                    override fun onStopTrackingTouch(seekBar: SeekBar) = Unit
                },
            )
        }
        content.addView(
            seekBar,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(8) },
        )

        val range = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        range.addView(
            menuText("0.3x", 15f, MENU_SECONDARY),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f),
        )
        range.addView(
            menuText("1.0x", 15f, MENU_SECONDARY),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        content.addView(
            range,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )

        content.addView(
            buildStepSliderSection(
                title = getString(R.string.hs5_frame_rate),
                values = (
                    AirPlayDisplaySettings.MIN_FPS..AirPlayDisplaySettings.MAX_FPS
                    step AirPlayDisplaySettings.FPS_STEP
                    ).toList(),
                selectedValue = fps,
                label = { "$it 帧/秒" },
                onValueChanged = { value ->
                    fps = value
                    updateResolutionMenu()
                },
            ),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(24) },
        )

        content.addView(
            settingsChoiceRow(
                label = getString(R.string.hs5_physical_size_basis),
                options = listOf(
                    AirPlayPhysicalSizeBasis.WIDTH to getString(R.string.hs5_widest_width),
                    AirPlayPhysicalSizeBasis.HEIGHT to getString(R.string.hs5_longest_height),
                ),
                selected = physicalSizeBasis,
            ) { value ->
                physicalSizeBasis = value
                updateResolutionMenu()
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(24) },
        )

        content.addView(
            buildStepSliderSection(
                title = getString(R.string.hs5_physical_length),
                values = (
                    AirPlayDisplaySettings.MIN_WIDTH_PHYSICAL_MM..
                        AirPlayDisplaySettings.MAX_WIDTH_PHYSICAL_MM
                    step AirPlayDisplaySettings.WIDTH_PHYSICAL_MM_STEP
                    ).toList(),
                selectedValue = widthPhysicalMm,
                label = { "$it mm" },
                onValueChanged = { value ->
                    widthPhysicalMm = value
                    updateResolutionMenu()
                },
            ),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(16) },
        )

        content = section("web")
        content.addView(
            settingsCategoryHeader(getString(R.string.hs5_web_displays)),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(32) },
        )
        for (type in listOf(SCREEN_TYPE_MAIN, SCREEN_TYPE_ALT)) {
            content.addView(buildWebDisplaySection(type),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { topMargin = dp(16) })
        }
        content.addView(
            menuText(
                "Web displays use HTTPS with a self-signed certificate so browsers can decode with WebCodecs " +
                    "(H.265 included). Each browser warns once: choose to continue.",
                13f,
                MENU_SECONDARY,
            ),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(16) })

        val hevcRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        hevcRow.addView(
            menuText("HEVC (H.265)", 20f, MENU_SECONDARY),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f),
        )
        val hevcSwitch = Switch(this).apply {
            isChecked = hevcEnabled
            contentDescription = getString(R.string.hs5_hevc_h_265_video_transport)
            showText = false
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(MENU_ACCENT, MENU_SECONDARY),
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(MENU_ACCENT_TRACK, MENU_TRACK_OFF),
            )
            setOnCheckedChangeListener { _, checked ->
                if (hevcEnabled == checked) return@setOnCheckedChangeListener
                hevcEnabled = checked
                appendLog(
                    "HEVC (H.265) ${if (hevcEnabled) "enabled" else "disabled"}; " +
                        "applies when settings close",
                )
                updateResolutionMenu()
            }
        }
        hevcRow.addView(
            hevcSwitch,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        content.addView(
            hevcRow,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(30) },
        )

        val softwareHevcRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        softwareHevcRow.addView(
            menuText(getString(R.string.hs5_hevc_software_decoder), 20f, MENU_SECONDARY),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f),
        )
        val softwareHevcSwitch = Switch(this).apply {
            isChecked = hevcSoftwareDecoderEnabled
            contentDescription = getString(R.string.hs5_use_software_hevc_decoder)
            showText = false
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(MENU_ACCENT, MENU_SECONDARY),
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(MENU_ACCENT_TRACK, MENU_TRACK_OFF),
            )
            setOnCheckedChangeListener { _, checked ->
                if (hevcSoftwareDecoderEnabled == checked) return@setOnCheckedChangeListener
                hevcSoftwareDecoderEnabled = checked
                appendLog(
                    "HEVC software decoder ${if (hevcSoftwareDecoderEnabled) "enabled" else "disabled"}; " +
                        "applies when settings close",
                )
                updateResolutionMenu()
            }
        }
        softwareHevcRow.addView(
            softwareHevcSwitch,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            content.addView(
                softwareHevcRow,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ).apply { topMargin = dp(16) },
            )
        }

        content.addView(
            buildSafeAreaSection(),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(30) },
        )

        content = section("window")
        content.addView(
            settingsCategoryHeader(getString(R.string.hs5_window)),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(40) },
        )
        content.addView(
            buildFullscreenSection(),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(12) },
        )
        content.addView(
            settingsSwitchRow(
                label = getString(R.string.hs5_more_gestures_to_settings_page),
                checked = moreGesturesToSettings,
                description = getString(R.string.hs5_enable_a_one_finger_swipe_down_along_the_left_edge_to_open_settings),
            ) { checked -> moreGesturesToSettings = checked },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(12) },
        )

        content = section("diagnostics")
        content.addView(
            settingsCategoryHeader(getString(R.string.hs5_diagnostics)),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(40) },
        )
        content.addView(
            buildMediaMetricsSection(),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(12) },
        )
        content.addView(
            buildAudioPacketCaptureSection(),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(20) },
        )
        content.addView(
            buildDebugLogsSection(),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(20) },
        )
        content.addView(
            buildVideoFrameLogsSection(),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(12) },
        )
        content.addView(
            Button(this).apply {
                text = getString(R.string.hs5_open_system_bluetooth_settings)
                applyMenuButtonStyle(MENU_BUTTON_PRIMARY)
                textSize = Hs5Ui.sp(this@CarPlayHostActivity, 17f)
                minHeight = dp(52)
                setOnClickListener { openSystemBluetoothSettings() }
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(16) },
        )

        content = section("compatibility")
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            content.addView(
                settingsCategoryHeader(getString(R.string.hs5_android_9_compatibility)),
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ).apply { topMargin = dp(40) },
            )
            content.addView(
                menuText(
                    "Android 9 不提供主动选择 HEVC 软件解码的开关。" +
                        "（API 28）\n" +
                        "HS5 使用系统 Wi-Fi Direct，可在连接设置中选择连接方式。\n" +
                        "视频解码器由系统选择，实机日志可查看实际解码器名称。",
                    16f,
                    MENU_SECONDARY,
                ),
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ).apply { topMargin = dp(12) },
            )
        }

        content = section("about")
        val preview = menuText("", 17f, MENU_SECONDARY)
        content.addView(
            preview,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(30) },
        )


        fun combined(vararg keys: String): View = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            keys.forEach { key ->
                val block = section(key)
                // The card already supplies the heading; remove the old long-form lead-in.
                if (block.childCount > 0 && block.getChildAt(0).tag == "hs5_section_header") {
                    block.removeViewAt(0)
                }
                if (block.childCount > 0) {
                    (block.getChildAt(0).layoutParams as? ViewGroup.MarginLayoutParams)?.topMargin = 0
                }
                addView(block, LinearLayout.LayoutParams(-1, -2))
            }
        }
        fun card(title: String, vararg keys: String) = Hs5SettingsView.Section(title, combined(*keys))
        val permissionControls = section("permissions")
        permissionControls.addView(menuText("录音用于 Siri 与通话；精确定位用于可选的车机 GPS 回传。", 16f, MENU_SECONDARY))
        permissionControls.addView(Button(this).apply {
            applyMenuButtonStyle()
            microphonePermissionButton = this
            setOnClickListener {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    updatePermissionControls()
                } else if (!awaitingMicrophonePermission) {
                    awaitingMicrophonePermission = true
                    microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
        })
        permissionControls.addView(Button(this).apply {
            text = "更多权限设置"; applyMenuButtonStyle()
            setOnClickListener {
                val missing = listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION)
                    .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
                val overlayMissing = !Settings.canDrawOverlays(this@CarPlayHostActivity)
                openPermissionSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS) {
                    missing.any { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED } ||
                        (overlayMissing && Settings.canDrawOverlays(this@CarPlayHostActivity))
                }
            }
        })
        permissionControls.addView(menuText("车机蓝牙与 Wi-Fi 保持开启。仪表地图需单独允许显示。", 16f, MENU_SECONDARY))
        updatePermissionControls()
        val about = section("about")
        about.addView(menuText(getString(R.string.hs5_build_version), 18f, MENU_LABEL, true), 0)
        about.addView(menuText("基于 xcertplay，沿用旧版 FAW Play 界面。", 16f, MENU_SECONDARY), 1)
        val pages = listOf(
            Hs5SettingsView.Page("连接设置", "配对并连接你的 iPhone", 0, listOf(card("无线与热点", "connection"), card("启动与兼容", "startup", "compatibility"))),
            Hs5SettingsView.Page("画面显示", "调整 CarPlay 画面与显示区域", 1, listOf(card("视频与分辨率", "display"), card("副屏与窗口", "web", "window"))),
            Hs5SettingsView.Page("声音与拾音", "调整音乐缓冲与麦克风", 7, listOf(card("音频设置", "audio"))),
            Hs5SettingsView.Page("导航与 HUD", "让导航信息出现在合适的位置", 2, listOf(card("车辆功能", "navigation"), card("车辆定位", "location"))),
            Hs5SettingsView.Page("权限与帮助", "检查权限，解决连接问题", 3, listOf(card("权限说明", "permissions"))),
            Hs5SettingsView.Page("诊断", "记录问题与查看运行状态", 4, listOf(card("诊断开关", "diagnostics"))),
            Hs5SettingsView.Page("认证与外观", "配置接收端认证和手机上的显示名称", 12, listOf(card("认证方式", "authentication"), card("名称与图标", "appearance"))),
            Hs5SettingsView.Page("关于", "版本与当前显示配置", 5, listOf(card("应用信息", "about"))),
        )
        resolutionValueView = resolutionValue
        resolutionPreviewView = preview
        this.hotspotStatusView = hotspotStatusView
        updateHotspotStatusBlock()
        updateResolutionMenu()
        return Hs5SettingsView(this, pages, settingsPage, { settingsPage = it },
            ::cancelSettingsEdits, ::saveSettingsAndReconnect, ::exitApplication, ::refreshUiAppearance)
    }

    private fun persistMenuSettings() {
        AirPlayPersistence.saveWebDisplay(this, SCREEN_TYPE_MAIN, mainWebDisplay)
        AirPlayPersistence.saveWebDisplay(this, SCREEN_TYPE_ALT, clusterWebDisplay)
        AirPlayPersistence.saveWirelessEnabled(this, wirelessEnabled)
        AirPlayPersistence.saveMfiTarget(this, mfiTarget)
        AirPlayPersistence.saveMfiI2cPath(this, mfiI2cPath)
        AirPlayPersistence.saveRemoteMfiServer(this, remoteMfiServer)
        AirPlayPersistence.saveRemoteMfiToken(this, remoteMfiToken)
        AirPlayPersistence.saveLocalMfiCertificateUri(this, localMfiCertificateUri)
        AirPlayPersistence.saveLocalMfiPrivateKeyUri(this, localMfiPrivateKeyUri)
        AirPlayPersistence.saveLocationReportingEnabled(this, locationReportingEnabled)
        AirPlayPersistence.saveAutoStartOnBoot(this, autoStartOnBoot)
        AirPlayPersistence.saveAdvancedAudioChannelMapping(this, advancedAudioChannelMapping)
        AirPlayPersistence.saveMainMediaAudioBufferDurationMs(
            this,
            mainMediaAudioBufferDurationMs,
        )
        AirPlayPersistence.saveMicrophoneGainPercent(this, microphoneGainPercent)
        AirPlayPersistence.saveDisplayScaleTenths(this, displayScaleTenths)
        AirPlayPersistence.saveFps(this, fps)
        AirPlayPersistence.saveWidthPhysicalMm(this, widthPhysicalMm)
        AirPlayPersistence.savePhysicalSizeBasis(this, physicalSizeBasis)
        AirPlayPersistence.saveHevcEnabled(this, hevcEnabled)
        AirPlayPersistence.saveHevcSoftwareDecoderEnabled(this, hevcSoftwareDecoderEnabled)
        AirPlayPersistence.saveManufacturer(this, manufacturer)
        AirPlayPersistence.saveModel(this, model)
        AirPlayPersistence.saveOemLabel(this, oemLabel)
        AirPlayPersistence.saveDebugLogsEnabled(this, debugLogsEnabled)
        AirPlayPersistence.saveVideoFrameLogsEnabled(this, videoFrameLogsEnabled)
        AirPlayPersistence.saveMediaMetricsEnabled(this, mediaMetricsEnabled)
        AirPlayPersistence.saveAudioPacketCaptureEnabled(this, audioPacketCaptureEnabled)
        AirPlayPersistence.saveMoreGesturesToSettings(this, moreGesturesToSettings)
        AirPlayPersistence.saveRightHandDrive(this, rightHandDrive)
        AirPlayPersistence.saveHideTopBar(this, hideTopBar)
        AirPlayPersistence.saveHideBottomBar(this, hideBottomBar)
        AirPlayPersistence.saveSafeAreaDrawOutside(this, safeAreaDrawOutside)
    }

    private fun captureSettingsBaseline(): SettingsBaseline {
        val safeAreaSize = currentActivitySize()
        val customIconBytes = try {
            AirPlayPersistence.loadCustomAirPlayIconFile(this)?.readBytes()
        } catch (error: Exception) {
            Log.w(TAG, "Could not read the current AirPlay icon for settings rollback", error)
            null
        }
        return SettingsBaseline(
            safeAreaSize = safeAreaSize,
            safeAreaRect = safeAreaSize?.let {
                AirPlayPersistence.loadSafeAreaRect(this, it.width, it.height)
            },
            customIconBytes = customIconBytes,
        )
    }

    private fun restoreSettingsBaseline() {
        val baseline = settingsBaseline ?: return
        loadPersistedSettings()
        webDisplayRefresh.forEach { it() }
        videoFrameLogSwitch?.isChecked = videoFrameLogsEnabled
        updateWebDisplayPreviews()
        baseline.safeAreaSize?.let { size ->
            baseline.safeAreaRect?.let { rect ->
                AirPlayPersistence.saveSafeAreaRect(
                    this,
                    size.width,
                    size.height,
                    rect,
                    commit = true,
                )
            } ?: AirPlayPersistence.clearSafeAreaRect(
                this,
                size.width,
                size.height,
                commit = true,
            )
        }
        try {
            baseline.customIconBytes?.let { bytes ->
                AirPlayPersistence.saveCustomAirPlayIcon(this, bytes)
            } ?: AirPlayPersistence.clearCustomAirPlayIcon(this)
        } catch (error: Exception) {
            Log.w(TAG, "Could not restore the previous AirPlay icon", error)
        }
        settingsBaseline = null
        locationPermissionAvailable = hasFineLocationPermission()
        hotspotStatus = HotspotStatus(state = if (wirelessEnabled) "stopped" else "off")
        syncMfiSettingsControls()
        syncMainMediaAudioBufferControls()
        syncMicrophoneGainControls()
        updateAirPlayIconPreview()
        updateSafeAreaSummary()
        updateHotspotStatusBlock()
        updateResolutionMenu()
        updateDebugOverlays()
        applyFullscreenMode()
        refreshDisplaySizeAfterLayout()
    }

    private fun webDisplayConfig(type: Int) = if (type == SCREEN_TYPE_MAIN) mainWebDisplay else clusterWebDisplay

    private fun setWebDisplayConfig(type: Int, config: CarPlayWebDisplayConfig) {
        if (type == SCREEN_TYPE_MAIN) mainWebDisplay = config else clusterWebDisplay = config
        updateWebDisplayPreviews()
        updateResolutionMenu()
    }

    private fun buildWebDisplaySection(type: Int): View {
        val section = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val enabled = settingsSwitchRow(
            label = if (type == SCREEN_TYPE_MAIN) getString(R.string.hs5_main_display) else getString(R.string.hs5_instrument_display),
            checked = webDisplayConfig(type).enabled,
            description = getString(R.string.hs5_open_this_display_in_a_browser_on_the_same_network),
        ) { checked ->
            setWebDisplayConfig(type, webDisplayConfig(type).copy(enabled = checked))
            details.visibility = if (checked) View.VISIBLE else View.GONE
        }
        section.addView(enabled)
        val resolution = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun dimension(value: Int, hint: String) = EditText(this).apply {
            setText(value.toString()); this.hint = hint; contentDescription = hint
            inputType = InputType.TYPE_CLASS_NUMBER; setSingleLine(); setTextColor(MENU_LABEL)
            setHintTextColor(MENU_SECONDARY); backgroundTintList = ColorStateList.valueOf(MENU_ACCENT)
        }
        val width = dimension(webDisplayConfig(type).width, "Width")
        val height = dimension(webDisplayConfig(type).height, "Height")
        webDisplayInputs[type] = width to height
        resolution.addView(width, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        resolution.addView(menuText(" × ", 18f, MENU_SECONDARY))
        resolution.addView(height, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        details.addView(menuText(getString(R.string.hs5_resolution), 15f, MENU_SECONDARY))
        details.addView(resolution)
        val preview = settingsSwitchRow(getString(R.string.hs5_local_preview), webDisplayConfig(type).preview,
            getString(R.string.hs5_fit_the_preview_to_the_configured_resolution)) { checked ->
            setWebDisplayConfig(type, webDisplayConfig(type).copy(preview = checked))
        }
        details.addView(preview)
        val address = menuText("", 13f, MENU_ACCENT).apply { setTextIsSelectable(true) }
        webDisplayAddressViews[type] = address
        details.addView(address)
        details.addView(menuText(getString(R.string.hs5_apply_with_save_reconnect), 13f, MENU_SECONDARY))
        section.addView(details)
        webDisplayRefresh += {
            val config = webDisplayConfig(type)
            ((enabled as ViewGroup).getChildAt(1) as Switch).isChecked = config.enabled
            ((preview as ViewGroup).getChildAt(1) as Switch).isChecked = config.preview
            width.setText(config.width.toString()); height.setText(config.height.toString())
            width.error = null; height.error = null
            details.visibility = if (config.enabled) View.VISIBLE else View.GONE
            updateWebDisplayAddresses()
        }
        webDisplayRefresh.last().invoke()
        return section
    }

    private fun updateWebDisplayAddresses() {
        for ((type, view) in webDisplayAddressViews) {
            view.text = CarPlayWebDisplayFactory.urls(type, AirPlayPersistence.webDisplayKey(this))
                .joinToString("\n").ifEmpty { getString(R.string.hs5_connect_to_a_local_network_to_get_the_display_address) }
        }
    }

    private fun validateWebDisplaySettings(): Boolean {
        for ((type, inputs) in webDisplayInputs) {
            val config = webDisplayConfig(type)
            if (!config.enabled) continue
            val updated = runCatching { config.copy(width = inputs.first.text.toString().toInt(), height = inputs.second.text.toString().toInt()) }
                .getOrElse {
                    inputs.first.error = getString(R.string.hs5_use_even_dimensions_320_3840_240_2160)
                    inputs.second.error = inputs.first.error
                    inputs.first.requestFocus()
                    return false
                }
            setWebDisplayConfig(type, updated)
        }
        return true
    }

    private fun buildMfiTargetSection(): View {
        val section = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val targetChoice = settingsChoiceRow(
            label = getString(R.string.hs5_mfi_certificate_signing_target),
            options = listOf(
                MfiTarget.USB_CH341 to "USB/CH341",
                MfiTarget.I2C to "I2C",
                MfiTarget.REMOTE to getString(R.string.hs5_remote),
                MfiTarget.LOCAL_FILES to getString(R.string.hs5_local_files),
            ),
            selected = mfiTarget,
        ) { target ->
            if (mfiTarget == target) return@settingsChoiceRow
            mfiTarget = target
            updateMfiTargetFields()
            appendLog("MFI target: ${mfiTargetLabel(target)}; applies when settings close")
        }
        mfiTargetGroup = (targetChoice as ViewGroup).getChildAt(1) as RadioGroup
        section.addView(
            targetChoice,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )

        val i2cFields = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(
                settingsInputRow(
                    getString(R.string.hs5_i2c_device),
                    mfiI2cPath,
                    onInputCreated = { mfiI2cPathInput = it },
                ) { value ->
                    mfiI2cPath = value
                    mfiErrorView?.visibility = View.GONE
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ),
            )
            addView(
                menuText(getString(R.string.hs5_linux_device_path_for_example_dev_i2c_1), 14f, MENU_SECONDARY),
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ).apply { topMargin = dp(4) },
            )
        }
        section.addView(
            i2cFields,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(8) },
        )
        mfiI2cFields = i2cFields

        val remoteFields = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(
                settingsInputRow(
                    "Server address",
                    remoteMfiServer,
                    onInputCreated = { remoteMfiServerInput = it },
                ) { value ->
                    remoteMfiServer = value
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ),
            )
            addView(
                settingsInputRow(
                    "Token (optional)",
                    remoteMfiToken,
                    password = true,
                    onInputCreated = { remoteMfiTokenInput = it },
                ) { value ->
                    remoteMfiToken = value
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ).apply { topMargin = dp(8) },
            )
            addView(
                menuText(
                    "地址需以 http:// 或 https:// 开头。令牌可留空；填写后通过 " +
                        "Authorization Bearer 请求头发送。",
                    14f,
                    MENU_SECONDARY,
                ),
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ).apply { topMargin = dp(4) },
            )
        }
        section.addView(
            remoteFields,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(8) },
        )
        mfiRemoteFields = remoteFields

        val localFields = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(
                localMfiDocumentRow(
                    getString(R.string.hs5_certificate_p7b),
                    localMfiCertificateUri,
                    onDocumentViewCreated = { localMfiCertificateDocumentView = it },
                ) {
                    externalActivityInProgress = true
                    localMfiCertificatePicker.launch(arrayOf("*/*"))
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ),
            )
            addView(
                localMfiDocumentRow(
                    getString(R.string.hs5_private_key_pk8),
                    localMfiPrivateKeyUri,
                    onDocumentViewCreated = { localMfiPrivateKeyDocumentView = it },
                ) {
                    externalActivityInProgress = true
                    localMfiPrivateKeyPicker.launch(arrayOf("*/*"))
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ).apply { topMargin = dp(8) },
            )
            addView(
                menuText(
                    "选择 DER PKCS#7 证书与配套的未加密 DER PKCS#8 " +
                        "私钥；每次认证重连时会重新读取文件。",
                    14f,
                    MENU_SECONDARY,
                ),
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ).apply { topMargin = dp(4) },
            )
        }
        section.addView(
            localFields,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(8) },
        )
        mfiLocalFields = localFields
        val error = menuText("", 14f, MENU_DANGER).apply {
            visibility = View.GONE
        }
        section.addView(
            error,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(6) },
        )
        mfiErrorView = error
        updateMfiTargetFields()
        return section
    }

    private fun updateMfiTargetFields() {
        mfiI2cFields?.visibility = if (mfiTarget == MfiTarget.I2C) View.VISIBLE else View.GONE
        mfiRemoteFields?.visibility = if (mfiTarget == MfiTarget.REMOTE) View.VISIBLE else View.GONE
        mfiLocalFields?.visibility = if (mfiTarget == MfiTarget.LOCAL_FILES) View.VISIBLE else View.GONE
        mfiErrorView?.visibility = View.GONE
    }

    private fun localMfiDocumentRow(
        label: String,
        uri: String,
        onDocumentViewCreated: (TextView) -> Unit,
        onChoose: () -> Unit,
    ): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(
            menuText(label, 15f, MENU_SECONDARY),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        val row = LinearLayout(this@CarPlayHostActivity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val documentView = menuText(localMfiDocumentLabel(uri), 14f, MENU_SECONDARY)
        onDocumentViewCreated(documentView)
        row.addView(
            documentView,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f),
        )
        row.addView(
            Button(this@CarPlayHostActivity).apply {
                text = getString(R.string.hs5_choose)
                applyMenuButtonStyle()
                contentDescription = "选择$label"
                setOnClickListener { onChoose() }
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { marginStart = dp(12) },
        )
        addView(
            row,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(4) },
        )
    }

    private fun updateLocalMfiDocumentViews() {
        localMfiCertificateDocumentView?.text = localMfiDocumentLabel(localMfiCertificateUri)
        localMfiPrivateKeyDocumentView?.text = localMfiDocumentLabel(localMfiPrivateKeyUri)
    }

    private fun localMfiDocumentLabel(value: String): String {
        if (value.isEmpty()) return getString(R.string.hs5_not_selected)
        val uri = try {
            Uri.parse(value)
        } catch (_: Exception) {
            return getString(R.string.hs5_selection_unavailable)
        }
        return try {
            contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null,
            )?.use { cursor ->
                if (!cursor.moveToFirst()) return@use null
                val column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (column >= 0) cursor.getString(column) else null
            } ?: uri.lastPathSegment ?: getString(R.string.hs5_selected_document)
        } catch (_: Exception) {
            uri.lastPathSegment ?: getString(R.string.hs5_selected_document)
        }
    }

    private fun retainDocumentReadPermission(uri: Uri, label: String): Boolean = try {
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        true
    } catch (failure: SecurityException) {
        Log.e(TAG, "Could not retain local MFi $label document permission", failure)
        Toast.makeText(
            this,
            "无法保留所选${label}的读取权限",
            Toast.LENGTH_LONG,
        ).show()
        false
    }

    private fun syncMfiSettingsControls() {
        mfiTargetGroup?.let { group ->
            val button = (0 until group.childCount)
                .map { group.getChildAt(it) }
                .filterIsInstance<RadioButton>()
                .firstOrNull { it.tag == mfiTarget }
            button?.let { group.check(it.id) }
        }
        if (mfiI2cPathInput?.text?.toString() != mfiI2cPath) {
            mfiI2cPathInput?.setText(mfiI2cPath)
        }
        if (remoteMfiServerInput?.text?.toString() != remoteMfiServer) {
            remoteMfiServerInput?.setText(remoteMfiServer)
        }
        if (remoteMfiTokenInput?.text?.toString() != remoteMfiToken) {
            remoteMfiTokenInput?.setText(remoteMfiToken)
        }
        updateLocalMfiDocumentViews()
        updateMfiTargetFields()
    }

    private fun mfiTargetLabel(target: MfiTarget): String = when (target) {
        MfiTarget.USB_CH341 -> "USB/CH341"
        MfiTarget.I2C -> "I2C"
        MfiTarget.REMOTE -> getString(R.string.hs5_remote)
        MfiTarget.LOCAL_FILES -> getString(R.string.hs5_local_files)
    }

    private fun buildIdentitySettingsSection(): View {
        val section = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        section.addView(
            settingsInputRow(getString(R.string.hs5_manufacturer), manufacturer) { value ->
                manufacturer = value
                updateResolutionMenu()
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        section.addView(
            settingsInputRow(getString(R.string.hs5_model), model) { value ->
                model = value
                updateResolutionMenu()
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(10) },
        )
        section.addView(
            settingsInputRow(getString(R.string.hs5_oem_label), oemLabel) { value ->
                oemLabel = value
                updateResolutionMenu()
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(10) },
        )
        return section
    }

    private fun settingsCategoryHeader(title: String): TextView =
        menuText(title, 16f, MENU_ACCENT, bold = true).apply { tag = "hs5_section_header" }

    private fun buildLocationReportingSection(): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val row = LinearLayout(this@CarPlayHostActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(
                menuText(getString(R.string.hs5_report_location_to_iphone), 20f, MENU_SECONDARY),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f),
            )
            val switch = Switch(this@CarPlayHostActivity).apply {
                isChecked = locationReportingEnabled
                contentDescription = getString(R.string.hs5_report_android_location_to_the_iphone)
                showText = false
                thumbTintList = ColorStateList(
                    arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                    intArrayOf(MENU_ACCENT, MENU_SECONDARY),
                )
                trackTintList = ColorStateList(
                    arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                    intArrayOf(MENU_ACCENT_TRACK, MENU_TRACK_OFF),
                )
                setOnCheckedChangeListener { _, checked ->
                    onLocationReportingChanged(checked)
                }
            }
            locationReportingSwitch = switch
            row.addView(
                switch,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ),
            )
            addView(
                row,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ),
            )
            addView(
                menuText(
                    getString(R.string.hs5_sends_precise_android_location_as_carplay_gps_data_when_the_iphone_requests_it),
                    14f,
                    MENU_SECONDARY,
                ),
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ).apply { topMargin = dp(6) },
            )
        }

    private fun onLocationReportingChanged(checked: Boolean) {
        if (locationReportingEnabled == checked) return
        locationReportingEnabled = checked
        appendLog(
            "Location reporting ${if (locationReportingEnabled) "enabled" else "disabled"}; " +
                "applies when settings close",
        )
        updateResolutionMenu()
        if (locationReportingEnabled && !locationPermissionAvailable) {
            requestLocationPermission()
        }
    }

    private fun buildDebugLogsSection(): View =
        settingsSwitchRow(
            label = getString(R.string.hs5_debug_logs),
            checked = debugLogsEnabled,
            description = getString(R.string.hs5_show_on_screen_debug_logs),
        ) { checked ->
            debugLogsEnabled = checked
            if (!checked) clearScreenLogs()
            appendLog("Debug logs ${if (debugLogsEnabled) "enabled" else "disabled"}")
            updateDebugOverlays()
        }

    private fun buildVideoFrameLogsSection(): View =
        settingsSwitchRow(
            label = getString(R.string.hs5_raw_video_in_saved_log),
            checked = videoFrameLogsEnabled,
            description = getString(R.string.hs5_include_original_video_packets_in_the_saved_log),
            onSwitchCreated = { videoFrameLogSwitch = it },
        ) { checked ->
            videoFrameLogsEnabled = checked
            sessionLog.videoFramesEnabled = checked
            appendLog("Raw video file logging ${if (checked) "enabled" else "disabled"}")
        }

    private fun buildMediaMetricsSection(): View =
        settingsSwitchRow(
            label = getString(R.string.hs5_media_latency_monitor),
            checked = mediaMetricsEnabled,
            description = getString(R.string.hs5_show_live_video_latency_frame_rate_and_audio_latency),
        ) { checked ->
            mediaMetricsEnabled = checked
            appendLog("Media latency monitor ${if (checked) "enabled" else "disabled"}")
            updateMediaMetricsOverlay()
        }

    private fun buildAudioPacketCaptureSection(): View =
        settingsSwitchRow(
            label = getString(R.string.hs5_audio_diagnostic_capture),
            checked = audioPacketCaptureEnabled,
            description = getString(R.string.hs5_capture_encrypted_udp_and_decrypted_rtp_audio_packets_for_diagnostics),
        ) { checked ->
            audioPacketCaptureEnabled = checked
            appendLog(
                "Audio diagnostic capture ${if (checked) "enabled" else "disabled"}; " +
                    "applies when settings close",
            )
        }

    private fun buildMicrophoneGainSection(): View {
        val section = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(
            menuText(getString(R.string.hs5_microphone_gain_0_8x_2_0x), 20f, MENU_SECONDARY),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f),
        )
        val gainValue = menuText(
            microphoneGainLabel(microphoneGainPercent),
            22f,
            MENU_ACCENT,
            bold = true,
        )
        microphoneGainValueView = gainValue
        header.addView(
            gainValue,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        section.addView(
            header,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val gainSlider = SeekBar(this).apply {
            max = (MicrophoneGain.MAX_PERCENT - MicrophoneGain.MIN_PERCENT) /
                MicrophoneGain.STEP_PERCENT
            progress = (microphoneGainPercent - MicrophoneGain.MIN_PERCENT) /
                MicrophoneGain.STEP_PERCENT
            splitTrack = false
            progressTintList = ColorStateList.valueOf(MENU_ACCENT)
            thumbTintList = ColorStateList.valueOf(MENU_ACCENT)
            contentDescription = getString(R.string.hs5_microphone_gain)
            setOnSeekBarChangeListener(
                object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(
                        seekBar: SeekBar,
                        progress: Int,
                        fromUser: Boolean,
                    ) {
                        val percent = MicrophoneGain.sanitize(
                            MicrophoneGain.MIN_PERCENT +
                                progress * MicrophoneGain.STEP_PERCENT,
                        )
                        microphoneGainPercent = percent
                        microphoneGainValueView?.text = microphoneGainLabel(percent)
                    }

                    override fun onStartTrackingTouch(seekBar: SeekBar) = Unit
                    override fun onStopTrackingTouch(seekBar: SeekBar) = Unit
                },
            )
        }
        microphoneGainSeekBar = gainSlider
        controls.addView(
            gainSlider,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f),
        )
        val testButton = Button(this).apply {
            text = getString(R.string.hs5_test)
            applyMenuButtonStyle(MENU_BUTTON_PRIMARY)
            textSize = Hs5Ui.sp(this@CarPlayHostActivity, 16f)
            minWidth = dp(78)
            contentDescription = getString(R.string.hs5_test_microphone_level)
            setOnClickListener {
                if (microphoneLevelMonitor?.isRunning == true) {
                    stopMicrophoneGainTest()
                } else {
                    startMicrophoneGainTest()
                }
            }
        }
        microphoneTestButton = testButton
        controls.addView(
            testButton,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { leftMargin = dp(12) },
        )
        section.addView(
            controls,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(6) },
        )

        val levelHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        levelHeader.addView(
            menuText(getString(R.string.hs5_peak_level), 15f, MENU_SECONDARY),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f),
        )
        val levelValue = menuText("0%", 15f, MENU_SECONDARY)
        microphoneLevelValueView = levelValue
        levelHeader.addView(
            levelValue,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        section.addView(
            levelHeader,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(8) },
        )
        val levelBar = ProgressBar(
            this,
            null,
            android.R.attr.progressBarStyleHorizontal,
        ).apply {
            max = 100
            progress = 0
            progressTintList = ColorStateList.valueOf(MENU_ACCENT)
            progressBackgroundTintList = ColorStateList.valueOf(MENU_TRACK_OFF)
            contentDescription = getString(R.string.hs5_microphone_peak_level)
        }
        microphoneLevelBar = levelBar
        section.addView(
            levelBar,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(14),
            ).apply { topMargin = dp(4) },
        )
        return section
    }

    private fun mainMediaAudioBufferLabel(durationMs: Int): String =
        String.format(
            Locale.US,
            "%d ms",
            MainMediaAudioBuffer.sanitizeDurationMs(durationMs),
        )

    private fun microphoneGainLabel(percent: Int): String =
        String.format(Locale.US, "%.1fx", MicrophoneGain.sanitize(percent) / 100.0)

    private fun syncMainMediaAudioBufferControls() {
        val durationMs = MainMediaAudioBuffer.sanitizeDurationMs(mainMediaAudioBufferDurationMs)
        mainMediaAudioBufferDurationMs = durationMs
        mainMediaAudioBufferValueView?.text = mainMediaAudioBufferLabel(durationMs)
        mainMediaAudioBufferSeekBar?.progress =
            (durationMs - MainMediaAudioBuffer.MIN_DURATION_MS) /
                MainMediaAudioBuffer.STEP_DURATION_MS
    }

    private fun syncMicrophoneGainControls() {
        microphoneGainValueView?.text = microphoneGainLabel(microphoneGainPercent)
        microphoneGainSeekBar?.progress =
            (microphoneGainPercent - MicrophoneGain.MIN_PERCENT) /
                MicrophoneGain.STEP_PERCENT
    }

    private fun startMicrophoneGainTest() {
        if (!menuOpen || handshakeResetInProgress || microphoneLevelMonitor != null) return
        if (!microphoneAvailable) {
            microphoneGainTestAfterPermission = true
            microphoneLevelValueView?.text = getString(R.string.hs5_permission_required)
            microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }

        lateinit var monitor: MicrophoneLevelMonitor
        monitor = MicrophoneLevelMonitor(
            context = applicationContext,
            gainPercent = { microphoneGainPercent },
            onPeakPercent = { peak ->
                runOnUiThread {
                    if (microphoneLevelMonitor !== monitor || !menuOpen || isDestroyed) {
                        return@runOnUiThread
                    }
                    microphoneLevelBar?.progress = peak
                    microphoneLevelValueView?.text = "$peak%"
                }
            },
            onStopped = { error ->
                runOnUiThread {
                    if (microphoneLevelMonitor !== monitor) return@runOnUiThread
                    microphoneLevelMonitor = null
                    microphoneTestButton?.text = getString(R.string.hs5_test)
                    microphoneTestButton?.isEnabled = menuOpen && !handshakeResetInProgress
                    if (error != null) {
                        Log.e(TAG, "microphone gain test failed", error)
                        microphoneLevelBar?.progress = 0
                        microphoneLevelValueView?.text =
                            error.message ?: getString(R.string.hs5_test_failed)
                    }
                }
            },
        )
        microphoneLevelMonitor = monitor
        microphoneTestButton?.text = getString(R.string.hs5_stop)
        microphoneLevelBar?.progress = 0
        microphoneLevelValueView?.text = getString(R.string.hs5_listening)
        if (!monitor.start()) {
            microphoneLevelMonitor = null
            microphoneTestButton?.text = getString(R.string.hs5_test)
        }
    }

    private fun stopMicrophoneGainTest() {
        microphoneGainTestAfterPermission = false
        val monitor = microphoneLevelMonitor
        microphoneLevelMonitor = null
        monitor?.close()
        microphoneTestButton?.text = getString(R.string.hs5_test)
        microphoneLevelBar?.progress = 0
        microphoneLevelValueView?.text = "0%"
    }

    private fun openSystemBluetoothSettings() {
        try {
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        } catch (error: ActivityNotFoundException) {
            appendLog("System Bluetooth settings are unavailable: ${error.message}")
            Toast.makeText(this, getString(R.string.hs5_system_bluetooth_settings_are_unavailable), Toast.LENGTH_LONG).show()
        } catch (error: SecurityException) {
            appendLog("Cannot open system Bluetooth settings: ${error.message}")
            Toast.makeText(this, getString(R.string.hs5_cannot_open_system_bluetooth_settings), Toast.LENGTH_LONG).show()
        }
    }

    private fun buildStepSliderSection(
        title: String,
        values: List<Int>,
        selectedValue: Int,
        label: (Int) -> String,
        onControlsCreated: ((TextView, SeekBar) -> Unit)? = null,
        onValueChanged: (Int) -> Unit,
    ): View {
        val section = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(
            menuText(title, 20f, MENU_SECONDARY),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f),
        )
        val selectedIndex = values.indexOf(selectedValue)
            .takeIf { it >= 0 }
            ?: 0
        val valueView = menuText(label(values[selectedIndex]), 22f, MENU_ACCENT, bold = true)
        header.addView(
            valueView,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        section.addView(
            header,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        val seekBar = SeekBar(this).apply {
            max = (values.size - 1).coerceAtLeast(0)
            progress = selectedIndex
            splitTrack = false
            progressTintList = ColorStateList.valueOf(MENU_ACCENT)
            thumbTintList = ColorStateList.valueOf(MENU_ACCENT)
            setOnSeekBarChangeListener(
                object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                        val value = values.getOrNull(progress) ?: return
                        valueView.text = label(value)
                        if (fromUser) onValueChanged(value)
                    }

                    override fun onStartTrackingTouch(seekBar: SeekBar) = Unit
                    override fun onStopTrackingTouch(seekBar: SeekBar) = Unit
                },
            )
        }
        section.addView(
            seekBar,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(8) },
        )
        onControlsCreated?.invoke(valueView, seekBar)
        return section
    }

    private fun buildAirPlayIconSection(): View {
        val section = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        section.addView(
            menuText(getString(R.string.hs5_airplay_icon), 20f, MENU_SECONDARY),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(8).toFloat()
                setColor(MENU_TRACK_OFF)
            }
        }
        row.addView(
            preview,
            LinearLayout.LayoutParams(dp(72), dp(72)),
        )
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        actions.addView(
            Button(this).apply {
                text = getString(R.string.hs5_choose_image)
                applyMenuButtonStyle()
                setOnClickListener {
                    externalActivityInProgress = true
                    imagePicker.launch("image/*")
                }
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        actions.addView(
            Button(this).apply {
                text = getString(R.string.hs5_default_icon)
                applyMenuButtonStyle()
                setOnClickListener {
                    AirPlayPersistence.clearCustomAirPlayIcon(this@CarPlayHostActivity)
                    updateAirPlayIconPreview()
                }
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(8) },
        )
        row.addView(
            actions,
            LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f,
            ).apply { marginStart = dp(16) },
        )
        section.addView(
            row,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(10) },
        )
        val status = menuText("", 14f, MENU_SECONDARY)
        section.addView(
            status,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(8) },
        )
        iconPreviewView = preview
        iconStatusView = status
        updateAirPlayIconPreview()
        return section
    }

    private fun buildDrivingSideSection(): View {
        val section = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        section.addView(
            menuText(getString(R.string.hs5_driving_side), 20f, MENU_SECONDARY),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        val group = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
        }
        val left = RadioButton(this).apply {
            id = View.generateViewId()
            text = getString(R.string.hs5_left_hand_drive)
            setTextColor(MENU_SECONDARY)
            buttonTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(MENU_ACCENT, MENU_SECONDARY),
            )
            isChecked = !rightHandDrive
        }
        val right = RadioButton(this).apply {
            id = View.generateViewId()
            text = getString(R.string.hs5_right_hand_drive)
            setTextColor(MENU_SECONDARY)
            buttonTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(MENU_ACCENT, MENU_SECONDARY),
            )
            isChecked = rightHandDrive
        }
        group.addView(left)
        group.addView(right)
        group.setOnCheckedChangeListener { _, checkedId ->
            rightHandDrive = checkedId == right.id
            updateResolutionMenu()
        }
        section.addView(
            group,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(8) },
        )
        return section
    }

    private fun buildFullscreenSection(): View {
        val section = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        section.addView(
            menuText(getString(R.string.hs5_fullscreen), 20f, MENU_SECONDARY),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        section.addView(
            settingsSwitchRow(
                label = getString(R.string.hs5_hide_top_bar),
                checked = hideTopBar,
                description = getString(R.string.hs5_hide_the_status_bar),
            ) { checked ->
                hideTopBar = checked
                applyFullscreenMode()
                refreshDisplaySizeAfterLayout()
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(10) },
        )
        section.addView(
            settingsSwitchRow(
                label = getString(R.string.hs5_hide_bottom_bar),
                checked = hideBottomBar,
                description = getString(R.string.hs5_hide_the_navigation_bar),
            ) { checked ->
                hideBottomBar = checked
                applyFullscreenMode()
                refreshDisplaySizeAfterLayout()
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(10) },
        )
        return section
    }

    private fun buildSafeAreaSection(): View {
        val section = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        section.addView(
            menuText(getString(R.string.hs5_safe_area), 20f, MENU_SECONDARY),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        val summary = menuText("", 15f, MENU_ACCENT)
        section.addView(
            summary,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(6) },
        )
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        buttons.addView(
            Button(this).apply {
                text = getString(R.string.hs5_set)
                applyMenuButtonStyle()
                setOnClickListener { openSafeAreaEditor() }
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f),
        )
        buttons.addView(
            Button(this).apply {
                text = getString(R.string.hs5_reset)
                applyMenuButtonStyle()
                setOnClickListener { resetSafeAreaForCurrentSize() }
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(12)
            },
        )
        section.addView(
            buttons,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(10) },
        )
        section.addView(
            settingsSwitchRow(
                label = getString(R.string.hs5_draw_outside_safe_area),
                checked = safeAreaDrawOutside,
                description = getString(R.string.hs5_allow_carplay_ui_outside_the_safe_area),
            ) { checked ->
                safeAreaDrawOutside = checked
                updateResolutionMenu()
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { topMargin = dp(12) },
        )
        safeAreaSummaryView = summary
        updateSafeAreaSummary()
        return section
    }

    private fun buildSafeAreaEditor(): View {
        val overlay = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            isClickable = true
        }
        val editor = SafeAreaEditorView(this)
        overlay.addView(
            editor,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
            ),
        )
        overlay.addView(
            menuText(getString(R.string.hs5_safe_area), 24f, MENU_LABEL, bold = true).apply {
                setPadding(dp(16), dp(12), dp(16), dp(8))
            },
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START,
            ),
        )
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(16))
        }
        controls.addView(
            Button(this).apply {
                text = getString(R.string.hs5_cancel)
                applyMenuButtonStyle()
                setOnClickListener { closeSafeAreaEditor() }
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f),
        )
        controls.addView(
            Button(this).apply {
                text = getString(R.string.hs5_save)
                applyMenuButtonStyle(MENU_BUTTON_PRIMARY)
                setOnClickListener { saveSafeAreaEditor() }
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(12)
            },
        )
        overlay.addView(
            controls,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM,
            ),
        )
        safeAreaEditorView = editor
        return overlay
    }

    private fun settingsInputRow(
        label: String,
        value: String,
        password: Boolean = false,
        numeric: Boolean = false,
        onInputCreated: ((EditText) -> Unit)? = null,
        onChanged: (String) -> Unit,
    ): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(
            menuText(label, 18f, MENU_SECONDARY).apply {
                gravity = Gravity.CENTER_VERTICAL
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        addView(
            EditText(this@CarPlayHostActivity).apply {
                setText(value)
                textSize = Hs5Ui.sp(this@CarPlayHostActivity, 18f)
                setTextColor(MENU_LABEL)
                setHintTextColor(MENU_SECONDARY)
                backgroundTintList = ColorStateList.valueOf(MENU_ACCENT)
                minHeight = dp(48)
                isSingleLine = true
                inputType = when {
                    numeric -> InputType.TYPE_CLASS_NUMBER
                    password -> InputType.TYPE_CLASS_TEXT or
                        InputType.TYPE_TEXT_VARIATION_PASSWORD or
                        InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                    else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                }
                addTextChangedListener(afterTextChanged(onChanged))
                onInputCreated?.invoke(this)
            },
            LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f,
            ).apply { marginStart = dp(12) },
        )
    }

    private fun settingsSwitchRow(
        label: String,
        checked: Boolean,
        description: String,
        onSwitchCreated: (Switch) -> Unit = {},
        onChanged: (Boolean) -> Unit,
    ): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(
            menuText(label, 18f, MENU_SECONDARY),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f),
        )
        addView(
            Switch(this@CarPlayHostActivity).apply {
                isChecked = checked
                contentDescription = description
                showText = false
                thumbTintList = ColorStateList(
                    arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                    intArrayOf(MENU_ACCENT, MENU_SECONDARY),
                )
                trackTintList = ColorStateList(
                    arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                    intArrayOf(MENU_ACCENT_TRACK, MENU_TRACK_OFF),
                )
                onSwitchCreated(this)
                setOnCheckedChangeListener { _, value -> onChanged(value) }
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
    }

    private fun afterTextChanged(onChanged: (String) -> Unit): TextWatcher =
        object : TextWatcher {
            override fun beforeTextChanged(
                text: CharSequence?,
                start: Int,
                count: Int,
                after: Int,
            ) = Unit

            override fun onTextChanged(
                text: CharSequence?,
                start: Int,
                before: Int,
                count: Int,
            ) = Unit

            override fun afterTextChanged(text: Editable?) {
                onChanged(text?.toString().orEmpty())
            }
        }

    private fun buildHs5Settings(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(menuText("红旗 HS5", 20f, MENU_SECONDARY))
        fun option(key: String, label: String, description: String) {
            addView(settingsSwitchRow(label, hs5Prefs.getBoolean(key, true), description) { enabled ->
                hs5Prefs.edit().putBoolean(key, enabled).apply()
            })
        }
        option("hud_enabled", "HUD 导航提示", "将手机导航提示发送到原厂 HUD")
        option("instrument_map_enabled", "仪表地图", "连接时启用仪表副屏；三指手势可隐藏或显示")
        option("wheel_enabled", "方向盘按键", "曲目、电话与 Siri 按键")
        option("night_enabled", "随车灯切换日夜模式", "使用车辆示宽灯状态")
        addView(Button(this@CarPlayHostActivity).apply {
            instrumentPermissionButton = this
            text = if (Settings.canDrawOverlays(this@CarPlayHostActivity)) "仪表显示权限：已允许" else "允许仪表地图显示"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@CarPlayHostActivity)) {
                    openPermissionSettings(Settings.ACTION_MANAGE_OVERLAY_PERMISSION) {
                        Settings.canDrawOverlays(this@CarPlayHostActivity)
                    }
                } else updatePermissionControls()
            }
        })
    }

    private fun openPermissionSettings(action: String, granted: () -> Boolean) {
        try { startActivity(Intent(action, Uri.parse("package:$packageName"))) }
        catch (_: ActivityNotFoundException) { Toast.makeText(this, "系统未提供此权限设置入口", Toast.LENGTH_LONG).show() }
    }

    private fun updatePermissionControls() {
        microphonePermissionButton?.text =
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                "Siri 与通话麦克风：已允许" else "允许 Siri 与通话麦克风"
        instrumentPermissionButton?.text =
            if (Settings.canDrawOverlays(this)) "仪表显示权限：已允许" else "允许仪表地图显示"
    }

    private fun buildHs5AudioSettings(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(settingsSwitchRow("原厂导航音频通道", hs5Prefs.getBoolean("navigation_legacy_stream", true),
            "使用 HS5 通道 14；关闭后使用 Android 导航音频路由") {
            hs5Prefs.edit().putBoolean("navigation_legacy_stream", it).apply()
        })
        addView(buildStepSliderSection(
            title = "音乐预缓冲",
            values = com.shilapi.xcertplay.media.MediaAudioBuffer.presets,
            selectedValue = com.shilapi.xcertplay.media.MediaAudioBuffer.sanitize(hs5Prefs.getInt("media_prebuffer_ms", 500)),
            label = { "$it ms · 请求容量 ${it + 200} ms" },
            onValueChanged = { hs5Prefs.edit().putInt("media_prebuffer_ms", it).apply() },
        ))
    }

    private fun menuText(
        text: String,
        sizeSp: Float,
        color: Int,
        bold: Boolean = false,
    ): TextView = TextView(this).apply {
        this.text = text
        textSize = Hs5Ui.sp(this@CarPlayHostActivity, sizeSp)
        setTextColor(color)
        typeface = if (bold) HandshakePanelView.MEDIUM else Typeface.DEFAULT
        includeFontPadding = false
    }

    private fun menuRipple(shape: GradientDrawable): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(MENU_RIPPLE), shape, null)

    /** Flat rounded button in the connection panel's palette. */
    private fun Button.applyMenuButtonStyle(fill: Int = MENU_BUTTON, textColor: Int = MENU_LABEL) {
        isAllCaps = false
        typeface = HandshakePanelView.MEDIUM
        setTextColor(textColor)
        stateListAnimator = null
        backgroundTintList = null
        background = menuRipple(
            GradientDrawable().apply {
                cornerRadius = Hs5Ui.dp(this@CarPlayHostActivity, 24).toFloat()
                setColor(fill)
            },
        )
        minHeight = Hs5Ui.dp(this@CarPlayHostActivity, 40)
        setPadding(dp(16), 0, dp(16), 0)
    }

    private fun updateHotspotStatus(status: CarPlayStatus) {
        if (!wirelessEnabled) return
        hotspotStatus = when (status) {
            CarPlayStatus.StartingHotspot -> HotspotStatus(state = getString(R.string.hs5_starting))
            is CarPlayStatus.HotspotReady -> HotspotStatus(
                state = getString(R.string.hs5_ready),
                ssid = status.ssid,
                band = status.band,
                channel = status.channel,
                backend = status.backend,
            )
            CarPlayStatus.WaitingForPairedIphone ->
                hotspotStatus.copy(state = getString(R.string.hs5_waiting_for_paired_iphone))
            CarPlayStatus.ConnectingBluetooth ->
                hotspotStatus.copy(state = getString(R.string.hs5_connecting_bluetooth))
            CarPlayStatus.RunningWireless ->
                hotspotStatus.copy(state = getString(R.string.hs5_running))
            CarPlayStatus.WirelessActive ->
                hotspotStatus.copy(state = getString(R.string.hs5_active))
            CarPlayStatus.AttachingNetwork ->
                hotspotStatus.copy(state = getString(R.string.hs5_starting_airplay_service))
            is CarPlayStatus.Failed -> hotspotStatus.copy(state = getString(R.string.hs5_error))
            else -> return
        }
        updateHotspotStatusBlock()
    }

    private fun updateHotspotStatusBlock() {
        if (!wirelessEnabled) {
            hotspotStatusView?.text = getString(R.string.hs5_wireless_hotspot_off)
            return
        }
        val status = hotspotStatus
        hotspotStatusView?.text = buildString {
            append("无线热点：").append(when (status.state) {
                "stopped" -> "未启动"
                "off" -> "已关闭"
                else -> status.state
            })
            status.ssid?.let { append("\nSSID: ").append(it) }
            status.backend?.let { append("\n连接后端：").append(it) }
            status.band?.let { append("\n频段：").append(it) }
            status.channel?.let {
                append("\n信道：").append(if (it == 0) getString(R.string.hs5_auto) else it.toString())
            }
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun <T> settingsChoiceRow(
        label: String,
        options: List<Pair<T, String>>,
        selected: T,
        onSelected: (T) -> Unit,
    ): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(
            menuText(label, 18f, MENU_SECONDARY),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        val group = RadioGroup(this@CarPlayHostActivity).apply {
            orientation = RadioGroup.VERTICAL
            setPadding(0, dp(4), 0, 0)
        }
        var selectedId = View.NO_ID
        for ((value, text) in options) {
            val button = RadioButton(this@CarPlayHostActivity).apply {
                id = View.generateViewId()
                this.text = text
                textSize = Hs5Ui.sp(this@CarPlayHostActivity, 17f)
                setTextColor(MENU_SECONDARY)
                buttonTintList = ColorStateList(
                    arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                    intArrayOf(MENU_ACCENT, MENU_SECONDARY),
                )
                tag = value
                isChecked = value == selected
            }
            if (value == selected) selectedId = button.id
            group.addView(
                button,
                RadioGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                ),
            )
        }
        if (selectedId != View.NO_ID) group.check(selectedId)
        group.setOnCheckedChangeListener { radioGroup, checkedId ->
            val value = radioGroup.findViewById<RadioButton>(checkedId)?.tag as? T ?: return@setOnCheckedChangeListener
            onSelected(value)
        }
        addView(
            group,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
    }

    private fun updateResolutionMenu() {
        resolutionValueView?.text = CarPlayDisplayScale.label(displayScaleTenths)
        val native = activeDisplaySize ?: currentActivitySize()
        val resolution = if (native == null) {
            "协商分辨率：等待获取屏幕尺寸"
        } else {
            val negotiated = mainWebDisplay.override(CarPlayDisplayScale.apply(
                AirPlayDisplayConfig(
                    widthPixels = native.width,
                    heightPixels = native.height,
                    widthPhysicalMm = widthPhysicalMm,
                    fps = fps,
                ),
                displayScaleTenths,
            ))
            "协商分辨率：${native.width} x ${native.height} -> " +
                "${negotiated.widthPixels} x ${negotiated.heightPixels}"
        }
        val transport = if (!hevcEnabled) {
            "H.264"
        } else {
            "HEVC（H.265，${if (hevcSoftwareDecoderEnabled) "软件优先" else "系统选择"}）"
        }
        val fullscreen = buildString {
            append(if (hideTopBar) "顶部栏隐藏" else "顶部栏显示")
            append(", ")
            append(if (hideBottomBar) "底部栏隐藏" else "底部栏显示")
        }
        resolutionPreviewView?.text = buildString {
            append(resolution).append('\n')
            append("接收端名称：").append(normalizedManufacturer()).append(" / ")
                .append(normalizedModel()).append('\n')
            append("车机显示名称：").append(oemLabel.ifBlank { "（空）" }).append('\n')
            append("帧率：").append(fps).append(" fps\n")
            append("检测到的最大尺寸：")
                .append(maximumDetectedWidthPixels).append(" x ")
                .append(maximumDetectedHeightPixels).append(" px\n")
            append("物理尺寸参考：")
                .append(
                    when (physicalSizeBasis) {
                        AirPlayPhysicalSizeBasis.WIDTH -> "最长宽边"
                        AirPlayPhysicalSizeBasis.HEIGHT -> "最长高边"
                    },
                )
                .append(" = ").append(widthPhysicalMm).append(" mm\n")
            native?.let { size ->
                val physical = resolvePhysicalSize(size)
                append("CarPlay 物理尺寸：")
                    .append(physical.widthMm).append(" x ")
                    .append(physical.heightMm).append(" mm\n")
            }
            append("驾驶位置：").append(if (rightHandDrive) "右舵" else "左舵").append('\n')
            append("全屏显示：").append(fullscreen).append('\n')
            append("视频编码：").append(transport).append('\n')
            append("位置上报：")
                .append(if (locationReportingEnabled) "开启" else "关闭")
                .append('\n')
            if (advancedAudioChannelMappingSupported) {
                append("音频通道映射：")
                    .append(if (advancedAudioChannelMapping) "AAOS 音频通道" else "普通 Android 兼容模式")
                    .append('\n')
            }
            append(safeAreaSummary())
        }
    }

    private fun createAirPlayConfig(size: DisplaySize): AirPlayConfig {
        val physical = resolvePhysicalSize(size)
        val baseDisplay = AirPlayDisplayConfig(
            widthPixels = size.width,
            heightPixels = size.height,
            widthPhysicalMm = physical.widthMm,
            heightPhysicalMm = physical.heightMm,
            fps = fps,
        )
        val scaledDisplay = CarPlayDisplayScale.apply(
            baseDisplay,
            displayScaleTenths,
        )
        val display = mainWebDisplay.override(scaledDisplay.copy(
            safeArea = AirPlaySafeArea.toInsets(
                mapping = AirPlayPersistence.loadSafeAreaRect(this, size.width, size.height),
                activityWidthPixels = size.width,
                activityHeightPixels = size.height,
                displayWidthPixels = scaledDisplay.widthPixels,
                displayHeightPixels = scaledDisplay.heightPixels,
            ),
            safeAreaDrawOutside = safeAreaDrawOutside,
        ))
        val cluster = if (hs5InstrumentEnabled()) CarPlayClusterDisplay.config(1920, 720, content = CarPlayClusterDisplay.Content.INSTRUMENTS, baseSafeArea = CarPlayClusterDisplay.HONGQI_SAFE_AREA_PERCENT) else clusterWebDisplay.takeIf { it.enabled }?.let {
            it.override(AirPlayDisplayConfig(it.width, it.height, widthPhysicalMm = widthPhysicalMm, fps = fps,
                primaryInputDevice = 0))
        }
        return AirPlayConfig(
            deviceName = "xcertplay",
            deviceId = "02:00:00:00:00:02",
            btMac = "02:00:00:00:00:01",
            sourceVersion = "950.7.1",
            main = display,
            cluster = cluster,
            receiverManagedClusterUi = !com.shilapi.xcertplay.hud.HongqiNavigation.supported(),
            rightHandDrive = rightHandDrive,
            hevc = hevcEnabled,
            microphone = microphoneAvailable,
            manufacturer = normalizedManufacturer(),
            model = normalizedModel(),
            oemLabel = oemLabel,
            icons = listOf(loadAirPlayIcon()),
        )
    }

    private fun loadAirPlayIcon(): AirPlayIcon {
        val customBytes = try {
            AirPlayPersistence.loadCustomAirPlayIconFile(this)?.readBytes()
        } catch (_: Exception) {
            null
        }
        if (customBytes != null) {
            decodeAirPlayIcon(customBytes)?.let { return it }
            AirPlayPersistence.clearCustomAirPlayIcon(this)
        }
        return decodeAirPlayIcon(defaultAirPlayIconBytes())
            ?: throw IllegalStateException("Packaged AirPlay icon is invalid")
    }

    private fun decodeAirPlayIcon(encoded: ByteArray): AirPlayIcon? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(encoded, 0, encoded.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0 ||
            bounds.outWidth != bounds.outHeight
        ) {
            return null
        }
        return AirPlayIcon(bounds.outWidth, bounds.outHeight, encoded)
    }

    private fun defaultAirPlayIconBytes(): ByteArray =
        resources.openRawResource(R.raw.placeholder_icon).use { it.readBytes() }

    private fun updateAirPlayIconPreview() {
        val preview = iconPreviewView ?: return
        val custom = AirPlayPersistence.loadCustomAirPlayIconFile(this)
        var customBitmap: Bitmap? = null
        if (custom != null) {
            customBitmap = BitmapFactory.decodeFile(custom.absolutePath)
            if (customBitmap == null) {
                AirPlayPersistence.clearCustomAirPlayIcon(this)
            }
        }
        val bitmap = customBitmap ?: BitmapFactory.decodeResource(resources, R.raw.placeholder_icon)
        preview.setImageBitmap(bitmap)
        iconStatusView?.text =
            if (customBitmap != null) "Custom 1:1 icon" else "Default placeholder icon"
    }

    private fun currentActivitySize(): DisplaySize? {
        val view = videoView
        if (view != null && view.width > 0 && view.height > 0) {
            return DisplaySize(view.width, view.height)
        }
        return activeDisplaySize
    }

    private fun resolvePhysicalSize(size: DisplaySize): AirPlayPhysicalSizeMm =
        AirPlayDisplaySettings.resolvePhysicalSizeMm(
            currentWidthPixels = size.width,
            currentHeightPixels = size.height,
            maximumWidthPixels = maxOf(maximumDetectedWidthPixels, size.width),
            maximumHeightPixels = maxOf(maximumDetectedHeightPixels, size.height),
            referenceMillimeters = widthPhysicalMm,
            basis = physicalSizeBasis,
        )

    private fun safeAreaSummary(): String {
        val size = currentActivitySize() ?: return "安全区域：等待屏幕完成布局"
        val mapping = AirPlayPersistence.loadSafeAreaRect(this, size.width, size.height)
        return if (mapping == null) {
            "安全区域：全屏 ${size.width} × ${size.height}"
        } else {
            "安全区域：${mapping.width} × ${mapping.height}，起点 " +
                "(${mapping.left}, ${mapping.top})，窗口 ${size.width} × ${size.height}"
        }
    }

    private fun updateSafeAreaSummary() {
        safeAreaSummaryView?.text = safeAreaSummary()
    }

    private fun openSafeAreaEditor() {
        val size = currentActivitySize()
        if (size == null) {
            appendLog("Safe area editor is unavailable before display layout")
            return
        }
        val editorView = safeAreaEditorView ?: return
        val initial = AirPlayPersistence.loadSafeAreaRect(this, size.width, size.height)
            ?: AirPlaySafeArea.default(size.width, size.height)
        safeAreaEditSize = size
        safeAreaEditorActive = true
        // Keep the current activity size; changing system bars here would remap the safe area.
        settingsMenu?.visibility = View.GONE
        safeAreaEditor?.visibility = View.VISIBLE
        editorView.setRect(initial, size.width, size.height)
        appendLog(
            "Safe area editor opened for ${size.width}x${size.height}; " +
                "drag the four boundaries",
        )
    }

    private fun closeSafeAreaEditor() {
        if (!safeAreaEditorActive) return
        safeAreaEditorActive = false
        safeAreaEditSize = null
        safeAreaEditor?.visibility = View.GONE
        settingsMenu?.visibility = View.VISIBLE
        updateSafeAreaSummary()
        updateResolutionMenu()
        appendLog("Safe area editor closed")
    }

    private fun saveSafeAreaEditor() {
        val size = safeAreaEditSize ?: currentActivitySize() ?: return
        val rect = safeAreaEditorView?.currentRectForSource() ?: return
        AirPlayPersistence.saveSafeAreaRect(this, size.width, size.height, rect)
        appendLog(
            "Safe area saved for ${size.width}x${size.height}: " +
                "${rect.width}x${rect.height} at (${rect.left}, ${rect.top})",
        )
        closeSafeAreaEditor()
    }

    private fun resetSafeAreaForCurrentSize() {
        val size = currentActivitySize()
        if (size == null) {
            appendLog("Safe area reset is unavailable before display layout")
            return
        }
        AirPlayPersistence.clearSafeAreaRect(this, size.width, size.height)
        updateSafeAreaSummary()
        updateResolutionMenu()
        appendLog("Safe area reset to full screen for ${size.width}x${size.height}")
    }

    private fun refreshDisplaySizeAfterLayout() {
        videoView?.post {
            val view = videoView ?: return@post
            scheduleDisplaySize(view.width, view.height)
        }
    }

    private fun normalizedManufacturer(): String =
        manufacturer.trim().ifBlank { AirPlayPersistence.DEFAULT_MANUFACTURER }

    private fun normalizedModel(): String =
        model.trim().ifBlank { AirPlayPersistence.DEFAULT_MODEL }

    private fun createMediaSink(
        airPlayConfig: AirPlayConfig,
        controllerGeneration: Int,
    ): AndroidMediaSink {
        val outputs = CarPlayWebDisplayFactory.create(
            context = applicationContext,
            configs = if (hs5InstrumentEnabled()) mapOf(SCREEN_TYPE_MAIN to mainWebDisplay) else mapOf(SCREEN_TYPE_MAIN to mainWebDisplay, SCREEN_TYPE_ALT to clusterWebDisplay),
            key = AirPlayPersistence.webDisplayKey(this),
            sendTouch = { CarPlayBackgroundSession.snapshot()?.controller?.sendTouch(it) ?: false },
        )
        return try {
            AndroidMediaSink(
                context = applicationContext,
                videoWidth = airPlayConfig.main.widthPixels,
                videoHeight = airPlayConfig.main.heightPixels,
                videoSizes = buildMap {
                    put(SCREEN_TYPE_MAIN, airPlayConfig.main.widthPixels to airPlayConfig.main.heightPixels)
                    airPlayConfig.cluster?.let { put(SCREEN_TYPE_ALT, it.widthPixels to it.heightPixels) }
                },
                preferSoftwareHevcDecoder = hevcSoftwareDecoderEnabled,
                advancedAudioChannelMapping = advancedAudioChannelMapping,
                mainMediaAudioBufferDurationMs = mainMediaAudioBufferDurationMs,
                hs5MediaPrebufferMillis = 500,
                hs5NavigationStream = 0,
                microphoneGainPercent = microphoneGainPercent,
                mediaMetricsMonitor = mediaMetricsMonitor,
                onClosed = { outputs?.close() },
                mediaTap = outputs,
                audioFocus = CarPlayBackgroundSession.audioFocus(this),
                onScreenStreamActiveChanged = { type, active ->
                    onScreenStreamStateChanged(controllerGeneration, type, active)
                },
            ).also { outputs?.bind(it) }
        } catch (error: Exception) { outputs?.close(); throw error }
    }

    private fun createMediaEngine(sink: AndroidMediaSink): CarPlayMediaEngine =
        CarPlayMediaEngine(
            sink = sink,
            microphoneEnabled = microphoneAvailable,
            audioCaptureDirectory = audioCaptureDirectory(),
            videoPacketLog = CarPlayBackgroundSession.log::appendVideoPacket,
        )

    private fun createSessionListener(controllerGeneration: Int): AirPlaySessionListener =
        object : AirPlaySessionListener {
            override fun onSessionActive(session: AirPlaySession) {
                runOnUiThread {
                    if (isDestroyed || controllerGeneration != restartGeneration || session.isClosed()) {
                        return@runOnUiThread
                    }
                    activeAirPlaySession = session
                    if (wirelessEnabled) wirelessRetryPolicy.reset()
                    syncAirPlayDarkMode()
                    if (menuOpen) return@runOnUiThread
                    appendLog("AirPlay session active")
                }
            }

            override fun onSessionDisconnected(session: AirPlaySession) {
                runOnUiThread {
                    if (isDestroyed || controllerGeneration != restartGeneration) {
                        return@runOnUiThread
                    }
                    if (activeAirPlaySession != null && activeAirPlaySession !== session) return@runOnUiThread
                    endConnectionPresentation()
                    failHandshake("CarPlay session ended", "iPhone closed the AirPlay session")
                    setConnectionStage(getString(R.string.hs5_carplay_session_ended_reconnecting))
                    appendLog("AirPlay session disconnected; showing connection home")
                    recoverConnection("AirPlay session disconnected")
                }
            }

            override fun onSessionEnded(session: AirPlaySession) {
                // The disconnect callback already restored the home screen before media teardown.
                appendFileLog("AirPlay session cleanup complete", System.currentTimeMillis())
            }

            override fun onTransportError(message: String) {
                runOnUiThread {
                    if (isDestroyed || controllerGeneration != restartGeneration) {
                        return@runOnUiThread
                    }
                    endConnectionPresentation()
                    failHandshake("Transport error", message)
                    setConnectionStage(getString(R.string.hs5_transport_error_reconnecting))
                    appendLog("CarPlay transport error: $message; reconnecting from scratch")
                    recoverConnection("CarPlay transport error: $message")
                }
            }

            override fun onDebugLog(message: String) {
                val now = System.currentTimeMillis()
                appendFileLog(message, now)
                if (HandshakeTimeline.isRelevant(message)) {
                    mainHandler.post { recordHandshake(controllerGeneration, message, now) }
                }
                if (!debugLogsEnabled) return
                val summary = ScreenLogPolicy.summary(message) ?: return
                synchronized(pendingScreenLogsLock) {
                    if (!debugLogsEnabled) return
                    pendingScreenLogs.addLast(PendingLog(controllerGeneration, now, summary))
                    if (pendingScreenLogs.size > MAX_SCREEN_LOG_LINES) pendingScreenLogs.removeFirst()
                    if (!screenDrainPosted) {
                        screenDrainPosted = true
                        mainHandler.post(drainScreenLogs)
                    }
                }
            }
        }.also { currentUiListener = it }

    private fun createStatusReporter(
        controllerGeneration: Int,
    ): (CarPlayStatus) -> Unit = { status ->
        runOnUiThread {
            if (!isDestroyed && controllerGeneration == restartGeneration) {
                updateHotspotStatus(status)
                val description = status.describe()
                setConnectionStage(description)
                when (status) {
                    is CarPlayStatus.Failed -> {
                        endConnectionPresentation()
                        failHandshake("CarPlay failed", description)
                        updateDebugOverlays()
                        appendLog("CarPlay link disconnected; showing connection home")
                        recoverConnection(description, status)
                    }
                    else -> Unit
                }
            }
        }
    }

    private fun adoptBackgroundSession(): Boolean {
        val snapshot = CarPlayBackgroundSession.snapshot() ?: return false
        if (snapshot.controller.isClosed()) {
            CarPlayBackgroundSession.clear(snapshot.controller)
            return false
        }
        connectionRequested = true
        bluetoothDiscoverabilityReady = true
        controller = snapshot.controller
        sink = snapshot.sink
        handshakeTimeline = snapshot.handshakeTimeline
        activeScreenStreamTypes = snapshot.activeScreenStreamTypes
        handshakePanel?.bind(handshakeTimeline)
        snapshot.sink.setMediaMetricsMonitor(mediaMetricsMonitor)
        if (snapshot.width > 0 && snapshot.height > 0) {
            activeDisplaySize = DisplaySize(snapshot.width, snapshot.height)
        }
        val generation = restartGeneration
        snapshot.controller.attachUi(
            createSessionListener(generation),
            createStatusReporter(generation),
        )
        snapshot.sink.setScreenStreamActiveChangedListener { type, active ->
            onScreenStreamStateChanged(generation, type, active)
        }
        currentSurface?.let(::attachSurface)
        clusterPreviewSurface?.let { attachDisplaySurface(SCREEN_TYPE_ALT, it) }
        controller?.let { owner -> sink?.let { renderer -> hongqi.attach(owner, renderer, createAirPlayConfig(activeDisplaySize ?: DisplaySize(snapshot.width, snapshot.height))) } }
        hongqi.screenState(SCREEN_TYPE_ALT, SCREEN_TYPE_ALT in activeScreenStreamTypes)
        updateWebDisplayPreviews()
        val serviceReused = snapshot.controller.hasActiveAirPlayAttachment()
        appendLog(
            if (serviceReused) {
                "Reusing existing background CarPlay service"
            } else {
                "Reusing existing background CarPlay session"
            },
        )
        setConnectionStage(
            if (serviceReused) {
                getString(R.string.hs5_carplay_service_already_running)
            } else {
                getString(R.string.hs5_carplay_session_already_running)
            },
        )
        updateDebugOverlays()
        return true
    }

    private fun startCarPlay(size: DisplaySize) {
        if (!connectionRequested || connectionPaused || shuttingDown.get() || menuOpen || handshakeResetInProgress || controller != null) return
        val controllerGeneration = restartGeneration
        // Preserve the user's permission-wait time, but never reuse a previous controller's
        // protocol history when automatic recovery or display changes start a new controller.
        handshakeTimeline = handshakeTimeline?.takeIf { it.failure == null && it.revision == 0 }
            ?: HandshakeTimeline(wirelessEnabled, System.currentTimeMillis(), lastAttemptFailure)
        lastAttemptFailure = null
        handshakePanel?.bind(handshakeTimeline)
        updateDebugOverlays()
        val config = createRuntimeConfig()
        val airPlayConfig = createAirPlayConfig(size)
        val locationProvider: Iap2LocationProvider? =
            if (config.locationReportingEnabled) {
                AndroidCarPlayLocationProvider(this).let { position ->
                    if (com.shilapi.xcertplay.hud.HongqiNavigation.supported()) com.shilapi.xcertplay.transport.VehicleSpeedLocationProvider(position, com.shilapi.xcertplay.hud.HongqiVehicleSpeed(this)) else position
                }
            } else {
                null
            }
        appendLog(
            "Starting CarPlay controller at ${size.width}x${size.height} -> " +
                "${airPlayConfig.main.widthPixels}x${airPlayConfig.main.heightPixels} " +
                "(${CarPlayDisplayScale.label(displayScaleTenths)}) " +
                "physical=${airPlayConfig.main.widthPhysicalMm}x" +
                "${airPlayConfig.main.heightPhysicalMm}mm " +
                "video=${if (airPlayConfig.hevc) "HEVC" else "H.264"} " +
                "decoder=${if (airPlayConfig.hevc && hevcSoftwareDecoderEnabled) "software" else "hardware"} " +
                "microphone=${airPlayConfig.microphone} " +
                "location=${if (config.locationReportingEnabled) "enabled" else "disabled"} " +
                "mfi=${mfiTargetLabel(config.mfiTarget)}",
        )
        Log.i(
            TAG,
            "starting controller display=${size.width}x${size.height} " +
                "negotiated=${airPlayConfig.main.widthPixels}x${airPlayConfig.main.heightPixels} " +
                "scale=${CarPlayDisplayScale.label(displayScaleTenths)} " +
                "hevc=${airPlayConfig.hevc} " +
                "softwareHevc=${airPlayConfig.hevc && hevcSoftwareDecoderEnabled} " +
                "microphone=${airPlayConfig.microphone} " +
                "location=${config.locationReportingEnabled} " +
                "mfi=${config.mfiTarget}",
        )
        val renderer = try {
            createMediaSink(airPlayConfig, controllerGeneration)
        } catch (error: Exception) {
            appendLog("Could not create web displays: ${error.message}")
            failHandshake("Could not start web displays", error.message ?: "Check resolution and port 8080")
            setConnectionStage("Could not start web displays; check resolution and port 8080")
            return
        }
        sink = renderer
        currentSurface?.let(::attachSurface)
        clusterPreviewSurface?.let { attachDisplaySurface(SCREEN_TYPE_ALT, it) }
        updateWebDisplayPreviews()
        val media = createMediaEngine(renderer)
        val pairings = AirPlayPersistence.loadPairings(this) { id, key ->
            AirPlayPersistence.savePairing(this, id, key)
        }
        val next = CarPlayController(
            context = this,
            config = config,
            airPlayConfig = airPlayConfig,
            identity = airPlayIdentity,
            pairings = pairings,
            listener = createSessionListener(controllerGeneration),
            media = media,
            reportStatus = createStatusReporter(controllerGeneration),
            loadPairRecord = { AirPlayPersistence.loadLockdownRecord(this) },
            savePairRecord = { record -> AirPlayPersistence.saveLockdownRecord(this, record) },
            clearPairRecord = { AirPlayPersistence.clearLockdownRecord(this) },
            locationProvider = locationProvider,
        )
        controller = next
        hongqi.attach(next, renderer, airPlayConfig)
        CarPlayBackgroundSession.store(
            next, renderer, size.width, size.height,
            checkNotNull(handshakeTimeline), activeScreenStreamTypes,
        )
        next.start()
    }

    private fun syncAirPlayDarkMode() {
        val session = activeAirPlaySession ?: return
        val night = darkMode
        airPlayCommandExecutor.execute {
            try {
                val sent = session.setNightMode(night)
                Log.i(
                    TAG,
                    "AirPlay dark mode=${if (night) "dark" else "light"} eventChannelReady=$sent",
                )
            } catch (error: Throwable) {
                Log.w(TAG, "Could not send AirPlay dark mode update", error)
            }
        }
    }

    private fun audioCaptureDirectory(): File? {
        if (!audioPacketCaptureEnabled) return null
        return File(filesDir, AUDIO_CAPTURE_DIRECTORY)
    }

    private fun scheduleDisplaySize(width: Int, height: Int) {
        if (width <= 0 || height <= 0 || shuttingDown.get()) return
        val size = DisplaySize(width, height)
        if (size == activeDisplaySize || size == pendingDisplaySize) return
        pendingDisplaySize = size
        mainHandler.removeCallbacks(applyDisplaySize)
        mainHandler.postDelayed(applyDisplaySize, DISPLAY_CHANGE_DEBOUNCE_MILLIS)
    }

    private fun applyDisplaySize(size: DisplaySize) {
        if (shuttingDown.get() || size == activeDisplaySize) return
        val previous = activeDisplaySize
        activeDisplaySize = size
        recordDetectedMaximum(size)
        updateResolutionMenu()
        if (previous == null) {
            appendLog("Display detected: ${size.width}x${size.height}")
            maybeStartCarPlay()
        } else if (menuOpen || handshakeResetInProgress) {
            appendLog(
                "Display updated while handshake is reset: " +
                    "${previous.width}x${previous.height} -> ${size.width}x${size.height}",
            )
        } else if (!mainWebDisplay.enabled) {
            restartCarPlay(
                "Display changed ${previous.width}x${previous.height} -> ${size.width}x${size.height}",
            )
        }
    }

    private fun recordDetectedMaximum(size: DisplaySize) {
        val width = maxOf(maximumDetectedWidthPixels, size.width)
        val height = maxOf(maximumDetectedHeightPixels, size.height)
        if (width == maximumDetectedWidthPixels && height == maximumDetectedHeightPixels) return
        maximumDetectedWidthPixels = width
        maximumDetectedHeightPixels = height
        AirPlayPersistence.saveMaximumDetectedDisplay(this, width, height)
    }

    private fun hs5InstrumentEnabled(): Boolean = hs5 &&
        Hs5ProductServices.featureAllowed(this, com.shilapi.xcertplay.licensing.LicenseFeatures.INSTRUMENT_MAP)

    internal fun reconnectWithCurrentPermissions() {
        connectFromHome()
        if (controller != null) restartCarPlay("按用户要求应用新权限和授权，重新连接")
    }

    private fun connectFromHome() {
        if (!setup.readyToConnect()) { setConnectionStage("认证尚未准备完成，请先完成首次引导检查"); return }
        microphoneAvailable = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        microphonePermissionResolved = true
        locationPermissionAvailable = hasFineLocationPermission()
        locationReportingEnabled = locationPermissionAvailable && AirPlayPersistence.loadLocationReportingEnabled(this)
        cancelBluetoothModeConfirmation()
        val retryFailedController = controller != null && handshakeTimeline?.failure != null
        connectionRequested = true
        handshakeTimeline = HandshakeTimeline(wirelessEnabled, System.currentTimeMillis(), lastAttemptFailure)
        handshakePanel?.bind(handshakeTimeline)
        homeView?.bind(handshakeTimeline)
        bluetoothDiscoverabilityReady = false
        wirelessRetryPolicy.reset()
        connectionPaused = false
        if (handshakeResetInProgress) startAfterHandshakeReset = true
        if (retryFailedController) {
            restartCarPlay("手动重试连接")
        }
        setConnectionStage("正在准备连接 iPhone")
        requestStartupPrerequisites()
    }

    private fun cancelConnectionAttempt() {
        if (shuttingDown.get() || menuOpen) return
        cancelBluetoothModeConfirmation()
        connectionRequested = false
        bluetoothDiscoverabilityReady = false
        connectionPaused = true
        pendingManagementRecovery = null
        reconnectScheduled = false
        startAfterHandshakeReset = false
        handshakeResetInProgress = true
        showConnectionDetails = false
        val generation = ++restartGeneration
        val oldController = controller
        val oldSink = sink
        CarPlayBackgroundSession.clear(oldController)
        controller = null
        sink = null
        activeAirPlaySession = null
        activeScreenStreamTypes.clear()
        // The details panel keeps the previous attempt for inspection after cancellation.
        handshakeTimeline?.fail("连接已取消", "用户取消了本次连接", System.currentTimeMillis())
        handshakePanel?.notifyChanged()
        handshakeTimeline = null
        setConnectionStage("已取消连接")
        appendLog("Connection attempt cancelled by user")
        teardownExecutor.execute {
            try {
                oldController?.close()
                oldController?.awaitClosed(CONTROLLER_CLOSE_TIMEOUT_MILLIS)
            } finally {
                try { oldSink?.close() } finally {
                    runOnUiThread {
                        if (!shuttingDown.get() && generation == restartGeneration) {
                            handshakeResetInProgress = false
                            if (!connectionPaused) {
                                startAfterHandshakeReset = false
                                maybeStartCarPlay()
                            }
                        }
                    }
                }
            }
        }
    }

    private fun maybeStartCarPlay() {
        if (connectionPaused) return
        if (controller == null && adoptBackgroundSession()) return
        if (!connectionRequested) return
        val size = activeDisplaySize ?: return
        val transportReady = if (wirelessEnabled) wirelessPermissionsReady else vpnReady
        val locationReady = !locationReportingEnabled || locationPermissionAvailable
        if (
            !transportReady ||
            (wirelessEnabled && !bluetoothDiscoverabilityReady) ||
            !locationReady ||
            !microphonePermissionResolved ||
            shuttingDown.get() ||
            menuOpen ||
            handshakeResetInProgress ||
            controller != null
        ) {
            return
        }
        startCarPlay(size)
    }

    private fun recoverConnection(reason: String, failure: CarPlayStatus.Failed? = null) {
        if (!wirelessEnabled) {
            reconnectAfterLoss(reason)
            return
        }
        val retry = wirelessRetryPolicy.next(failure?.radioRecovery == true,
            failure?.frequencyMHz, failure?.retryable != false)
        if (retry == null) {
            connectionPaused = true
            reconnectScheduled = false
            setConnectionStage("$reason；自动重试已停止，请点击打开 CarPlay 重试")
            appendLog("wireless recovery stopped attempts=${wirelessRetryPolicy.failures}")
            return
        }
        val radio = if (failure?.radioRecovery == true) {
            if (android.os.Build.VERSION.SDK_INT >= 29) "，重新选择无线信道" else "，由车机系统重新建立无线网络"
        } else ""
        setConnectionStage("$reason；${retry.delayMillis / 1000} 秒后第 ${retry.attempt}/3 次尝试$radio")
        appendLog("wireless recovery attempt=${retry.attempt}/3 radioAttempt=${retry.radioAttempt}")
        reconnectAfterLoss(reason, retry.delayMillis)
    }

    private fun reconnectAfterLoss(reason: String, retryDelayMillis: Long? = null) {
        if (!connectionRequested || isDestroyed || connectionPaused || shuttingDown.get() || handshakeResetInProgress) return
        if (menuOpen) { pendingManagementRecovery = reason to retryDelayMillis; return }
        if (reconnectScheduled) return
        reconnectScheduled = true
        val generation = restartGeneration
        val delayMillis = retryDelayMillis ?: if (reason.contains("AirPlay iAP tunnel", ignoreCase = true)) {
            IAP_TUNNEL_RECONNECT_DELAY_MILLIS
        } else {
            RECONNECT_DELAY_MILLIS
        }
        appendLog("$reason; retrying in ${delayMillis}ms")
        mainHandler.postDelayed(
            {
                reconnectScheduled = false
                if (
                    !connectionRequested || connectionPaused || isDestroyed || shuttingDown.get() ||
                    handshakeResetInProgress ||
                    generation != restartGeneration
                ) {
                    return@postDelayed
                }
                if (menuOpen) { pendingManagementRecovery = reason to 0L; return@postDelayed }
                restartCarPlay("Reconnecting after $reason")
            },
            delayMillis,
        )
    }

    /** Full-stack fallback when an AirPlay-only reconnect is unavailable. */
    private fun restartCarPlay(reason: String) {
        if (!connectionRequested || isDestroyed || connectionPaused || shuttingDown.get() || menuOpen || handshakeResetInProgress) return
        val size = activeDisplaySize ?: return
        appendLog(reason)
        activeScreenStreamTypes.clear()
        setConnectionStage(reason)
        Log.i(TAG, "$reason; rebuilding stack at ${size.width}x${size.height}")
        val generation = ++restartGeneration
        val oldController = controller
        val oldSink = sink
        CarPlayBackgroundSession.clear(oldController)
        controller = null
        sink = null
        teardownExecutor.execute {
            oldController?.close()
            oldController?.awaitClosed(CONTROLLER_CLOSE_TIMEOUT_MILLIS)
            oldSink?.close()
            runOnUiThread {
                if (!shuttingDown.get() && generation == restartGeneration) maybeStartCarPlay()
            }
        }
    }

    private fun openSettingsMenu() {
        if (menuOpen || shuttingDown.get()) return
        releaseTouch()
        menuOpen = true
        setup.managementOpen(true)
        settingsMenu?.visibility = View.VISIBLE
        setup.refresh()
        updateDebugOverlays()
    }

    private fun closeManagement() {
        if (!menuOpen) return
        menuOpen = false
        setup.managementOpen(false)
        settingsMenu?.visibility = View.GONE
        setup.refresh()
        updateDebugOverlays()
        val pending = pendingManagementRecovery
        pendingManagementRecovery = null
        if (pending != null) reconnectAfterLoss(pending.first, pending.second)
        else if (connectionRequested && !connectionPaused) requestStartupPrerequisites()
    }

    private fun openLegacySettingsMenu() {
        if (menuOpen || shuttingDown.get()) return
        cancelBluetoothModeConfirmation()
        showConnectionDetails = false
        stopMicrophoneGainTest()
        settingsBaseline = captureSettingsBaseline()
        menuOpen = true
        handshakeResetInProgress = true
        startAfterHandshakeReset = false
        hotspotStatus = HotspotStatus(state = if (wirelessEnabled) "stopped" else "off")
        updateHotspotStatusBlock()
        val generation = ++restartGeneration
        releaseTouch()
        val oldController = controller
        val oldSink = sink
        CarPlayBackgroundSession.clear(oldController)
        controller = null
        sink = null
        activeScreenStreamTypes.clear()
        setConnectionStage(getString(R.string.hs5_reconnecting_after_settings))
        gestureOverlay?.visibility = View.GONE
        settingsMenu?.visibility = View.VISIBLE
        webDisplayRefresh.forEach { it() }
        syncMainMediaAudioBufferControls()
        syncMicrophoneGainControls()
        microphoneTestButton?.isEnabled = false
        updateDebugOverlays()
        clearScreenLogs()
        appendLog("Settings opened; CarPlay handshake reset")
        updateResolutionMenu()
        teardownExecutor.execute {
            try {
                oldController?.close()
                oldController?.awaitClosed(CONTROLLER_CLOSE_TIMEOUT_MILLIS)
            } finally {
                try {
                    oldSink?.close()
                } finally {
                    runOnUiThread {
                        if (shuttingDown.get() || generation != restartGeneration) {
                            return@runOnUiThread
                        }
                        handshakeResetInProgress = false
                        microphoneTestButton?.isEnabled = menuOpen
                        if (!menuOpen && startAfterHandshakeReset) {
                            startAfterHandshakeReset = false
                            maybeStartCarPlay()
                        }
                    }
                }
            }
        }
    }

    private fun saveSettingsAndReconnect() {
        if (!menuOpen) return
        if (!validateMfiSettings()) { (settingsMenu as? Hs5SettingsView)?.selectPage(6); return }
        if (!validateWebDisplaySettings()) { (settingsMenu as? Hs5SettingsView)?.selectPage(1); return }
        connectionPaused = false
        connectionRequested = true
        persistMenuSettings()
        settingsBaseline = null
        finishSettingsMenu("Settings saved")
    }

    /** Validate only the selected MFi identity source before persisting settings. */
    private fun validateMfiSettings(): Boolean {
        val error = when {
            mfiTarget == MfiTarget.I2C && mfiI2cPath.isBlank() ->
                getString(R.string.hs5_i2c_device_path_is_required)
            mfiTarget == MfiTarget.REMOTE && remoteMfiServer.isBlank() ->
                getString(R.string.hs5_remote_server_address_is_required)
            mfiTarget == MfiTarget.REMOTE &&
                !remoteMfiServer.trim().startsWith("http://") &&
                !remoteMfiServer.trim().startsWith("https://") ->
                getString(R.string.hs5_remote_server_address_must_start_with_http_or_https)
            mfiTarget == MfiTarget.LOCAL_FILES && localMfiCertificateUri.isBlank() ->
                getString(R.string.hs5_select_a_local_certificate)
            mfiTarget == MfiTarget.LOCAL_FILES && localMfiPrivateKeyUri.isBlank() ->
                getString(R.string.hs5_select_a_local_private_key)
            '\u0000' in mfiI2cPath -> getString(R.string.hs5_i2c_device_path_contains_u_0000)
            '\u0000' in remoteMfiServer -> getString(R.string.hs5_remote_server_address_contains_u_0000)
            '\u0000' in remoteMfiToken -> getString(R.string.hs5_remote_token_contains_u_0000)
            '\u0000' in localMfiCertificateUri -> getString(R.string.hs5_local_certificate_uri_contains_u_0000)
            '\u0000' in localMfiPrivateKeyUri -> getString(R.string.hs5_local_private_key_uri_contains_u_0000)
            else -> null
        }
        mfiErrorView?.text = error.orEmpty()
        mfiErrorView?.visibility = if (error == null) View.GONE else View.VISIBLE
        return error == null
    }

    private fun cancelSettingsEdits() {
        if (!menuOpen) return
        restoreSettingsBaseline()
        finishSettingsMenu("Settings changes discarded")
    }

    private fun finishSettingsMenu(prefix: String) {
        if (!menuOpen) return
        stopMicrophoneGainTest()
        menuOpen = false
        settingsMenu?.visibility = View.GONE
        gestureOverlay?.visibility = View.VISIBLE
        updateWebDisplayPreviews()
        updateDebugOverlays()
        clearScreenLogs()
        appendLog(
            "$prefix; starting a fresh handshake at " +
                "${CarPlayDisplayScale.label(displayScaleTenths)} with " +
                (if (hevcEnabled) "HEVC (H.265)" else "H.264") +
                ", MFI ${mfiTargetLabel(mfiTarget)}" +
                ", Wi-Fi session Wi-Fi Direct",
        )
        if (handshakeResetInProgress) {
            startAfterHandshakeReset = true
        }
        requestStartupPrerequisites()
    }

    private fun exitApplication() {
        if (shuttingDown.get()) return
        restoreSettingsBaseline()
        finishAndRemoveTask()
        shutdown(terminateProcess = true, reason = "settings exit application")
    }

    private fun shutdown(terminateProcess: Boolean, reason: String) {
        if (!shuttingDown.compareAndSet(false, true)) return
        cancelBluetoothModeConfirmation()
        connectionRequested = false
        stopMicrophoneGainTest()
        restartGeneration += 1
        mainHandler.removeCallbacks(applyDisplaySize)
        val oldController = controller
        val oldSink = sink
        CarPlayBackgroundSession.clear(oldController)
        controller = null
        sink = null
        Log.i(TAG, "shutdown reason=$reason terminateProcess=$terminateProcess")
        teardownExecutor.execute {
            oldController?.close()
            val clean = oldController?.awaitClosed(CONTROLLER_CLOSE_TIMEOUT_MILLIS) ?: true
            oldSink?.close()
            airPlayCommandExecutor.shutdown()
            if (terminateProcess) {
                applicationContext.stopService(Intent(applicationContext, CarPlayVpnService::class.java))
            }
            sessionLog.append("CarPlay stopped; clean=$clean")
            sessionLog.close()
            Log.i(TAG, "shutdown complete clean=$clean")
            teardownExecutor.shutdown()
            if (terminateProcess) Process.killProcess(Process.myPid())
        }
    }

    private fun attachSurface(surface: Surface) = attachDisplaySurface(SCREEN_TYPE_MAIN, surface)

    private fun attachDisplaySurface(type: Int, surface: Surface) {
        if (type == SCREEN_TYPE_ALT && hs5InstrumentEnabled()) return
        val outputs = CarPlayWebDisplayFactory.find(sink)
        if (outputs?.owns(type) == true) outputs.preview(type, surface) else sink?.setSurface(type, surface)
    }

    private fun detachSurface(type: Int, surface: Surface) {
        val outputs = CarPlayWebDisplayFactory.find(sink)
        if (outputs?.owns(type) == true) outputs.preview(type, null) else sink?.clearSurface(type, surface)
    }

    private fun createMainVideoView(): View = if (mainWebDisplay.enabled) {
        TextureView(this).apply { isOpaque = false; surfaceTextureListener = textureListener }
    } else {
        VideoSurfaceView(this, onSurface = { next ->
            currentSurface?.let { if (it !== next) detachSurface(SCREEN_TYPE_MAIN, it) }
            currentSurface = next
            next?.let(::attachSurface)
            appendLog(if (next != null) "Video surface created" else "Video surface destroyed")
        }, onSizeChanged = ::scheduleDisplaySize)
    }

    private fun releaseMainVideoView(view: View) {
        (view as? VideoSurfaceView)?.close()
        if (view is TextureView) {
            // Revoke callbacks before a replacement can attach its Surface. TextureView still
            // owns its SurfaceTexture; only our wrapper Surface is explicitly released here.
            view.surfaceTextureListener = null
            currentSurface?.let { surface ->
                detachSurface(SCREEN_TYPE_MAIN, surface)
                surface.release()
            }
        }
        currentSurface = null
        currentSurfaceTexture = null
    }

    private fun updateMainVideoView() {
        val previous = videoView ?: return
        if ((previous is TextureView) == mainWebDisplay.enabled) return
        val parent = previous.parent as? android.view.ViewGroup ?: return
        val index = parent.indexOfChild(previous)
        val params = previous.layoutParams
        releaseTouch()
        releaseMainVideoView(previous)
        parent.removeView(previous)
        val next = createMainVideoView()
        videoView = next
        parent.addView(next, index, params)
    }

    private fun updateWebDisplayPreviews() {
        updateMainVideoView()
        val view = videoView
        view?.visibility = if (!mainWebDisplay.enabled || mainWebDisplay.preview) View.VISIBLE else View.INVISIBLE
        val matrix = android.graphics.Matrix()
        if (view != null && view.width > 0 && view.height > 0 && mainWebDisplay.enabled) {
            val rect = CarPlayTouchMapper.contentRect(view.width, view.height, mainWebDisplay.width, mainWebDisplay.height)
            matrix.setScale((rect[2] / view.width).toFloat(), (rect[3] / view.height).toFloat(), view.width / 2f, view.height / 2f)
        }
        (view as? TextureView)?.setTransform(matrix)
        clusterPreview?.let { cluster ->
            cluster.visibility = if (!(hs5InstrumentEnabled()) && clusterWebDisplay.enabled && clusterWebDisplay.preview) View.VISIBLE else View.GONE
            val root = contentRoot
            if (root != null && root.width > 0 && root.height > 0) {
                val scale = minOf(root.width.toDouble() / clusterWebDisplay.width, root.height * 0.35 / clusterWebDisplay.height)
                val params = cluster.layoutParams
                val width = (clusterWebDisplay.width * scale).toInt().coerceAtLeast(1)
                val height = (clusterWebDisplay.height * scale).toInt().coerceAtLeast(1)
                if (params.width != width || params.height != height) { params.width = width; params.height = height; cluster.layoutParams = params }
            }
        }
        currentSurface?.let { webDisplays?.preview(SCREEN_TYPE_MAIN, it) }
        clusterPreviewSurface?.let { webDisplays?.preview(SCREEN_TYPE_ALT, it) }
    }

    // This is the Android Activity callback; AndroidX marks its internal dispatch bridge restricted.
    @android.annotation.SuppressLint("RestrictedApi")
    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (!menuOpen && SteeringWheelControls.enabled(this) && CarPlayRemoteKeys.dispatch(event, controller)) return true
        return super.dispatchKeyEvent(event)
    }

    private fun releaseTouch() {
        controller?.sendTouch(emptyList())
        touchMapper.clear()
    }

    private fun onHostTouch(view: View, event: MotionEvent): Boolean {
        if (menuOpen) return true
        if (hongqi.touch(event)) { releaseTouch(); return true }

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gestureSequenceActive = false
                gestureTracking = false
                edgeSettingsGestureCaptured = moreGesturesToSettings &&
                    event.x in 0f..(view.width / 8f) &&
                    event.y in 0f..(view.height / 4f)
                edgeSettingsGestureEligible = edgeSettingsGestureCaptured
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.pointerCount == THREE_FINGER_COUNT && !gestureSequenceActive) {
                    edgeSettingsGestureCaptured = false
                    edgeSettingsGestureEligible = false
                    gestureSequenceActive = true
                    gestureTracking = true
                    gestureStartX = pointerCentroid(event, horizontal = true)
                    gestureStartY = pointerCentroid(event, horizontal = false)
                    releaseTouch()
                    appendLog("Three-finger swipe tracking started")
                    return true
                }
            }
        }

        if (edgeSettingsGestureCaptured) {
            when (event.actionMasked) {
                MotionEvent.ACTION_POINTER_DOWN -> edgeSettingsGestureEligible = false
                MotionEvent.ACTION_MOVE -> {
                    if (event.pointerCount != 1 || event.x !in 0f..(view.width / 8f)) {
                        edgeSettingsGestureEligible = false
                    }
                }
                MotionEvent.ACTION_UP -> {
                    val openSettings = edgeSettingsGestureEligible &&
                        event.x in 0f..(view.width / 8f) &&
                        event.y in (view.height * 3f / 4f)..view.height.toFloat()
                    edgeSettingsGestureCaptured = false
                    edgeSettingsGestureEligible = false
                    if (openSettings) openSettingsMenu()
                }
                MotionEvent.ACTION_CANCEL -> {
                    edgeSettingsGestureCaptured = false
                    edgeSettingsGestureEligible = false
                }
            }
            return true
        }

        if (gestureSequenceActive) {
            if (!gestureTracking || event.pointerCount != THREE_FINGER_COUNT) {
                if (event.actionMasked == MotionEvent.ACTION_UP ||
                    event.actionMasked == MotionEvent.ACTION_CANCEL
                ) {
                    gestureSequenceActive = false
                    gestureTracking = false
                } else if (event.actionMasked == MotionEvent.ACTION_POINTER_UP) {
                    gestureTracking = false
                }
                return true
            }
            if (event.actionMasked == MotionEvent.ACTION_MOVE) {
                val deltaX = Math.abs(pointerCentroid(event, horizontal = true) - gestureStartX)
                val deltaY = pointerCentroid(event, horizontal = false) - gestureStartY
                if (
                    deltaY >= dp(THREE_FINGER_SWIPE_DISTANCE_DP) &&
                    deltaY >= deltaX * THREE_FINGER_SWIPE_DIRECTION_RATIO
                ) {
                    gestureSequenceActive = false
                    gestureTracking = false
                    openSettingsMenu()
                    return true
                }
            }
            return true
        }

        if (mainWebDisplay.enabled && !mainWebDisplay.preview) return true
        val contacts = touchMapper.contacts(event, view.width, view.height,
            if (mainWebDisplay.enabled) mainWebDisplay.width else view.width,
            if (mainWebDisplay.enabled) mainWebDisplay.height else view.height)
        val queued = controller?.sendTouch(contacts) ?: false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN,
            MotionEvent.ACTION_POINTER_DOWN,
            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_POINTER_UP,
            MotionEvent.ACTION_CANCEL -> Log.i(
                TAG,
                "touch action=${MotionEvent.actionToString(event.actionMasked)} " +
                    "pointers=${event.pointerCount} queued=$queued",
            )
        }
        return true
    }

    private fun pointerCentroid(event: MotionEvent, horizontal: Boolean): Float {
        var total = 0f
        for (index in 0 until event.pointerCount) {
            total += if (horizontal) event.getX(index) else event.getY(index)
        }
        return total / event.pointerCount
    }

    private fun onScreenStreamStateChanged(generation: Int, type: Int, active: Boolean) {
        runOnUiThread {
            if (shuttingDown.get() || generation != restartGeneration) return@runOnUiThread
            if (active) {
                activeScreenStreamTypes.add(type)
            } else {
                activeScreenStreamTypes.remove(type)
            }
            if (!isDestroyed) hongqi.screenState(type, active)
            setup.connectionState(connectionMessage, connectionRequested && !connectionPaused, SCREEN_TYPE_MAIN in activeScreenStreamTypes)
            updateDebugOverlays()
        }
    }

    /** Retire this controller's UI callbacks immediately; cleanup and the next stack run later. */
    private fun endConnectionPresentation() {
        restartGeneration++
        activeAirPlaySession = null
        activeScreenStreamTypes.clear()
        hongqi.screenState(SCREEN_TYPE_MAIN, false)
        hongqi.screenState(SCREEN_TYPE_ALT, false)
    }

    private fun setStatus(message: String) {
        runOnUiThread {
            setConnectionStage(message)
            appendLog(message)
        }
    }

    private var connectionMessage = "点击连接以开始 CarPlay"
    private fun setConnectionStage(message: String) {
        connectionMessage = message
        setup.connectionState(message, connectionRequested && !connectionPaused, SCREEN_TYPE_MAIN in activeScreenStreamTypes)
        handshakePanel?.setStatus(message)
        homeView?.bind(handshakeTimeline)
        homeView?.setStatus(message)
        updateDebugOverlays()
    }

    private fun updateDebugOverlays() {
        val showLogs = debugLogsEnabled && !menuOpen
        statusScrollView?.visibility = if (showLogs) View.VISIBLE else View.GONE
        disconnectedSettingsButton?.visibility =
            if (!menuOpen && SCREEN_TYPE_MAIN !in activeScreenStreamTypes &&
                (showConnectionDetails || debugLogsEnabled)
            ) View.VISIBLE else View.GONE
        val showPanel = !debugLogsEnabled && !menuOpen && setup.onboarding.visibility != View.VISIBLE && SCREEN_TYPE_MAIN !in activeScreenStreamTypes
        handshakePanel?.visibility = if (showPanel && showConnectionDetails) View.VISIBLE else View.GONE
        homeView?.visibility = if (showPanel && !showConnectionDetails) View.VISIBLE else View.GONE
        updateMediaMetricsOverlay()
    }

    private fun recordHandshake(controllerGeneration: Int, message: String, atMillis: Long) {
        if (controllerGeneration != restartGeneration) return
        val timeline = handshakeTimeline ?: return
        if (timeline.accept(message, atMillis)) {
            handshakePanel?.notifyChanged()
            homeView?.bind(timeline)
        }
    }

    private fun failHandshake(title: String, detail: String) {
        val timeline = handshakeTimeline ?: return
        timeline.fail(title, detail, System.currentTimeMillis())
        lastAttemptFailure = timeline.failure?.let { "${it.title}: ${it.detail}" }
        handshakePanel?.notifyChanged()
        homeView?.bind(timeline)
    }

    private fun updateMediaMetricsOverlay() {
        val root = contentRoot ?: return
        if (!mediaMetricsEnabled) {
            sink?.setMediaMetricsMonitor(null)
            mediaMetricsOverlay?.let(root::removeView)
            mediaMetricsOverlay = null
            mediaMetricsMonitor = null
            return
        }
        val monitor = mediaMetricsMonitor ?: MediaMetricsMonitor().also {
            mediaMetricsMonitor = it
        }
        sink?.setMediaMetricsMonitor(monitor)
        // The frame-rate axis follows the configured target, which the settings menu can change
        // while the overlay stays alive.
        val overlay = mediaMetricsOverlay ?: MediaMetricsOverlayView(
            this,
            monitor,
            fpsAxisMax = { fps.toFloat() },
        ).also {
            mediaMetricsOverlay = it
            val settingsIndex = root.indexOfChild(settingsMenu)
            root.addView(
                it,
                if (settingsIndex >= 0) settingsIndex else root.childCount,
                mediaMetricsOverlayLayoutParams(root.width, root.height),
            )
        }
        overlay.visibility = if (!menuOpen && !safeAreaEditorActive) View.VISIBLE else View.GONE
        updateMediaMetricsOverlayLayout(root.width, root.height)
    }

    private fun updateMediaMetricsOverlayLayout(screenWidth: Int, screenHeight: Int) {
        val overlay = mediaMetricsOverlay ?: return
        val desired = mediaMetricsOverlayLayoutParams(screenWidth, screenHeight)
        val current = overlay.layoutParams
        if (current.width != desired.width || current.height != desired.height) {
            overlay.layoutParams = desired
        }
    }

    private fun mediaMetricsOverlayLayoutParams(
        screenWidth: Int,
        screenHeight: Int,
    ): FrameLayout.LayoutParams {
        val fallback = resources.displayMetrics
        val panelWidth = (screenWidth.takeIf { it > 0 } ?: fallback.widthPixels) / 3
        val panelHeight = (screenHeight.takeIf { it > 0 } ?: fallback.heightPixels) / 3
        return FrameLayout.LayoutParams(panelWidth, panelHeight, Gravity.TOP or Gravity.START)
    }

    private fun appendLog(message: String) {
        val now = System.currentTimeMillis()
        appendFileLog(message, now)
        if (debugLogsEnabled && !menuOpen) appendScreenLog(now, message)
    }

    private fun appendScreenLog(timestampMillis: Long, message: String) {
        val summary = ScreenLogPolicy.summary(message) ?: return
        logLines.add(timestampMillis, formattedLogLine(summary, timestampMillis))
        if (!logRenderScheduled) {
            logRenderScheduled = true
            mainHandler.postDelayed(renderLogLines, LOG_RENDER_INTERVAL_MILLIS)
        }
    }

    private fun appendFileLog(message: String, timestampMillis: Long) =
        sessionLog.appendTimestamped(message, timestampMillis)

    private fun formattedLogLine(message: String, nowMillis: Long): String =
        "${SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(nowMillis))}  $message"

    private fun initializeSessionLog() {
        val baseDirectory = getExternalFilesDir(null) ?: filesDir
        val logFile = File(File(baseDirectory, "logs"), "xcertplay.log")
        sessionLog.start(
            logFile,
            "xcertplay log started " +
                "${SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())} " +
                "pid=${Process.myPid()} path=${logFile.absolutePath}",
            onError = { Log.e(TAG, it) },
        )
    }

    private fun refreshLogView(nowMillis: Long) {
        if (!debugLogsEnabled || menuOpen) return
        val cutoff = nowMillis - LOG_RETENTION_MILLIS
        logLines.expireBefore(cutoff)
        statusView?.text = logLines.renderedText()
        scrollLogsToBottom()

        mainHandler.removeCallbacks(expireOldLogLines)
        logLines.firstTimestampMillis?.let { oldest ->
            val delay = (oldest + LOG_RETENTION_MILLIS - nowMillis + 1L)
                .coerceAtLeast(1L)
            mainHandler.postDelayed(expireOldLogLines, delay)
        }
    }

    private fun clearScreenLogs() {
        synchronized(pendingScreenLogsLock) {
            pendingScreenLogs.clear()
            screenDrainPosted = false
        }
        mainHandler.removeCallbacks(drainScreenLogs)
        logLines.clear()
        mainHandler.removeCallbacks(expireOldLogLines)
        mainHandler.removeCallbacks(renderLogLines)
        logRenderScheduled = false
        statusView?.text = ""
    }

    private fun scrollLogsToBottom() {
        statusScrollView?.post {
            statusScrollView?.fullScroll(View.FOCUS_DOWN)
        }
    }

    private fun applyFullscreenMode() {
        val hideTop = hideTopBar
        val hideBottom = hideBottomBar
        WindowCompat.setDecorFitsSystemWindows(window, !(hideTop && hideBottom))
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        if (hideTop) {
            controller.hide(WindowInsetsCompat.Type.statusBars())
        } else {
            controller.show(WindowInsetsCompat.Type.statusBars())
        }
        if (hideBottom) {
            controller.hide(WindowInsetsCompat.Type.navigationBars())
        } else {
            controller.show(WindowInsetsCompat.Type.navigationBars())
        }
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun CarPlayStatus.describe(): String = when (this) {
        CarPlayStatus.DiscoveringMfi -> "准备接收端认证"
        CarPlayStatus.WaitingForMfi -> "等待认证设备"
        CarPlayStatus.RequestingMfiPermission -> "等待认证设备 USB 授权"
        CarPlayStatus.MfiReady -> "认证已就绪"
        CarPlayStatus.StartingHotspot -> "正在开启无线热点"
        is CarPlayStatus.HotspotReady ->
            "Hotspot ready: $backend, $ssid, $band, " +
                "channel ${if (channel == 0) "auto" else channel}"
        CarPlayStatus.WaitingForPairedIphone -> getString(R.string.hs5_waiting_for_paired_iphone)
        CarPlayStatus.ConnectingBluetooth -> getString(R.string.hs5_connecting_bluetooth)
        CarPlayStatus.RunningWireless -> "无线 CarPlay 控制链路已启动"
        CarPlayStatus.WirelessActive -> "无线 CarPlay 已连接"
        is CarPlayStatus.WirelessConnecting -> stage.label
        CarPlayStatus.DiscoveringIphone -> getString(R.string.hs5_discovering_iphone)
        CarPlayStatus.WaitingForIphone -> "等待 USB 连接的 iPhone"
        CarPlayStatus.RequestingIphonePermission -> "等待 iPhone USB 授权"
        CarPlayStatus.WaitingForReenumeration -> getString(R.string.hs5_waiting_for_iphone_re_enumeration)
        CarPlayStatus.SelectingConfiguration -> getString(R.string.hs5_selecting_carplay_configuration)
        CarPlayStatus.OpeningDataPaths -> getString(R.string.hs5_opening_usb_data_paths)
        CarPlayStatus.Pairing -> getString(R.string.hs5_pairing_with_iphone)
        CarPlayStatus.ConnectingControl -> getString(R.string.hs5_connecting_iap2_control)
        CarPlayStatus.AttachingNetwork ->
            if (wirelessEnabled) getString(R.string.hs5_starting_airplay_service) else getString(R.string.hs5_attaching_ncm_airplay_network)
        CarPlayStatus.RunningControl -> getString(R.string.hs5_carplay_control_running)
        CarPlayStatus.ControlEnded -> getString(R.string.hs5_carplay_control_window_ended)
        is CarPlayStatus.Failed -> "连接失败：${message}"
    }

    private companion object {
        const val TAG = "xcertplay-usb"
        const val SCREEN_TYPE_MAIN = 110
        const val SCREEN_TYPE_ALT = 111
        const val LOG_RETENTION_MILLIS = 5 * 60_000L
        const val LOG_RENDER_INTERVAL_MILLIS = 100L
        const val MAX_SCREEN_LOG_LINES = 100
        const val DISPLAY_CHANGE_DEBOUNCE_MILLIS = 500L
        const val RECONNECT_DELAY_MILLIS = 2_000L
        const val IAP_TUNNEL_RECONNECT_DELAY_MILLIS = 15_000L
        const val CONTROLLER_CLOSE_TIMEOUT_MILLIS = 4_000L
        const val AUDIO_CAPTURE_DIRECTORY = "audio-captures"
        const val THREE_FINGER_COUNT = 3
        const val THREE_FINGER_SWIPE_DISTANCE_DP = 72
        const val THREE_FINGER_SWIPE_DIRECTION_RATIO = 1.15f
        const val MAX_SETTINGS_MENU_WIDTH_PX = 1200
        const val MENU_CORNER_DP = 22
        const val MENU_BUTTON_CORNER_DP = 14
        val NO_VIDEO_BACKGROUND = Color.BLACK
    }

    private data class DisplaySize(val width: Int, val height: Int)
    private data class PendingLog(
        val generation: Int,
        val timestampMillis: Long,
        val message: String,
    )
    private data class HotspotStatus(
        val state: String,
        val ssid: String? = null,
        val band: String? = null,
        val channel: Int? = null,
        val backend: String? = null,
    )
}

/** Process-local hand-off for keeping the CarPlay session alive while no Activity is visible. */
private object CarPlayBackgroundSession {
    val log = SessionLog()
    private var audioFocusSession: AndroidMediaSink.AudioFocusSession? = null

    @Synchronized
    fun audioFocus(context: android.content.Context): AndroidMediaSink.AudioFocusSession =
        audioFocusSession ?: AndroidMediaSink.createAudioFocus(context).also { audioFocusSession = it }

    data class Snapshot(
        val controller: CarPlayController,
        val sink: AndroidMediaSink,
        val width: Int,
        val height: Int,
        val handshakeTimeline: HandshakeTimeline,
        val activeScreenStreamTypes: MutableSet<Int>,
    )

    private var controller: CarPlayController? = null
    private var sink: AndroidMediaSink? = null
    private var width = 0
    private var height = 0
    private var handshakeTimeline: HandshakeTimeline? = null
    private var activeScreenStreamTypes = mutableSetOf<Int>()

    @Synchronized
    fun snapshot(): Snapshot? {
        val currentController = controller ?: return null
        val currentSink = sink ?: return null
        val timeline = handshakeTimeline ?: return null
        return Snapshot(currentController, currentSink, width, height, timeline, activeScreenStreamTypes)
    }

    @Synchronized
    fun store(
        controller: CarPlayController,
        sink: AndroidMediaSink,
        width: Int,
        height: Int,
        handshakeTimeline: HandshakeTimeline,
        activeScreenStreamTypes: MutableSet<Int>,
    ) {
        this.controller = controller
        this.sink = sink
        this.width = width
        this.height = height
        this.handshakeTimeline = handshakeTimeline
        this.activeScreenStreamTypes = activeScreenStreamTypes
    }

    @Synchronized
    fun clear(expected: CarPlayController? = null) {
        if (expected != null && controller !== expected) return
        controller?.let(HongqiWheelControls::detach)
        controller = null
        sink = null
        width = 0
        height = 0
        handshakeTimeline = null
        activeScreenStreamTypes = mutableSetOf()
    }
}
