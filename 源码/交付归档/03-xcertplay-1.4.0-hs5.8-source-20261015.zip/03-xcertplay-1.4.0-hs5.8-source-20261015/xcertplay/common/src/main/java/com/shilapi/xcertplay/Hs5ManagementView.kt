// SPDX-License-Identifier: AGPL-3.0-only
package com.shilapi.xcertplay

import android.content.Context
import android.content.res.ColorStateList
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch

/** User-facing management deliberately exposes no video, audio or HS5 tuning parameters. */
internal class Hs5ManagementView(
    context: Context,
    private val callbacks: Hs5ManagementCallbacks,
) : LinearLayout(context) {
    private var snapshot: Hs5ManagementSnapshot? = null

    fun bind(value: Hs5ManagementSnapshot) {
        if (snapshot == value) return
        snapshot = value
        removeAllViews()
        orientation = VERTICAL
        tag = "hs5_management_root"
        val colors = FawUiTheme.palette(context)
        setBackgroundColor(colors.background)
        setPadding(Hs5Ui.dp(context, 12), Hs5Ui.dp(context, 10), Hs5Ui.dp(context, 12), Hs5Ui.dp(context, 10))
        val header = Hs5SetupUi.header(context, "管理")
        header.addView(Hs5Ui.button(context, "返回首页", action = callbacks.onBack).apply {
            tag = "hs5_management_back"
        }, LayoutParams(Hs5Ui.dp(context, 100), -1))
        addView(header, LayoutParams(-1, Hs5Ui.dp(context, 48)))
        val content = Hs5Ui.column(context)
        card(content, "权限与准备", 6) {
            Hs5SetupUi.description(this, "连接期间更改权限或绑定授权，部分功能在下次连接时生效。")
            if (value.sessionActive) {
                Hs5SetupUi.action(this, "断开并重新连接", "hs5_reconnect", action = callbacks.onReconnect).apply {
                    isFocusable = true
                    contentDescription = "断开并重新连接 CarPlay，应用新的权限和授权"
                }
            }
            Hs5SetupUi.permission(this, "麦克风", "用于 Siri 与通话的车机拾音。", value.microphone,
                "hs5_management_microphone", callbacks.onRequestMicrophone)
            Hs5SetupUi.permission(this, "精确定位", "用于车机 GPS 回传；未允许时使用 iPhone 定位。", value.location,
                "hs5_management_location", callbacks.onRequestLocation)
            value.wirelessPermission?.let {
                Hs5SetupUi.permission(this, "无线连接权限", "当前 Android 版本连接附近设备所需的系统权限。", it,
                    "hs5_management_wireless_permission", callbacks.onRequestWirelessPermissions)
            }
            Hs5SetupUi.check(this, "CarPlay 认证", value.authentication)
        }
        card(content, "增强功能授权", 3) {
            Hs5SetupUi.description(this, "基础 CarPlay 免费；HUD、仪表地图和方向盘增强功能需绑定授权。")
            Hs5SetupUi.license(this, value.license, callbacks.onStartBinding, callbacks.onRedeemCode, callbacks.onCancelBinding)
        }
        card(content, "车辆状态（只读）", 10) {
            addView(Hs5VehicleDataView(context), LayoutParams(-1, -2))
        }
        card(content, "仪表显示", 3) {
            Hs5SetupUi.description(this, "Apple CarPlay Ultra 可将车辆仪表与 iPhone 内容整合显示。")
            addView(Switch(context).apply {
                tag = "hs5_ultra_switch"
                text = "Apple CarPlay Ultra"
                textSize = Hs5Ui.sp(context, 17f)
                setTextColor(colors.text)
                thumbTintList = ColorStateList.valueOf(colors.accent)
                // An ordinary cluster video stream does not establish CarPlay Ultra capability.
                isChecked = value.ultraEnabled && value.ultraSupported
                isEnabled = value.canToggleUltra
                alpha = if (isEnabled) 1f else 0.55f
                contentDescription = "Apple CarPlay Ultra，${if (isEnabled) "可以切换" else "暂不可切换"}"
                setOnCheckedChangeListener { _, enabled ->
                    if (value.canToggleUltra) callbacks.onToggleUltra(enabled)
                }
            }, LayoutParams(-1, Hs5Ui.dp(context, 52)))
            val reason = when {
                !value.ultraSupported -> value.ultraUnavailableReason.ifBlank { "当前版本尚未接入 Apple CarPlay Ultra，暂不可开启。" }
                !value.license.active -> "绑定增强授权后可切换。"
                else -> "已具备 CarPlay Ultra 接入能力。"
            }
            Hs5SetupUi.description(this, reason, "hs5_ultra_status", true)
            Hs5SetupUi.description(this, value.instrumentPermissionDetail, "hs5_instrument_permission_status")
            if (value.instrumentPermission == Hs5InstrumentPermission.NEEDED && value.license.active) {
                Hs5SetupUi.action(this, "授权仪表显示（系统特殊权限）", "hs5_instrument_permission",
                    action = callbacks.onInstrumentPermission)
            }
        }
        card(content, "软件更新", 5) {
            Hs5SetupUi.update(this, value.update, callbacks.onCheckUpdates, callbacks.onInstallUpdate)
        }
        card(content, "设备与诊断", 10) {
            Hs5SetupUi.action(this, "手机配对管理", "hs5_manage_phones", action = callbacks.onManagePhones)
            Hs5SetupUi.action(this, "连接诊断", "hs5_diagnostics", action = callbacks.onDiagnostics)
            Hs5SetupUi.description(this, "画面、声音、HUD 和按键已采用 HS5 固定配置。")
        }
        val scroll = ScrollView(context).apply {
            isFillViewport = true
            addView(content, LayoutParams(-1, -2))
        }
        addView(scroll, LayoutParams(-1, 0, 1f).apply { topMargin = Hs5Ui.dp(context, 10) })
    }

    private fun card(content: LinearLayout, title: String, icon: Int, build: LinearLayout.() -> Unit) {
        val panel = Hs5Ui.card(context, title, icon).apply(build)
        content.addView(panel, LayoutParams(-1, -2).apply { bottomMargin = Hs5Ui.dp(context, 10) })
    }
}
