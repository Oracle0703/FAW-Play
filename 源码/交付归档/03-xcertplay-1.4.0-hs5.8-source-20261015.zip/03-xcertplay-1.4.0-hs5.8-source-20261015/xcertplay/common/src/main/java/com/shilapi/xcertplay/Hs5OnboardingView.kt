// SPDX-License-Identifier: AGPL-3.0-only
package com.shilapi.xcertplay

import android.content.Context
import android.content.res.ColorStateList
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import com.shilapi.xcertplay.host.R

/** Native, scrollable first-use UI. It renders host evidence and never initiates work on bind. */
internal class Hs5OnboardingView(
    context: Context,
    private val callbacks: Hs5OnboardingCallbacks,
) : LinearLayout(context) {
    private var snapshot: Hs5OnboardingSnapshot? = null

    fun bind(value: Hs5OnboardingSnapshot) {
        if (value == snapshot) return
        snapshot = value
        removeAllViews()
        orientation = VERTICAL
        tag = "hs5_onboarding_root"
        val colors = FawUiTheme.palette(context)
        setBackgroundColor(colors.background)
        setPadding(Hs5Ui.dp(context, 12), Hs5Ui.dp(context, 10), Hs5Ui.dp(context, 12), Hs5Ui.dp(context, 10))
        addView(Hs5SetupUi.header(context, "首次使用"), LayoutParams(-1, Hs5Ui.dp(context, 46)))
        val body = Hs5Ui.row(context).apply { gravity = Gravity.TOP }
        if (resources.configuration.screenWidthDp >= 600) {
            val steps = Hs5Ui.column(context).apply {
                background = Hs5Ui.shape(context, colors.surface)
                setPadding(Hs5Ui.dp(context, 12), Hs5Ui.dp(context, 12), Hs5Ui.dp(context, 12), Hs5Ui.dp(context, 12))
            }
            Hs5OnboardingStep.entries.forEach { step ->
                steps.addView(Hs5Ui.label(context, "${step.ordinal + 1}  ${step.title}", 14f,
                    if (step == value.step) colors.accent else colors.muted, step == value.step).apply {
                    contentDescription = "${step.title}${if (step == value.step) "，当前步骤" else ""}"
                    setPadding(0, Hs5Ui.dp(context, 10), 0, Hs5Ui.dp(context, 10))
                }, LayoutParams(-1, -2))
            }
            body.addView(steps, LayoutParams(Hs5Ui.dp(context, 166), -1).apply { rightMargin = Hs5Ui.dp(context, 12) })
        }
        val content = Hs5Ui.column(context).apply {
            setPadding(Hs5Ui.dp(context, 14), Hs5Ui.dp(context, 12), Hs5Ui.dp(context, 14), Hs5Ui.dp(context, 12))
            background = Hs5Ui.shape(context, colors.surface, colors.border)
        }
        content.addView(Hs5Ui.label(context, "第 ${value.step.ordinal + 1} / ${Hs5OnboardingStep.entries.size} 步", 12f, colors.muted))
        content.addView(Hs5Ui.label(context, value.step.title, 24f, colors.text, true))
        when (value.step) {
            Hs5OnboardingStep.WELCOME -> welcome(content, value)
            Hs5OnboardingStep.PERMISSIONS -> permissions(content, value)
            Hs5OnboardingStep.UPDATE -> update(content, value)
            Hs5OnboardingStep.LICENSE -> license(content, value)
            Hs5OnboardingStep.CONNECTION -> connection(content, value)
        }
        val scroll = ScrollView(context).apply {
            isFillViewport = true
            addView(content, LayoutParams(-1, -2))
        }
        body.addView(scroll, LayoutParams(0, -1, 1f))
        addView(body, LayoutParams(-1, 0, 1f).apply { topMargin = Hs5Ui.dp(context, 10) })
        addView(footer(value), LayoutParams(-1, Hs5Ui.dp(context, 48)).apply { topMargin = Hs5Ui.dp(context, 10) })
    }

    private fun welcome(content: LinearLayout, value: Hs5OnboardingSnapshot) {
        Hs5SetupUi.description(content, "欢迎使用红旗 HS5 无线 CarPlay。完成准备后，在 iPhone 上搜索车机蓝牙并连接。")
        Hs5SetupUi.check(content, "车机环境", value.environment)
        Hs5SetupUi.check(content, "蓝牙", value.bluetooth)
        Hs5SetupUi.check(content, "Wi-Fi", value.wifi)
        Hs5SetupUi.check(content, "CarPlay 认证", value.authentication)
        Hs5SetupUi.description(content, "画面、声音和车辆适配已使用 HS5 固定配置，无需调节。")
        Hs5SetupUi.action(content, "重新检查", "hs5_setup_refresh", action = callbacks.onRefreshEnvironment)
    }

    private fun permissions(content: LinearLayout, value: Hs5OnboardingSnapshot) {
        Hs5SetupUi.description(content, "点击允许后，由系统弹窗确认。未允许的功能可以稍后处理，基础 CarPlay 仍可继续。")
        Hs5SetupUi.permission(content, "麦克风", "用于 Siri 和通话的车机拾音。", value.microphone,
            "hs5_setup_microphone", callbacks.onRequestMicrophone)
        Hs5SetupUi.permission(content, "精确定位", "用于车机 GPS 回传；未允许时继续使用 iPhone 定位。", value.location,
            "hs5_setup_location", callbacks.onRequestLocation)
        value.wirelessPermission?.let {
            Hs5SetupUi.permission(content, "附近设备与无线连接", "当前 Android 版本连接蓝牙和 Wi-Fi 所需的系统权限。", it,
                "hs5_setup_wireless_permission", callbacks.onRequestWirelessPermissions)
        }
    }

    private fun update(content: LinearLayout, value: Hs5OnboardingSnapshot) {
        Hs5SetupUi.description(content, "在连接 iPhone 前检查 HS5 专用版本。免费用户同样可以更新。")
        Hs5SetupUi.update(content, value.update, callbacks.onCheckUpdates, callbacks.onInstallUpdate)
        Hs5SetupUi.description(content, "暂时无法联网时，可继续设置并稍后检查。")
    }

    private fun license(content: LinearLayout, value: Hs5OnboardingSnapshot) {
        Hs5SetupUi.description(content, "基础 CarPlay 免费。绑定增强授权后，启用 HUD、仪表地图和方向盘增强功能。")
        Hs5SetupUi.license(content, value.license, callbacks.onStartBinding, callbacks.onRedeemCode, callbacks.onCancelBinding)
        Hs5SetupUi.description(content, "软件功能授权与 CarPlay 认证分别管理。跳过绑定不影响已就绪的基础连接。")
    }

    private fun connection(content: LinearLayout, value: Hs5OnboardingSnapshot) {
        val name = value.bluetoothName?.takeIf { it.isNotBlank() }
        Hs5SetupUi.description(content, if (name == null) "车机蓝牙名称尚未读取，请重新检查。" else "手机搜索的车机蓝牙名称：$name")
        Hs5SetupUi.description(content, "1. 点击下方开始连接。\n2. 在 iPhone「设置 → 蓝牙」中选择车机名称并确认配对。\n3. 按 iPhone 提示允许使用 CarPlay，等待自动进入。")
        Hs5SetupUi.check(content, "CarPlay 认证", value.authentication)
        Hs5SetupUi.description(content, value.connectionMessage, "hs5_setup_connection_status", true)
        if (!value.canConnect && !value.connected) {
            listOf("车机环境" to value.environment, "蓝牙" to value.bluetooth, "Wi-Fi" to value.wifi)
                .filter { !it.second.ready }.forEach { Hs5SetupUi.check(content, it.first, it.second) }
            if (value.wirelessPermission != null && value.wirelessPermission != Hs5PermissionStatus.GRANTED) {
                Hs5SetupUi.permission(content, "无线连接权限", "先允许系统无线连接权限，再开始配对。", value.wirelessPermission,
                    "hs5_setup_wireless_permission", callbacks.onRequestWirelessPermissions)
            }
            Hs5SetupUi.action(content, "重新检查", "hs5_setup_refresh", action = callbacks.onRefreshEnvironment)
        }
        Hs5SetupUi.action(content, "连接详情", "hs5_setup_connection_details", action = callbacks.onConnectionDetails)
    }

    private fun footer(value: Hs5OnboardingSnapshot): LinearLayout = Hs5Ui.row(context).apply {
        if (value.step != Hs5OnboardingStep.WELCOME) {
            addView(Hs5Ui.button(context, "上一步") { callbacks.onMoveTo(value.step.previous()) }.apply {
                tag = "hs5_setup_previous"
                isEnabled = !value.connecting
            }, LayoutParams(0, -1, 1f))
        }
        val text = when (value.step) {
            Hs5OnboardingStep.WELCOME -> "开始设置"
            Hs5OnboardingStep.PERMISSIONS -> "继续"
            Hs5OnboardingStep.UPDATE -> if (value.update.state == Hs5UpdateState.UP_TO_DATE) "继续" else "稍后更新，继续"
            Hs5OnboardingStep.LICENSE -> if (value.license.active) "继续" else "使用免费基础功能"
            Hs5OnboardingStep.CONNECTION -> when {
                value.connected -> "进入首页"
                value.connecting -> "取消连接"
                else -> "开始连接"
            }
        }
        addView(Hs5Ui.button(context, text, true) {
            when {
                value.step != Hs5OnboardingStep.CONNECTION -> callbacks.onMoveTo(value.step.next())
                value.connected -> callbacks.onFinish()
                value.connecting -> callbacks.onCancelConnection()
                else -> callbacks.onConnect()
            }
        }.apply {
            tag = "hs5_setup_continue"
            isEnabled = when (value.step) {
                Hs5OnboardingStep.WELCOME -> value.environment.ready
                Hs5OnboardingStep.PERMISSIONS -> value.microphone != Hs5PermissionStatus.REQUESTING &&
                    value.location != Hs5PermissionStatus.REQUESTING && value.wirelessPermission != Hs5PermissionStatus.REQUESTING
                Hs5OnboardingStep.UPDATE -> value.update.state != Hs5UpdateState.DOWNLOADING
                Hs5OnboardingStep.LICENSE -> value.license.state != Hs5LicenseState.BINDING
                Hs5OnboardingStep.CONNECTION -> value.connected || value.connecting || value.canConnect
            }
            alpha = if (isEnabled) 1f else 0.5f
        }, LayoutParams(0, -1, if (value.step == Hs5OnboardingStep.WELCOME) 1f else 2f).apply { leftMargin = Hs5Ui.dp(context, 8) })
    }
}

/** Shared presentation helpers; no settings fields, permission requests or network work live here. */
internal object Hs5SetupUi {
    fun header(context: Context, title: String): LinearLayout {
        val colors = FawUiTheme.palette(context)
        return Hs5Ui.row(context).apply {
            setPadding(Hs5Ui.dp(context, 10), 0, Hs5Ui.dp(context, 10), 0)
            background = Hs5Ui.shape(context, colors.surface)
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_faw_logo)
                imageTintList = ColorStateList.valueOf(colors.accent)
                scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = "红旗"
            }, LinearLayout.LayoutParams(Hs5Ui.dp(context, 30), -1))
            addView(Hs5Ui.label(context, "${context.getString(R.string.app_name)} · $title", 18f, colors.text, true).apply {
                setPadding(Hs5Ui.dp(context, 10), 0, 0, 0)
            }, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    fun description(content: LinearLayout, text: String, viewTag: String? = null, important: Boolean = false) {
        val context = content.context
        val colors = FawUiTheme.palette(context)
        content.addView(Hs5Ui.label(context, text, if (important) 17f else 14f,
            if (important) colors.text else colors.muted, important).apply {
            tag = viewTag
            setPadding(0, Hs5Ui.dp(context, 8), 0, Hs5Ui.dp(context, 5))
            if (important) accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }, LinearLayout.LayoutParams(-1, -2))
    }

    fun check(content: LinearLayout, title: String, value: Hs5SetupCheck) {
        val state = when (value.state) {
            Hs5CheckState.CHECKING -> "检查中"
            Hs5CheckState.READY -> "已就绪"
            Hs5CheckState.UNAVAILABLE -> "暂不可用"
            Hs5CheckState.FAILED -> "检查失败"
        }
        description(content, "$title · $state\n${value.detail}", important = true)
    }

    fun action(content: LinearLayout, text: String, viewTag: String, enabled: Boolean = true,
               primary: Boolean = false, action: () -> Unit): Button {
        val context = content.context
        val button = Hs5Ui.button(context, text, primary, action).apply {
            tag = viewTag
            isEnabled = enabled
            alpha = if (enabled) 1f else 0.5f
        }
        content.addView(button, LinearLayout.LayoutParams(-1, Hs5Ui.dp(context, 48)).apply { topMargin = Hs5Ui.dp(context, 6) })
        return button
    }

    fun permission(content: LinearLayout, title: String, detail: String, state: Hs5PermissionStatus,
                   viewTag: String, onRequest: () -> Unit) {
        description(content, "$title · ${state.label}\n$detail", important = true)
        if (state.canRequest) action(content, "允许$title", viewTag, action = onRequest)
    }

    fun update(content: LinearLayout, status: Hs5UpdateStatus, onCheck: () -> Unit, onInstall: () -> Unit) {
        description(content, status.detail, "hs5_update_status", true)
        action(content, when (status.state) {
            Hs5UpdateState.CHECKING -> "正在检查更新"
            Hs5UpdateState.DOWNLOADING -> "正在下载更新"
            else -> "检查更新"
        }, "hs5_check_updates", !status.busy, action = onCheck)
        if (status.state == Hs5UpdateState.AVAILABLE) {
            action(content, "下载并更新", "hs5_install_update", primary = true, action = onInstall)
        }
    }

    fun license(content: LinearLayout, status: Hs5LicenseStatus, onBind: () -> Unit, onRedeem: () -> Unit,
                onCancel: () -> Unit) {
        description(content, status.detail, "hs5_license_status", true)
        if (!status.active) {
            action(content, if (status.state == Hs5LicenseState.BINDING) "等待手机完成绑定" else "手机扫码绑定",
                "hs5_bind_license", status.canBind, primary = true, action = onBind)
            action(content, "在手机兑换", "hs5_redeem_license", status.canBind, action = onRedeem)
            if (status.state == Hs5LicenseState.BINDING) {
                action(content, "取消绑定，稍后再试", "hs5_cancel_binding", action = onCancel)
            }
        }
    }
}
