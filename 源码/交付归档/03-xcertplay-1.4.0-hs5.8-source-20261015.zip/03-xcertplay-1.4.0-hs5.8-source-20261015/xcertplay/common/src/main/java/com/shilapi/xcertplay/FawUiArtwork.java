// SPDX-License-Identifier: AGPL-3.0-only
package com.shilapi.xcertplay;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import com.shilapi.xcertplay.host.R;
/** Artwork reused from the old FAW Play UI; it owns no connection or media state. */
public final class FawUiArtwork {
    /** Flat phone-to-display illustration, drawn at native resolution. */
    public static final class ConnectionArt extends Drawable {
        private final FawUiTheme.Palette colors; private final int size; private final Drawable mark;
        ConnectionArt(Context context, FawUiTheme.Palette colors, int size) {
            this.colors = colors; this.size = size;
            mark = context.getDrawable(R.drawable.ic_faw_logo).mutate(); mark.setTint(colors.accent);
        }
        @Override public int getIntrinsicWidth() { return size; }
        @Override public int getIntrinsicHeight() { return size; }
        @Override public void draw(Canvas canvas) {
            canvas.save(); canvas.translate(getBounds().left, getBounds().top);
            canvas.scale(getBounds().width()/240f, getBounds().height()/240f);
            Paint line = new Paint(Paint.ANTI_ALIAS_FLAG); line.setStyle(Paint.Style.STROKE); line.setColor(colors.muted); line.setStrokeWidth(2); line.setStrokeCap(Paint.Cap.ROUND);
            canvas.drawRoundRect(8, 54, 62, 182, 8, 8, line); canvas.drawLine(28,61,42,61,line); canvas.drawLine(29,174,41,174,line);
            canvas.drawRoundRect(114, 70, 234, 160, 9, 9, line); canvas.drawLine(160,178,188,178,line); canvas.drawLine(174,160,174,178,line);
            line.setColor(colors.accent); line.setStrokeWidth(4);
            for (int i=0;i<3;i++) canvas.drawArc(58-i*9, 95-i*9, 84+i*9, 125+i*9, -55, 110, false, line);
            mark.setBounds(150, 92, 198, 140); mark.draw(canvas);
            canvas.restore();
        }
        @Override public void setAlpha(int alpha) {}
        @Override public void setColorFilter(android.graphics.ColorFilter filter) {}
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }
    /** Small deterministic line icons; the generated screenshot is not used as a UI bitmap. */
    public static final class Mark extends Drawable {
        private final int kind, color, size;
        Mark(int kind, int color, int size) { this.kind=kind; this.color=color; this.size=size; }
        @Override public int getIntrinsicWidth() { return size; }
        @Override public int getIntrinsicHeight() { return size; }
        @Override public void draw(Canvas canvas) {
            canvas.save(); canvas.translate(getBounds().left, getBounds().top); canvas.scale(getBounds().width()/24f, getBounds().height()/24f);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(color); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.7f); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
            Path path = new Path();
            switch(kind) {
                case 0: canvas.drawRoundRect(3, 10, 14, 20, 4, 4, p); canvas.drawRoundRect(10, 3, 21, 13, 4, 4, p); canvas.drawLine(9, 15, 15, 9, p); break;
                case 1: canvas.drawRoundRect(2, 4, 22, 17, 2, 2, p); canvas.drawLine(8, 21, 16, 21, p); canvas.drawLine(12, 17, 12, 21, p); break;
                case 2: path.moveTo(12, 2); path.lineTo(21, 22); path.lineTo(12, 17); path.lineTo(3, 22); path.close(); canvas.drawPath(path,p); break;
                case 3: path.moveTo(12, 2); path.lineTo(21, 6); path.lineTo(19, 16); path.quadTo(17, 21, 12, 23); path.quadTo(7, 21, 5, 16); path.lineTo(3, 6); path.close(); canvas.drawPath(path,p); canvas.drawLine(8,12,11,15,p); canvas.drawLine(11,15,16,9,p); break;
                case 4: path.moveTo(2,12); path.lineTo(7,12); path.lineTo(10,3); path.lineTo(14,21); path.lineTo(17,12); path.lineTo(22,12); canvas.drawPath(path,p); break;
                case 7: canvas.drawLine(9, 5, 9, 18, p); canvas.drawLine(9, 5, 20, 3, p); canvas.drawLine(20, 3, 20, 16, p); canvas.drawOval(3, 16, 9, 21, p); canvas.drawOval(14, 14, 20, 19, p); break;
                case 8: path.moveTo(5, 3); path.lineTo(9, 7); path.lineTo(7, 10); path.quadTo(9, 15, 14, 17); path.lineTo(17, 15); path.lineTo(21, 19); path.quadTo(17, 25, 9, 17); path.quadTo(0, 8, 5, 3); canvas.drawPath(path, p); break;
                case 9: canvas.drawCircle(12, 12, 7, p); canvas.drawCircle(12, 12, 3, p); for (int i=0;i<8;i++) { double angle=i*Math.PI/4; canvas.drawLine(12+(float)Math.cos(angle)*7,12+(float)Math.sin(angle)*7,12+(float)Math.cos(angle)*10,12+(float)Math.sin(angle)*10,p); } break;
                case 10: canvas.drawRoundRect(6, 2, 18, 22, 2, 2, p); canvas.drawLine(10, 19, 14, 19, p); break;
                case 11: canvas.drawCircle(12,12,5,p); for (int i=0;i<8;i++) { double a=i*Math.PI/4; canvas.drawLine(12+(float)Math.cos(a)*8,12+(float)Math.sin(a)*8,12+(float)Math.cos(a)*10,12+(float)Math.sin(a)*10,p); } break;
                case 12: canvas.drawCircle(8,8,5,p); canvas.drawLine(12,12,21,21,p); canvas.drawLine(16,16,19,13,p); canvas.drawLine(19,19,22,16,p); break;
                case 5: canvas.drawCircle(12,12,10,p); canvas.drawPoint(12,7,p); canvas.drawLine(12,11,12,17,p); break;
                default: canvas.drawLine(12,2,12,10,p); canvas.drawArc(3,3,21,21,-55,290,false,p);
            }
            canvas.restore();
        }
        @Override public void setAlpha(int alpha) {}
        @Override public void setColorFilter(android.graphics.ColorFilter filter) {}
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }
}
