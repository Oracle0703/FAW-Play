package com.shilapi.xcertplay

import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import java.util.concurrent.FutureTask
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/** Ordered capture retaining the session head and a rolling tail in one size-limited file. */
internal class SessionLogFile(
    val file: File,
    private val maxBytes: Int = MAX_BYTES,
    private val headLimitBytes: Int = maxBytes / 3,
    private val onError: (String) -> Unit = {},
    private val outputFactory: (File, Boolean) -> OutputStream = { destination, append ->
        FileOutputStream(destination, append)
    },
) : Closeable {
    init {
        require(maxBytes >= 2048)
        require(headLimitBytes in 1..(maxBytes - RETENTION_MARKER_RESERVE - TRUNCATION_MARKER_RESERVE - 128))
    }
    private val lock = ReentrantLock()
    // Lifecycle waits never hold the admission lock used by transport callbacks.
    private val lifecycleLock = ReentrantLock()
    private val pendingChanged = lock.newCondition()
    private class WriteTask(val control: Boolean, val video: Boolean = false, val write: () -> Unit)
    private val pending = ArrayDeque<WriteTask>()
    private var pendingRecords = 0
    private val droppedRecords = AtomicLong(0)
    private var output: BufferedOutputStream? = null
    private var bytesWritten = 0L
    private var committedBytes = 0L
    private var unflushedRecords = 0
    private var unflushedHeadBytes = 0L
    private var unflushedTailRecords = 0
    private var headFrozenAtFlush = false
    private var failureMarkerPending = false
    private var headBytes = 0L
    private var headFrozen = false
    private val tailRecordSizes = ArrayDeque<Int>()
    private var retentionMarker = ByteArray(0)
    private var removedBytes = 0L
    private var removedRecords = 0L
    private var rotations = 0L
    private var closed = false
    private val formatter = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private var failedRecords = 0L
    private val videoPending = AtomicBoolean(false)
    private val droppedVideoPackets = AtomicLong(0)
    private val writerThread = Thread(::drain, "xcertplay-log-writer").apply {
        isDaemon = true
        start()
    }

    /** Clears previous records and starts a new session. */
    fun reset(header: String) {
        lifecycleLock.withLock {
            barrier {
                try {
                    flushOutput()
                    openOutput(append = false)
                    headBytes = 0
                    headFrozen = false
                    tailRecordSizes.clear()
                    retentionMarker = ByteArray(0)
                    removedBytes = 0
                    removedRecords = 0
                    rotations = 0
                    failedRecords = 0
                    headFrozenAtFlush = false
                    writeLine(header)
                    flushOutput()
                } catch (error: Exception) {
                    reportWriteFailure(error)
                }
            }.get()
        }
    }

    /** Ordered snapshot boundary for export and explicit lifecycle work, outside callbacks. */
    fun flush() {
        lifecycleLock.withLock {
            if (lock.withLock { closed }) return
            barrier { writePendingLoss(); flushOutput() }.get()
        }
    }
    fun append(line: String) = enqueue { line }
    fun appendTimestamped(message: String, timestampMillis: Long) = enqueue {
        "${formatter.format(Date(timestampMillis))}  $message"
    }
    /** Raw capture is best-effort: reserve queue space for connection records, never stall video. */
    fun appendVideoPacket(
        type: Int, codec: String, sequence: Long,
        header: ByteArray, wire: ByteArray, plain: ByteArray?,
    ) {
        val payload = plain?.takeUnless { it === wire }
        val size = header.size.toLong() + wire.size + (payload?.size ?: 0)
        val recordBudget = maxBytes - headLimitBytes - RETENTION_MARKER_RESERVE - TRUNCATION_MARKER_RESERVE - 1024
        if (size > MAX_PENDING_VIDEO_BYTES || size * 2 > recordBudget ||
            !videoPending.compareAndSet(false, true)) {
            droppedVideoPackets.incrementAndGet()
            return
        }
        // Copy outside the queue lock: an opt-in raw dump cannot delay ordinary diagnostics.
        val capturedHeader = header.copyOf()
        val capturedWire = wire.copyOf()
        val capturedPlain = payload?.copyOf()
        val at = System.currentTimeMillis()
        if (!lock.tryLock()) {
            videoPending.set(false)
            droppedVideoPackets.incrementAndGet()
            return
        }
        try {
            if (closed || MAX_PENDING_RECORDS - pendingRecords < VIDEO_QUEUE_RESERVE) {
                videoPending.set(false)
                droppedVideoPackets.incrementAndGet()
                return
            }
            pending.addLast(WriteTask(control = false, video = true) {
                try {
                    writePendingLoss()
                    writeLine(buildString {
                        append(formatter.format(Date(at)))
                        append("  TRACE MEDIA VIDEO type=$type codec=$codec sequence=$sequence")
                        append(" opcode=${capturedHeader.getOrNull(4)?.toInt()?.and(0xff)}")
                        append(" headerBytes=${capturedHeader.size} wireBytes=${capturedWire.size}")
                        append(" plainBytes=${capturedPlain?.size ?: 0}\n  headerHex=")
                        append(hex(capturedHeader))
                        append("\n  wireHex="); append(hex(capturedWire))
                        capturedPlain?.let { append("\n  plainHex="); append(hex(it)) }
                    })
                } finally { videoPending.set(false) }
            })
            pendingRecords++
            pendingChanged.signal()
        } finally { lock.unlock() }
    }

    private fun writePendingLoss() {
        val records = droppedRecords.getAndSet(0)
        if (records > 0) writeLine("LOG LOSS droppedRecords=$records reason=queue-capacity")
        val dropped = droppedVideoPackets.getAndSet(0)
        if (dropped > 0) writeLine("LOG VIDEO LOSS droppedPackets=$dropped reason=capture-capacity")
    }

    private fun hex(bytes: ByteArray): String {
        val digits = "0123456789abcdef"
        val output = CharArray(bytes.size * 2)
        bytes.forEachIndexed { index, byte ->
            val value = byte.toInt() and 0xff
            output[index * 2] = digits[value ushr 4]
            output[index * 2 + 1] = digits[value and 15]
        }
        return String(output)
    }

    private fun enqueue(line: () -> String) {
        lock.withLock {
            if (closed) return
            if (pendingRecords == MAX_PENDING_RECORDS) {
                // Preserve reset/export/close barriers and the most recent diagnostic records.
                val iterator = pending.iterator()
                while (iterator.hasNext()) {
                    val task = iterator.next()
                    if (task.control) continue
                    iterator.remove()
                    pendingRecords--
                    if (task.video) {
                        videoPending.set(false)
                        droppedVideoPackets.incrementAndGet()
                    } else {
                        droppedRecords.incrementAndGet()
                    }
                    break
                }
            }
            pending.addLast(WriteTask(control = false) { writePendingLoss(); writeLine(line()) })
            pendingRecords++
            pendingChanged.signal()
        }
    }

    /** Only lifecycleLock holders submit controls, so at most one barrier can be pending. */
    private fun barrier(action: () -> Unit): FutureTask<Unit> = lock.withLock {
        check(!closed) { "Log writer is closed" }
        FutureTask<Unit> { action(); Unit }.also {
            pending.addLast(WriteTask(control = true, write = it::run))
            pendingChanged.signal()
        }
    }

    private fun drain() {
        while (true) {
            val task = lock.withLock {
                while (pending.isEmpty() && !closed) pendingChanged.await()
                if (pending.isEmpty()) return
                pending.removeFirst().also { if (!it.control) pendingRecords-- }
            }
            try {
                task.write()
            } catch (error: Exception) {
                reportWriteFailure(error)
            }
            if (!task.control && (unflushedRecords >= FLUSH_BATCH_RECORDS ||
                    lock.withLock { pending.isEmpty() })) {
                flushOutput()
            }
        }
    }

    private fun writeLine(line: String) {
        try {
            val lossMarker = if (failedRecords > 0 && !failureMarkerPending) {
                "\nLOG LOSS priorFailedRecords=$failedRecords\n".toByteArray(StandardCharsets.UTF_8)
            } else null
            // A single oversized record must leave room for the pinned head and markers.
            val maxRecordBytes = maxBytes - headBytes.toInt() - RETENTION_MARKER_RESERVE -
                TRUNCATION_MARKER_RESERVE - 1 - (lossMarker?.size ?: 0)
            var bytes = line.toByteArray(StandardCharsets.UTF_8)
            var truncationMarker = ByteArray(0)
            if (bytes.size > maxRecordBytes) {
                val originalSize = bytes.size
                var start = bytes.size - maxRecordBytes
                while (start < bytes.size && bytes[start].toInt() and 0xc0 == 0x80) start++
                bytes = bytes.copyOfRange(start, bytes.size)
                truncationMarker = ("LOG TRUNCATED originalRecordBytes=$originalSize " +
                    "keptSuffixBytes=${bytes.size}\n").toByteArray(StandardCharsets.UTF_8)
                check(truncationMarker.size <= TRUNCATION_MARKER_RESERVE)
            }
            val recordSize = (lossMarker?.size ?: 0) + truncationMarker.size + bytes.size + 1
            if (output == null) openOutput(append = true)
            if (bytesWritten + recordSize > maxBytes) {
                if (!flushOutput()) {
                    failedRecords++
                    return
                }
                compactTail(recordSize)
            }
            val active = output!!
            if (lossMarker != null) {
                active.write(lossMarker)
            }
            active.write(truncationMarker)
            active.write(bytes)
            active.write('\n'.code)
            bytesWritten += recordSize
            unflushedRecords++
            failureMarkerPending = failureMarkerPending || lossMarker != null
            if (!headFrozen && headBytes + recordSize <= headLimitBytes) {
                headBytes += recordSize
                unflushedHeadBytes += recordSize
            } else {
                headFrozen = true
                tailRecordSizes.addLast(recordSize)
                unflushedTailRecords++
            }
        } catch (error: Exception) {
            reportWriteFailure(error)
        }
    }

    private fun flushOutput(): Boolean {
        if (unflushedRecords == 0) return true
        return try {
            output!!.flush()
            committedBytes = bytesWritten
            unflushedRecords = 0
            unflushedHeadBytes = 0
            unflushedTailRecords = 0
            headFrozenAtFlush = headFrozen
            if (failureMarkerPending) failedRecords = 0
            failureMarkerPending = false
            true
        } catch (error: Exception) {
            reportWriteFailure(error, recordInFlight = false)
            false
        }
    }

    /** Evicts whole oldest tail records in batches; the pinned head is never discarded. */
    private fun compactTail(incomingRecordSize: Int) {
        val target = maxOf(maxBytes / 6L,
            bytesWritten + incomingRecordSize + RETENTION_MARKER_RESERVE - maxBytes)
        var droppedBytes = 0L
        var droppedRecords = 0
        for (size in tailRecordSizes) {
            droppedBytes += size
            droppedRecords++
            if (droppedBytes >= target) break
        }
        val marker = ("LOG RETENTION maxBytes=$maxBytes headLimitBytes=$headLimitBytes " +
            "headBytes=$headBytes rotations=${rotations + 1} " +
            "removedRecords=${removedRecords + droppedRecords} " +
            "removedBytes=${removedBytes + droppedBytes}\n").toByteArray(StandardCharsets.UTF_8)
        check(marker.size <= RETENTION_MARKER_RESERVE)
        val oldTailStart = headBytes + retentionMarker.size
        val remainingTailBytes = bytesWritten - oldTailStart - droppedBytes
        val nextSize = headBytes + marker.size + remainingTailBytes
        check(remainingTailBytes >= 0 && nextSize + incomingRecordSize <= maxBytes)

        // Replace the complete snapshot atomically in the same directory. Readers see either
        // the old or new head+tail, and a failed copy leaves the original file intact.
        output?.close()
        output = null
        val temporary = File.createTempFile(file.name + ".", ".rotate", file.absoluteFile.parentFile)
        try {
            RandomAccessFile(file, "r").use { source ->
                temporary.outputStream().buffered().use { destination ->
                    val buffer = ByteArray(64 * 1024)
                    copyRange(source, destination, 0, headBytes, buffer)
                    destination.write(marker)
                    copyRange(source, destination, oldTailStart + droppedBytes, remainingTailBytes, buffer)
                }
            }
            check(temporary.renameTo(file)) { "Could not replace rotated log ${file.absolutePath}" }
            repeat(droppedRecords) { tailRecordSizes.removeFirst() }
            removedBytes += droppedBytes
            removedRecords += droppedRecords
            rotations++
            retentionMarker = marker
            bytesWritten = nextSize
            committedBytes = nextSize
            openOutput(append = true)
        } finally {
            temporary.delete()
        }
    }

    private fun copyRange(source: RandomAccessFile, destination: BufferedOutputStream,
        start: Long, length: Long, buffer: ByteArray) {
        source.seek(start)
        var remaining = length
        while (remaining > 0) {
            val count = minOf(buffer.size.toLong(), remaining).toInt()
            source.readFully(buffer, 0, count)
            destination.write(buffer, 0, count)
            remaining -= count
        }
    }

    private fun openOutput(append: Boolean) {
        output?.close()
        output = null
        file.parentFile?.mkdirs()
        output = outputFactory(file, append).buffered()
        bytesWritten = if (append) file.length() else 0L
        committedBytes = bytesWritten
        headFrozenAtFlush = headFrozen
    }

    private fun reportWriteFailure(error: Exception, recordInFlight: Boolean = true) {
        failedRecords += unflushedRecords + if (recordInFlight) 1 else 0
        runCatching { output?.close() }; output = null
        // A batch is committed only after flush. Discard partial bytes and restore its offsets.
        bytesWritten = committedBytes
        headBytes -= unflushedHeadBytes
        repeat(unflushedTailRecords) { tailRecordSizes.removeLast() }
        headFrozen = headFrozenAtFlush
        unflushedRecords = 0
        unflushedHeadBytes = 0
        unflushedTailRecords = 0
        failureMarkerPending = false
        runCatching { RandomAccessFile(file, "rw").use { it.setLength(bytesWritten) } }
        reportError("Log write failed path=${file.absolutePath} failedRecords=$failedRecords reason=${error.message}")
    }

    private fun reportError(message: String) { runCatching { onError(message) } }

    override fun close() {
        lifecycleLock.withLock {
            val completion = lock.withLock {
                if (closed) return
                closed = true
                FutureTask<Unit> {
                    writePendingLoss()
                    flushOutput()
                    runCatching { output?.close() }.onFailure { reportError("Log close failed: ${it.message}") }
                    output = null
                }.also {
                    pending.addLast(WriteTask(control = true, write = it::run))
                    pendingChanged.signalAll()
                }
            }
            completion.get()
            writerThread.join()
        }
    }

    private companion object {
        const val MAX_BYTES = 30 * 1024 * 1024
        const val MAX_PENDING_VIDEO_BYTES = 8 * 1024 * 1024L
        const val RETENTION_MARKER_RESERVE = 512
        const val TRUNCATION_MARKER_RESERVE = 128
        const val MAX_PENDING_RECORDS = 64
        const val VIDEO_QUEUE_RESERVE = 8
        const val FLUSH_BATCH_RECORDS = 32
    }
}
