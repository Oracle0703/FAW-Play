package com.shilapi.xcertplay

import android.app.Activity
import android.app.Presentation
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.Gravity
import android.widget.FrameLayout
import com.shilapi.xcertplay.airplay.AirPlayConfig
import com.shilapi.xcertplay.airplay.CarPlayClusterDisplay
import com.shilapi.xcertplay.hud.*
import com.shilapi.xcertplay.media.AndroidMediaSink
import com.shilapi.xcertplay.orchestration.CarPlayController

/** Activity owns windows/listeners; the controller owns the retained vehicle navigation session. */
internal class HongqiHostIntegration(private val activity: Activity, onNight: (Boolean?) -> Unit) {
    private val vehicleData = com.shilapi.xcertplay.vehicle.Hs5VehicleData.acquire(activity, this)
    private val main = Handler(Looper.getMainLooper())
    private val displayManager = activity.getSystemService(DisplayManager::class.java)
    private val night = HongqiNightModeSource(activity, onNight)
    private var controller: CarPlayController? = null
    private var sink: AndroidMediaSink? = null
    private var presentation: InstrumentPresentation? = null
    private var active = false
    private var clusterConfigured = false
    private var lanes: ClusterLaneGuidance? = null
    private val gesture = HongqiNavigationControls.Gesture()
    private var closed = false
    private val laneListener: (ClusterLaneGuidance?) -> Unit = { next ->
        main.post { if (!closed) { lanes=next; presentation?.laneView?.setGuidance(next) } }
    }
    private val displays = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(id: Int) { refreshPresentation() }
        override fun onDisplayChanged(id: Int) { refreshPresentation() }
        override fun onDisplayRemoved(id: Int) { if (presentation?.display?.displayId == id) closePresentation() }
    }
    private val authorizationPoll = object : Runnable {
        override fun run() { if (!closed) { refreshAuthorization(); main.postDelayed(this, 1000) } }
    }
    init {
        if (HongqiNavigation.supported()) {
            FawNavigationOutputs.setLaneOverlayListener(laneListener)
            displayManager.registerDisplayListener(displays, main)
            main.post(authorizationPoll)
        }
    }
    fun resume() { if (HongqiNavigation.supported()) { night.start(); HongqiWheelControls.onResume(activity); refreshPresentation() } }
    fun pause() { night.stop(); HongqiWheelControls.onPause(activity) }
    fun attach(controller: CarPlayController, sink: AndroidMediaSink, config: AirPlayConfig) {
        if (!HongqiNavigation.supported()) return
        clusterConfigured = config.cluster != null
        this.controller=controller
        if (this.sink !== sink) closePresentation()
        this.sink=sink
        HongqiWheelControls.attach(activity, controller)
        if (clusterConfigured) refreshPresentation() else closePresentation()
    }
    private fun licensedCluster() = Hs5ProductServices.featureAllowed(activity, com.shilapi.xcertplay.licensing.LicenseFeatures.INSTRUMENT_MAP)
    fun refreshAuthorization() {
        if (!licensedCluster()) closePresentation() else refreshPresentation()
    }
    fun screenState(type: Int, running: Boolean) {
        if (closed || type != 111 || !HongqiNavigation.supported()) return
        active=running
        presentation?.let { HongqiNavigation.streamActive(it, running) }
    }
    private fun refreshPresentation() {
        if (closed || !HongqiNavigation.supported() || !clusterConfigured || !licensedCluster() || sink == null) return
        val display=HongqiNavigation.findDisplay(activity) ?: run { closePresentation(); return }
        if (presentation?.display?.displayId == display.displayId) return
        closePresentation()
        val expected=sink ?: return
        try {
            InstrumentPresentation(activity, display, expected).also { presentation=it; it.show(); it.laneView?.setGuidance(lanes); HongqiNavigation.streamActive(it, active) }
        } catch (error: RuntimeException) { closePresentation(); android.util.Log.w("HS5-Display", "Instrument window unavailable: ${error.javaClass.simpleName}") }
    }
    private fun closePresentation() { presentation?.dismiss(); presentation=null }
    fun close() {
        if (closed) return
        closed = true
        vehicleData.close()
        night.stop()
        displayManager.unregisterDisplayListener(displays)
        FawNavigationOutputs.clearLaneOverlayListener(laneListener)
        closePresentation()
        // A retained controller keeps HUD and media alive while its Activity is absent.
        main.removeCallbacksAndMessages(null)
    }
    fun touch(event: MotionEvent): Boolean {
        if (!HongqiNavigation.supported() || !licensedCluster()) return false
        val action = gesture.accept(event, activity.resources.displayMetrics.density, HongqiNavigation.isNavigating())
        if (action == 1 || action == 2) {
            HongqiNavigation.setMapShown(activity, action == 1)
            if (action == 1) refreshPresentation()
        }
        return action != 0
    }

    private class InstrumentPresentation(context: android.content.Context, display: android.view.Display, private val sink: AndroidMediaSink) : Presentation(context, display) {
        private var output: Surface? = null
        private var video: VideoSurfaceView? = null
        var laneView: ClusterLaneGuidanceView? = null
        override fun onCreate(state: Bundle?) {
            super.onCreate(state)
            HongqiNavigation.preparePresentation(this)
            val root=FrameLayout(context)
            video=VideoSurfaceView(context, onSurface={ next ->
                output?.let { if(it !== next) sink.clearSurface(111,it) }
                output=next
                next?.let { sink.setSurface(111,it) }
            }).also { root.addView(it, FrameLayout.LayoutParams(-1,-1)) }
            laneView=ClusterLaneGuidanceView(context).also { root.addView(it, FrameLayout.LayoutParams(-1,-1)) }
            setContentView(root)
        }
        override fun dismiss() {
            video?.close(); output=null
            HongqiNavigation.presentationStopped(this)
            super.dismiss()
        }
    }
}
