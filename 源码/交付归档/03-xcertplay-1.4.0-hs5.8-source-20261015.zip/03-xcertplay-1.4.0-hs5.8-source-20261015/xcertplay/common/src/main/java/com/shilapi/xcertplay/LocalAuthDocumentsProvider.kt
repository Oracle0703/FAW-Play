// SPDX-License-Identifier: AGPL-3.0-only
package com.shilapi.xcertplay

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File
import java.io.FileNotFoundException

/** Read-only, unexported content URIs for identities provisioned into app-private storage. */
class LocalAuthDocumentsProvider : ContentProvider() {
    override fun onCreate() = true

    private fun document(uri: Uri): File {
        val app = requireNotNull(context)
        val name = uri.pathSegments.singleOrNull()
        if (uri.scheme != "content" || uri.authority != app.packageName + ".localauth" ||
            uri.query != null || uri.fragment != null || name !in DOCUMENTS
        ) throw FileNotFoundException("Unknown local authentication document")
        return File(File(app.noBackupFilesDir, "local-auth"), requireNotNull(name))
    }

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        if (mode != "r") throw FileNotFoundException("Local authentication documents are read-only")
        return ParcelFileDescriptor.open(document(uri), ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun query(
        uri: Uri, projection: Array<out String>?, selection: String?,
        selectionArgs: Array<out String>?, sortOrder: String?,
    ): Cursor {
        val file = document(uri)
        if (!file.isFile) throw FileNotFoundException("Local authentication document is not configured")
        val columns = projection ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        return MatrixCursor(columns).apply {
            addRow(columns.map { column ->
                when (column) {
                    OpenableColumns.DISPLAY_NAME -> file.name
                    OpenableColumns.SIZE -> file.length()
                    else -> null
                }
            })
        }
    }

    override fun getType(uri: Uri): String { document(uri); return "application/octet-stream" }
    override fun insert(uri: Uri, values: ContentValues?): Uri = throw UnsupportedOperationException("Read-only provider")
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int =
        throw UnsupportedOperationException("Read-only provider")
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int =
        throw UnsupportedOperationException("Read-only provider")

    companion object {
        private val DOCUMENTS = setOf("certificate.p7b", "identity.pk8")
    }
}
