package com.shilapi.xcertplay

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.AtomicFile
import androidx.core.content.FileProvider
import com.shilapi.xcertplay.licensing.DeviceActivation
import com.shilapi.xcertplay.licensing.LicenseDecision
import com.shilapi.xcertplay.licensing.LicensePackageSignature
import com.shilapi.xcertplay.licensing.ProductLicense
import com.shilapi.xcertplay.shared.BuildConfig
import com.shilapi.xcertplay.updates.Hs5UpdateConfiguration
import com.shilapi.xcertplay.updates.UpdateChannelNotPublishedException
import com.shilapi.xcertplay.updates.UpdateException
import com.shilapi.xcertplay.updates.UpdateManifest
import com.shilapi.xcertplay.updates.UpdateManifestVerifier
import com.shilapi.xcertplay.updates.UpdateTransport
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

enum class Hs5UpdateCheckStatus { AVAILABLE, UP_TO_DATE, NOT_CONFIGURED, CHANNEL_NOT_PUBLISHED, FAILED }
data class Hs5UpdateCheck(val status: Hs5UpdateCheckStatus, val message: String, val manifest: UpdateManifest? = null)

/** Blocking network methods run on the caller's worker. This is independent of MFi auth. */
object Hs5ProductServices {
    @JvmStatic fun basicCarPlayAllowed(): Boolean = true
    @JvmStatic fun licenseStatus(context: Context): LicenseDecision = ProductLicense.check(context)
    @JvmStatic fun refreshLicense(context: Context): LicenseDecision = ProductLicense.refresh(context)
    @JvmStatic fun featureAllowed(context: Context, feature: String): Boolean = ProductLicense.featureAllowed(context, feature)
    @JvmStatic fun beginBinding(context: Context): DeviceActivation = ProductLicense.beginActivation(context)
    @JvmStatic fun awaitBinding(context: Context, activation: DeviceActivation, cancelled: AtomicBoolean): LicenseDecision =
        ProductLicense.awaitActivation(context, activation, cancelled)
    @JvmStatic fun cancelBinding(context: Context, activation: DeviceActivation) = ProductLicense.cancelActivation(context, activation)

    @JvmStatic fun checkUpdate(context: Context): Hs5UpdateCheck {
        Hs5UpdateConfiguration.problem()?.let { return Hs5UpdateCheck(Hs5UpdateCheckStatus.NOT_CONFIGURED, it) }
        return try {
            verifyInstalledUpdateSigner(context)
            val manifest = UpdateTransport.fetch(context.packageName, BuildConfig.HS5_UPDATE_PUBLIC_KEY_SPKI,
                BuildConfig.HS5_UPDATE_SIGNING_CERT_SHA256)
            if (manifest.versionCode > currentVersion(context)) {
                Hs5UpdateCheck(Hs5UpdateCheckStatus.AVAILABLE, "发现新版本 ${manifest.versionName}。", manifest)
            } else Hs5UpdateCheck(Hs5UpdateCheckStatus.UP_TO_DATE, "当前已是最新版本。")
        } catch (e: UpdateChannelNotPublishedException) {
            Hs5UpdateCheck(Hs5UpdateCheckStatus.CHANNEL_NOT_PUBLISHED, e.message ?: "当前应用的更新渠道尚未发布。")
        } catch (e: UpdateException) {
            Hs5UpdateCheck(Hs5UpdateCheckStatus.FAILED, e.message ?: "更新检查未完成，请重试。")
        } catch (_: Exception) {
            Hs5UpdateCheck(Hs5UpdateCheckStatus.FAILED, "无法连接更新服务器，请检查网络后重试。")
        }
    }

    @JvmStatic fun downloadUpdate(context: Context, manifest: UpdateManifest, cancelled: AtomicBoolean,
        progress: (Long, Long) -> Unit): File {
        val verified = verifyManifest(context, manifest)
        requireCompatibleVersion(context, verified)
        val file = UpdateTransport.download(verified, directory(context), cancelled, progress)
        validateArchive(context, verified, file)
        val atomic = AtomicFile(File(directory(context), "manifest-envelope.json"))
        val output = atomic.startWrite()
        try {
            output.write(verified.envelope.toByteArray(Charsets.UTF_8))
            atomic.finishWrite(output)
        } catch (e: Exception) { atomic.failWrite(output); throw e }
        return file
    }

    @JvmStatic fun downloadedUpdate(context: Context): Pair<UpdateManifest, File>? = runCatching {
        val text = AtomicFile(File(directory(context), "manifest-envelope.json")).openRead().use { input ->
            val output = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(4096)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                if (count > UpdateManifestVerifier.MAX_ENVELOPE_BYTES - output.size()) {
                    throw UpdateException("更新信息超出大小限制。")
                }
                output.write(buffer, 0, count)
            }
            output.toString("UTF-8")
        }
        val verified = UpdateManifestVerifier.verify(text, BuildConfig.HS5_UPDATE_PUBLIC_KEY_SPKI,
            context.packageName, BuildConfig.HS5_UPDATE_SIGNING_CERT_SHA256)
        val file = File(directory(context), verified.sha256 + ".apk")
        validateArchive(context, verified, file)
        verified to file
    }.getOrNull()

    /** Caller starts this Intent only after connection is idle. Android owns installation consent. */
    @JvmStatic fun installUpdate(context: Context, manifest: UpdateManifest, file: File, sessionActive: Boolean): Intent {
        if (sessionActive) throw UpdateException("CarPlay 正在连接或运行，请断开连接后再安装更新。")
        validateArchive(context, manifest, file)
        if (!context.packageManager.canRequestPackageInstalls()) {
            throw UpdateException("系统尚未允许此应用安装更新包，请使用车机安装器安装已验证的更新包。")
        }
        val uri = FileProvider.getUriForFile(context, context.packageName + ".updates", file)
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            clipData = ClipData.newRawUri("HS5 更新包", uri)
        }
    }

    internal fun validateArchive(context: Context, manifest: UpdateManifest, file: File) {
        val verified = verifyManifest(context, manifest)
        requireCompatibleVersion(context, verified)
        if (file.canonicalFile != File(directory(context), verified.sha256 + ".apk").canonicalFile ||
            !UpdateTransport.matchesFile(file, verified)) throw UpdateException("本地更新包完整性校验失败，请重新下载。")
        @Suppress("DEPRECATION")
        val flags = PackageManager.GET_SIGNING_CERTIFICATES or PackageManager.GET_SIGNATURES
        val info = context.packageManager.getPackageArchiveInfo(file.absolutePath, flags)
            ?: throw UpdateException("无法读取更新包，请重新下载。")
        val app = info.applicationInfo ?: throw UpdateException("更新包缺少应用信息。")
        val signatures = info.signingInfo?.apkContentsSigners
        if (info.packageName != context.packageName || info.longVersionCode != verified.versionCode ||
            info.versionName != verified.versionName || app.minSdkVersion != verified.minSdk ||
            !LicensePackageSignature.matchesSingleSigner(signatures?.map { it.toByteArray() }?.toTypedArray() ?: emptyArray(),
                verified.signingCertSha256) || !info.splitNames.isNullOrEmpty()) {
            throw UpdateException("更新包的应用、版本或发布签名不匹配。")
        }
    }

    private fun verifyManifest(context: Context, supplied: UpdateManifest): UpdateManifest {
        Hs5UpdateConfiguration.problem()?.let { throw UpdateException(it) }
        verifyInstalledUpdateSigner(context)
        val verified = UpdateManifestVerifier.verify(supplied.envelope, BuildConfig.HS5_UPDATE_PUBLIC_KEY_SPKI,
            context.packageName, BuildConfig.HS5_UPDATE_SIGNING_CERT_SHA256)
        if (supplied != verified) throw UpdateException("更新信息与签名清单不一致。")
        return verified
    }

    private fun verifyInstalledUpdateSigner(context: Context) {
        val info = context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        val signatures = info.signingInfo?.apkContentsSigners?.map { it.toByteArray() }?.toTypedArray() ?: emptyArray()
        if (!LicensePackageSignature.matchesSingleSigner(signatures, BuildConfig.HS5_UPDATE_SIGNING_CERT_SHA256)) {
            throw UpdateException("当前安装包签名与 HS5 更新渠道不一致，请联系提供方。")
        }
    }

    private fun requireCompatibleVersion(context: Context, manifest: UpdateManifest) {
        if (manifest.versionCode <= currentVersion(context)) throw UpdateException("此更新包版本不高于当前版本。")
        if (manifest.minSdk > Build.VERSION.SDK_INT) throw UpdateException("新版本需要更高的 Android 系统，当前车机暂不支持。")
    }

    private fun currentVersion(context: Context): Long = context.packageManager.getPackageInfo(context.packageName, 0).longVersionCode
    private fun directory(context: Context) = File(context.cacheDir, "app-updates")
}
