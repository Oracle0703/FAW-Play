package com.shilapi.xcertplay;
import android.view.MotionEvent;
public final class HongqiNavigationControls {
    /** 0 passes through, 1 opens, 2 closes, 3 consumes the rest of an accepted gesture. */
    public static final class Gesture {
        private static final int FINGER_COUNT = 3;
        private static final float MIN_SWIPE_DP = 72;
        private static final float MIN_FINGER_SWIPE_DP = 36;
        private static final float HORIZONTAL_DOMINANCE = 1.3f;
        private boolean tracking, consumed, rejected;
        private final int[] ids = new int[FINGER_COUNT];
        private final float[] xs = new float[FINGER_COUNT], ys = new float[FINGER_COUNT];
        public int accept(MotionEvent event, float density) {
            return accept(event, density, true);
        }
        public int accept(MotionEvent event, float density, boolean navigating) {
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) { tracking = consumed = rejected = false; return 0; }
            if (consumed) {
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) consumed = false;
                return 3;
            }
            if (!navigating) { tracking = false; return 0; }
            // Extra fingers invalidate this whole sequence, including after they are lifted.
            if (event.getPointerCount() > FINGER_COUNT) { rejected = true; tracking = false; }
            if (rejected) return 0;
            if (action == MotionEvent.ACTION_POINTER_DOWN && event.getPointerCount() == FINGER_COUNT) {
                tracking = true;
                for (int i = 0; i < FINGER_COUNT; i++) {
                    ids[i] = event.getPointerId(i); xs[i] = event.getX(i); ys[i] = event.getY(i);
                }
                return 0;
            }
            if (event.getPointerCount() != FINGER_COUNT || action == MotionEvent.ACTION_POINTER_UP
                    || action == MotionEvent.ACTION_CANCEL || action == MotionEvent.ACTION_UP) {
                tracking = false; return 0;
            }
            if (!tracking || action != MotionEvent.ACTION_MOVE) return 0;
            float deltaX = 0, deltaY = 0;
            float[] moves = new float[FINGER_COUNT];
            for (int i = 0; i < FINGER_COUNT; i++) {
                int at = event.findPointerIndex(ids[i]);
                if (at < 0) { tracking = false; return 0; }
                moves[i] = event.getX(at) - xs[i];
                deltaX += moves[i]; deltaY += Math.abs(event.getY(at) - ys[i]);
            }
            deltaX /= FINGER_COUNT; deltaY /= FINGER_COUNT;
            if (Math.abs(deltaX) < MIN_SWIPE_DP * density
                    || Math.abs(deltaX) < deltaY * HORIZONTAL_DOMINANCE) return 0;
            float direction = Math.signum(deltaX);
            for (float move : moves) if (move * direction < MIN_FINGER_SWIPE_DP * density) return 0;
            consumed = true; tracking = false;
            return deltaX < 0 ? 1 : 2;
        }
    }
}
