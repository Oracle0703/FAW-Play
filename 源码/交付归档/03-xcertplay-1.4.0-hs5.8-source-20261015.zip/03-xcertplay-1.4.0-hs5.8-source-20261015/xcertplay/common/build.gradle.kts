plugins {
    id("com.android.library")
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.shilapi.xcertplay.host"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        minSdk = 28
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    testOptions { unitTests.isIncludeAndroidResources = true }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation("com.google.zxing:core:3.5.3")
    implementation("org.nanohttpd:nanohttpd:2.3.1")
    implementation("org.nanohttpd:nanohttpd-websocket:2.3.1")
    api(project(":shared"))
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    testImplementation(libs.junit)
    testImplementation("org.robolectric:robolectric:4.17")
    testImplementation("org.mockito:mockito-core:5.20.0")
}

// Only the user-approved accessory identity is bundled; all other private files stay excluded.
abstract class PrepareHs5IdentityAssets : org.gradle.api.DefaultTask() {
    @get:org.gradle.api.tasks.InputDirectory
    abstract val identityDirectory: org.gradle.api.file.DirectoryProperty
    @get:org.gradle.api.tasks.OutputDirectory
    abstract val outputDirectory: org.gradle.api.file.DirectoryProperty
    @org.gradle.api.tasks.TaskAction
    fun prepare() {
        val input = identityDirectory.get().asFile
        val output = outputDirectory.get().asFile.resolve("hs5-auth")
        val names = listOf("certificate.p7b", "identity.pk8")
        require(names.all { input.resolve(it).isFile }) { "HS5 accessory identity build inputs are missing" }
        output.mkdirs()
        names.forEach { input.resolve(it).copyTo(output.resolve(it), overwrite = true) }
    }
}
val hs5IdentityAssets = tasks.register<PrepareHs5IdentityAssets>("prepareHs5IdentityAssets") {
    identityDirectory.set(rootProject.layout.projectDirectory.dir(".private/local-auth"))
    outputDirectory.set(layout.buildDirectory.dir("generated/hs5IdentityAssets"))
}
androidComponents.onVariants { variant ->
    variant.sources.assets?.addGeneratedSourceDirectory(hs5IdentityAssets, PrepareHs5IdentityAssets::outputDirectory)
}
